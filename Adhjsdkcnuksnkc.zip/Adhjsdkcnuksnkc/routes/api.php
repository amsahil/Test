<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\WellifyController;
use App\Http\Controllers\ImageUploadController;

Route::post('/upload', [ImageUploadController::class, 'upload']);

Route::group([
    'middleware' => 'api',
    'prefix' => 'auth'
], function ($router) {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/auto-login', [AuthController::class, 'autoLogin']);
    Route::post('/reset-password', [AuthController::class, 'resetPass']);
    Route::get('/logout', [AuthController::class, 'logout'])->middleware('auth:api');
    Route::get('/refresh', [AuthController::class, 'refresh'])->middleware('auth:api');
    Route::get('/profile', [AuthController::class, 'profile'])->middleware('auth:api');
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
    Route::post('/verify-otp', [AuthController::class, 'verifyOtp']);
    Route::post('/reset-password', [AuthController::class, 'resetPassword']);
    Route::post('/change-password', [AuthController::class, 'changePassword'])->middleware('auth:api');
    Route::post('/update-user', [AuthController::class, 'updateUserProfile'])->middleware('auth:api');

    /**wellify */
    Route::get('/wellify-mood', [WellifyController::class, 'wellifyMood'])->middleware('auth:api');
    Route::get('/wellify-category', [WellifyController::class, 'getCategories'])->middleware('auth:api');
    Route::get('/wellify-timezones', [WellifyController::class, 'wellifyTimezones'])->middleware('auth:api');
    Route::get('/wellify-seeds', [WellifyController::class, 'wellifySeeds'])->middleware('auth:api');
});

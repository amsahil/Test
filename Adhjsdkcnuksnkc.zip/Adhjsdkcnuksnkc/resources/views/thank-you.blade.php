{{-- @extends('layouts.app') --}}
@extends('layouts.app')


@section('content')
<section class="d-flex align-items-center justify-content-center" style="min-height: 80vh;">
    <div class="text-center">
        <img src="{{ asset('assets/images/logo_collpased.svg') }}" alt="Success" width="120" class="mb-4">
        {{-- <h1 class="display-1">🎉</h1> --}}

        <h2 class="text-success fw-bold">Payment Successful</h2>
        <p class="mt-3 text-muted">Thank you for completing the setup fee payment.<br>
            Your account is now ready. Please wait while your credentials are verified by the system.
        </p>

        <a href="{{ url('/login') }}" class="btn btn-success mt-4 px-4" style="background-color: #52ab17; border-color: #52ab17;">
            Go to Login
        </a>
    </div>
</section>
@endsection

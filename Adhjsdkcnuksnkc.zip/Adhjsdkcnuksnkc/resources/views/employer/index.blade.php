@include('common.header')
@include('common.sidebar')
@yield('employee')
@yield('department')
@include('common.footer')
 
<script src="{{ asset('employer.js/employee_module.js') }}"></script>
<script>
    window.routes = {
        departmentsData: "{{ route('departments.getDepartments') }}",
        departmentsIndexUrl: "{{ route('departments.index') }}",
        employeesIndexUrl: "{{ route('staffs.index') }}",
        getunAssignedDepartmentsData: "{{ route('departments.getUnassignedDepartments') }}",
        employeesData: "{{ route('staffs.getStaffs') }}",
        inactiveEmployeesData: "{{ route('staffs.getDeletedStaffs') }}"
    };
</script>

</body>

</html>
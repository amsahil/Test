@include('superAdmin.auth.authCommon.meta')
<body>
    <div class="container-fluid login_body">
        <div class="row main-row w-100">
            <!-- Image with text section -->
            @include('superAdmin.auth.authCommon.banner')
            <!-- form section -->
            @yield('content')
        </div>
    </div>
    <script src="{{ asset('assets/js/script.js') }}"></script>
</body>

</html>

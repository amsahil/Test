<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wellify : Login</title>
    <link rel="shortcut icon" href="{{asset('assets/images/logo_collpased.svg')}}">
    <!-- Styles -->
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/responsive.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/custom.css') }}">
</head>

<body>
    <!-- Loader -->
    <div class="loader-overlay d-none" id="loader">
        <div class="spinner"></div>
    </div>

    <div class="container-fluid login_body">
        <div class="row main-row w-100">

            <!-- Left Side Image/Text -->
            <div class="col-xxl-5 col-xl-5 col-lg-6 col-md-12 login_banner h-100">
                <div class="glass_box col-xxl-10 col-xl-10 col-lg-10">
                    <div class="text-section">
                        <h1 class="text-center">Your Virtual Garden</h1>
                        <h5 class="text-center">Nurture your seeds by gently planting them,<br> and add a sprinkle of
                            water droplets to help them thrive</h5>
                    </div>
                </div>
            </div>

            <!-- Right Side: Login Form -->
            <div class="col-xxl-7 col-xl-7 col-lg-6 col-md-12 d-flex align-items-center justify-content-center h-100">
                <div class="form_login text-center col-xxl-6 col-xl-7 col-lg-10 col-md-8 col-12">
                    @php
                    $wellifyLogoUrl = Storage::disk('s3')->temporaryUrl(
                    'staging/public/wellify-logo.svg',
                    now()->addHour()
                    );
                    @endphp
                    <img src="{{ $wellifyLogoUrl }}" alt="Wellify Logo" class="logo-img text-center">
                    <h2 class="text-white">Welcome Back</h2>
                    <p class="login_subtitle mb_30">Welcome to Wellify, please login to continue.</p>

                    <!-- Validation & Error Messages -->
                    @if (session('error'))
                    <div class="alert alert-danger">{{ session('error') }}</div>
                    @endif

                    <!-- Login Form -->
                    <form method="POST" action="{{ route('login') }}">
                        @csrf

                        <!-- <div class="mb_30 position-relative {{ $errors->has('email') ? 'error_input' : '' }}">
                <select name="employer_id" id="employer_name" class="form-control input" >
                </select>
                <div class="invalid-feedback" id="employerFeedback"></div>
            </div> -->
                        <!-- Email -->
                        <div class="mb_30 position-relative {{ $errors->has('email') ? 'error_input' : '' }}">
                            <!-- <input type="email" name="email" class="form-control" id="loginEmail" placeholder="Email" > -->
                            <input type="email" name="email" class="form-control" id="loginEmail" placeholder="Email"
                                value="{{ old('email') }}">
                            <!-- @if ($errors->has('email'))
                    <span class="error_message" style="color: red; font-size: 0.9rem; margin-top: 5px;">
                      {{ $errors->first('email') }}
                    </span>
                  @endif -->
                            <div class="input_icons">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M8 12C8 13.0609 8.42143 14.0783 9.17157 14.8284C9.92172 15.5786 10.9391 16 12 16C13.0609 16 14.0783 15.5786 14.8284 14.8284C15.5786 14.0783 16 13.0609 16 12C16 10.9391 15.5786 9.92172 14.8284 9.17157C14.0783 8.42143 13.0609 8 12 8C10.9391 8 9.92172 8.42143 9.17157 9.17157C8.42143 9.92172 8 10.9391 8 12Z"
                                        stroke="#999999" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                    <path
                                        d="M16 11.9998V13.4998C16 14.1629 16.2634 14.7988 16.7322 15.2676C17.2011 15.7365 17.837 15.9998 18.5 15.9998C19.163 15.9998 19.7989 15.7365 20.2678 15.2676C20.7366 14.7988 21 14.1629 21 13.4998V11.9998C21.0025 10.0659 20.382 8.18269 19.2304 6.62904C18.0788 5.07539 16.4574 3.934 14.6064 3.37395C12.7554 2.81389 10.7732 2.86497 8.95343 3.51961C7.13371 4.17425 5.57324 5.39763 4.50321 7.00852C3.43317 8.61942 2.91047 10.5321 3.01255 12.4633C3.11463 14.3945 3.83605 16.2415 5.06995 17.7306C6.30385 19.2197 7.98459 20.2718 9.86319 20.7309C11.7418 21.1901 13.7183 21.0319 15.5 20.2798"
                                        stroke="#999999" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>

                            </div>
                            <!-- @error('email')
                <p class="validation_text">{{ $message }}</p>
             @enderror -->
                        </div>

                        <!-- @php
              $error = Session::has("error_class") ? "error_input" : '';
            @endphp -->
                        <!-- Password -->
                        <!-- <div class="mb-3 position-relative"> -->
                        <div class="mb-3">
                            <div class="position-relative {{ $errors->has('password') ? 'error_input' : '' }}">
                                <!-- <input type="password" name="password" class="form-control" id="loginPassword" placeholder="Password"> -->
                                <input type="password" name="password" class="form-control" id="loginPassword"
                                    placeholder="Password">
                                <div class="input_icons">
                                    <svg width="24" height="25" viewBox="0 0 24 25" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M8 10.5V7.5C8 5.29 9.79 3.5 12 3.5C14.21 3.5 16 5.29 16 7.5V10.5M12 15.5C12.2652 15.5 12.5196 15.3946 12.7071 15.2071C12.8946 15.0196 13 14.7652 13 14.5C13 14.2348 12.8946 13.9804 12.7071 13.7929C12.5196 13.6054 12.2652 13.5 12 13.5C11.7348 13.5 11.4804 13.6054 11.2929 13.7929C11.1054 13.9804 11 14.2348 11 14.5C11 14.7652 11.1054 15.0196 11.2929 15.2071C11.4804 15.3946 11.7348 15.5 12 15.5ZM12 15.5V18.5M6.6 10.5H17.4C18.28 10.5 19 11.22 19 12.1V19.1C19 20.42 17.92 21.5 16.6 21.5H7.4C6.08 21.5 5 20.42 5 19.1V12.1C5 11.22 5.72 10.5 6.6 10.5Z"
                                            stroke="#999999" stroke-width="2" stroke-miterlimit="10"
                                            stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </div>
                                <div class="input_icons view_password">
                                    <span>
                                        @php
                                        $eyeImageUrl = Storage::disk('s3')->temporaryUrl(
                                        'staging/public/eye_view.svg',
                                        now()->addHour() // Link expires in 1 hour
                                        );
                                        @endphp
                                        <img src="{{ $eyeImageUrl }}" alt="Show" id="eye_view">
                                        @php
                                        $eyeSlashImageUrl = Storage::disk('s3')->temporaryUrl(
                                        'staging/public/eye_slash.svg',
                                        now()->addHour() // Link expires in 1 hour
                                        );
                                        @endphp
                                        <img src="{{ $eyeSlashImageUrl }}" alt="Hide" id="eye_slash" class="d-none">
                                    </span>
                                </div>
                            </div>
                            <!-- @error('password')
                  <p class="validation_text">{{ $message }}</p>
              @enderror -->
                            <!-- @if ($errors->any())
              @foreach ($errors->all() as $error)
              <p class="validation_text mb-0 ">
                {{ $error }}
              </p>
              @endforeach
              @endif -->
                        </div>
                        <!-- Remember + Forgot -->
                        <div class="mb_30 form-check d-flex justify-content-between align-items-center ps-0">
                            <span class="d-flex align-items-center gap-2">
                                <input type="checkbox" id="remember-me" name="remember">
                                <!-- <input type="checkbox" id="remember-me" name="remember" value="1" {{ old('remember') ? 'checked' : '' }}> -->
                                <label for="remember-me">Remember Me</label>
                            </span>
                            <a href="{{ route('forgot.password') }}">Forgot Password?</a>
                        </div>

                        <!-- Submit -->
                        <div class="d-grid gap-2">
                            <button class="button primary_btn" type="submit">Sign In</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    $(document).ready(function() {
        $.ajax({
            url: "{{ route('login') }}",
            type: "GET",
            dataType: "json",
            success: function(response) {
                let $select = $('#employer_name');
                $select.empty();

                if (response.length > 0) {
                    $.each(response, function(index, role) {
                        const selected = index === 0 ? 'selected' : '';
                        $select.append(
                            `<option value="${role.name}" ${selected}>${role.name}</option>`
                        );
                    });
                } else {
                    $select.append('<option value="">No roles available</option>');
                }
            },
            error: function(xhr) {
                console.error('Error fetching roles:', xhr.responseText);
                $('#employerFeedback').text('Failed to load roles.').show();
            }
        });
    });
    </script>

    <!-- Scripts -->
    <script src="{{ asset('assets/js/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/js/bootstrap.bundle.js') }}"></script>
    <script src="{{ asset('assets/js/script.js') }}"></script>
</body>

</html>
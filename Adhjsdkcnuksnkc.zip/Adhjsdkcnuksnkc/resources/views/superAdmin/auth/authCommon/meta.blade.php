<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wellify : @yield('title', 'page')</title>
    $logoUrl = Storage::disk('s3')->temporaryUrl(
    'staging/public/logo_collpased.svg',
    now()->addHour()
    );
    <link rel="shortcut icon" href="{{ $logoUrl )}}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/all.min.css">

</head>
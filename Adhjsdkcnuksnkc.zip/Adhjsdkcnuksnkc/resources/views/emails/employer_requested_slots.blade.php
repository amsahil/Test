<!DOCTYPE html>
<html>

<head>
    <title>Request for Additional Slots</title>
</head>

<body>
    <h3>Employer Requested Additional Slots</h3>
    <p><strong>Employer Name:</strong> {{ $employer->first_name }} {{ $employer->last_name }}</p>
    <p><strong>Email:</strong> {{ $employer->email }}</p>
    <p><strong>Requested Additional Slots:</strong> {{ $requestedSlots }}</p>
    <p>Please review this request and update the employer's slots in the admin panel if appropriate.</p>
</body>

</html>
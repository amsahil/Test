<p>Hello {{ $employer->first_name }},</p>

<p>You have requested additional slots for your program.</p>

<p>Amount Due: <strong>${{ $amount }} USD</strong></p>

<p>Please complete your payment by clicking the button below:</p>

<a href="{{ $paymentLink }}" style="padding: 10px 20px; background-color: #007bff; color: #fff; text-decoration: none;">
    Pay Now
</a>

<p>Thank you for your continued trust in our platform.</p>

<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
    xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="x-apple-disable-message-reformatting">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <title>One Time Payment Mail</title>

    <style type="text/css">
    * {
        margin: 0;
        padding: 0;
    }

    .logo {
        max-width: 180px;
    }

    .footer_link {
        padding: 10px 30px;
    }

    .footer_link a {
        padding: 10px 15px;
        font-size: 14px;
    }

    p {
        margin-bottom: 1rem;
    }

    @media (max-width:600px) {
        .logo {
            max-width: 150px;
        }

        .footer_link {
            padding: 5px;
        }

        .footer_link a {
            padding: 5px;
            font-size: 12px;
        }
    }
    </style>
</head>

<body style="margin: 0;padding: 0;background-color: #ffffff;color: #000000;font-family: 'Poppins', sans-serif;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0"
        style="max-width:600px; margin: auto; box-shadow: 0 0 5px #00000030;">
        <tbody>
            <tr>
                <td style="background-color: #073029;text-align: center;padding:1rem;">
                    <img src="{{ asset('assets/images/wellify-logo.svg') }}" alt="Wellify Logo" class="logo"
                        style="max-width: 180px; width: 100%; height: auto; display: block; margin: auto;">
                </td>
            </tr>
            <tr>
                <td>
                    <img src="{{ asset('assets/images/email.svg') }}" alt="Wellify Logo" class="logo"
                        style="max-width: 180px; width: 100%; height: auto; display: block; margin: auto;">
                </td>
            </tr>
            <tr>
                <td style="background-color: #fff;text-align: center;padding:1rem;">
                    <h2 style="margin: 20px 0 0 0; color: #161616; font-size: 26px; font-weight: 600;">Welcome to
                        Wellify!</h2>
                </td>
            </tr>
            <tr>
                <td style="padding: 1rem;">
                    <p style="color: #161616;">Hi <span class="non-editable" style="color:#52ab17;">
                            <b>{{ $user->first_name }}</b></span>,</p>
                    <p style="color: #161616; margin-bottom:10px;">Please complete your one-time setup fee of <strong
                            style="color: #007bff">${{ number_format($fee, 2) }}</strong> to activate your account.</p>

                    <p style="text-align: center">
                        <a href="{{ $url }}"
                            style="padding: 10px 30px; background: #52ab17; color: #fff; text-decoration: none; border-radius: 30px; font-size:14px;">
                            Pay Now
                        </a>
                    </p>
                    <p style="color: #161616;">
                        Your program period will last <strong>{{ $programDays }} days</strong> and you may onboard up to
                        <strong>{{ $user->number_of_users }}</strong> employees after payment.
                    </p>



                    <p style="margin-bottom: 1rem; font-weight:400; font-size:14px; margin-top:30px;">Once your payment
                        is confirmed, your account will be activated and you will receive your login credentials.</p>
                </td>
            </tr>
            <tr>
                <td style="background-color: #104038; text-align: center; padding: 10px;" class="footer_link">
                    <div style="text-align:center; padding: 10px;">
                        <a href="#" style="color: #ddd; text-decoration: none; margin: 0 10px;">FAQs</a>
                        <span style="color:#fff;"> | </span>
                        <a href="#" style="color: #ddd; text-decoration: none; margin: 0 10px;">Terms &amp;
                            Condition</a>
                        <span style="color:#fff;"> | </span>
                        <a href="#" style="color: #ddd; text-decoration: none; margin: 0 10px;">Contact Us</a>
                    </div>
                    <hr style="border-top: 1px solid #b4b4b4; margin: 10px 0;">
                    <div style="display: flex; justify-content: center; gap: 15px;">
                        <img src="{{ asset('assets/images/twitter.png') }}" alt="Twitter"
                            style="max-width: 40px; height: auto;">
                        <img src="{{ asset('assets/images/Linkedin.png') }}" alt="LinkedIn"
                            style="max-width: 40px; height: auto;">
                        <img src="{{ asset('assets/images/instagram.png') }}" alt="Instagram"
                            style="max-width: 40px; height: auto;">
                    </div>
                </td>
            </tr>

            <tr>
                <td style="background-color: #104038; color: #a3b2c3; text-align: center; padding: 10px 0;">
                    <p style="margin: 0; color: #a3b2c3;font-size: 14px;">Copyright &copy; {{ date('Y') }} <a href="#"
                            style="color: #a3b2c3;">Wellify</a> | All rights reserved</p>
                </td>
            </tr>
        </tbody>
    </table>
</body>
{{-- <p>Hi {{ $user->first_name }},</p>

<p>Welcome! Please complete your one-time setup fee of <strong>$500</strong> to activate your account.</p>

<p>
    <a href="{{ $url }}" style="padding: 10px 20px; background: #007bff; color: #fff; text-decoration: none;">
        Pay Now
    </a>
</p>

<p>Once your payment is confirmed, your account will be activated and you will receive your login credentials.</p>

<p>Thank you,<br>Team</p> --}}

</html>
@extends('layouts.app')
@include('common.header')
@include('common.sidebar')

    <!-- Datatable to Show Classes List-->
    <section class="main_card">
        <nav>
            <div class="nav nav-tabs d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block justify-content-between" id="nav-tab" role="tablist">
                <div class="tabs_buttons d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">
                    <button class="nav-link active mb-xxl-0 mb-xl-0  mb-lg-0 mb-md-0 mb-2" id="nav-home-tab" data-bs-toggle="tab"
                        data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home"
                        aria-selected="true">Active Activities</button>
                    <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab"
                        data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile"
                        aria-selected="false">Deleted Activities</button>
                </div>
            </div>
        </nav>

         <div class="tab-content" id="nav-tabContent">
            <!-- Active Activities Tab -->
            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"
                tabindex="0">
                <div class="container-fluid">
                    <div class="row">
                        <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                            <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Manage Activities</h5>
                            <button class="button primary_btn" type="button" data-bs-toggle="modal"
                                data-bs-target="#add_new">
                                Add New
                            </button>
                        </div>
                    </div>
                    <div class="row pt_24">
                        <div class="col-12">
                            <table id="activitiesTable" class="table table-striped datatable">
                                <thead>
                                    <tr>
                                        <th scope="col"></th>
                                        <th scope="col">ID</th>
                                        <th scope="col">Activity Name</th>
                                        {{-- <th scope="col">Prerequisite Class</th> --}}
                                        <th scope="col">Associated Moods</th>
                                        <th scope="col">Points</th>
                                        <th scope="col">Water Droplet</th>
                                        <th scope="col">Images</th>
                                        <th scope="col">Activity Media</th>
                                        <th scope="col">Level ID</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0">
                <div class="container-fluid">
                    <div class="row">
                        <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                            <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Deleted Activities</h5>
                            <div class="button_group d-flex gap-3">
                            <button class="button secondary_btn" type="button" data-bs-target="#bulk_restore_user"
                                data-bs-toggle="modal" id="bulkRestoreButton">
                                Restore
                            </button>
                        </div>
                        </div>
                    </div>
                    <div class="row pt_24">
                        <div class="col-12">
                            <table id="inactiveActivitiesTable" class="table table-striped datatable">
                                <thead>
                                    <tr>
                                        <th scope="col"><input type="checkbox" id="selectAllRestore"></th>
                                        <th scope="col"></th>
                                        <th scope="col">ID</th>
                                        <th scope="col">Activity Name</th>
                                        <th scope="col">Associated Moods</th>
                                        {{-- <th scope="col">Prerequisite Class</th> --}}
                                        <th scope="col">Points</th>
                                        <th scope="col">Water Droplet</th>
                                        {{-- <th scope="col">Images</th> --}}
                                        {{-- <th scope="col">Activity Media</th> --}}
                                        <th scope="col">Level ID</th>
                                        {{-- <th scope="col">Status</th> --}}
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- Modal Add Activity -->
    <div class="modal fade" id="add_new" data-bs-keyboard="false" tabindex="-1" aria-labelledby="add_newLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="add_newLabel">Add New Activity</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="createActivityForm" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">
                        <div class="container-fluid p-0">
                            <div class="row">
                                <!-- Activity ID -->
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="activity_id" class="form-label">Activity ID</label>
                                    <input type="text" class="form-control input" name="activity_id" id="activity_id" placeholder="Enter Activity ID" required>
                                </div>

                                <!-- Activity Name -->
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="title" class="form-label">Activity Name</label>
                                    <input type="text" class="form-control input" name="title" id="title" placeholder="Enter Activity name" required>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label class="form-label">Select Moods<span class="text-danger">*</span></label>
                                    <select name="mood_id[]" id="choices-multiple-remove-button" class="form-select form-control input" placeholder="Select moods" multiple tabindex="-1">
                                        @foreach ($moods as $mood)
                                            <option value="{{ $mood->id }}">{{ $mood->title }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <!-- Prerequisite Classes -->
                                {{-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="prerequisite_class" class="form-label">Prerequisite Class</label>
                                    <select name="prerequisite_class[]" id="choices-multiple-remove-button" class="form-select form-control input" multiple="multiple">
                                        @foreach($classes as $class)
                                            <option value="{{ $class->id }}">{{ $class->title }}</option>
                                        @endforeach
                                    </select>
                                </div> --}}

                                <!-- Points -->
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="points_on_completion" class="form-label">Points</label>
                                    <input type="number" class="form-control input" name="points_on_completion" id="points_on_completion" placeholder="Enter points" min="0">
                                </div>

                                <!-- Water Droplet -->
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="water_on_completion" class="form-label">Water Droplet</label>
                                    <input type="number" class="form-control input" name="water_on_completion" id="water_on_completion" placeholder="Enter water droplets" min="0">
                                </div>

                                <!-- Category -->
                                {{-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="activity_category_id" class="form-label">Category</label>
                                    <select name="activity_category_id" id="activity_category_id" class="form-select form-control input" required>
                                        <option value="">Select Category</option>
                                        @foreach($categories as $id => $title)
                                            <option value="{{ $id }}">{{ $title }}</option>
                                        @endforeach
                                    </select>
                                </div> --}}

                                <!-- Level -->
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="level_id" class="form-label">Level</label>
                                    <select name="level_id" id="level_id" class="form-select form-control input">
                                        <option value="">Select Level</option>
                                        @foreach($levels as $level)
                                            <option value="{{ $level->id }}">{{ $level->title }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <!-- Thumbnail Image (SVG only) -->
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="background_image" class="form-label">Thumbnail Image</label>
                                    <input type="file" class="form-control input" name="background_image" id="background_image" accept=".svg" required>
                                    <small class="text-muted">Only SVG files are allowed</small>
                                </div>

                                <!-- Associated Moods -->
                                {{-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="mood_id" class="form-label">Associated Moods</label>
                                    <select name="mood_id[]" id="mood_id" class="form-select form-control input" multiple="multiple">
                                        @foreach($moods as $mood)
                                            <option value="{{ $mood->id }}">{{ $mood->title }}</option>
                                        @endforeach
                                    </select>
                                </div> --}}

                                <!-- Description -->
                                <div class="col-12 mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control input rounded-3" name="description" placeholder="Enter Description" id="description" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="button primary_btn m-0">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Show Activity -->
    <div class="modal fade" id="view_user" data-bs-keyboard="false" tabindex="-1" aria-labelledby="view_userLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="view_userLabel">View Activity</h3>
                    <button type="button" class="btn-close " data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid p-0">
                        <div class="row">
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label mb-1">Activity ID</label>
                                <p class="mb-0" id="view_activity_id"></p>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label mb-1">Activity Name</label>
                                <p class="mb-0" id="view_activity_name"></p>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                               <label class="form-label mb-1">Points</label>
                               <p class="mb-0" id="view_points"></p>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                               <label class="form-label mb-1">Water Droplet</label>
                               <p class="mb-0" id="view_water_droplets"></p>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                               <label class="form-label mb-1">Level</label>
                               <p class="mb-0" id="view_level"></p>
                            </div>
                            <div class="col-12 mb-3">
                                        <label class="form-label mb-1">Associated Moods</label>
                                        <div class="d-flex gap-2 flex-wrap" id="view_moods">
                                            <!-- Moods will be appended here -->
                                    </div>
                                </div>
                            <div class="col-12">
                                <label class="form-label mb-1">Description</label>
                                <p id="view_description"></p>
                            </div>
                            <div class="col-md-6 mb-3" id="media_count_container" style="display: none;">
                                <div class="alert alert-success d-flex align-items-center" role="alert">
                                    <span>
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M16.24 3.5H7.73999C6.41391 3.5 5.14214 4.02678 4.20446 4.96447C3.26677 5.90215 2.73999 7.17392 2.73999 8.5V15.5C2.73999 16.1566 2.86932 16.8068 3.12059 17.4134C3.37187 18.02 3.74016 18.5712 4.20446 19.0355C5.14214 19.9732 6.41391 20.5 7.73999 20.5H16.24C16.8966 20.5 17.5468 20.3707 18.1534 20.1194C18.76 19.8681 19.3112 19.4998 19.7755 19.0355C20.2398 18.5712 20.6081 18.02 20.8594 17.4134C21.1107 16.8068 21.24 16.1566 21.24 15.5V8.5C21.24 7.84339 21.1107 7.19321 20.8594 6.58658C20.6081 5.97995 20.2398 5.42876 19.7755 4.96447C19.3112 4.50017 18.76 4.13188 18.1534 3.8806C17.5468 3.62933 16.8966 3.5 16.24 3.5Z"
                                                stroke="#0a3622" stroke-width="1.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path
                                                d="M2.98999 17L5.73999 13.8C6.09983 13.4426 6.5721 13.2205 7.07687 13.1713C7.58164 13.1221 8.08791 13.2488 8.50999 13.53C8.93207 13.8112 9.43834 13.9379 9.94311 13.8887C10.4479 13.8395 10.9201 13.6174 11.28 13.26L13.61 10.93C14.2795 10.2582 15.1659 9.8462 16.111 9.76744C17.0562 9.68868 17.9985 9.94831 18.77 10.5L21.26 12.43M7.98999 10.17C8.20798 10.17 8.42384 10.1271 8.62525 10.0436C8.82665 9.96022 9.00964 9.83794 9.16379 9.6838C9.31793 9.52965 9.44021 9.34665 9.52363 9.14525C9.60705 8.94385 9.64999 8.72799 9.64999 8.51C9.64999 8.292 9.60705 8.07614 9.52363 7.87474C9.44021 7.67334 9.31793 7.49035 9.16379 7.3362C9.00964 7.18206 8.82665 7.05978 8.62525 6.97636C8.42384 6.89294 8.20798 6.85 7.98999 6.85C7.54973 6.85 7.1275 7.02489 6.81619 7.3362C6.50488 7.64751 6.32999 8.06974 6.32999 8.51C6.32999 8.95026 6.50488 9.37249 6.81619 9.6838C7.1275 9.99511 7.54973 10.17 7.98999 10.17Z"
                                                stroke="#0a3622" stroke-width="1.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>
                                    </span>
                                    <span class="ms-3" id="view_image_count_text"></span>
                                </div>
                            </div>

                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                    <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                        tabindex="-1">Close</button>
                </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Edit Activity Modal -->
    <div class="modal fade" id="edit_activity" tabindex="-1" aria-labelledby="editActivityLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <form id="edit_activity_form" enctype="multipart/form-data">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title fs-5">Edit Activity</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <input type="hidden" name="id" id="edit_id">

                        <div class="row">
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Activity ID</label>
                                <input type="text" class="form-control input" id="edit_activity_id" name="activity_id" readonly style="background-color: #f0f0f0; color: #6c757d; cursor: not-allowed;">
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Activity Name</label>
                                <input type="text" class="form-control input" id="edit_title" name="title" required>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="edit_moods" class="form-label">Select Moods</label>
                                <select id="edit_moods" class="form-select form-control input" name="mood_id[]" multiple>
                                    @foreach($moods as $mood)
                                        <option value="{{ $mood->id }}">{{ $mood->title }}</option>
                                    @endforeach
                                </select>
                            </div>

                            {{-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="prerequisite_class" class="form-label">Prerequisite Class</label>
                                <select name="prerequisite_class[]" id="choices-multiple-remove-button" class="form-select form-control input" multiple="multiple">
                                    @foreach($classes as $class)
                                        <option value="{{ $class->id }}">{{ $class->title }}</option>
                                    @endforeach
                                </select>
                            </div> --}}

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Points</label>
                                <input type="number" name="points_on_completion" class="form-control input" id="edit_points">
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Water Droplet</label>
                                <input type="number" name="water_on_completion" class="form-control input" id="edit_water">
                            </div>

                            {{-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="activity_category_id" class="form-label">Category</label>
                                <select name="activity_category_id" id="edit_category" class="form-select form-control input" required>
                                    <option value="">Select Category</option>
                                    @foreach($categories as $id => $title)
                                        <option value="{{ $id }}">{{ $title }}</option>
                                    @endforeach
                                </select>
                            </div> --}}

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="level_id" class="form-label">Level</label>
                                <select name="level_id" id="edit_level" class="form-select form-control input">
                                    <option value="">Select Level</option>
                                    @foreach($levels as $level)
                                        <option value="{{ $level->id }}">{{ $level->title }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Thumbnail Image  </label>
                                <input type="file" name="background_image" class="form-control input" accept=".svg">
                                <small class="text-muted">Only SVG files are allowed</small>
                            </div>

                            <div class="col-12 mb-3">
                                <label class="form-label">Description</label>
                                <textarea class="form-control input rounded-3" name="description" id="edit_description" rows='3'></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="button primary_btn m-0">Update</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Delete Activity -->
    <div class="modal fade" id="delete_class_modal" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete_userLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body delete">
                    <div class="container-fluid px-0 py-3">
                        <div class="row">
                            <div class="col-12 text-center">
                                   @php
                                $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/warning.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{ $warningImageUrl }}" alt="warning icon" class="img-fluid">
                                <h4 class="mt-4 text-danger">Delete This Activity?</h4>
                                <p class="mt-3 line_height_30">This Activity will move to recently deleted<br>Are you sure you want to continue?</p>
                                <input type="hidden" id="delete_class_id">
                            </div>
                            <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button>
                                <button class="button primary_btn m-0 warning_button" type="button" id="confirm_delete_class">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Images Modal -->
    <div class="modal fade" id="addimagesModal" tabindex="-1" aria-labelledby="addImagesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5">Add Activity Images</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <form id="uploadImageForm" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="activity_id" id="uploadActivityId">

                        <div class="container-fluid p-0" id="addImages_main">
                            <div class="row align-items-center add_newrow">
                                <div class="col-xxl-5 mb-3">
                                    <div class="uploader">
                                        <input type="file" name="media[]"  accept=".svg" class="file-upload d-none"  required>
                                        <label class="py-2 px-3 d-flex image_label rounded-3 file-label cursor-pointer">
                                            <img class="file-image d-none" src="#" alt="Preview" />
                                            <span class="start text-center w-100">
                                                <span class="d-block">Select a file</span>
                                                <span class="btn btn-success my-2">Select a file</span>
                                            </span>
                                        </label>
                                    </div>
                                </div>

                                <div class="col-xxl-5 mb-3">
                                    <textarea name="description[]" class="form-control input rounded-3 desc-field" placeholder="Enter Description" rows="3" maxlength="255" required></textarea>
                                </div>

                               <div class="col-xxl-2 mb-3 text-center">
                                @php
                                $addImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/Add_icon.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{$addImageUrl }}" alt="add icon"
                                    class="img-fluid add-more me-2" style="cursor:pointer; width: 28px; height: 28px;" title="Add new row">
                                @php
                                $deleteImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/Delete_icon.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{ $deleteImageUrl }}" alt="delete icon"
                                    class="img-fluid remove-row" style="cursor:pointer; width: 28px; height: 28px;" title="Remove this row">
                            </div>
                            </div>
                        </div>

                        <!-- Spinner -->
                        <div id="uploadLoader" class="text-center my-3" style="display: none;">
                            <div class="spinner-border text-success" role="status"></div>
                        </div>

                        <div class="modal-footer gap-3">
                            <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="button primary_btn m-0">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<script src="assets/js/choice.js"></script>
<script>
    $(document).ready(function () {
     var multipleCancelButton = new Choices('#choices-multiple-remove-button, #choices-multiple-remove-button2' , {
         removeItemButton: true,
        //  searchResultLimit: 5,
        //  renderChoiceLimit: 5
        });
    });
</script>

<script>
    $(document).ready(function() {
    // Initialize main activities table
    var activitiesTable = $('#activitiesTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: '{{ route('wellify_activities.activities.data') }}',
        columns: [
            { data: 'dummy', orderable: false, searchable: false },
            { data: 'activity_id', name: 'activity_id' },
            { data: 'title' },
            // { data: 'prerequisite_class' },
            { data: 'associated_moods' },
            { data: 'points_on_completion' },
            { data: 'water_on_completion' },
            { data: 'media_status' },
            { data: 'activities_images' },
            { data: 'level_id' },
            { data: 'class_status' },
            { data: 'actions', orderable: false, searchable: false }
        ],
        responsive: false,
        pageLength: 10,
        paging: true,
        scrollCollapse: true,
        scrollX: true,
        order: [[1, 'desc']] // Changed to use column index 1 (activity_id)
    });

    // Initialize deleted activities table

    $('#inactiveActivitiesTable').DataTable({

        processing: true,
        serverSide: true,
        ajax: {
            url: '/wellify-activities/deleted',
            type: 'GET'
        },
        columns: [
            {
                data: 'checkbox',
                name: 'checkbox',
                orderable: false,
                searchable: false,
                render: function(data, type, row) {
                    console.log(row,'hiiiii');
                    return '<input type="checkbox" class="restore-checkbox" value="'+row.activity_id+'">';
                }
            },
            { data: 'dummy', orderable: false, searchable: false },
            { data: 'activity_id', name: 'activity_id' },
            { data: 'title' },
            // { data: 'prerequisite_class' },
            { data: 'associated_moods' },
            { data: 'points_on_completion' },
            { data: 'water_on_completion' },
            // { data: 'media_status' },
            // { data: 'activities_images' },
            { data: 'level_id' },
            // { data: 'class_status' },
            {
                data: 'actions',
                name: 'actions',
                orderable: false,
                searchable: false,
                render: function(data, type, row) {
                    return '<span class="btn-restore" title="Restore" data-id="'+row.activity_id+'" data-bs-toggle="modal" data-bs-target="#restore_user"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.00003 3.723C6.75838 4.23409 4.7972 5.58344 3.51867 7.49436C2.24014 9.40527 1.74116 11.7329 2.12403 14M9.00003 3.723L6.00003 2.5M9.00003 3.723L8.00003 6.5M19.064 16.5C19.6816 15.2571 20.002 13.8878 20 12.5C20 8.04 16.757 4.339 12.5 3.624M19.064 16.5L22 14.5M19.064 16.5L17.5 13.5M3.51603 17.5C4.33773 18.7314 5.45079 19.7408 6.75638 20.4386C8.06196 21.1364 9.51967 21.501 11 21.5C13.2144 21.5028 15.3515 20.6864 17 19.208M3.51603 17.5H7.00003M3.51603 17.5V21" stroke="#007C00" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg> </span>';
                }



            }
        ],
        responsive: true,
        order: [[2, 'desc']] // Changed to use column index 2 (activity_id)
    });

        // Update media_status dropdown
    $(document).on('change', '.image_status_select', function () {
        let activityId = $(this).data('id');
        let status = $(this).val();

        $.ajax({
            url: '/wellify-activities/update-media-status',
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                activity_id: activityId,
                media_status: status
            },
            success: function (res) {
                console.log('Response', res)
                if(res.success) {
                    location.reload();
                }
            },
            error: function (xhr) {
                console.log('Error', xhr.responseJSON);
                toastr.error('Failed to update media status');
            }
        });
    });

    $(document).on('change', '.toggle-status', function() {
        let activityId = $(this).data('activity-id');
        let status = $(this).is(':checked') ? 1 : 0;
        let checkbox = $(this);

        $.ajax({
            url: '/wellify-activities/update-status',
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                activity_id: activityId,
                status: status
            },
            beforeSend: function() {
                checkbox.prop('disabled', true);
            },
            success: function(response) {
                if(response.success) {
                   location.reload();
                }
            },
            error: function(xhr) {
                toastr.error('Failed to update status');
                // Revert the checkbox if error occurs
                checkbox.prop('checked', !checkbox.is(':checked'));
            },
            complete: function() {
                checkbox.prop('disabled', false);
            }
        });
    });

    $(document).on('click', '.delete_icon1', function(e) {
        e.preventDefault();
        let activityId = $(this).data('id');
        $('#delete_class_id').val(activityId);
        $('#delete_class_modal').modal('show');
    });

    // When confirm delete button is clicked
    $(document).on('click', '#confirm_delete_class', function() {
        let activityId = $('#delete_class_id').val();
        let $row = $('.delete_icon1[data-id="' + activityId + '"]').closest('tr');

        $.ajax({
            url: `/wellify-activities/${activityId}`,
            type: 'DELETE',
            data: {
                _token: '{{ csrf_token() }}'
            },
            beforeSend: function() {
                $('#confirm_delete_class').prop('disabled', true);
            },
            success: function(response) {
                if(response.success) {
                    location.reload()
                    toastr.success(response.message);
                    $('#delete_class_modal').modal('hide');

                    // Remove the row or reload DataTable
                    if ($.fn.DataTable.isDataTable('#activitiesTable')) {

                        location.reload();
                    } else {
                        $row.fadeOut(300, function() {
                            $(this).remove();
                        });
                    }
                }
            },
            error: function(xhr) {
                toastr.error(xhr.responseJSON?.message || 'Failed to delete activity');
            },
            complete: function() {
                $('#confirm_delete_class').prop('disabled', false).text('Delete');
            }
        });
    });

    // Restore single activity
    $(document).on('click', '.btn-restore', function() {
        let $btn = $(this);
        let activityId = $btn.data('id');

        $btn.prop('disabled', true).html;

        $.ajax({
            url: '/wellify-activities/' + activityId + '/restore',
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                if(response.success) {
                    location.reload();
                    // Refresh both tables
                    activitiesTable.ajax.reload();
                    deletedTable.ajax.reload();
                }
            },
            error: function() {
                toastr.error('Failed to restore activity');
                $btn.prop('disabled', false).text('Restore');
            }
        });
    });

    // Bulk restore
    $('#bulkRestoreButton').click(function() {
        let ids = $('.restore-checkbox:checked').map(function() {
            return $(this).val();
        }).get();

        if(ids.length === 0) {
            toastr.warning('Please select at least one activity');
            return;
        }

        $.ajax({
            url: '/wellify-activities/bulk-restore',
            method: 'POST',
            data: {
                ids: ids,
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                toastr.success(response.message);
                deletedTable.ajax.reload();
                $('#selectAllRestore').prop('checked', false);
            },
            error: function() {
                toastr.error('Failed to restore activities');
            }
        });
    });

    // Select all checkboxes
    $('#selectAllRestore').change(function() {
        $('.restore-checkbox').prop('checked', $(this).prop('checked'));
    });

    // Permanent delete
    $(document).on('click', '.btn-delete-permanent', function() {
        if(confirm('Are you sure you want to permanently delete this activity?')) {
            let activityId = $(this).data('id');

            $.ajax({
                url: '/wellify-activities/' + activityId + '/force-delete',
                method: 'DELETE',
                data: {
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    toastr.success(response.message);
                    deletedTable.ajax.reload();
                },
                error: function() {
                    toastr.error('Failed to permanently delete activity');
                }
            });
        }
    });


    // Delete functionality
    // $(document).on('click', '.delete_icon1', function(e) {
    //     e.preventDefault();
    //     let activityId = $(this).data('id');
    //     let $row = $(this).closest('tr');

    //     Swal.fire({
    //         title: 'Are you sure?',
    //         text: "You won't be able to revert this!",
    //         icon: 'warning',
    //         showCancelButton: true,
    //         confirmButtonColor: '#3085d6',
    //         cancelButtonColor: '#d33',
    //         confirmButtonText: 'Yes, delete it!'
    //     }).then((result) => {
    //         if (result.isConfirmed) {
    //             $.ajax({
    //                 url: `/wellify-activities/${activityId}`,
    //                 type: 'DELETE',
    //                 data: {
    //                     _token: '{{ csrf_token() }}'
    //                 },
    //                 success: function(response) {
    //                     if(response.success) {
    //                         location.reload();
    //                     }
    //                 },
    //                 error: function(xhr) {
    //                     toastr.error(xhr.responseJSON?.message || 'Failed to delete activity');
    //                 }
    //             });
    //         }
    //     });
    // });

        // $(document).on('click', '.upload_icon', function () {
        //     const classId = $(this).data('id');
        //     $('#media_class_id').val(classId);
        //     $('#uploadClassId').val(classId);

        //     // Load images in gallery
        //     $.ajax({
        //         url: '/wellify-activities/' + classId + '/media/images',
        //         type: 'GET',
        //         success: function (response) {
        //             const gallery = $('#imageGallery');
        //             gallery.empty();

        //             if (response.length === 0) {
        //                 gallery.append('<p>No images uploaded.</p>');
        //             } else {
        //                 response.forEach(item => {
        //                     gallery.append(`
        //                         <div class="media-item mb-3 p-2 border rounded" data-id="${item.id}">
        //                             <img src="${item.url}" class="img-fluid rounded mb-2" alt="${item.name}" style="max-height: 300px;" />
        //                             <p><strong>${item.name}</strong><br class="media-desc">${item.description || 'No description'}</p>
        //                             <div class="action-buttons">
        //                                 <button class="btn btn-sm btn-warning edit-media" data-id="${item.id}" data-description="${item.description || ''}"><i class="bi bi-pencil"></i> Edit</button>
        //                                 <button class="btn btn-danger btn-sm delete-media" data-id="${item.id}"><i class="bi bi-trash"></i> Delete</button>
        //                             </div>

        //                             <form class="edit-media-form mt-2 d-none" data-id="${item.id}" enctype="multipart/form-data">
        //                                 <input type="text" name="description" class="form-control mb-2" value="${item.description || ''}" required>
        //                                 <input type="file" name="media" class="form-control mb-2">
        //                                 <button type="submit" class="btn btn-success btn-sm me-2">Save</button>
        //                                 <button type="button" class="btn btn-secondary btn-sm cancel-edit">Cancel</button>
        //                             </form>
        //                         </div>
        //                     `);
        //                 });
        //             }
        //         },
        //         error: function () {
        //             $('#imageGallery').html('<p class="text-danger">Failed to load images.</p>');
        //         }
        //     });
        // });

        // $('#addMoreMedia').click(function () {
        //     $('#mediaInputsContainer').append(`
        //         <div class="media-input-group mb-3">
        //             <input type="file" name="media[]" class="form-control" required>
        //             <input type="text" name="description[]" class="form-control mt-2" placeholder="Description" required>
        //         </div>
        //     `);
        // });

        // $('#uploadMediaForm').on('submit', function (e) {
        //     e.preventDefault();
        //     let formData = new FormData(this);

        //     $.ajax({
        //         url: '{{ route("wellify_classes.media.upload") }}',
        //         type: 'POST',
        //         data: formData,
        //         contentType: false,
        //         processData: false,
        //         success: function () {
        //             alert('Media uploaded successfully!');
        //             $('#upload_media_modal').modal('hide');
        //             $('#classesTable').DataTable().ajax.reload();
        //         },
        //         error: function () {
        //             alert('Upload failed.');
        //         }
        //     });
        // });

        // function loadMedia(classId) {
        //     $.ajax({
        //         url: `/wellify-activities/${classId}/media`,
        //         type: 'GET',
        //         success: function(data) {
        //             let mediaContainer = $('#mediaPreview');
        //             mediaContainer.empty();

        //             data.forEach(item => {
        //                 let mediaTag = '';
        //                 if (item.media_type_id == 1 || item.media_type_id == 3) {
        //                     mediaTag = `<img src="${item.media_url}" class="img-thumbnail mb-2" width="100" />`;
        //                 } else if (item.media_type_id == 2) {
        //                     mediaTag = `<a href="${item.media_url}" target="_blank">View PDF</a>`;
        //                 }

        //                 mediaContainer.append(`
        //                     <div class="media-item mb-3 p-2 border rounded" data-id="${item.id}">
        //                         ${mediaTag}
        //                         <p class="mb-1"><strong>${item.name || 'Untitled'}</strong></p>
        //                         <p class="mb-2">${item.description || 'No description'}</p>
        //                         <button class="btn btn-danger btn-sm delete-media" data-id="${item.id}">Delete</button>
        //                     </div>
        //                 `);
        //             });
        //         },
        //         error: function () {
        //             $('#mediaPreview').html('<p class="text-danger">Failed to load media.</p>');
        //         }
        //     });
        // }

        // $('#mediaUploadModal').on('show.bs.modal', function (e) {
        //     const classId = $(e.relatedTarget).data('id');
        //     $('#uploadClassId').val(classId);
        //     loadMedia(classId);
        // });

        // $(document).on('click', '.delete-media', function () {
        //     const id = $(this).data('id');
        //     // console.log(id,'hii');
        //     if (confirm('Are you sure you want to delete this media?')) {
        //         $.ajax({
        //             url: `/wellify-activities/media/${id}`,
        //             type: 'DELETE',
        //             headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        //             success: function () {
        //                 $(`.media-item[data-id="${id}"]`).remove();
        //             },
        //             error: function () {
        //                 alert('Failed to delete media.');
        //             }
        //         });
        //     }
        // });
        // $(document).on('click', '.edit-media', function () {
        //     const card = $(this).closest('.media-item');
        //     card.find('.edit-media-form').removeClass('d-none');
        //     card.find('.action-buttons, .media-desc').hide();
        // });
        // $(document).on('click', '.cancel-edit', function () {
        //     const form = $(this).closest('.edit-media-form');
        //     form.addClass('d-none');
        //     form.closest('.media-item').find('.action-buttons, .media-desc').show();
        // });
        // $(document).on('submit', '.edit-media-form', function (e) {
        //     e.preventDefault();
        //     const form = $(this);
        //     const mediaId = form.data('id');
        //     const formData = new FormData(this);

        //     $.ajax({
        //         url: `/wellify-activities/media/${mediaId}/edit`,
        //         type: 'POST',
        //         data: formData,
        //         processData: false,
        //         contentType: false,
        //         headers: {
        //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //         },
        //         success: function () {
        //             alert('Media updated!');
        //             $('#upload_icon').trigger('click');
        //         },
        //         error: function () {
        //             alert('Failed to update media.');
        //         }
        //     });
        // });
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
    // Initialize Select2 for multiple select fields
        $('#choices-multiple-remove-button, #mood_id').select2({
            placeholder: "Select options",
            width: '100%',
            closeOnSelect: false
        });

        // Form submission
        $('#createActivityForm').submit(function(e) {
            e.preventDefault();

            let form = $(this)[0];
            let formData = new FormData(form);

            // Fix: Append moods[] manually
            let moods = $('#choices-multiple-remove-button').val(); // Get selected moods
            if (moods && Array.isArray(moods)) {
                moods.forEach(id => formData.append('mood_id[]', id));
            }
            const $form = $(this);
            const $submitBtn = $form.find('.primary_btn');
            $submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status"></span> Submitting...');

            // Validate SVG file
            const svgFile = $('#background_image')[0].files[0];
            if (svgFile && !svgFile.name.toLowerCase().endsWith('.svg')) {
                toastr.error('Only SVG files are allowed for the thumbnail image');
                $submitBtn.prop('disabled', false).text('Submit');
                return false;
            }

            const formData = new FormData(this);

            $.ajax({
                url: '{{ route("wellify-activities.store") }}',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        location.reload();
                        $('#add_new').modal('hide');

                        // Reset form
                        $form[0].reset();
                        $('#choices-multiple-remove-button, #mood_id').val(null).trigger('change');

                        // Refresh DataTable if exists
                        if (typeof activitiesTable !== 'undefined') {
                            activitiesTable.ajax.reload(null, false);
                        }
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    let errorMessage = 'An error occurred';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    } else if (xhr.responseJSON && xhr.responseJSON.errors) {
                        errorMessage = '';
                        $.each(xhr.responseJSON.errors, function(key, value) {
                            errorMessage += value[0] + '\n';
                        });
                    }
                    toastr.error(errorMessage);
                },
                complete: function() {
                    $submitBtn.prop('disabled', false).text('Submit');
                }
            });
        });

        // Reset form when modal is hidden
        $('#add_new').on('hidden.bs.modal', function () {
            $('#createActivityForm')[0].reset();
            $('#choices-multiple-remove-button, #mood_id').val(null).trigger('change');
        });
    });
</script>

<script>
    $(document).on('click', '.view_icon1', function () {
        const activityId = $(this).data('id');

        $.ajax({
            url: `/wellify-activities/${activityId}`,
            type: 'GET',
            success: function (response) {
                if (response.success) {
                    const a = response.data;

                    $('#view_activity_id').text(a.activity_id ?? '—');
                    $('#view_activity_name').text(a.title ?? '—');


                    let moodHTML = '—';
                    if (Array.isArray(a.associated_moods) && a.associated_moods.length > 0) {
                        moodHTML = '';
                        a.associated_moods.forEach(mood => {
                            moodHTML += `
                                <span class="px-3 py-1 fw-semibold rounded-pill d-inline-block mb-1"
                                      style="background-color: #${mood.color_code}; color: #${mood.text_code}; border: 1px solid #${mood.text_code};">
                                    ${mood.title}
                                </span>
                            `;
                        });
                    }
                    $('#view_moods').html(moodHTML);

                    $('#view_description').text(a.description ?? '—');
                    $('#view_level').text(a.levels ?? '—');

                    const points = a.points_on_completion ?? 0;
                    $('#view_points').text(`${points} ${points == 1 ? 'Point' : 'Points'}`);

                    const droplets = a.water_on_completion ?? 0;
                    $('#view_water_droplets').text(`${droplets} ${droplets == 1 ? 'Water Droplet' : 'Water Droplets'}`);

                    const imageCount = a.image_count ?? 0;
                    if (imageCount > 0) {
                        $('#media_count_container').show();
                        $('#view_image_count_text').text(`${imageCount} ${imageCount === 1 ? 'Image' : 'Images'} Uploaded`);
                    } else {
                        $('#media_count_container').hide();
                    }

                    $('#view_user').modal('show');
                } else {
                    toastr.error(response.message);
                }
            },
            error: function () {
                toastr.error('Failed to fetch activity.');
            }
        });
    });
</script>

<script>
    let editMoodsSelect;

    document.addEventListener('DOMContentLoaded', function () {
        const moodElement = document.getElementById('edit_moods');
        if (moodElement) {
            editMoodsSelect = new Choices(moodElement, {
                removeItemButton: true,
                placeholder: true,
                placeholderValue: 'Select moods',
                maxItemCount: -1,
                searchResultLimit: 5,
                renderChoiceLimit: 100,
            });
        }
    });
    $(document).on('click', '.edit_activity', function () {
        const activityId = $(this).data('id');

        $.ajax({
            url: `/wellify-activities/${activityId}`,
            type: 'GET',
            success: function (res) {
                if (res.success) {
                    const a = res.data;

                    $('#edit_id').val(a.id);
                    $('#edit_activity_id').val(a.activity_id);
                    $('#edit_title').val(a.title);
                    $('#edit_description').val(a.description);
                    $('#edit_level').val(a.level_id).trigger('change');
                    $('#edit_points').val(a.points_on_completion);
                    $('#edit_water').val(a.water_on_completion);

                    // Reset and re-set moods using Choices.js
                    if (editMoodsSelect) {
                        editMoodsSelect.clearStore();
                        editMoodsSelect.setChoices([
                            @foreach($moods as $mood)
                                { value: '{{ $mood->id }}', label: '{{ $mood->title }}', selected: false },
                            @endforeach
                        ], 'value', 'label', false);

                        if (Array.isArray(a.mood_ids)) {
                            a.mood_ids.forEach(moodId => {
                                editMoodsSelect.setChoiceByValue(moodId.toString());
                            });
                        }
                    }

                    $('#edit_activity').modal('show');
                } else {
                    toastr.error(res.message);
                }
            },
            error: function () {
                toastr.error('Failed to fetch activity.');
            }
        });
    });

    $('#edit_activity_form').on('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(this);
        const activityId = $('#edit_activity_id').val();

        $.ajax({
            url: `/wellify-activities/${activityId}`,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            headers: { 'X-HTTP-Method-Override': 'PUT' },
            success: function (res) {
                if (res.success) {
                    location.reload();
                    $('#edit_activity').modal('hide');
                    $('#edit_activity_form')[0].reset();
                    editMoodsSelect.clearStore();
                    toastr.success(res.message);
                    $('#your_data_table_id').DataTable().ajax.reload(null, false);
                } else {
                    toastr.error(res.message);
                }
            },
            error: function (xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    Object.values(errors).forEach(err => toastr.error(err[0]));
                } else {
                    toastr.error('Update failed');
                }
            }
        });
    });
</script>

{{-- <script>
    // Open modal with activity id
    $(document).on('click', '.open-upload-modal', function () {
        $('#uploadActivityId').val($(this).data('id'));
        $('#addimagesModal').modal('show');
    });

    // Show file preview
    $(document).on('change', '.file-upload', function () {
        const input = this;
        const file = input.files[0];

        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const $label = $(input).closest('.file-label');
                $label.find('.file-image')
                    .attr('src', e.target.result)
                    .removeClass('d-none');


                $label.find('.start span:first-child').text(file.name);
            };
            reader.readAsDataURL(file);
        }
    });

    // Add more input rows
    $(document).on('click', '.add-more', function () {
        $('#addImages_main').append(`
            <div class="row align-items-center add_newrow">
                <div class="col-xxl-5 mb-3">
                    <div class="col-xxl-5 mb-3">
                        <div class="uploader">
                            <input type="file" name="media[]" id="media_input_1" class="file-upload d-none" accept=".svg,image/svg+xml" required>
                            <label for="media_input_1" class="py-2 px-3 d-flex image_label rounded-3 file-label">
                                <img class="file-image d-none" src="#" alt="Preview">
                                <span class="start text-center w-100">
                                    <span class="d-block">Select a file</span>
                                    <span class="btn btn-success my-2">Select a file</span>
                                </span>
                            </label>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-5 mb-3">
                    <textarea name="description[]" class="form-control input rounded-3" placeholder="Enter Description" rows="3" required></textarea>
                </div>

                <div class="col-xxl-2 mb-3 text-center">
                   @php
                                $addImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/Add_icon.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                    <img src="{{   $addImageUrl }}" class="img-fluid add-more" style="cursor:pointer;">
                </div>
            </div>
        `);
    });

    $(document).on('click', '.remove-row', function () {
        const totalRows = $('.add_newrow').length;
        if (totalRows > 1) {
            $(this).closest('.add_newrow').remove();
        } else {
            toastr.warning('At least one image is required.');
        }
    });
    // Submit form
    $('#uploadImageForm').on('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);

        $.ajax({
            url: '{{ route('wellify-activities.media.upload') }}',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.success) {
                    toastr.success(res.message);
                    $('#addimagesModal').modal('hide');
                    $('#uploadImageForm')[0].reset();
                    $('#your_data_table_id').DataTable().ajax.reload(null, false);
                } else {
                    toastr.error(res.message);
                }
            },
            error: function (xhr) {
                if (xhr.status === 422) {
                    $.each(xhr.responseJSON.errors, function (key, val) {
                        toastr.error(val[0]);
                    });
                } else {
                    toastr.error('Upload failed.');
                }
            }
        });

    });
</script> --}}

<script>
    // Open modal with activity id
    $(document).on('click', '.open-upload-modal', function () {
        $('#uploadActivityId').val($(this).data('id'));
        $('#addimagesModal').modal('show');
    });

    // Trigger file input when label is clicked
    $(document).on('click', '.file-label', function () {
        $(this).closest('.uploader').find('.file-upload').trigger('click');
    });

    // Show file preview
    $(document).on('change', '.file-upload', function () {
        const input = this;
        const file = input.files[0];

        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const $label = $(input).closest('.uploader').find('.file-label');
                $label.find('.file-image').attr('src', e.target.result).removeClass('d-none');
                $label.find('.start span:first-child').text(file.name);
            };
            reader.readAsDataURL(file);
        }
    });

    // Add more input rows
    $(document).on('click', '.add-more', function () {
        const newRow = $('.add_newrow:first').clone();

        newRow.find('input[type="file"]').val('');
        newRow.find('textarea').val('');
        newRow.find('.file-image').addClass('d-none').attr('src', '#');
        newRow.find('.start span:first-child').text('Select a file');

        $('#addImages_main').append(newRow);
    });

    // Remove input row
    $(document).on('click', '.remove-row', function () {
        const totalRows = $('.add_newrow').length;
        if (totalRows > 1) {
            $(this).closest('.add_newrow').remove();
        } else {
            toastr.warning('At least one image is required.');
        }
    });

    // Submit form
    $('#uploadImageForm').on('submit', function (e) {
        e.preventDefault();

        // Client-side validation
        let valid = true;
        $('.desc-field').each(function () {
            if ($(this).val().length > 255) {
                toastr.error('Description cannot exceed 255 characters.');
                valid = false;
                return false;
            }
        });

        $('.file-upload').each(function () {
            const file = this.files[0];
            if (file && file.type !== 'image/svg+xml') {
                toastr.error('Only SVG files are allowed.');
                valid = false;
                return false;
            }
        });

        if (!valid) return;

        const formData = new FormData(this);
        $('#uploadLoader').show(); // Show spinner

        $.ajax({
            url: '{{ route('wellify-activities.media.upload') }}',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                $('#uploadLoader').hide(); // Hide spinner
                if (res.success) {
                    location.reload();
                    toastr.success(res.message);
                    $('#addimagesModal').modal('hide');

                    $('#uploadImageForm')[0].reset();
                    $('#addImages_main').html($('.add_newrow:first').prop('outerHTML')); // Reset rows
                    $('#uploadImageForm').find('.file-image').addClass('d-none');
                    $('#your_data_table_id').DataTable().ajax.reload(null, false);
                    setTimeout(() => location.reload(), 1000);
                } else {
                    toastr.error(res.message);
                }
            },
            error: function (xhr) {
                $('#uploadLoader').hide();
                if (xhr.status === 422) {
                    $.each(xhr.responseJSON.errors, function (key, val) {
                        toastr.error(val[0]);
                    });
                } else {
                    toastr.error('Upload failed.');
                }
            }
        });
    });
</script>

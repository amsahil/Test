@include('common.footer')
@php
$employeeRoutes = ['staff.index', 'departments.index'];
$isManageEmployeesActive = in_array(Route::currentRouteName(), $employeeRoutes);
@endphp
@php
if(auth()->user()){
$user = auth()->user();
}
else{
$user = Auth::guard('staff')->user();
}
$role = $user ? $user->getRoleNames()->first() : null;

@endphp

<style>
.nav.sidebar_nav {
    height: 100%;
}

.main_menu {
    overflow-y: auto;
    overflow-x: hidden;
    height: calc(100% - 100px);
}

.sidebar.sidebar_collapsed .main_menu .submenu_wrapper {
    display: none;
}

@media (max-width: 1024px) {
    .sidebar.sidebar_collapsed .main_menu .submenu_wrapper {
        display: unset;
    }

}
</style>

<aside class="sidebar" id="sidebar">
    <a href="#" class="d-flex align-items-center justify-content-center mb-3">
        @php
        $wellifyLogoUrl = Storage::disk('s3')->temporaryUrl(
        'staging/public/wellify-logo.svg',
        now()->addHour()
        );
        @endphp
        <img src="{{ $wellifyLogoUrl }}" alt="logo icon" class="img-fluid logo_main">
        <!-- <img src="{{ asset('assets/images/wellify-logo.svg') }}" alt="logo main" class="img-fluid logo_main"> -->
        @php
        $wellifySmallLogoUrl = Storage::disk('s3')->temporaryUrl(
        'staging/public/logo_collpased.svg',
        now()->addHour()
        );
        @endphp
        <img src="{{ $wellifySmallLogoUrl }}" alt="logo main" class="img-fluid logo_collapsed" id="logo_small">
        <!-- <img src="assets/images/logo_collpased.svg" alt="logo main" class="img-fluid logo_collapsed"
            id="logo_small"> -->
    </a>
    <hr class="text-white">
    <!-- <p class="menu_title">Menu</p> -->
    <nav aria-label="menu" class="nav sidebar_nav pt-3">
        <ul class="nav nav-pills d-block mb-auto main_menu w-100">
            <li class="mb-3">
                <p class="menu_title">Employer</p>
            </li>
            <li class="nav-item mb-3">
                <!-- <a href="{{ route('dashboard') }}" -->
                <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}"
                    href="{{ route('dashboard') }}">
                    <!-- class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}" -->
                    <!-- aria-current="page"> -->
                    <span class="menu_icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M21 14H14V21H21V14Z" stroke="#ddd" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                            <path d="M10 14H3V21H10V14Z" stroke="#ddd" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                            <path d="M21 3H14V10H21V3Z" stroke="#ddd" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                            <path d="M10 3H3V10H10V3Z" stroke="#ddd" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </span>
                    <span class="nav_text">Dashboard</span>
                </a>
            </li>

            {{-- Manage Employer visible only to Super Admin --}}
            @role('Super Admin')
            <li class="nav-item mb-3">
                <a href="{{ route('wellify_users.index') }}"
                    class="nav-link {{ request()->routeIs('wellify_users.*') ? 'active' : '' }}" aria-current="page">
                    <span class="menu_icon">
                        <svg width="24" height="27" viewBox="0 0 14 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M7 8C8.65685 8 10 6.65685 10 5C10 3.34315 8.65685 2 7 2C5.34315 2 4 3.34315 4 5C4 6.65685 5.34315 8 7 8Z"
                                stroke="#DDDDDD" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                            <path
                                d="M6 10H4.31765C3.83513 10 3.59387 10 3.37806 10.0461C2.63116 10.2056 1.9853 10.7661 1.62346 11.569C1.51891 11.8009 1.44262 12.0765 1.29003 12.6278C1.10668 13.2901 1.01501 13.6213 1.00261 13.8884C0.958883 14.8308 1.46818 15.6817 2.22441 15.9297C2.43875 16 2.72864 16 3.30844 16H6.5M6 10L7 11L8 10M6 10H8M6.5 16L7 12.5L7.5 16M6.5 16H7.5M8 10H9.6824C10.1649 10 10.4061 10 10.6219 10.0461C11.3688 10.2056 12.0147 10.7661 12.3765 11.569C12.4811 11.8009 12.5574 12.0765 12.71 12.6278C12.8933 13.2901 12.985 13.6213 12.9974 13.8884C13.0411 14.8308 12.5318 15.6817 11.7756 15.9297C11.5613 16 11.2714 16 10.6916 16H7.5"
                                stroke="#DDDDDD" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </span>
                    <span class="nav_text">Manage Employers</span>
                </a>
            </li>
            @endrole

            @hasanyrole('Super Admin|Employer')
            <!-- Top-level Menu: Departments -->
            <li class="nav-item mb-3">
                <a class="nav-link {{ request()->routeIs('departments.index') ? 'active' : '' }}"
                    href="{{ route('departments.index') }}">
                    <span class="menu_icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="23" height="24" viewBox="0 0 23 24" fill="none">
                            <path
                                d="M13.4167 21.5837V8.16699M13.4167 21.5837H7.66675C4.95658 21.5837 3.60054 21.5837 2.75912 20.7413C1.91675 19.8999 1.91675 18.5438 1.91675 15.8337V8.16699C1.91675 5.45683 1.91675 4.10078 2.75912 3.25937C3.60054 2.41699 4.95658 2.41699 7.66675 2.41699C10.3769 2.41699 11.733 2.41699 12.5744 3.25937C13.4167 4.10078 13.4167 5.45683 13.4167 8.16699M13.4167 21.5837H17.2501C19.0575 21.5837 19.9602 21.5837 20.5218 21.0221C21.0834 20.4605 21.0834 19.5577 21.0834 17.7503V12.0003C21.0834 10.1929 21.0834 9.29016 20.5218 8.72858C19.9602 8.16699 19.0575 8.16699 17.2501 8.16699H13.4167"
                                stroke="#ddd" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            <path
                                d="M9 11C11.2091 11 13 9.20914 13 7C13 4.79086 11.2091 3 9 3C6.79086 3 5 4.79086 5 7C5 9.20914 6.79086 11 9 11Z"
                                stroke="#DDDDDD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </span>
                    <span class="nav_text">Departments</span>
                </a>
            </li>

            <li class="nav-item mb-3">
                <a class="nav-link {{ request()->routeIs('staffs.index') ? 'active' : '' }}"
                    href="{{ route('staffs.index') }}">
                    <span class="menu_icon">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M4.82672 1.94174L9.59603 6.71137C9.62893 6.74398 9.65505 6.78279 9.67287 6.82555C9.69069 6.86831 9.69986 6.91417 9.69986 6.96049C9.69986 7.00682 9.69069 7.05268 9.67287 7.09544C9.65505 7.1382 9.62893 7.17701 9.59603 7.20962L7.2087 9.59681C7.17609 9.62971 7.13728 9.65582 7.09452 9.67364C7.05175 9.69146 7.00589 9.70064 6.95956 9.70064C6.91323 9.70064 6.86737 9.69146 6.82461 9.67364C6.78184 9.65582 6.74304 9.62971 6.71042 9.59681L1.9417 4.82837C1.15306 6.24371 0.84754 7.87762 1.07149 9.48228C1.29543 11.0869 2.03662 12.5748 3.18264 13.7201C4.18039 14.7187 5.4413 15.4132 6.81853 15.7229C8.19577 16.0326 9.63265 15.9447 10.9618 15.4694L18.1821 22.6892C18.2801 22.7877 18.3966 22.8659 18.525 22.9192C18.6533 22.9725 18.7909 23 18.9298 23C19.0688 23 19.2064 22.9725 19.3347 22.9192C19.463 22.8659 19.5795 22.7877 19.6775 22.6892L22.6892 19.6771C22.7877 19.5791 22.8659 19.4626 22.9192 19.3343C22.9725 19.206 23 19.0684 23 18.9295C23 18.7905 22.9725 18.6529 22.9192 18.5246C22.8659 18.3963 22.7877 18.2798 22.6892 18.1818L15.4695 10.9625C15.9451 9.63326 16.0332 8.19623 15.7235 6.81883C15.4138 5.44144 14.719 4.1804 13.7202 3.1826C12.5745 2.03672 11.0864 1.29559 9.48152 1.07156C7.87664 0.84753 6.24246 1.15282 4.82672 1.94114V1.94174Z"
                                stroke="#DDDDDD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </span>
                    <span class="nav_text">Manage Staffs</span>
                </a>
            </li>



            @role('Super Admin|Employer')
            <li class="nav-item mb-3">
                <a href="{{ route('wellify_employees.index') }}"
                    class="nav-link {{ request()->routeIs('wellify_employees.*') ? 'active' : '' }}"
                    aria-current="page">
                    <span class="menu_icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="23" height="24" viewBox="0 0 23 24" fill="none">
                            <path
                                d="M13.4167 21.5837V8.16699M13.4167 21.5837H7.66675C4.95658 21.5837 3.60054 21.5837 2.75912 20.7413C1.91675 19.8999 1.91675 18.5438 1.91675 15.8337V8.16699C1.91675 5.45683 1.91675 4.10078 2.75912 3.25937C3.60054 2.41699 4.95658 2.41699 7.66675 2.41699C10.3769 2.41699 11.733 2.41699 12.5744 3.25937C13.4167 4.10078 13.4167 5.45683 13.4167 8.16699M13.4167 21.5837H17.2501C19.0575 21.5837 19.9602 21.5837 20.5218 21.0221C21.0834 20.4605 21.0834 19.5577 21.0834 17.7503V12.0003C21.0834 10.1929 21.0834 9.29016 20.5218 8.72858C19.9602 8.16699 19.0575 8.16699 17.2501 8.16699H13.4167M6.22925 11.042H5.27091M10.0626 11.042H9.10425M6.22925 7.20866H5.27091M6.22925 14.8753H5.27091M10.0626 7.20866H9.10425M10.0626 14.8753H9.10425M17.7292 14.8753H16.7709M17.7292 11.042H16.7709"
                                stroke="#ddd" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </span>
                    <span class="nav_text">Manage Employees</span>
                </a>
            </li>
            @endrole



            @role('Super Admin')
            <li class="nav-item mb-3">
                <a href="{{ route('wellifyplans.index') }}"
                    class="nav-link {{ request()->routeIs('wellifyplans.index') ? 'active' : '' }}" aria-current="page">
                    <span class="menu_icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M4.99949 14.5996L3.00031 12.5971L1 14.5996M19.0005 9.43359L20.9997 11.4373L23 9.43359"
                                fill="#17AC38" />
                            <path
                                d="M4.99949 14.5996L3.00031 12.5971L1 14.5996M19.0005 9.43359L20.9997 11.4373L23 9.43359"
                                stroke="#DDDDDD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            <path
                                d="M20.9994 11.4372C20.9994 9.04542 20.0517 6.75403 18.3639 5.06285C17.5287 4.22602 16.5367 3.5621 15.4447 3.1091C14.3526 2.65609 13.182 2.4229 11.9997 2.42285C10.8513 2.42194 9.71348 2.64299 8.64892 3.07383C7.46054 3.55031 6.38745 4.27478 5.50127 5.19889C4.6151 6.123 3.93622 7.2255 3.50995 8.4328M3 12.5959C3.00173 14.6882 3.73035 16.7149 5.06123 18.3294C6.39067 19.942 8.2403 21.0411 10.2922 21.4379C12.3441 21.8346 14.4702 21.5042 16.3049 20.5035C18.1396 19.5007 19.5692 17.892 20.3495 15.9523"
                                stroke="#DDDDDD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            <path
                                d="M9.26953 14.2298C9.32826 14.8996 9.64688 15.5198 10.1572 15.9575C10.6675 16.3953 11.3289 16.6159 11.9998 16.572C14.202 16.572 14.73 15.305 14.73 14.2298C14.73 13.1547 13.8196 12.0152 11.9998 12.0152C10.18 12.0152 9.26953 11.2954 9.26953 9.82872C9.29479 9.32049 9.47426 8.83201 9.78404 8.42831C10.0938 8.02461 10.5192 7.72485 11.0036 7.56892C11.3251 7.46513 11.6636 7.4279 11.9998 7.45949C12.6715 7.43029 13.329 7.65962 13.8368 8.10031C14.3446 8.541 14.6643 9.15954 14.73 9.82872M11.9998 17.9371V16.7514M11.9998 6.08984V7.45497"
                                stroke="#DDDDDD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>

                    </span>
                    <span class="nav_text">Manage Plans</span>
                </a>
            </li>

            @endrole

            @role('Employer')
            <li class="nav-item mb-3">
                <a href="{{ route('wellifyemployerplans.index') }}"
                    class="nav-link {{ request()->routeIs('wellifyemployerplans.index') ? 'active' : '' }}"
                    aria-current="page">
                    <span class="menu_icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M4.99949 14.5996L3.00031 12.5971L1 14.5996M19.0005 9.43359L20.9997 11.4373L23 9.43359"
                                fill="#17AC38" />
                            <path
                                d="M4.99949 14.5996L3.00031 12.5971L1 14.5996M19.0005 9.43359L20.9997 11.4373L23 9.43359"
                                stroke="#DDDDDD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            <path
                                d="M20.9994 11.4372C20.9994 9.04542 20.0517 6.75403 18.3639 5.06285C17.5287 4.22602 16.5367 3.5621 15.4447 3.1091C14.3526 2.65609 13.182 2.4229 11.9997 2.42285C10.8513 2.42194 9.71348 2.64299 8.64892 3.07383C7.46054 3.55031 6.38745 4.27478 5.50127 5.19889C4.6151 6.123 3.93622 7.2255 3.50995 8.4328M3 12.5959C3.00173 14.6882 3.73035 16.7149 5.06123 18.3294C6.39067 19.942 8.2403 21.0411 10.2922 21.4379C12.3441 21.8346 14.4702 21.5042 16.3049 20.5035C18.1396 19.5007 19.5692 17.892 20.3495 15.9523"
                                stroke="#DDDDDD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            <path
                                d="M9.26953 14.2298C9.32826 14.8996 9.64688 15.5198 10.1572 15.9575C10.6675 16.3953 11.3289 16.6159 11.9998 16.572C14.202 16.572 14.73 15.305 14.73 14.2298C14.73 13.1547 13.8196 12.0152 11.9998 12.0152C10.18 12.0152 9.26953 11.2954 9.26953 9.82872C9.29479 9.32049 9.47426 8.83201 9.78404 8.42831C10.0938 8.02461 10.5192 7.72485 11.0036 7.56892C11.3251 7.46513 11.6636 7.4279 11.9998 7.45949C12.6715 7.43029 13.329 7.65962 13.8368 8.10031C14.3446 8.541 14.6643 9.15954 14.73 9.82872M11.9998 17.9371V16.7514M11.9998 6.08984V7.45497"
                                stroke="#DDDDDD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>

                    </span>
                    <span class="nav_text">Plans</span>
                </a>
            </li>
            @endrole

            @endhasanyrole

            @role('Staff')
            <li class="nav-item mb-3">
                <a href="{{ route('wellify_employees.index') }}"
                    class="nav-link {{ request()->routeIs('wellify_employees.*') ? 'active' : '' }}"
                    aria-current="page">
                    <span class="menu_icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="23" height="24" viewBox="0 0 23 24" fill="none">
                            <path
                                d="M13.4167 21.5837V8.16699M13.4167 21.5837H7.66675C4.95658 21.5837 3.60054 21.5837 2.75912 20.7413C1.91675 19.8999 1.91675 18.5438 1.91675 15.8337V8.16699C1.91675 5.45683 1.91675 4.10078 2.75912 3.25937C3.60054 2.41699 4.95658 2.41699 7.66675 2.41699C10.3769 2.41699 11.733 2.41699 12.5744 3.25937C13.4167 4.10078 13.4167 5.45683 13.4167 8.16699M13.4167 21.5837H17.2501C19.0575 21.5837 19.9602 21.5837 20.5218 21.0221C21.0834 20.4605 21.0834 19.5577 21.0834 17.7503V12.0003C21.0834 10.1929 21.0834 9.29016 20.5218 8.72858C19.9602 8.16699 19.0575 8.16699 17.2501 8.16699H13.4167M6.22925 11.042H5.27091M10.0626 11.042H9.10425M6.22925 7.20866H5.27091M6.22925 14.8753H5.27091M10.0626 7.20866H9.10425M10.0626 14.8753H9.10425M17.7292 14.8753H16.7709M17.7292 11.042H16.7709"
                                stroke="#ddd" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </span>
                    <span class="nav_text">Manage Employees</span>
                </a>
            </li>
            @endrole

            @role('Super Admin')
            <li class="mb-3">
                <hr class="text-white">
            </li>

            <li class="nav-item mb-3 position-relative submenu_li" id="submenu_nav">
                <a href="#"
                    class="nav-link {{ request()->is('wellify_moods*') || request()->is('wellify-classes*') || request()->is('wellify-activities*') || request()->is('wellify-seeds*') ||request()->is('wellify/activities/*/media*') ||request()->is('wellify/activity/*/media-data*')? 'active' : '' }}"
                    aria-current="page">
                    <span class="menu_icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M15.88 13.4178C15.9219 13.1769 16.1406 13 16.3967 13H17.6036C17.8596 13 18.0783 13.1769 18.1202 13.4178L18.2194 13.9871C18.2487 14.1533 18.3651 14.292 18.5196 14.3738C18.554 14.3916 18.588 14.4107 18.622 14.4302C18.7733 14.5173 18.9571 14.5444 19.1224 14.4853L19.6888 14.2827C19.8049 14.241 19.9327 14.24 20.0495 14.2799C20.1663 14.3198 20.2644 14.3979 20.3265 14.5004L20.9297 15.4991C20.9917 15.6016 21.0135 15.7218 20.9913 15.8383C20.9692 15.9548 20.9045 16.0599 20.8087 16.1351L20.3419 16.5027C20.2055 16.6098 20.138 16.7751 20.1417 16.9436C20.1424 16.9813 20.1424 17.0191 20.1417 17.0569C20.138 17.2249 20.2055 17.3902 20.3419 17.4973L20.8092 17.8649C21.0065 18.0204 21.0577 18.2893 20.9302 18.5004L20.326 19.4991C20.2641 19.6016 20.166 19.6798 20.0493 19.7198C19.9326 19.7597 19.8049 19.7589 19.6888 19.7173L19.1224 19.5147C18.9571 19.4556 18.7733 19.4827 18.6215 19.5698C18.5878 19.5894 18.5537 19.6083 18.5191 19.6267C18.3651 19.708 18.2487 19.8467 18.2194 20.0129L18.1202 20.5822C18.0783 20.8236 17.8596 21 17.6036 21H16.3962C16.1402 21 15.9219 20.8231 15.8795 20.5822L15.7804 20.0129C15.7515 19.8467 15.6352 19.708 15.4806 19.6262C15.4461 19.608 15.412 19.5892 15.3782 19.5698C15.227 19.4827 15.0431 19.4556 14.8774 19.5147L14.3109 19.7173C14.1949 19.7589 14.0672 19.7598 13.9505 19.72C13.8339 19.6801 13.7358 19.602 13.6737 19.4996L13.07 18.5009C13.0081 18.3984 12.9863 18.2782 13.0084 18.1617C13.0306 18.0452 13.0953 17.9401 13.1911 17.8649L13.6584 17.4973C13.7943 17.3907 13.8618 17.2249 13.8585 17.0569C13.8578 17.0191 13.8578 16.9813 13.8585 16.9436C13.8618 16.7747 13.7943 16.6098 13.6584 16.5027L13.1911 16.1351C13.0954 16.06 13.0308 15.9549 13.0086 15.8385C12.9865 15.7221 13.0082 15.602 13.07 15.4996L13.6737 14.5009C13.7357 14.3983 13.8339 14.32 13.9506 14.2801C14.0674 14.2401 14.1953 14.241 14.3114 14.2827L14.8774 14.4853C15.0431 14.5444 15.227 14.5173 15.3782 14.4302C15.4117 14.4107 15.4462 14.392 15.4806 14.3733C15.6352 14.292 15.7515 14.1533 15.7804 13.9871L15.88 13.4178Z"
                                stroke="#DDDDDD" stroke-linecap="round" stroke-linejoin="round" />
                            <path
                                d="M18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18C16.7348 18 16.4804 17.8946 16.2929 17.7071C16.1054 17.5196 16 17.2652 16 17C16 16.7348 16.1054 16.4804 16.2929 16.2929C16.4804 16.1054 16.7348 16 17 16C17.2652 16 17.5196 16.1054 17.7071 16.2929C17.8946 16.4804 18 16.7348 18 17Z"
                                stroke="#DDDDDD" stroke-linecap="round" stroke-linejoin="round" />
                            <path
                                d="M5.99902 10.841C6.60002 11.022 7.27302 11.171 7.99902 11.281M10.999 15C6.58002 15 2.99902 13.656 2.99902 12M5.99902 17.841C6.60002 18.022 7.27302 18.171 7.99902 18.281M10.999 8C15.417 8 18.999 6.656 18.999 5C18.999 3.343 15.417 2 10.999 2C6.58102 2 2.99902 3.343 2.99902 5C2.99902 6.656 6.58002 8 10.999 8Z"
                                stroke="#DDDDDD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            <path d="M10.999 22C6.58002 22 2.99902 20.656 2.99902 19V5M18.999 5V10.5" stroke="#DDDDDD"
                                stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </span>
                    <span class="nav_text">CMS</span>
                </a>
                <div class="submenu_wrapper ">
                    <ul class="submenu {{ request()->is('wellify_moods*') || request()->is('wellify-classes*') || request()->is('wellify-activities*') || request()->is('wellify-seeds*') || request()->is('wellify/activities/*/media*') || request()->is('wellify/activity/*/media-data*')? '' : 'd-none' }} py-2"
                        id="cms_submenu">
                        <li><a class="dropdown-item py-2 fw-light {{ Route::is('wellify_moods.index') ? 'text_primary' : '' }}"
                                href="{{ route('wellify_moods.index') }}">Manage Moods</a></li>
                        <li><a class="dropdown-item py-2 fw-light  {{ Route::is('wellify_classes.index') ? 'text_primary' : '' }}"
                                href="{{ route('wellify_classes.index') }}">Manage Classes</a></li>
                        <li><a class="dropdown-item py-2 fw-light {{ Route::is('wellify_activities.index') || Route::is('wellify_activities.media') ? 'text_primary' : '' }}"
                                href="{{ route('wellify_activities.index') }}">Manage Activities</a></li>
                        {{-- <li><a class="dropdown-item py-2 fw-light {{ Route::is('wellify/activities/*/media*') || ('wellify/activity/*/media-data*') ? 'text_primary' : '' }}"
                        href="{{ route('wellify/activities/*/media*') || ('wellify/activity/*/media-data*') }}">Manage
                        Activities</a>
            </li> --}}
            <li><a class="dropdown-item py-2 fw-light {{ Route::is('wellify-seeds.index') ? 'text_primary' : '' }}"
                    href="{{ route('wellify-seeds.index') }}">Manage Seeds</a></li>
        </ul>
        </div>
        </li>
        @endrole
        </ul>
    </nav>
</aside>
<main class="main" id="main">

    <header class="header">
        <label class="hamburger">
            <input type="checkbox">
            <svg viewBox="0 0 32 32" id="hamburger">
                <path class="line line-top-bottom"
                    d="M27 10 13 10C10.8 10 9 8.2 9 6 9 3.5 10.8 2 13 2 15.2 2 17 3.8 17 6L17 26C17 28.2 18.8 30 21 30 23.2 30 25 28.2 25 26 25 23.8 23.2 22 21 22L7 22">
                </path>
                <path class="line" d="M7 16 27 16"></path>
            </svg>
        </label>
        <div class="d-flex align-items-center justify-content-center gap-4 header_right">
            <div class="position-relative">
                <span>
                    <!-- <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                        <path
                            d="M24 10.667C24 8.54526 23.1571 6.51043 21.6569 5.01014C20.1566 3.50985 18.1217 2.66699 16 2.66699C13.8783 2.66699 11.8434 3.50985 10.3431 5.01014C8.84286 6.51043 8 8.54526 8 10.667C8 20.0003 4 22.667 4 22.667H28C28 22.667 24 20.0003 24 10.667Z"
                            stroke="#DDDDDD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        <path
                            d="M18.3067 28C18.0723 28.4041 17.7358 28.7395 17.331 28.9727C16.9262 29.2059 16.4672 29.3286 16 29.3286C15.5329 29.3286 15.0739 29.2059 14.6691 28.9727C14.2642 28.7395 13.9278 28.4041 13.6934 28"
                            stroke="#DDDDDD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg> -->
                </span>
                <!-- <span class="counter">12</span> -->
            </div>
            <span>
                <!-- <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                    <g clip-path="url(#clip0_2591_9679)">
                        <path
                            d="M16 20C18.2091 20 20 18.2091 20 16C20 13.7909 18.2091 12 16 12C13.7909 12 12 13.7909 12 16C12 18.2091 13.7909 20 16 20Z"
                            stroke="#DDDDDD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        <path
                            d="M25.8668 19.9997C25.6893 20.4018 25.6364 20.8479 25.7148 21.2805C25.7932 21.713 25.9994 22.1121 26.3068 22.4263L26.3868 22.5063C26.6348 22.754 26.8315 23.0481 26.9657 23.3718C27.0999 23.6956 27.1689 24.0426 27.1689 24.393C27.1689 24.7434 27.0999 25.0905 26.9657 25.4142C26.8315 25.7379 26.6348 26.032 26.3868 26.2797C26.1392 26.5276 25.8451 26.7243 25.5213 26.8585C25.1976 26.9927 24.8506 27.0618 24.5002 27.0618C24.1497 27.0618 23.8027 26.9927 23.479 26.8585C23.1553 26.7243 22.8612 26.5276 22.6135 26.2797L22.5335 26.1997C22.2193 25.8923 21.8201 25.6861 21.3876 25.6077C20.9551 25.5292 20.509 25.5822 20.1068 25.7597C19.7125 25.9287 19.3761 26.2093 19.1392 26.5671C18.9023 26.9248 18.7752 27.344 18.7735 27.773V27.9997C18.7735 28.7069 18.4925 29.3852 17.9924 29.8853C17.4923 30.3854 16.8141 30.6663 16.1068 30.6663C15.3996 30.6663 14.7213 30.3854 14.2212 29.8853C13.7211 29.3852 13.4402 28.7069 13.4402 27.9997V27.8797C13.4298 27.4383 13.287 27.0103 13.0302 26.6513C12.7734 26.2922 12.4145 26.0187 12.0002 25.8663C11.598 25.6889 11.1519 25.6359 10.7194 25.7143C10.2869 25.7928 9.88773 25.999 9.5735 26.3063L9.4935 26.3863C9.24583 26.6343 8.95173 26.831 8.628 26.9652C8.30427 27.0994 7.95727 27.1684 7.60683 27.1684C7.25639 27.1684 6.90938 27.0994 6.58565 26.9652C6.26193 26.831 5.96782 26.6343 5.72016 26.3863C5.47223 26.1387 5.27553 25.8446 5.14134 25.5208C5.00714 25.1971 4.93806 24.8501 4.93806 24.4997C4.93806 24.1492 5.00714 23.8022 5.14134 23.4785C5.27553 23.1548 5.47223 22.8607 5.72016 22.613L5.80016 22.533C6.10754 22.2188 6.31374 21.8197 6.39217 21.3871C6.47059 20.9546 6.41765 20.5085 6.24016 20.1063C6.07115 19.712 5.7905 19.3757 5.43278 19.1387C5.07506 18.9018 4.65588 18.7747 4.22683 18.773H4.00016C3.29292 18.773 2.61464 18.4921 2.11454 17.992C1.61445 17.4919 1.3335 16.8136 1.3335 16.1063C1.3335 15.3991 1.61445 14.7208 2.11454 14.2207C2.61464 13.7206 3.29292 13.4397 4.00016 13.4397H4.12016C4.56149 13.4294 4.9895 13.2865 5.34856 13.0297C5.70762 12.7729 5.98112 12.414 6.1335 11.9997C6.31098 11.5975 6.36393 11.1514 6.2855 10.7189C6.20708 10.2864 6.00088 9.88725 5.6935 9.57301L5.6135 9.49301C5.36556 9.24535 5.16887 8.95124 5.03467 8.62751C4.90047 8.30379 4.8314 7.95678 4.8314 7.60634C4.8314 7.2559 4.90047 6.90889 5.03467 6.58517C5.16887 6.26144 5.36556 5.96734 5.6135 5.71967C5.86116 5.47174 6.15526 5.27505 6.47899 5.14085C6.80272 5.00665 7.14972 4.93758 7.50016 4.93758C7.8506 4.93758 8.19761 5.00665 8.52134 5.14085C8.84506 5.27505 9.13917 5.47174 9.38683 5.71967L9.46683 5.79967C9.78107 6.10706 10.1802 6.31325 10.6127 6.39168C11.0452 6.47011 11.4913 6.41716 11.8935 6.23967H12.0002C12.3945 6.07066 12.7309 5.79001 12.9678 5.43229C13.2047 5.07457 13.3318 4.65539 13.3335 4.22634V3.99967C13.3335 3.29243 13.6144 2.61415 14.1145 2.11406C14.6146 1.61396 15.2929 1.33301 16.0002 1.33301C16.7074 1.33301 17.3857 1.61396 17.8858 2.11406C18.3859 2.61415 18.6668 3.29243 18.6668 3.99967V4.11967C18.6685 4.54872 18.7957 4.96791 19.0326 5.32563C19.2695 5.68335 19.6058 5.96399 20.0002 6.13301C20.4023 6.31049 20.8484 6.36344 21.2809 6.28501C21.7135 6.20659 22.1126 6.00039 22.4268 5.69301L22.5068 5.61301C22.7545 5.36507 23.0486 5.16838 23.3723 5.03418C23.696 4.89998 24.0431 4.83091 24.3935 4.83091C24.7439 4.83091 25.0909 4.89998 25.4147 5.03418C25.7384 5.16838 26.0325 5.36507 26.2802 5.61301C26.5281 5.86067 26.7248 6.15477 26.859 6.4785C26.9932 6.80223 27.0623 7.14923 27.0623 7.49967C27.0623 7.85012 26.9932 8.19712 26.859 8.52085C26.7248 8.84458 26.5281 9.13868 26.2802 9.38634L26.2002 9.46634C25.8928 9.78058 25.6866 10.1797 25.6082 10.6122C25.5297 11.0447 25.5827 11.4909 25.7602 11.893V11.9997C25.9292 12.394 26.2098 12.7304 26.5675 12.9673C26.9253 13.2042 27.3444 13.3313 27.7735 13.333H28.0002C28.7074 13.333 29.3857 13.614 29.8858 14.1141C30.3859 14.6142 30.6668 15.2924 30.6668 15.9997C30.6668 16.7069 30.3859 17.3852 29.8858 17.8853C29.3857 18.3854 28.7074 18.6663 28.0002 18.6663H27.8802C27.4511 18.6681 27.0319 18.7952 26.6742 19.0321C26.3165 19.269 26.0358 19.6053 25.8668 19.9997V19.9997Z"
                            stroke="#DDDDDD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </g>
                    <defs>
                        <clipPath id="clip0_2591_9679">
                            <rect width="32" height="32" fill="white" />
                        </clipPath>
                    </defs>
                </svg> -->
            </span>
            @php
            use Illuminate\Support\Facades\Auth;
            use Illuminate\Support\Facades\Storage;

            if(auth()->user()){
            $user = auth()->user();
            }else{
            $user = Auth::guard('staff')->user();
            }
            $fullName = trim("{$user->first_name} {$user->last_name}");
            $role = $user->getRoleNames()->first();

            $roleFormatted = match($role) {
            'superadmin' => 'Super Admin',
            'employer' => 'Employer',
            'employee' => ($user->supervisor_id == 2 ? 'Employer' : 'Employee'),
            default => ucfirst($role),
            };

            $defaultAvatar = asset('assets/images/default_logo.jfif');
            $profilePicUrl = $defaultAvatar;

            if ($user->profile_picture) {
            $s3Path = 'staging/users/' . $user->profile_picture;

            try {
            $profilePicUrl = Storage::disk('s3')->temporaryUrl(
            $s3Path,
            now()->addMinutes(10)
            );
            } catch (Exception $e) {
            // fallback to default if URL generation fails
            $profilePicUrl = $defaultAvatar;
            }
            }
            @endphp
            <div class="dropdown user_dropdown_header">
                <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <span>
                        <img src="{{ $profilePicUrl }}" alt="User Avatar" class="user_dropdown_img">
                    </span>
                    <span class="admin_name">
                        <span class="header_name">{{ $fullName }}</span>
                        <span class="user_role">{{ $roleFormatted }}</span>
                    </span>
                </button>

                <ul class="dropdown-menu w-100">
                    <li>
                        <a class="dropdown-item" href="{{ route('profile.show', $user->id) }}" id="user-profile">
                            Profile
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#" id="logout-button">
                            Logout
                        </a>
                    </li>
                </ul>
            </div>

        </div>
    </header>

    <script>
    var hamburger = document.getElementById("hamburger");
    var sidebar = document.getElementById("sidebar");
    var main = document.getElementById("main");

    hamburger.addEventListener("click", () => {
        sidebar.classList.toggle("sidebar_collapsed");
        main.classList.toggle("main_collapsed");
    });
    </script>
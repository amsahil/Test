<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="{{asset('assets/js/popperjs.js')}}"></script>
<script src="{{asset('assets/js/bootstrap.js')}}"></script>
<script src="{{ asset('assets/js/script.js') }}"></script>
<!-- datatables -->
<script src="{{asset('assets/js/datatable.js')}}"></script>
<script src="{{asset('assets/js/datatable_bootstrap.js')}}"></script>
<script src="{{asset('assets/js/datatable_responsive.js') }}"></script>
<script src="{{ asset('assets/js/sweetalert.min.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" defer></script>
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/js/script.js') }}"></script>




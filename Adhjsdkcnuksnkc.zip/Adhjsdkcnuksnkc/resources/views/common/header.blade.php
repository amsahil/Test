<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer List</title>
    <link rel="shortcut icon" href="{{asset('assets/images/logo_collpased.svg')}}">
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/responsive.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/datatable.bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/datatable_responsive.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/custom.css') }}">
    <link rel="stylesheet" href="assets/css/choice.css">
</head>

<body class="body">
<form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
        @csrf
    <p>Logout is rendering</p>

    </form>
</body>
</html>

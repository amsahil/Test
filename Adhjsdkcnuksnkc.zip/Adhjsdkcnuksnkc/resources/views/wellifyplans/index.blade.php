@extends('layouts.app')
@include('common.header')
@include('common.sidebar')

        <section class="main_card">
            <div class="nav nav-tabs d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block justify-content-between"
                id="nav-tab" role="tablist">
                <div
                    class="tabs_buttons d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block mb-xxl-0 mb-xl-0  mb-lg-0 mb-md-0 mb-3">
                    <button class="nav-link active mb-xxl-0 mb-xl-0  mb-lg-0 mb-md-0 mb-2" id="nav-home-tab"
                        data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab"
                        aria-controls="nav-home" aria-selected="true">B2B Plans</button>
                    <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile"
                        type="button" role="tab" aria-controls="nav-profile" aria-selected="false">DTC Plans</button>
                </div>
            </div>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"
                    tabindex="0">
                    <div class="cotainr-fluid">
                        <div class="row">
                            <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                                <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Plans For B2B</h5>
                                <div class="button_group d-flex gap-3">
                                    <button class="button primary_btn" type="button" data-bs-toggle="modal"
                                        data-bs-target="#add_new">
                                        Add Plan
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="row pt_24">
                            <div class="col-12">
                                <table id="example" class="table table-striped datatable mt-2 order-column nowrap">
                                    <thead>
                                        <tr>
                                            <th scope="col"></th>
                                            <th scope="col">Plan Name</th>
                                            <th scope="col">Free Trial</th>
                                            <th scope="col">Classes Per Week</th>
                                            <th scope="col">Activities Per Week</th>
                                            {{-- <th scope="col">Make Default</th> --}}
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"
                    tabindex="0">
                    <div class="cotainr-fluid">
                        <div class="row">
                            <!-- <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Plans For D2C</h5> -->
                             <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                                <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Plans For DTC</h5>
                                <div class="button_group d-flex gap-3">
                                </div>
                            </div>
                        </div>
                        <div class="row pt_24">
                            <div class="col-12">
                                <table id="responsiveTable"
                                    class="table stripe row-border order-column nowrap datatable mt-2">
                                    <thead>
                                        <tr>
                                            <th scope="col" style="text-align: left;"></th>
                                            <th scope="col" style="text-align: left;">Plan Name</th>
                                            <th scope="col" style="text-align: left;">Monthly Price</th>
                                            <th scope="col" style="text-align: left;">Free Trial</th>
                                            <th scope="col" style="text-align: left;">Classes Per Week</th>
                                            <th scope="col" style="text-align: left;">Activities Per Week</th>
                                            <th scope="col" style="text-align: left;">Status</th>
                                            <th scope="col" style="text-align: left;">Action</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <!-- modal for add new Employee -->

    <!-- Modal Add B2B Plan -->
    <div class="modal fade" id="add_new" data-bs-keyboard="false" tabindex="-1" aria-labelledby="add_newLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="add_newLabel">Add Pricing plan</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('plans.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                    <div class="container-fluid p-0">
                        <div class="row">
                            {{-- <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="employer_id" class="form-label">Select Employer <span class="text-danger">*</span></label>
                                <select class="form-control input" name="employer_id" required>
                                    <option value="" disabled selected>Select an Employer</option>
                                    @foreach($employers as $employer)
                                        <option value="{{ $employer->id }}">
                                            {{ $employer->username }}
                                        </option>
                                    @endforeach
                                </select>
                            </div> --}}
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="planName" class="form-label">Plan Name</label>
                                <input type="tel" class="form-control input" id="planName" name="plan_name" placeholder="Enter plan name"
                                    required tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="freeTrial" class="form-label">Free Trial</label>
                                <input type="text" class="form-control input" id="freeTrial" name="free_trial_days"
                                    placeholder="Enter free trial" tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="classweek" class="form-label">Classes Per Week</label>
                                <input type="text" class="form-control input" id="classweek" name="weekly_classes"
                                    placeholder="Enter weekly classes or Unlimited" required tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="activityweek" class="form-label">Activities Per Week</label>
                                <input type="text" class="form-control input" id="activityweek" name="weekly_activities"
                                    placeholder="Enter weekly activities or Unlimited" required tabindex="-1">
                            </div>
                            <div class="col-12">
                                <hr class="hr pb-3">
                            </div>
                            <div id="userRangeContainer">
                                <div class="col-12 user-range-row">
                                    <div class="row">
                                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                        <label for="user_range" class="form-label">User Range</label>
                                        <input type="text" class="form-control input" name="users_range[]" placeholder="eg. format - 100-200" required tabindex="-1">
                                    </div>
                                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                        <label for="monthly" class="form-label">Monthly Price/User</label>
                                        <input type="tel" class="form-control input" name="monthly_price[]" value="" required tabindex="-1">
                                    </div>
                                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-7 col-12 mb-3 d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block align-items-end gap-2">
                                        {{-- <div>
                                            <label for="annual" class="form-label">Annual Price/User</label>
                                            <input type="tel" class="form-control input" name="annual_price[]" value="" required tabindex="-1">
                                        </div> --}}
                                            <img src="assets/images/Add_icon.svg" alt="Add icon" class="img-fluid mb-2 float-xxl-left float-xl-left float-lg-left float-md-left float-end mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-3 add-icon" style="cursor:pointer;">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <label for="notes" class="form-label">Notes</label>
                                <textarea class="form-control input rounded-3" placeholder="Enter Notes" id="notes" name="notes"
                                    rows="2" tabindex="-1"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                            tabindex="-1">Close</button>
                        <button type="submit" class="button primary_btn m-0" id="submitBtn">
                            <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true" id="submitSpinner"></span>
                            <span class="btn-text">Submit</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Edit B2B-->
    <!-- Edit B2B Plan Modal -->
    <div class="modal fade" id="edit_b2b" data-bs-keyboard="false" tabindex="-1" aria-labelledby="edit_b2bLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <form id="editB2BPlanForm" method="POST" action="">
                    @csrf
                    @method('PUT')
                    <div class="modal-header">
                        <h3 class="modal-title fs-5" id="edit_b2bLabel">Edit B2B Pricing</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="plan_id" id="edit_plan_id">

                        <div class="container-fluid p-0">
                            <div class="row">
                                <div class="col-xxl-6 mb-3">
                                    <label class="form-label">Plan Name</label>
                                    <input type="text" class="form-control input" name="plan_name" id="edit_plan_name" required>
                                </div>
                                <div class="col-xxl-6 mb-3">
                                    <label class="form-label">Free Trial (days)</label>
                                    <input type="text" class="form-control input" name="free_trial_days" id="edit_free_trial">
                                </div>
                                <div class="col-xxl-6 mb-3">
                                    <label class="form-label">Classes Per Week</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control input" name="weekly_classes" id="edit_weekly_classes">
                                        <div class="input-group-text">
                                            <input type="checkbox" id="edit_unlimited_classes" class="form-check-input me-1">
                                            <label for="edit_unlimited_classes" class="form-check-label m-0">Unlimited</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xxl-6 mb-3">
                                    <label class="form-label">Activities Per Week</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control input" name="weekly_activities" id="edit_weekly_activities">
                                        <div class="input-group-text">
                                            <input type="checkbox" id="edit_unlimited_activities" class="form-check-input me-1">
                                            <label for="edit_unlimited_activities" class="form-check-label m-0">Unlimited</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <hr class="hr pb-3">
                                </div>

                                <div class="col-12 mb-3">

                                    <div id="edit_user_ranges_wrapper"></div>

                                </div>


                                {{-- <div id="edit_user_range_container">
                                    <!-- Add Icon to Add User Range -->
                                    <img src="assets/images/Add_icon.svg"
                                        alt="Add icon"
                                        id="addUserRangeEdit"
                                        class="img-fluid mb-2 float-xxl-left float-xl-left float-lg-left float-md-left float-end mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-3 add-icon"
                                        style="cursor:pointer;">

                                </div> --}}
                                <div class="col-12 mb-3">
                                    <label class="form-label">Notes</label>
                                    <textarea class="form-control input rounded-3" name="notes" id="edit_notes" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="button primary_btn m-0">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


   @if (session('success'))
        <script>
            swal({
                title: "Success!",
                text: "{{ session('success') }}",
                icon: "success",
                timer: 3000,
                buttons: false,
            });
        </script>
        @endif

        @if (session('error'))
        <script>
            swal({
                title: "Error!",
                text: "{{ session('error') }}",
                icon: "error",
                timer: 3000,
                buttons: false,
            });
        </script>
    @endif

    <!-- Modal Edit B2B-->

    <!-- Modal View B2B-->
    <div class="modal fade" id="view_user" data-bs-keyboard="false" tabindex="-1" aria-labelledby="view_userLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="view_userLabel">View Pricing Plan</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid p-0">
                        <div class="row">
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label class="form-label">Plan Name</label>
                                <p>Business to Business (B2B)</p>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label class="form-label">Free Trial</label>
                                <p>7 Days</p>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label class="form-label">Classes Per Week</label>
                                <p>Unlimited</p>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label class="form-label">Activities Per Week</label>
                                <p>Unlimited</p>
                            </div>
                            <div class="col-12">
                                <hr class="hr mt-0">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6 mb-1">
                                <label class="form-label">Users Range</label>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6 mb-1">
                                <label class="form-label">Monthly Price</label>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6">
                                <p class="mb-2">1-500</p>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6">
                                <p class="mb-2">$5.99/User</p>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6">
                                <p class="mb-2">501-2,000</p>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6">
                                <p class="mb-2">$5.00/User</p>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6">
                                <p class="mb-2">2,001-5,000</p>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6">
                                <p class="mb-2">$4.50/User</p>
                            </div>

                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6">
                                <p class="mb-2">5,001-10,000</p>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6">
                                <p class="mb-2">$4.00/User</p>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6">
                                <p class="mb-2">10,001+</p>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-6">
                                <p class="mb-2">$3.50/User</p>
                            </div>
                            <div class="col-12">
                                <hr class="hr">
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Note</label>
                                <ul>
                                    <li>Setup Fee (one-time): $500 per organization</li>
                                    <li>Program Cost: $1.00 per employee for a 30-day program</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer gap-3">
                    <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                        tabindex="-1">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-----------------------------------------------  Edit Free Plan pop-up  --------------------------------------------------->
    <!-- Modal Free Trial-->
    <div class="modal fade" id="editD2c" data-bs-keyboard="false" tabindex="-1" aria-labelledby="edit_b2bLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="editFreeLabel">Edit D2C Plan</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('plans.update-d2c-data') }}" method="POST">
                        @csrf
                    <div class="container-fluid p-0">
                        <div class="row">

                            <input type="hidden" name="plan_id" id="planIdEdit" value="">

                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="planNameEdit" class="form-label">Plan Name</label>
                                <input type="text" class="form-control input" id="planNameEdit"
                                    value="Business to business (B2B)" name="planNameEdit" required tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="freePlanmonth" class="form-label">Monthly Price</label>
                                <input type="text" class="form-control input" id="freePlanmonth" name="freePlanmonth"  required
                                    tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="freePlanclass" class="form-label">Classes Per Week</label>
                                <input type="text" class="form-control input" id="freePlanclass" name="freePlanclass"
                                    required tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="freePlanactivity" class="form-label">Activities Per Week</label>
                                <input type="text" class="form-control input" id="freePlanactivity" name="freePlanactivity"
                                    required tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="freePlantrial" class="form-label">Free Trial</label>
                                <input type="text" class="form-control input" id="freePlantrial" name="freePlantrial" required
                                    tabindex="-1">
                            </div>
                            <div class="col-12 mb-3">
                                <label for="editFreenotes" class="form-label">Notes</label>
                                <textarea class="form-control input rounded-3" placeholder="Enter Notes"
                                    id="editFreenotes" name="editFreenotes" rows="2"
                                    tabindex="-1">If a user does not subscribe after the trial, they are downgraded to freemium.</textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer gap-3">
                    <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                        tabindex="-1">Close</button>
                    <button class="button primary_btn m-0" type="submit" tabindex="-1">Submit</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Freemium-->
    <div class="modal fade" id="editFreemium" data-bs-keyboard="false" tabindex="-1" aria-labelledby="edit_b2bLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="editFreemiumLabel">Edit Freemium</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid p-0">
                        <div class="row">
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="editFreemiumName" class="form-label">Plan Name</label>
                                <input type="text" class="form-control input" id="editFreemiumName"
                                    value="Post Trial (Freemium)" required tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="editFreemiumprice" class="form-label">Monthly Price</label>
                                <input type="text" class="form-control input" id="editFreemiumprice" value="$0.00"
                                    required tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="editFreemiumclass" class="form-label">Classes Per Week</label>
                                <input type="text" class="form-control input" id="editFreemiumclass" value="1 Class"
                                    required tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="editFreemiumactivity" class="form-label">Activities Per Week</label>
                                <input type="text" class="form-control input" id="editFreemiumactivity"
                                    value="1 Activity" required tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="editFreemiumtrial" class="form-label">Free Trial</label>
                                <input type="text" class="form-control input" id="editFreemiumtrial" value="N/A"
                                    required tabindex="-1">
                            </div>
                            <div class="col-12 mb-3">
                                <label for="freemiumnotes" class="form-label">Notes</label>
                                <textarea class="form-control input rounded-3" placeholder="Enter Notes"
                                    id="freemiumnotes" rows="2"
                                    tabindex="-1">If a user does not subscribe after the trial, they are downgraded to freemium.</textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer gap-3">
                    <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                        tabindex="-1">Close</button>
                    <button class="button primary_btn m-0" type="submit" tabindex="-1">Submit</button>
                </div>
            </div>
        </div>
    </div>
    <!---------------------------------------------- Edit D2C pop-up ------------------------------------------------------------->
    <!-- Modal Free Trial-->
    <div class="modal fade" id="editD2c" data-bs-keyboard="false" tabindex="-1" aria-labelledby="edit_b2bLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="editD2cabel">Edit D2C</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid p-0">
                        <div class="row">
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="editD2cName" class="form-label">Plan Name</label>
                                <input type="text" class="form-control input" id="editD2cName"
                                    value="Direct to Consumer (DTC)" required tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="editD2ctrial" class="form-label">Free Trial</label>
                                <input type="text" class="form-control input" id="editD2ctrial" value="7 Days" required
                                    tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="editD2cprice" class="form-label">Monthly Price</label>
                                <input type="text" class="form-control input" id="editD2cprice" value="$7.99" required
                                    tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="editD2cannual" class="form-label">Annual Price</label>
                                <input type="text" class="form-control input" id="editD2cannual" value="$75.99" required
                                    tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="editD2cclass" class="form-label">Classes Per Week</label>
                                <input type="text" class="form-control input" id="editD2cclass" value="Unlimited"
                                    required tabindex="-1">
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="editD2cactivity" class="form-label">Activities Per Week</label>
                                <input type="text" class="form-control input" id="editD2cactivity" value="Unlimited"
                                    required tabindex="-1">
                            </div>
                            <div class="col-12 mb-3">
                                <label for="b2cnotes" class="form-label">Notes</label>
                                <textarea class="form-control input rounded-3" placeholder="Enter Notes" id="b2cnotes"
                                    rows="2"
                                    tabindex="-1">If a user does not subscribe after the trial, they are downgraded to freemium.</textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer gap-3">
                    <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                        tabindex="-1">Close</button>
                    <button class="button primary_btn m-0" type="submit" tabindex="-1">Submit</button>
                </div>
            </div>
        </div>
    </div>


<script>
    document.querySelector('form').addEventListener('submit', function () {
        const submitBtn = document.getElementById('submitBtn');
        const spinner = document.getElementById('submitSpinner');

        submitBtn.disabled = true;
        spinner.classList.remove('d-none');
    });

    $(document).ready(function() {
        $('#userRangeContainer').on('click', '.add-icon', function() {
            let newRow = $(this).closest('.user-range-row').clone();
            newRow.find('input').val('');
            $('#userRangeContainer').append(newRow);
        });
    });
</script>

<script>
    let b2bTable;
    let editUserRangeIndex = 0;

    function loadB2BPlans() {
        b2bTable = $('#example').DataTable({
            destroy: true,
            processing: true,
            serverSide: false,
            ajax: "{{ route('plans.b2b-data') }}",
            columns: [
                { data: null, defaultContent: '' },
                { data: 'plan_name' },
                { data: 'free_trial', defaultContent: 'N/A' },
                { data: 'weekly_classes' },
                { data: 'weekly_activities' },
                // {
                //     data: 'is_default',
                //     render: function (isDefault, type, row) {
                //         const checked = isDefault ? 'checked' : '';
                //         return `
                //             <div class="flipswitch1">
                //                 <input class="flipswitch1-cb toggle-default-plan" type="checkbox"
                //                     id="default_${row.id}" data-id="${row.id}" ${checked}>
                //                 <label for="default_${row.id}" class="flipswitch1-label">
                //                     <span class="flipswitch1-inner d-block"></span>
                //                     <span class="flipswitch1-switch d-block"></span>
                //                 </label>
                //             </div>
                //         `;
                //     },
                //     orderable: false,
                //     searchable: false,
                // },
                {
                    data: 'status',
                    render: function (data, type, row) {
                        let checked = data == 1 ? 'checked' : '';
                        return `
                            <div class="flipswitch">
                                <input class="flipswitch-cb toggle-status" type="checkbox" id="fs_${row.id}" data-id="${row.id}" ${checked}>
                                <label for="fs_${row.id}" class="flipswitch-label">
                                    <span class="flipswitch-inner d-block"></span>
                                    <span class="flipswitch-switch d-block"></span>
                                </label>
                            </div>
                        `;
                    },
                    orderable: false,
                    searchable: false,
                },
                {
                    data: 'id',
                    render: function (data) {
                        return `
                            <span class="edit_icon" title="Edit" onclick="fetchPlanDetails(${data})">
                                <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                                    <path d="M14.666 2.49993C14.8849 2.28106 15.1447 2.10744 15.4307 1.98899C15.7167 1.87054 16.0232 1.80957 16.3327 1.80957C16.6422 1.80957 16.9487 1.87054 17.2347 1.98899C17.5206 2.10744 17.7805 2.28106 17.9993 2.49993C18.2182 2.7188 18.3918 2.97863 18.5103 3.2646C18.6287 3.55057 18.6897 3.85706 18.6897 4.16659C18.6897 4.47612 18.6287 4.78262 18.5103 5.06859C18.3918 5.35455 18.2182 5.61439 17.9993 5.83326L6.74935 17.0833L2.16602 18.3333L3.41602 13.7499L14.666 2.49993Z" stroke="#A25AD9" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </span>
                        `;
                    },
                    orderable: false,
                    searchable: false,
                }
            ]
        });
    }

    $(document).on('change', '.toggle-default-plan', function () {
        const planId = $(this).data('id');
        const isChecked = $(this).is(':checked');

        $.ajax({
            url: '/plans/' + planId + '/toggle-default',
            type: 'POST',
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
                status: isChecked ? 1 : 0
            },
            success: function (res) {
                setTimeout(() => {
                    $('#example').DataTable().ajax.reload(null, false);
                }, 200);
            },
            error: function () {
                alert('Failed to update default plan.');
                $('#example').DataTable().ajax.reload(null, false);
            }
        });
    });

    function fetchPlanDetails(id) {
        fetch(`/plans/${id}/edit`)
            .then(async (res) => {
                if (!res.ok) throw new Error(`HTTP error! Status: ${res.status}`);
                const plan = await res.json();
                loadPlanForEdit(plan);
                $('#edit_b2b').modal('show');
            })
            .catch(error => {
                console.error("Error fetching plan:", error);
                alert("Error fetching plan details. Check console for details.");
            });
    }

    function loadPlanForEdit(plan) {
        $('#edit_plan_id').val(plan.id);
        $('#edit_plan_name').val(plan.name);
        $('#edit_free_trial').val(plan.trial_days);
        $('#edit_weekly_classes').val(plan.class_limit ?? 'Unlimited').prop('readonly', plan.class_limit === null);
        $('#edit_unlimited_classes').prop('checked', plan.class_limit === null);
        $('#edit_weekly_activities').val(plan.activity_limit ?? 'Unlimited').prop('readonly', plan.activity_limit === null);
        $('#edit_unlimited_activities').prop('checked', plan.activity_limit === null);
        $('#edit_notes').val(plan.notes ?? '');
        $('#editB2BPlanForm').attr('action', `/plans/${plan.id}`);
        $('#edit_user_ranges_wrapper').html('');
        editUserRangeIndex = 0;

        plan.ranges.forEach((range, index) => {
            const rangeText = `${range.users_range_min}${range.users_range_max ? '-' + range.users_range_max : '+'}`;
            addUserRangeRow(index, rangeText, range.mothly_price_per_user, range.yearly_price_per_user);
        });
    }

    function addUserRangeRow(index = null, range = '', monthly = '', annual = '') {
        const id = index ?? editUserRangeIndex++;
        $('#edit_user_ranges_wrapper').append(`
            <div class="row user-range-row mb-2" data-index="${id}">
                <div class="col-xxl-5 col-md-4 mb-2">
                    <input type="text" class="form-control input" name="users_range[]" placeholder="e.g. 1-100" value="${range}">
                </div>
                <div class="col-xxl-5 col-md-3 mb-2">
                    <input type="number" step="0.01" class="form-control input" name="monthly_price[]" placeholder="Monthly Price" value="${monthly}">
                </div>
                <div class="col-xxl-2 col-md-2 mb-2 d-flex align-items-center justify-content-center">
                    <img src="assets/images/Add_icon.svg" alt="Add icon" id="addUserRangeEdit" class="me-2 img-fluid float-xxl-left float-xl-left float-lg-left float-md-left float-end mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-3 add-icon">
                    <img src=" assets/images/Delete_icon.svg" alt="add icon" class="ms-2 img-fluid curser-pointer remove-range" >
                </div>
            </div>
        `);
    }

    // function addUserRangeRow(index = null, range = '', monthly = '', annual = '') {
    //     const id = index ?? editUserRangeIndex++;
    //     $('#edit_user_range_container').append(`
    //         <div class="row user-range-row mb-2" data-index="${id}">
    //             <div class="col-xxl-4 col-md-4 mb-2">
    //                 <input type="text" class="form-control input" name="users_range[]" placeholder="e.g. 1-100" value="${range}">
    //             </div>
    //             <div class="col-xxl-3 col-md-3 mb-2">
    //                 <input type="number" step="0.01" class="form-control input" name="monthly_price[]" placeholder="Monthly Price" value="${monthly}">
    //             </div>

    //             <div class="col-xxl-2 col-md-2 mb-2 d-flex align-items-center justify-content-center">

    //                 <button type="button" class="btn btn-sm btn-outline-danger remove-range">X</button>
    //             </div>
    //         </div>
    //     `);
    // }

    document.addEventListener("DOMContentLoaded", function () {
        loadB2BPlans();

        $('#addUserRangeEdit').on('click', function () {
            addUserRangeRow();
        });

        $('#edit_user_ranges_wrapper').on('click', '.remove-range', function () {
            $(this).closest('.user-range-row').remove();
        });

        $('#edit_unlimited_classes').on('change', function () {
            const input = $('#edit_weekly_classes');
            if (this.checked) {
                input.val('Unlimited').prop('readonly', true);
            } else {
                input.val('').prop('readonly', false);
            }
        });

        $('#edit_unlimited_activities').on('change', function () {
            const input = $('#edit_weekly_activities');
            if (this.checked) {
                input.val('Unlimited').prop('readonly', true);
            } else {
                input.val('').prop('readonly', false);
            }
        });
    });
</script>

<script>
    // Handle form submission for both add and edit
    $(document).ready(function() {
        var d2cTable;
        function loadD2CPlans() {
        const table = $('#responsiveTable').DataTable({
        processing: true,
        serverSide: false,
        ajax: '{{ route("plans.d2c-data") }}',
        columns: [
            { data: null, defaultContent: '' },
            { data: 'plan_name' },
            {
                data: 'price',
                defaultContent: 'N/A',
                render: function(data, type, row) {
                    if (data === null || data === undefined || data === '') {
                        return 'N/A';
                    }
                    return '$' + parseFloat(data).toFixed(2);
                }
            },
            { data: 'trial_days' },
            { data: 'weekly_classes' },
            { data: 'weekly_activities' },
            {
                data: 'status',
                render: function(data, type, row) {
                    const checked = data == 1 ? 'checked' : '';
                    return `
                        <div class="flipswitch">
                            <input class="flipswitch-cb toggle-d2c-status" type="checkbox"
                                id="d2c_fs_${row.id}" data-id="${row.id}" ${checked}>
                            <label for="d2c_fs_${row.id}" class="flipswitch-label">
                                <span class="flipswitch-inner d-block"></span>
                                <span class="flipswitch-switch d-block"></span>
                            </label>
                        </div>
                    `;
                }
            },
            {
                data: 'id',
                orderable: false,
                searchable: false,
                render: function(data) {
                    // Changed data-bs-target to #editD2c
                    return `
                        <span class="edit_icon" title="Edit" data-bs-toggle="modal"
                            data-bs-target="#editD2c" data-id="${data}" style="cursor:pointer;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                                <path d="M14.666 2.49993C14.8849 2.28106 15.1447 2.10744 15.4307 1.98899C15.7167 1.87054 16.0232 1.80957 16.3327 1.80957C16.6422 1.80957 16.9487 1.87054 17.2347 1.98899C17.5206 2.10744 17.7805 2.28106 17.9993 2.49993C18.2182 2.7188 18.3918 2.97863 18.5103 3.2646C18.6287 3.55057 18.6897 3.85706 18.6897 4.16659C18.6897 4.47612 18.6287 4.78262 18.5103 5.06859C18.3918 5.35455 18.2182 5.61439 17.9993 5.83326L6.74935 17.0833L2.16602 18.3333L3.41602 13.7499L14.666 2.49993Z"
                                    stroke="#A25AD9" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </span>
                    `;
                }
            }
        ]
    });

    // Handle edit icon click
    $('#responsiveTable tbody').on('click', '.edit_icon', function () {
            // Get the row data for the clicked row
            const rowData = table.row($(this).parents('tr')).data();

            if (!rowData) return;

            // Populate modal fields
            $('#planNameEdit').val(rowData.plan_name || '');
            $('#freePlanmonth').val(rowData.price != null ? '$' + parseFloat(rowData.price).toFixed(2) : '');
            $('#freePlanclass').val(rowData.weekly_classes || '');
            $('#freePlanactivity').val(rowData.weekly_activities || '');
            $('#freePlantrial').val(rowData.trial_days || '');
            $('#editFreenotes').val(rowData.notes || '');
            $('#planIdEdit').val(rowData.id);
            // Show the modal (Bootstrap 5)
            const editModal = new bootstrap.Modal(document.getElementById('editD2c'));
            editModal.show();
        });
    }

        loadB2BPlans();

        // On tab switch
        $('button[data-bs-toggle="tab"]').on('shown.bs.tab', function (e) {
            var target = $(e.target).data('bsTarget');
            if (target === '#nav-profile') {
                if (!$.fn.DataTable.isDataTable('#responsiveTable')) {
                    loadD2CPlans();
                }
            } else if (target === '#nav-home') { // B2B tab
                if (!$.fn.DataTable.isDataTable('#example')) {
                    loadB2BPlans();
                }
            }
        });
    });

    $(document).on('change', '.toggle-status', function() {
        const checkbox = $(this);
        const planId = checkbox.data('id');
        const status = checkbox.is(':checked') ? 1 : 0;

        $.ajax({
            url: '/plans/update-status',
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                id: planId,
                status: status
            },
            success: function(response) {
                swal({
                    title: "Success!",
                    text: "Status Updated successfully",
                    icon: "success",
                    timer: 3000,
                    buttons: false,
                });
            },
            error: function(xhr) {
                swal({
                    title: "Error!",
                    text: "Failed to update status",
                    icon: "error",
                    timer: 3000,
                    buttons: false,
                });
                // Optionally revert checkbox state
                checkbox.prop('checked', !status);
            }
        });
    });

    $(document).on('change', '.toggle-d2c-status', function () {
        const checkbox = $(this);
        const planId = checkbox.data('id');
        const status = checkbox.is(':checked') ? 1 : 0;

        $.ajax({
            url: '/plans/update-d2c-status',
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                id: planId,
                status: status
            },
            success: function (res) {
               swal({
                    title: "Success!",
                    text: "Status Updated successfully",
                    icon: "success",
                    timer: 3000,
                    buttons: false,
                });
            },
            error: function (err) {
                swal({
                    title: "Error!",
                    text: "Failed to update status",
                    icon: "error",
                    timer: 3000,
                    buttons: false,
                });
                checkbox.prop('checked', !status);
            }
        });
    });

    function toggleUserRangeFields() {
        const selectedType = $('#type').val();
        if (selectedType === 'dtc') {
            // Hide user range min/max fields
            $('#users_range_min').closest('.col-xxl-6').hide();
            $('#users_range_max').closest('.col-xxl-6').hide();
        } else {
            // Show user range min/max fields
            $('#users_range_min').closest('.col-xxl-6').show();
            $('#users_range_max').closest('.col-xxl-6').show();
        }
    }
    toggleUserRangeFields();

    $('#type').change(function() {
        toggleUserRangeFields();
    });

    $('.edit_icon').click(function(){
        $('#editD2c').toggle();
    })
</script>


    <!-- Modal delete plan-->
    <!-- <div class="modal fade" id="delete_user" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete_userLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body delete">
                    <div class="container-fluid px-0 py-3">
                        <div class="row">
                            <div class="col-12 text-center">
                                <img src="assets/images/warning.svg" alt="warning icon" class="img-fluid">
                                <h4 class="mt-4 text-danger">Delete This Plan?</h4>
                                <p class="mt-3 line_height_30"> This pricing plan will be deleted,<br>
                                    Are you sure you want to continue?</p>
                            </div>
                            <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                                    tabindex="-1">Cancel</button>
                                <button class="button primary_btn m-0 warning_button" type="submit"
                                    tabindex="-1">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->


    <!-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="assets/js/popperjs.js"></script>
    <script src="assets/js/bootstrap.js"></script>

    <script src="assets/js/datatable.js"></script>
    <script src="assets/js/datatable_bootstrap.js"></script>
    <script src="assets/js/datatable_responsive.js"></script>
    <script src="assets/js/datatable_select.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/alldata_table.js"></script>
</body>

</html> -->
{{-- <script>
    function fetchPlanDetails(id) {
        fetch(`/plans/${id}/edit`)
            .then(res => res.json())
            .then(plan => {
                if (plan && plan.id) {
                    loadPlanForEdit(plan); // this is already defined
                    $('#edit_b2b').modal('show');
                } else {
                    alert("Plan data not found.");
                }
            })
            .catch(error => {
                console.error("Fetch error:", error);
                alert("Error fetching plan details.");
            });
    }
</script> --}}

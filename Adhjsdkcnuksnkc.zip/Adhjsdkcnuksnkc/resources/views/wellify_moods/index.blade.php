{{-- @extends('layouts.app') --}}
@include('common.header')
@include('common.sidebar')
<head><meta name="csrf-token" content="{{ csrf_token() }}"></head>
 <section class="main_card">
    <div class="container-fluid">
        <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
            <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Manage Moods</h5>
            {{-- <button class="button primary_btn" type="button" data-bs-toggle="modal"
                data-bs-target="#add_new">
                Add New
            </button> --}}
        </div>
    </div>

    <div class="row pt_24">
        <div class="col-12">
            <table id="example" class="table table-striped datatable">
                <thead>
                    <tr>
                        <th scope="col"></th>
                        <th scope="col">ID</th>
                        <th scope="col">Mood Name</th>
                        <th scope="col">Header Image</th>
                        <th scope="col">Text color</th>
                        <th scope="col">Mood Color</th>
                        <th scope="col">Created On</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- DataTables will populate this -->
                </tbody>
            </table>
        </div>
    </div>
</section>
    <!-- Edit Mood Modal -->
    <div class="modal fade" id="editMoodModal" data-bs-keyboard="false" tabindex="-1" aria-labelledby="editMoodModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="editMoodModalLabel">Edit Mood</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
                </div>
                <form id="editMoodForm" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">
                        <div class="container-fluid p-0">
                            <div class="row">
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label for="moodId" class="form-label">Mood ID</label>
                                    <input type="text" class="form-control input" id="moodId" disabled tabindex="-1">
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label for="moodName" class="form-label">Mood Name</label>
                                    <input type="text" class="form-control input" id="moodName" name="title" readonly>
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label for="moodTextColor" class="form-label">Text Color</label>
                                    <select class="form-control input" id="moodTextColor" name="text_code" required>
                                        <option value="000000" >Black</option>
                                        <option value="ffffff" >White</option>
                                    </select>
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label for="moodColorCode" class="form-label">
                                        Mood Color <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" class="form-control input" id="moodColorCode" name="color_code" required readonly>
                                        <span class="input-group-text input_group">
                                            <input type="color" id="colorPicker">
                                        </span>
                                    </div>
                                    <small class="text-muted">Please select a color using the color picker only.</small>
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label for="moodImage" class="form-label">Header Image</label>
                                    <input type="file" class="form-control input" id="moodImage" name="image" accept=".svg,image/svg+xml">
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label class="form-label w-100">Current Image</label>
                                    <img id="currentMoodImage" src="" alt="Current Mood Image" class="logo-preview">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal" tabindex="-1">Cancel</button>
                        <button type="submit" class="button primary_btn m-0">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="{{ asset('assets/js/popperjs.js') }}"></script>
    <script src="{{ asset('assets/js/bootstrap.js') }}"></script>
    <script src="{{ asset('assets/js/script.js') }}"></script>

    {{-- DataTables --}}
    <script src="{{ asset('assets/js/datatable.js') }}"></script>
    <script src="{{ asset('assets/js/datatable_bootstrap.js') }}"></script>
    <script src="{{ asset('assets/js/datatable_responsive.js') }}"></script>
<!-- SweetAlert2 -->

<!-- Toastr -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
    $(document).ready(function() {


        const table = $('#example').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('wellify_moods.data') }}",
            columns: [
                { data: 'dummy', orderable: false, searchable: false },
                { data: 'id' },
                { data: 'title' , orderable: true, searchable: true},
                { data: 'image', orderable: true, searchable: true },
                { data: 'text_code', orderable: true, searchable: true},
                { data: 'color_code', orderable: true, searchable: true },
                { data: 'created_on',name:'created_at', orderable: true, searchable: true },
                { data: 'status', orderable: true, searchable: true },
                { data: 'action', orderable: false, searchable: false }
            ],
            order: [[3, 'desc']],
            columnDefs: [{
                // targets: 0,
                render: function(data, type, row, meta) {
                    return meta.row ;
                }
            }]
        });
    });
</script>
<script>

$(document).on('change', '.toggle-status', function () {
    var checkbox = $(this);
    var moodId = checkbox.data('id');
    var status = checkbox.is(':checked') ? 1 : 0;

    $.ajax({
        url: '/wellify_moods/toggle-status/' + moodId,
        method: 'POST',
        data: {
            _token: $('meta[name="csrf-token"]').attr('content'),
            status: status
        },
        success: function (response) {
            toastr.success(response.message);
        },
        error: function (xhr) {
            // revert the checkbox
            checkbox.prop('checked', !checkbox.is(':checked'));

            if (xhr.responseJSON && xhr.responseJSON.message) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Limit Reached',
                    text: xhr.responseJSON.message
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops!',
                    text: 'Something went wrong while updating the status.'
                });
            }
        }
    });
});
</script>
<script>
$(document).on('click', '.edit-mood-btn', function () {
    var moodId = $(this).data('id');
    $.ajax({
        url: "{{ url('wellify_moods') }}/" + moodId + "/edit",
        type: "GET",
        success: function (response) {
            $('#moodId').val(response.id);
            $('#moodName').val(response.title);
            $('#moodTextColor').val(response.text_code).trigger('change');
            $('#currentMoodImage').attr('src', response.image_url);
            $('#moodColorCode').val(response.color_code);
            $('#colorPicker').val(response.color_code);
            $('#editMoodModal').modal('show');
        },
        error: function (xhr) {
            toastr.error('Failed to fetch mood details');
        }
    });
});

// Update preview color when moodColorCode changes via picker
$('#colorPicker').on('change', function () {
    $('#moodColorCode').val($(this).val());
});

// Text color dropdown preview (black or white)
$('#moodTextColor').on('change', function () {
    const selectedColor = $(this).val();
    $('#textColorPreview').css('color', '#' + selectedColor);
});

// Form submission
$('#editMoodForm').on('submit', function (e) {
    e.preventDefault();
    var moodId = $('#moodId').val();
    var formData = new FormData(this);

    $.ajax({
        url: "{{ url('wellify_moods') }}/" + moodId,
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function (response) {
            $('#editMoodModal').modal('hide');
            location.reload();
        },
        error: function (xhr) {
            if (xhr.responseJSON && xhr.responseJSON.errors) {
                $.each(xhr.responseJSON.errors, function (key, value) {
                    toastr.error(value);
                });
            } else {
                toastr.error('Failed to update mood');
            }
        }
    });
});
</script>


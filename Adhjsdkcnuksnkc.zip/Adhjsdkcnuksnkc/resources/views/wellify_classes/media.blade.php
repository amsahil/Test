{{-- @extends('layouts.app') --}}
@include('common.header')
@include('common.sidebar')
<style>
    #classMediaTable tbody tr[draggable="true"] {
        cursor: move;
    }

    .border_draggable {
        border: 2px dashed #a25ad9 !important;
    }
</style>
    <section class="main_card">
        <div class="container-fluid">
            <div class="row">
                <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                    <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">{{ $class->title }}</h5>
                    <button class="button primary_btn" type="button" data-bs-toggle="modal" data-bs-target="#add_new">
                        Add New
                    </button>
                </div>
            </div>
            <div class="row pt_24">
                <div class="col-12">
                    <input type="hidden" id="class_id" value="{{ $class->id }}">
                    <table class="table table-striped datatable" id="classMediaTable">
                        <thead>
                            <tr>
                                <th scope="col"></th>
                                    {{-- <th scope="col">ID</th> --}}
                                    <th scope="col">Image</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </section>

    <!-- Add New Modal -->
    <div class="modal fade" id="add_new" data-bs-keyboard="false" tabindex="-1" aria-labelledby="add_newLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form id="uploadMediaForm" enctype="multipart/form-data">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title fs-5" id="add_newLabel">Add New Images</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                            tabindex="-1"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container-fluid p-0">
                            <input type="hidden" name="class_id" id="media-class-id" value="{{ $class->id }}">
                            <div id="media-upload-container">
                                <div class="row media-upload-block">
                                    <div class="col-12 mb-3">
                                        <label class="form-label">Upload Image <span class="text-danger">*</span></label>
                                        <input type="file" name="media[]" class="form-control input media-input" accept=".svg,image/svg+xml" required>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <label class="form-label">Description <span class="text-danger">*</span></label>
                                        <textarea name="description[]" class="form-control input rounded-3" rows="3" required></textarea>
                                    </div>
                                </div>
                            </div>
                            {{-- <button type="button" class="btn btn-secondary btn-sm mb-3" id="add-more-upload">+ Add More</button> --}}
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="button primary_btn m-0">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Edit image-->
    <div class="modal fade" id="edit_user3" data-bs-keyboard="false" tabindex="-1" aria-labelledby="edit_userLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <form id="editImageForm" method="POST" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" id="edit_media_id" name="media_id">
                    <div class="modal-header">
                        <h3 class="modal-title fs-5">Edit Image</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container-fluid p-0">
                            <div class="row">
                                {{-- <div class="col-12 mb-3 text-center">
                                    <img id="currentImagePreview" src="" alt="Preview" style="max-height: 150px;">
                                </div> --}}
                                <div class="col-12 mb-3">
                                    <label for="upload-img1" class="form-label">Change Image</label>
                                    <input type="file" class="form-control input" id="upload-img1" accept=".svg,image/svg+xml" name="media">
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="imageDesc" class="form-label">Description</label>
                                    <textarea class="form-control input rounded-3" placeholder="Enter Description"
                                        id="imageDesc" name="description" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Close</button>
                        <button class="button primary_btn m-0" type="submit">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="modal fade" id="delete_user" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete_userLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body delete">
                    <input type="hidden" id="delete_media_id">
                    <div class="container-fluid px-0 py-3">
                        <div class="row">
                            <div class="col-12 text-center">
                                   @php
                                $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/warning.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{   $warningImageUrl }}" alt="warning icon" class="img-fluid">
                                <h4 class="mt-4 text-danger">Delete This Image?</h4>
                                <p class="mt-3 line_height_30"> This Image and Descriptions will be deleted.<br>
                                    Are you sure you want to continue?</p>
                            </div>
                            <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                                    tabindex="-1">Cancel</button>
                                <button class="button primary_btn m-0 warning_button" type="submit"
                                    tabindex="-1">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


 <script src="{{ asset('assets/js/popperjs.js') }}"></script>
    <script src="{{ asset('assets/js/bootstrap.js') }}"></script>
    <script src="{{ asset('assets/js/script.js') }}"></script>

    {{-- DataTables --}}
    <script src="{{ asset('assets/js/datatable.js') }}"></script>
    <script src="{{ asset('assets/js/datatable_bootstrap.js') }}"></script>
    <script src="{{ asset('assets/js/datatable_responsive.js') }}"></script>


<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    });
</script>
<script>
    $(document).ready(function() {
        let classId = "{{ $class->id }}";
        $('#classMediaTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: '{{ url("/wellify/class") }}/' + classId + '/media-data',
            columns: [
                // { data: null, defaultContent: '', orderable: false, searchable: false },
                { data: 'dummy', orderable: false, searchable: false},
                // { data: 'id',orderable: true, searchable: true },
                { data: 'image', orderable: true, searchable: true },
                { data: 'description', orderable: true, searchable: true },
                { data: 'action', orderable: false, searchable: false }
            ],
            createdRow: function (row, data, dataIndex) {
                row.setAttribute('data-id', data.id);
                row.setAttribute('draggable', true);
            },
            order: [[5, 'desc']]
        });
    });
</script>

<script>
    $(document).ready(function () {
        // Add more upload inputs
        $('#add-more-upload').click(function () {
            const block = `
            <div class="row media-upload-block">
                <div class="col-12 mb-3">
                    <label class="form-label">Upload Image</label>
                    <input type="file" name="media[]" class="form-control input media-input" required>
                </div>
                <div class="col-12 mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="description[]" class="form-control input rounded-3" rows="3" required></textarea>
                </div>
            </div>`;
            $('#media-upload-container').append(block);
        });

        // Submit form
        $('#uploadMediaForm').on('submit', function (e) {
            e.preventDefault();

            let formData = new FormData(this);

            $.ajax({
                url: '{{ route("class-media.upload") }}',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (response) {
                    if (response.success) {
                        $('#add_new').modal('hide');
                        $('#uploadMediaForm')[0].reset();
                        $('.media-upload-block').not(':first').remove(); // Keep only one block

                        location.reload();
                    } else {
                        alert(response.message || 'Upload failed.');
                    }
                },
                error: function (xhr) {
                    alert(xhr.responseJSON.message || 'Server error.');
                }
            });
        });

        // Open modal and populate fields
        $(document).on('click', '.edit_icon', function () {
            let mediaId = $(this).data('id');

            $.ajax({
                url: `/class-media/${mediaId}`,
                method: 'GET',
                success: function (res) {
                    $('#edit_media_id').val(res.id);
                    $('#imageDesc').val(res.description);
                    $('#currentImagePreview').attr('src', res.preview_url);
                    $('#edit_user3').modal('show');
                },
                error: function () {
                    alert('Failed to fetch media details.');
                }
            });
        });

        $('#editImageForm').on('submit', function (e) {
            e.preventDefault();

            let formData = new FormData(this);

            $.ajax({
                url: `/class-media/update`,
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function () {
                    $('#edit_user3').modal('hide');
                    $('#media-table').DataTable().ajax.reload(null, false);
                    location.reload();
                },
                error: function () {
                    alert('Update failed');
                }
            });
        });


        // Submit edit form
        $('#editMediaForm').on('submit', function (e) {
            e.preventDefault();
            let formData = new FormData(this);
            formData.append('_token', '{{ csrf_token() }}');
            formData.append('_method', 'POST');

            $.ajax({
                url: '{{ route("class-media.update") }}',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (res) {
                    if (res.success) {
                        $('#edit_user3').modal('hide');
                        $('#editMediaForm').DataTable().ajax.reload();
                        location.reload();
                    } else {
                        alert(res.message || 'Update failed');
                    }
                },
                error: function (xhr) {
                    alert(xhr.responseJSON.message || 'Server error');
                }
            });
        });


        let deleteId = null;

        $(document).on('click', '.delete_icon', function () {
            deleteId = $(this).data('id');
            $('#delete_media_id').val(deleteId);
            $('#delete_user').modal('show');
        });

        $('.warning_button').on('click', function () {
            let id = $('#delete_media_id').val();

            $.ajax({
                url: `/class-media/delete/${id}`,
                method: 'DELETE',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: function () {
                    $('#delete_user').modal('hide');
                    $('#media-table').DataTable().ajax.reload(null, false);
                    location.reload();
                },
                error: function () {
                    alert('Failed to delete image.');
                }
            });
        });
    });


</script>
{{-- <script>
    document.addEventListener('DOMContentLoaded', function () {
        let table = document.getElementById('classMediaTable');
        let draggedRow = null;

        table.addEventListener('dragstart', function (e) {
            if (e.target.tagName === 'TR') {
                draggedRow = e.target;
                e.dataTransfer.effectAllowed = 'move';
            }
        });

        table.addEventListener('dragover', function (e) {
            e.preventDefault();
            const targetRow = e.target.closest('tr');
            if (targetRow && draggedRow !== targetRow) {
                targetRow.classList.add('border_draggable');
            }
        });

        table.addEventListener('dragleave', function (e) {
            const targetRow = e.target.closest('tr');
            if (targetRow) {
                targetRow.classList.remove('border_draggable');
            }
        });

        table.addEventListener('drop', function (e) {
            e.preventDefault();
            const targetRow = e.target.closest('tr');
            if (draggedRow && targetRow && draggedRow !== targetRow) {
                const tbody = table.querySelector('tbody');
                tbody.insertBefore(draggedRow, targetRow.nextSibling);

                table.querySelectorAll('.border_draggable').forEach(el => el.classList.remove('border_draggable'));
                const orderedIds = Array.from(tbody.querySelectorAll('tr')).map(tr => tr.getAttribute('data-id'));

                fetch('/class-media/update-sequence', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify({ ids: orderedIds })
                })
                .then(res => {
                    if (!res.ok) {
                        throw new Error('Fetch failed with status ' + res.status);
                    }
                    return res.json();
                })
                .then(data => {
                    console.log('Success:', data.message);
                })
                .catch(err => {
                    console.error('Fetch error:', err);
                    alert('Error: ' + err.message);
                });
            }
        });
    });
</script> --}}
<script>
    document.addEventListener('DOMContentLoaded', function () {
        let table = document.getElementById('classMediaTable');
        let draggedRow = null;

        table.addEventListener('dragstart', function (e) {
            if (e.target.tagName === 'TR') {
                draggedRow = e.target;
                e.dataTransfer.effectAllowed = 'move';
            }
        });

        table.addEventListener('dragover', function (e) {
            e.preventDefault();
            const targetRow = e.target.closest('tr');
            if (targetRow && draggedRow !== targetRow) {
                targetRow.classList.add('border_draggable');
            }
        });

        table.addEventListener('dragleave', function (e) {
            const targetRow = e.target.closest('tr');
            if (targetRow) {
                targetRow.classList.remove('border_draggable');
            }
        });

        table.addEventListener('drop', function (e) {
            e.preventDefault();
            const targetRow = e.target.closest('tr');

            if (draggedRow && targetRow && draggedRow !== targetRow) {
                // Remove visual highlight
                table.querySelectorAll('.border_draggable').forEach(el => el.classList.remove('border_draggable'));

                const draggedId = draggedRow.getAttribute('data-id');
                const targetId = targetRow.getAttribute('data-id');

                fetch('/class-media/swap-sequence', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify({
                        dragged_id: draggedId,
                        target_id: targetId
                    })
                })
                .then(res => {
                    if (!res.ok) throw new Error('Fetch failed with status ' + res.status);
                    return res.json();
                })
                .then(data => {
                    console.log('Swapped:', data.message);
                    location.reload(); // reload to reflect changes
                })
                .catch(err => {
                    console.error('Swap error:', err);
                    alert('Error: ' + err.message);
                });
            }
        });
    });
</script>
{{-- <script>
    document.addEventListener('DOMContentLoaded', function () {
        let table = document.getElementById('classMediaTable');
        let draggedRow = null;

        table.addEventListener('dragstart', function (e) {
            const row = e.target.closest('tr');
            if (row) {
                draggedRow = row;
                e.dataTransfer.effectAllowed = 'move';
            }
        });

        table.addEventListener('dragover', function (e) {
            e.preventDefault();
            const targetRow = e.target.closest('tr');
            if (targetRow && draggedRow !== targetRow) {
                targetRow.classList.add('border_draggable');
            }
        });

        table.addEventListener('dragleave', function (e) {
            const targetRow = e.target.closest('tr');
            if (targetRow) {
                targetRow.classList.remove('border_draggable');
            }
        });

        table.addEventListener('drop', function (e) {
            e.preventDefault();
            const targetRow = e.target.closest('tr');
            if (draggedRow && targetRow && draggedRow !== targetRow) {
                const tbody = table.querySelector('tbody');
                tbody.insertBefore(draggedRow, targetRow.nextSibling);

                table.querySelectorAll('.border_draggable').forEach(el => el.classList.remove('border_draggable'));

                const orderedIds = Array.from(tbody.querySelectorAll('tr')).map(tr => tr.getAttribute('data-id'));

                fetch('/class-media/update-sequence', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify({ ids: orderedIds })
                })
                .then(res => {
                    if (!res.ok) throw new Error('Fetch failed with status ' + res.status);
                    return res.json();
                })
                .then(data => {
                    console.log('Sequence updated:', data.message);
                })
                .catch(err => {
                    console.error('Error:', err);
                    alert('Update failed: ' + err.message);
                });
            }
        });
    });
</script> --}}

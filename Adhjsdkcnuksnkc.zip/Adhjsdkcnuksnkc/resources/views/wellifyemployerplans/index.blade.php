@extends('layouts.app')
@include('common.header')
@include('common.sidebar')

@if(Auth::user()->hasRole('Employer'))
    @if($plans->count())
        <div class="row mt-4">
            <h4>Available Plans</h4>
            @foreach($plans as $plan)
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm rounded p-3">
                        <h5>{{ $plan->name }}</h5>
                        <p><strong>Trial:</strong> {{ $plan->trial_days ?? 'No Trial' }} days</p>
                        <p><strong>Classes/week:</strong> {{ $plan->class_limit ?? 'Unlimited' }}</p>
                        <p><strong>Activities/week:</strong> {{ $plan->activity_limit ?? 'Unlimited' }}</p>
                        <ul class="list-group list-group-flush mt-2">
                            @foreach($plan->ranges as $range)
                                <li class="list-group-item">
                                    <strong>{{ $range->users_range_min }}-{{ $range->users_range_max ?? '+' }} Users:</strong>
                                    ${{ $range->mothly_price_per_user }} per user/month
                                </li>
                            @endforeach
                        </ul>
                        @if($plan->notes)
                            <p class="mt-2"><em>{{ $plan->notes }}</em></p>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>
    @else
        <p>No plans available at the moment.</p>
    @endif
@endif


<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\WellifyUser; // Import the Employer model

class EmployerAdditionalSlotsPaidNotification extends Notification implements ShouldQueue
{
    use Queueable;

    protected $employer;
    protected $additionalSlots;

    /**
     * Create a new notification instance.
     */
    public function __construct(WellifyUser $employer, int $additionalSlots)
    {
        $this->employer = $employer;
        $this->additionalSlots = $additionalSlots;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
                    ->subject('Employer Purchased Additional Employee Slots')
                    ->line('Employer "' . $this->employer->organization . '" (ID: ' . $this->employer->id . ') has successfully purchased ' . $this->additionalSlots . ' additional employee slots.')
                    ->line('Their new total paid employee limit is now: ' . $this->employer->number_of_users . ' slots.')
                    ->action('View Employer Details', url('/admin/employers/' . $this->employer->id . '/edit')) // Adjust URL to your employer view/edit route
                    ->line('Please review their account as needed.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            'employer_id' => $this->employer->id,
            'employer_name' => $this->employer->organization,
            'additional_slots_purchased' => $this->additionalSlots,
            'new_total_slots' => $this->employer->number_of_users,
            'message' => 'Additional employee slots purchased by employer.',
        ];
    }
}
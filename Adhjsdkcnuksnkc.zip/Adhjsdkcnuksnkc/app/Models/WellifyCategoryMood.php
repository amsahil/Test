<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\WellifyCategory;
use App\Models\WellifyMood;

class WellifyCategoryMood extends Model
{
    protected $table = 'wellify_category_mood';
    protected $primaryKey = 'id';
    public $timestamps = true;

    public function category()
    {
        return $this->belongsTo(WellifyCategory::class, 'category_id');
    }

    public function mood()
    {
        return $this->belongsTo(WellifyMood::class, 'mood_id', 'id');
    }

}

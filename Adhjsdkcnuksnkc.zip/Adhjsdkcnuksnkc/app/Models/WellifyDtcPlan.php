<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WellifyDtcPlan extends Model
{
    protected $table = 'wellify_dtc_subscription_plan';

    protected $fillable = [
        'name',
        'duration',
        'trial_days',
        'price',
        'class_limit',
        'activity_limit',
        'is_freemium',
        'status',
        'notes',
    ];
}

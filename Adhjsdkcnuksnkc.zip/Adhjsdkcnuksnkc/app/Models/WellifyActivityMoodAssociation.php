<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyMood;
use App\Models\WellifyActivity;

class WellifyActivityMoodAssociation extends Model
{
    use SoftDeletes;
    protected $table = 'wellify_activity_mood_associations';

    protected $fillable = [
        'activity_id','mood_id',
    ];   

    public function class()
    {
        return $this->belongsTo(WellifyActivity::class, 'activity_id');
    }

    public function mood()
    {
        return $this->belongsTo(WellifyMood::class, 'mood_id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\WellifyCategory;
use Illuminate\Database\Eloquent\SoftDeletes;

class WellifyMood extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_moods';

    protected $fillable = [
        'title',
        'description',
        'wellify_types_id',
    ];

    public function type()
    {
        return $this->belongsTo(WellifyType::class, 'wellify_types_id');
    }

    public function categories()
    {
        return $this->belongsToMany(WellifyCategory::class, 'category_id');
    }
    public function moods()
    {
        return $this->hasMany(WellifyCategoryMood::class,'mood_id', 'id');
    }


    public function creator() {
        return $this->belongsTo(User::class, 'created_by');
    }

}

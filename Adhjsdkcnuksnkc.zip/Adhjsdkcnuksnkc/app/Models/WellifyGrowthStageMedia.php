<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WellifyGrowthStageMedia extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_growth_stage_media';

    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $fillable = [
        'growth_stage_id',
        'seed_id',
        'media',
        'media_type','description',
        'status','is_update','sequence_no'
    ];

    public function growthStage()
    {
        return $this->belongsTo(WellifyGrowthStage::class, 'growth_stage_id');
    }
    public function seed()
    {
        return $this->belongsTo(WellifySeed::class, 'seed_id');
    }
}

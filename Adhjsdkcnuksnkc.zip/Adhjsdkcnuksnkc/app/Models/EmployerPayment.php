<?php

namespace App\Models;

use App\Models\Employer\Employee;
use Illuminate\Database\Eloquent\Model;

class EmployerPayment extends Model
{
    protected $fillable = [
        'employer_id',
        'app_user_id',
        'stripe_payment_id',
        'stripe_checkout_session_id',
        'stripe_customer_id',
        'amount_paid',
        'currency',
        'status',
        'paid_at',
        'payment_method',
        'card_brand',
        'card_last4',
        'receipt_url',
        'customer_email',
        'app_users_count',
    ];

    // public function employer()
    // {
    //     return $this->belongsTo(WellifyUser::class);
    // }

    public function employer()
    {
        return $this->belongsTo(WellifyUser::class, 'employer_id');
    }

    public function appUser()
    {
        return $this->belongsTo(Employee::class, 'app_user_id');
    }
}



<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyClass;
use App\Models\WellifyUser;

class WellifyClassCompletion extends Model
{
    use SoftDeletes;
    protected $table = 'wellify_users_class_completions';

    protected $casts = [
        'class_id' => 'string',
    ];

    protected $fillable = [
        'user_id','class_id','is_completed','completed_at',
    ];

    public function classes()
    {
        return $this->belongsToMany(WellifyClass::class, 'class_id');
    }

    public function users()
    {
        return $this->belongsToMany(WellifyUser::class, 'user_id');
    }
}

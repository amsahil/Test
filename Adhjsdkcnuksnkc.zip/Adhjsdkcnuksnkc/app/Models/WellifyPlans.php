<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class WellifyPlans extends Model
{
    use HasFactory;
    protected $table = 'wellify_subscription_plans';

    protected $fillable = [
        'employer_id',
        'name',
        'duration',
        'trial_days',
        'class_limit',
        'activity_limit',
        'is_freemium',
        'status',
        'notes',
        'is_default',
    ];

    public function ranges()
    {
        return $this->hasMany(WellifyPlansRange::class, 'plan_id');
    }



}

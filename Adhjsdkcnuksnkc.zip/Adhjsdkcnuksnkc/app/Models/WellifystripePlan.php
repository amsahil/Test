<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WellifystripePlan extends Model
{
    protected $table = 'wellify_subscription_plans';

    protected $fillable = [
        'stripe_product_id',
        'stripe_price_id',
        'name',
        'currency',
        'amount',
        'interval'
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyActivity;

class WellifyActivityMedia extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_activity_media';
    protected $casts = [
        'activity_id' => 'string'
    ];

    protected $fillable = [
        'activity_id','media','media_type','description','status',
    ];

    public function activity()
    {
        return $this->belongsToMany(WellifyActivity::class, 'activity_id');
    }

    public function mediaTypes()
    {
        return $this->belongsToMany(WellifyActivityMedia::class, 'id');
    }

}

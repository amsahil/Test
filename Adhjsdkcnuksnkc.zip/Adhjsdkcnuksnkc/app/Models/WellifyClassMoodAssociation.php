<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyClass;
use App\Models\WellifyMood;
use App\Models\WellifyActivity;

class WellifyClassMoodAssociation extends Model
{
    // use SoftDeletes;
    protected $table = 'wellify_class_mood_associations';

    protected $fillable = [
        'class_id','mood_id',
    ];

    public function class()
    {
        return $this->belongsTo(WellifyClass::class, 'class_id');
    }

    public function mood()
    {
        return $this->belongsTo(WellifyMood::class, 'mood_id');
    }
}

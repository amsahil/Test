<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WellifyActivityCategory extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_activity_categories';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id','title','image','short_description','detailed_description','status'
    ];

    public function moods()
    {
        return $this->hasMany(WellifyCategoryMood::class,'mood_id', 'id');
    }
    public function activities()
    {
        return $this->hasMany(WellifyActivity::class, 'activity_category_id');
    }
}

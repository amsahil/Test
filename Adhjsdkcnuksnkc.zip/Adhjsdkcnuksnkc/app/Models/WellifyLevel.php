<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyCategory;
use App\Models\WellifyMood;

class WellifyLevel extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_levels';

    protected $fillable = [ 'title' ];

}

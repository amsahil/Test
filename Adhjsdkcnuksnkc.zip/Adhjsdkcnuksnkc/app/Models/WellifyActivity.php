<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyClass;
use App\Models\WellifyMood;
use App\Models\WellifyLevel;

class WellifyActivity extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_activities';
    protected $dates = ['deleted_at'];
    protected $casts = ['class_id' => 'string'];
    protected $primaryKey = 'activity_id';
    public $incrementing = false;
    protected $fillable = [
        'activity_id','title','description','background_image',
        'class_id','mood_id','level_id','points_on_completion',
        'water_on_completion','prerequisite_class','status',
        'media_status','activity_category_id'
    ];

    public function category()
    {
        return $this->belongsTo(WellifyActivityCategory::class, 'activity_category_id','id');
    }
    public function classes()
    {
        return $this->belongsToMany(WellifyClass::class, 'category_id');
    }
    public function moods()
    {
        return $this->belongsToMany(WellifyMood::class, 'wellify_activity_mood_associations', 'activity_id', 'mood_id', 'activity_id', 'id');
    }
    public function levels()
    {
        return $this->belongsTo(WellifyLevel::class, 'level_id');
    }

    public function media()
    {
        return $this->hasMany(WellifyActivityMedia::class,'activity_id','activity_id');
    }
    public function prerequisiteClass()
    {
        return $this->belongsTo(WellifyClass::class, 'prerequisite_class', 'id');
    }
}

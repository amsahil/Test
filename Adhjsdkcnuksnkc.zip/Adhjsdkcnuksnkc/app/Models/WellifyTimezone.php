<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class WellifyTimezone extends Model
{
    protected $table = 'wellify_timezones';
    protected $fillable = [
        'abbreviation',
        'full_name',
        'utc_offset',
        'tz_identifier',
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WellifyGrowthStage extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_growth_stages';
    protected $primaryKey = 'id';
    public $timestamps = true;

    protected $fillable = [
        'title',
        'description',
        'water_droplet_needed',
    ];

    public function growthStageMedia()
    {
        return $this->hasMany(WellifyGrowthStageMedia::class, 'growth_stage_id');
    }

}

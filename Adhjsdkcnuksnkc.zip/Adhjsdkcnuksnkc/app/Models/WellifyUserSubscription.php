<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WellifyUserSubscription extends Model
{
    protected $table = 'wellify_user_subscription';

    protected $fillable = [
        'user_id',
        'stripe_customer_id',
        'stripe_subscription_id',
        'stripe_price_id',
        'plan_name',
        'status',
        'current_period_start',
        'current_period_end',
        'cancel_at_period_end',
        'trial_end',
    ];
}

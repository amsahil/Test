<?php

namespace App\Models\Employer;

use App\Models\WellifyUser;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Department extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $fillable = [
        'name',
        'description',
        'employer_id',
        'created_at',
        'created_by',
        'status'
    ];
    protected $table = 'wellify_departments';

    public function employees()
    {
        return $this->hasMany(WellifyUser::class, 'department_id');
    }
       public function employer()
    {
        return $this->belongsTo(WellifyUser::class, 'employer_id');
    }
}

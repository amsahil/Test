<?php

namespace App\Models\Employer;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Auth\Passwords\CanResetPassword;

class Staff extends Authenticatable
{

    use HasFactory;
    use SoftDeletes;
    use HasRoles;
    use CanResetPassword;

    protected $dates = ['deleted_at'];
    protected $table = 'wellify_staffs';
    protected $guard_name = 'staff';

    protected $casts = [
        'licenses' => 'array',
    ];

    protected $fillable = [
        'username',
        'mobile_phone',
        'email',
        'first_name',
        'last_name',
        'created_by',
        'state',
        'city',
        'country',
        'department_id',
        'password'
    ];
    // If you are using password hashing and remember tokens:
    // protected $hidden = ['password', 'remember_token'];


    // Optional: mutator for password hashing
    // public function setPasswordAttribute($value)
    // {
    //     if (!empty($value) && \Illuminate\Support\Facades\Hash::needsRehash($value)) {
    //         $this->attributes['password'] = bcrypt($value);
    //     } else {
    //         $this->attributes['password'] = $value;
    //     }
    // }

    // public function department()
    // {
    //     return $this->belongsTo(Department::class);
    // }
    public function department()
    {
        return $this->belongsTo(Department::class)->withDefault([
            'name' => 'Unassigned'
        ]);
    }
}

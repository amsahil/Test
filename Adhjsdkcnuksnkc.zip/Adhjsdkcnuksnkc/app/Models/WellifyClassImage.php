<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyClass;

class WellifyClassImage extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_classes_images';
    protected $casts = [
        'class_id' => 'string'
    ];

    protected $fillable = [
        'class_id','image','description'
    ];


    public function classes()
    {
        return $this->belongsToMany(WellifyClass::class, 'class_id');
    }
}

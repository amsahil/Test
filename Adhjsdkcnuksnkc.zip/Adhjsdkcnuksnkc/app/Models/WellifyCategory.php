<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyCategoryMood;

class WellifyCategory extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_class_categories';

    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'title',
        'short_description',
        'detailed_description',
    ];

    public function moods()
    {
        return $this->hasMany(WellifyCategoryMood::class, 'mood_id', 'id');
    }
}

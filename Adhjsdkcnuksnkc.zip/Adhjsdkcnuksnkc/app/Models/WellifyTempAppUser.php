<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Spatie\Permission\Traits\HasRoles;
use App\Models\WellifyUser;
use App\Models\Employer\Department;

class WellifyTempAppUser extends Model
{
   use HasFactory, HasRoles;
   protected $table = 'wellify_temp_app_users';
      protected $fillable = [
        'import_id', 'title', 'first_name', 'last_name', 'username', 'email', 'mobile_phone',
        'organization', 'office', 'city', 'state', 'country', 'licenses',
        'staff_id', 'employer_id', 'created_by', 'error_message'
    ];
   public function department()
    {
        return $this->belongsTo(Department::class)->withDefault([
            'name' => 'Unassigned'
        ]);
    }
    
    // Define the relationship for employer
    public function employer()
    {
        return $this->belongsTo(WellifyUser::class, 'employer_id');
    }
    // Define the relationship for created_by user
    public function creator()
    {
        return $this->belongsTo(WellifyUser::class, 'created_by');
    }
}

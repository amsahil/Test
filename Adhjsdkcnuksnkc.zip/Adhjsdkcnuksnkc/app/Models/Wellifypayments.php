<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Wellifypayments extends Model
{
    protected $table = 'wellify_payment_details';

    protected $fillable = [
        'user_id',
        'stripe_payment_id',
        'amount',
        'currency',
        'status',
        'payment_method',
        'card_last_4digit',
        'card_type',
        'card_owner',
        'card_owner_email',
    ];

    protected $casts = [
        'payment_method' => 'array',
    ];
}

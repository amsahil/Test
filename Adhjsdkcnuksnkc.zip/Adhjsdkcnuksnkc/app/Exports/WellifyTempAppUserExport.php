<?php

namespace App\Exports;

use App\Models\WellifyTempAppUser;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Excel;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class WellifyTempAppUserExport implements FromCollection, WithHeadings, WithStyles
{
    use Exportable;

    protected $ids;
    private $writerType = Excel::XLSX;

    public function __construct(array $ids)
    {
        $this->ids = $ids;
    }

    public function collection()
    {
        return WellifyTempAppUser::with('department') // Eager load the department
        ->select("first_name", "last_name", "email", "mobile_phone as phone", "city", "state", "country")
        ->whereIn('id', $this->ids)
        ->get()
        ->map(function ($user) {
            return [
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'email' => $user->email,
                'phone' => $user->phone,
                'city' => $user->city,
                'state' => $user->state,
                'country' => $user->country,
            ];
        });
    }

    public function headings(): array
    {
        return ["first_name", "last_name", "email", "phone", "city", "state", "country"];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [ // Row 1
                'font' => [
                    'bold' => true,
                ],
            ],
        ];
    }
}

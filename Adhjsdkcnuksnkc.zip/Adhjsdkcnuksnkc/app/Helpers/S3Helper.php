<?php

namespace App\Helpers;

use Aws\S3\S3Client;

class S3Helper
{
    public static function generatePresignedUrl($folder, $filename, $default = null)
    {
        try {
            if (!$filename) {
                return $default ?? url('assets/images/default_logo.jfif');
            }

            $s3 = new S3Client([
                'version' => 'latest',
                'region' => env('AWS_DEFAULT_REGION'),
                'credentials' => [
                    'key' => env('AWS_ACCESS_KEY_ID'),
                    'secret' => env('AWS_SECRET_ACCESS_KEY'),
                ],
            ]);

            $key = $folder . '/' . $filename;

            $cmd = $s3->getCommand('GetObject', [
                'Bucket' => env('AWS_BUCKET'),
                'Key'    => $key,
            ]);

            $request = $s3->createPresignedRequest($cmd, '+20 minutes');

            return (string) $request->getUri();
        } catch (\Exception $e) {
            return $default ?? url('assets/images/default_logo.jfif');
        }
    }
}

<?php

namespace App\Http\Controllers\Employer;

use App\Http\Controllers\Controller;
use App\Models\Employer\Department;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use App\Models\WellifyUser;
use Illuminate\Validation\ValidationException;

class DepartmentController extends Controller
{
    /**
     * to display all departments
     */
    public function index()
    {
        $user = Auth::user();
        if ($user->hasRole('Super Admin')) {
            $employees = WellifyUser::where('supervisor_id', '2')->get();
            $departments = Department::orderBy('created_at', 'desc')->get();

            return view('employer.department', compact('departments', 'employees'));
        } elseif ($user->hasRole('Employer')) {
            $departments = Department::where('employer_id', $user->id)
                ->orderBy('created_at', 'desc')
                ->get();
        }
        return view('employer.department', compact('departments'));
    }

    /**get departments listings**/
    public function getDepartments(Request $request)
    {
        $user = auth()->user();
        if ($user->hasRole('Super Admin')) {
            $departments = Department::orderBy('created_at', 'desc')->get();
        } else {
            $departments = Department::where(function ($query) use ($user) {
                $query->whereNull('employer_id')
                    ->orWhere('employer_id', $user->id);
            })
                ->orderBy('created_at', 'desc')
                ->get();
        }
        $data = $departments->map(function ($department) use ($user) {
            $editButton = '
                            <span class="edit_icon1 me-4 edit-dept-modal" title="Edit"
                                    data-id="' . $department->id . '"
                                    data-name="' . $department->name . '"
                                    data-description="' . $department->description . '">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20"
                                        viewBox="0 0 21 20" fill="none">
                                        <path
                                            d="M14.666 2.49993C14.8849 2.28106 15.1447 2.10744 15.4307 1.98899C15.7167 1.87054 16.0232 1.80957 16.3327 1.80957C16.6422 1.80957 16.9487 1.87054 17.2347 1.98899C17.5206 2.10744 17.7805 2.28106 17.9993 2.49993C18.2182 2.7188 18.3918 2.97863 18.5103 3.2646C18.6287 3.55057 18.6897 3.85706 18.6897 4.16659C18.6897 4.47612 18.6287 4.78262 18.5103 5.06859C18.3918 5.35455 18.2182 5.61439 17.9993 5.83326L6.74935 17.0833L2.16602 18.3333L3.41602 13.7499L14.666 2.49993Z"
                                            stroke="#A25AD9" stroke-width="1.66667" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>
                                </span>';

            $deleteButton = '<span class="delete_icon delete-dept-btn" title="Delete"
                    data-id="' . $department->id . '">
                        <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20"
                            viewBox="0 0 21 20" fill="none">
                            <path
                                d="M3 5.00033H4.66667M4.66667 5.00033H18M4.66667 5.00033V16.667C4.66667 17.109 4.84226 17.5329 5.15482 17.8455C5.46738 18.1581 5.89131 18.3337 6.33333 18.3337H14.6667C15.1087 18.3337 15.5326 18.1581 15.8452 17.8455C16.1577 17.5329 16.3333 17.109 16.3333 16.667V5.00033H4.66667ZM7.16667 5.00033V3.33366C7.16667 2.89163 7.34226 2.46771 7.65482 2.15515C7.96738 1.84259 8.39131 1.66699 8.83333 1.66699H12.1667C12.6087 1.66699 13.0326 1.84259 13.3452 2.15515C
                                13.6577 2.46771 13.8333 2.89163 13.8333 3.33366V5.00033M8.83333 9.16699V14.167M12.1667 9.16699V14.167"
                                stroke="#F54E51" stroke-width="1.66667" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </span>';

            $departmentData = [
                'id' => $department->id,
                'name' => $department->name,
                'description' => $department->description,
                'actions' => $editButton . $deleteButton,
            ];

            // Include employer_id only if the user is not an employer
            if (!$user->hasRole('Employer')) {
                $departmentData['employer_id'] = optional($department->employer)->username ?? 'N/A';
            }

            return $departmentData;
        });
        return response()->json([
            'data' => $data
        ]);
    }

    /**to store all departments */
    public function store(Request $request)
    {
        $user = Auth::user();
        try {
            if ($user->hasRole('Employer')) {
                $validatedData = $request->validate([
                    'name' => [
                        'required',
                        'string',
                        'max:255',
                        Rule::unique('wellify_departments')->where(function ($query) use ($user) {
                            return $query->where('employer_id', $user->id);
                        }),
                    ],
                    'description' => 'nullable|string|max:1000',
                ], [
                    'name.required' => 'Department Name is required.',
                    'name.max' => 'Department Name cannot exceed 255 characters.',
                    'name.unique' => 'This Department has already been taken by you.',
                    'description.max' => 'Description cannot exceed 1000 characters.'
                ]);

                $department = Department::create([
                    'name' => $validatedData['name'],
                    'description' => $validatedData['description'] ?? '',
                    'employer_id' => $user->id,
                    'created_by' => $user->id,
                ]);

                return response()->json([
                    'success' => true,
                    'message' => 'Department created successfully!',
                    'department' => $department
                ]);
            } elseif ($user->hasRole('Super Admin')) {
                $validatedData = $request->validate([
                    'employer_id' => [
                        'required',
                        'exists:wellify_users,id'
                    ],
                    'name' => [
                        'required',
                        'string',
                        'max:255',
                        Rule::unique('wellify_departments')->where(function ($query) use ($request) {
                            return $query->where('employer_id', $request->input('employer_id'));
                        }),
                    ],
                    'description' => 'nullable|string|max:1000',
                ], [
                    'employer_id.required' => 'Please select an Employer.',
                    'employer_id.exists' => 'Selected Employer is invalid.',
                    'name.required' => 'Department Name is required.',
                    'name.max' => 'Department Name cannot exceed 255 characters.',
                    'name.unique' => 'This Department has already been taken for the selected Employer.',
                    'description.max' => 'Description cannot exceed 1000 characters.'
                ]);

                $department = Department::create([
                    'name' => $validatedData['name'],
                    'description' => $validatedData['description'] ?? '',
                    'employer_id' => $validatedData['employer_id'],
                    'created_by' => $user->id,
                ]);
                return response()->json([
                    'success' => true,
                    'message' => 'Department created successfully!',
                    'department' => $department
                ]);
            }
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized action.'
            ], 403);
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors()
            ], 422);
        } catch (\Illuminate\Database\QueryException $e) {
            Log::error('Department Creation Database Error', [
                'message' => $e->getMessage(),
                'sql' => $e->getSql(),
                'bindings' => $e->getBindings(),
                'user_id' => $user->id,
                'request_data' => $request->all()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'An error occurred while creating the department. Please check your input and try again.'
            ], 500);
        } catch (\Exception $e) {
            Log::error('Unexpected Department Creation Error', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'user_id' => $user->id,
                'request_data' => $request->all()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'An unexpected error occurred. Please try again later.'
            ], 500);
        }
    }

    /**to update departments */
    public function update(Request $request, $id)
    {
        $user = Auth::user();
        try {
            $department = Department::findOrFail($id);

            if ($user->hasRole('Employer')) {
                $employerId = $user->id;
            } elseif ($user->hasRole('Super Admin')) {
                $employerId = $department->employer_id;
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized action.'
                ], 403);
            }
            $validatedData = $request->validate([
                'name' => [
                    'required',
                    'string',
                    'max:255',
                    Rule::unique('wellify_departments')
                        ->where(function ($query) use ($employerId, $id) {
                            return $query->where('employer_id', $employerId)
                                ->where('id', '!=', $id);
                        }),
                ],
                'description' => 'nullable|string|max:1000',
            ], [
                'name.required' => 'Department Name is required.',
                'name.max' => 'Department Name cannot exceed 255 characters.',
                'name.unique' => 'This Department name already exists for your organization.',
                'description.max' => 'Description cannot exceed 1000 characters.'
            ]);
            $department->name = $validatedData['name'];
            $department->description = $request->input('description') ?? $department->description;
            $department->save();

            return response()->json([
                'success' => true,
                'message' => 'Department updated successfully!',
                'department' => $department
            ]);
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            Log::error('Department Update Error', [
                'message' => $e->getMessage(),
                'user_id' => $user->id,
                'request_data' => $request->all()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'An error occurred while updating the department.'
            ], 500);
        }
    }
    /**to destroy departments */
    public function destroy($id)
    {
        $department = Department::find($id);
        if (!$department) {
            return response()->json([
                'success' => false,
                'message' => 'Department not found.'
            ], 404);
        }
        try {
            $department->delete();

            return response()->json([
                'success' => true,
                'message' => 'Department deleted successfully',
            ]);
        } catch (\Exception $e) {
            Log::error('Department delete failed: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Something went wrong while deleting the department.',
            ], 500);
        }
    }

    /**to restore the department*/
    public function restore($id)
    {
        $validatedData = request()->validate([
            'id' => 'required|exists:departments,id',
        ]);

        /**Find the department, including trashed ones*/
        $department = Department::withTrashed()->findOrFail($validatedData['id']);

        /** Restore the department if it is trashed*/
        if ($department->trashed()) {
            $department->restore();
        }
        return response()->json([
            'success' => true,
            'message' => 'Department restored successfully.'
        ]);
    }
}

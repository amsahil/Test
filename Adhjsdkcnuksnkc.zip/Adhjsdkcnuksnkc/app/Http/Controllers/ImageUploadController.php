<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;

class ImageUploadController extends Controller
{
    public function upload(Request $request)
    {

        // Validate the incoming request
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $file = $request->file('image');

        // Create S3 client
        $s3 = new S3Client([
            'version' => 'latest',
            'region'  => env('AWS_DEFAULT_REGION'),
            'credentials' => [
                'key'    => env('AWS_ACCESS_KEY_ID'),
                'secret' => env('AWS_SECRET_ACCESS_KEY'),
            ]
        ]);

        $keyname = 'uploads/' . time() . '_' . $file->getClientOriginalName();

        // Upload file to S3
        try {
            $result = $s3->putObject([
                'Bucket' => env('AWS_BUCKET'),
                'Key'    => $keyname,
                'Body'   => fopen($file, 'r+'),
                'ACL'    => 'private', // Change to 'private' if you want to restrict access
            ]);

            return response()->json([
                'message' => 'File uploaded successfully',
                'file_link' => $result['ObjectURL'],
            ]);
        } catch (S3Exception $e) {
            dd($e);
            return response()->json([
                'error' => 'Upload failed: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function uploadTest(Request $request){
dd('me');
    }
}

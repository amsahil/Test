<?php

namespace App\Http\Controllers;

use Aws\S3\S3Client;
use App\Models\WellifyMood;
use App\Models\WellifyType;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class WellifyMoodController extends Controller
{
    public function index()
    {
        return view('wellify_moods.index');
    }

    public function getData(Request $request)
    {
        $moods = WellifyMood::with('type', 'creator')->select('wellify_moods.*');

        return DataTables::of($moods)
            ->addColumn('type_name', fn($mood) => $mood->type?->title)
            ->addColumn('dummy', fn() => ' ')
            ->addColumn('image', function ($mood) {
                if (!$mood->image) return '<img src="'. url('assets/images/default_logo.jfif') . '" alt="Default Image" class="logo_outer border-0">';

                try {
                    $s3 = new S3Client([
                        'version' => 'latest',
                        'region' => env('AWS_DEFAULT_REGION'),
                        'credentials' => [
                            'key' => env('AWS_ACCESS_KEY_ID'),
                            'secret' => env('AWS_SECRET_ACCESS_KEY'),
                        ],
                    ]);

                    $key = env('S3_MOODS') . $mood->image;
                    $cmd = $s3->getCommand('GetObject', [
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $key,
                        'ContentType' => 'image/svg+xml',
                    ]);

                    $request = $s3->createPresignedRequest($cmd, '+20 minutes');
                    $url = (string) $request->getUri();

                    // return '<img src="' . $url . '" alt="Mood Image" class="logo_outer border-0">';
                    // return '<img src="' .url('assets/images/default_logo.jfif') .'" alt="Mood Image" alt="Class Image" target="_blank" class=" logo_outer border-0">';
                        return '<img src="' . $url . '" alt="Mood Image" alt="Class Image" target="_blank" class=" logo_outer border-0">';
                } catch (\Exception $e) {
                    return '<img src="'.url('assets/images/default_logo.jfif') . '" alt="Default Image" class="logo_outer border-0">';
                }
            })
            ->addColumn('text_code', function ($mood) {
                $name = $this->hexToColorName($mood->text_code);
                return '<span class="text-dark">'.$name.'</span>';
            })
            ->addColumn('color_code', function ($mood) {
                $textColor = strtoupper(ltrim($mood->text_code, '#'));
                $bgColor = strtoupper(ltrim($mood->color_code, '#'));
                $moodName = $mood->color_code;

                return '<span class="px-3 py-1 fw-semibold rounded-pill d-inline-block" style="color: #' . $textColor . '; background-color: #' . $bgColor . ';"> #' . $moodName . '</span>';
            })
            ->addColumn('created_on', fn($mood) => $mood->created_at->format('M d, Y'))
            ->addColumn('status', function ($row) {
                $checked = $row->status ? 'checked' : '';
                return '
                    <div class="flipswitch">
                        <input class="flipswitch-cb toggle-status" type="checkbox"
                            id="fs' . $row->id . '" data-id="' . $row->id . '" ' . $checked . '>
                        <label for="fs' . $row->id . '" class="flipswitch-label">
                            <span class="flipswitch-inner d-block"></span>
                            <span class="flipswitch-switch d-block"></span>
                        </label>
                    </div>';
            })
            ->addColumn('action', function ($mood) {
                return '<div class="action_td">
                    <span class="btn btn-sm btn-light edit-mood-btn" data-id="'.$mood->id.'" title="Edit">
                        <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                        <path d="M14.666 2.49993C14.8849 2.28106 15.1447 2.10744 15.4307 1.98899C15.7167 1.87054 16.0232 1.80957 16.3327 1.80957C16.6422 1.80957 16.9487 1.87054 17.2347 1.98899C17.5206 2.10744 17.7805 2.28106 17.9993 2.49993C18.2182 2.7188 18.3918 2.97863 18.5103 3.2646C18.6287 3.55057 18.6897 3.85706 18.6897 4.16659C18.6897 4.47612 18.6287 4.78262 18.5103 5.06859C18.3918 5.35455 18.2182 5.61439 17.9993 5.83326L6.74935 17.0833L2.16602 18.3333L3.41602 13.7499L14.666 2.49993Z" stroke="#A25AD9" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </span>
                    </div>';
            })
            ->filterColumn('text_code', function($query, $keyword) {
                $query->where('text_code', 'like', "%{$keyword}%");
            })
            ->filterColumn('color_code', function($query, $keyword) {
                $query->where('color_code', 'like', "%{$keyword}%");
            })
            ->filterColumn('created_on', function($query, $keyword) {
                $query->whereDate('created_at', 'like', "%{$keyword}%");
            })
            ->filterColumn('status', function($query, $keyword) {
                $query->where('status', 'like', "%{$keyword}%");
            })
            ->orderColumn('text_code', 'text_code $1')
            ->orderColumn('color_code', 'color_code $1')
            ->orderColumn('created_on', 'created_at $1')
            ->orderColumn('status', 'status $1')
            ->rawColumns(['image', 'text_code', 'color_code', 'action', 'dummy', 'status'])
            ->make(true);
    }

    private function hexToColorName($hex)
    {
        $map = [
            '#000000' => 'Black',
            '#FFFFFF' => 'White',
            '#FF0000' => 'Red',
            '#00FF00' => 'Lime',
            '#0000FF' => 'Blue',
            '#FFFF00' => 'Yellow',
            '#00FFFF' => 'Cyan',
            '#FF00FF' => 'Magenta',
        ];

        $hex = strtoupper($hex);
        if (strpos($hex, '#') !== 0) {
            $hex = '#' . $hex;
        }

        return $map[$hex] ?? $hex;
    }

    public function toggleStatus(Request $request, $id)
    {
        $mood = WellifyMood::findOrFail($id);

        if ($request->status == 1) {
            $activeCount = WellifyMood::where('status', 1)->count();
            if ($activeCount >= 12) {
                return response()->json([
                    'error' => true,
                    'message' => 'You can only have 12 active moods at a time. Please deactivate one to activate a new mood.'
                ], 400);
            }
        }

        $mood->status = $request->status;
        $mood->save();

        return response()->json(['message' => 'Mood status updated successfully.']);
    }

    public function edit($id)
    {
        $mood = WellifyMood::findOrFail($id);

        try {
            $imageUrl = null;
            if ($mood->image) {
                $s3 = new S3Client([
                    'version' => 'latest',
                    'region' => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key' => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ],
                ]);

                $key = env('S3_MOODS') . $mood->image;
                $cmd = $s3->getCommand('GetObject', [
                    'Bucket' => env('AWS_BUCKET'),
                    'Key'    => $key,
                ]);

                $request = $s3->createPresignedRequest($cmd, '+20 minutes');
                $imageUrl = (string) $request->getUri();
            }
        } catch (\Exception $e) {
            $imageUrl = url('assets/images/default_logo.jfif');
        }

        return response()->json([
            'id' => $mood->id,
            'title' => $mood->title,
            'text_code' => $mood->text_code,
            'color_code' => $mood->color_code,
            'image_url' => $imageUrl,
            'image_name' => $mood->image
        ]);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'text_code' => 'required|string',
            'color_code' => 'required|string',
            'image' => 'nullable|mimes:svg,svg+xml'
        ]);

        $mood = WellifyMood::findOrFail($id);
        $mood->title = $request->title;
        $mood->text_code = $request->text_code;
        $mood->color_code = $request->color_code;

        if ($request->hasFile('image')) {
            $file = $request->file('image');

            if ($file->getMimeType() !== 'image/svg+xml') {
                return response()->json(['error' => 'Only SVG images are allowed'], 422);
            }
            try {
                $s3 = new S3Client([
                    'version' => 'latest',
                    'region' => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key' => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ],
                ]);

                $file = $request->file('image');
                $fileName = time() . '_' . $file->getClientOriginalName();
                $key = env('S3_MOODS') . $fileName;

                $s3->putObject([
                    'Bucket' => env('AWS_BUCKET'),
                    'Key'    => $key,
                    'Body'   => fopen($file->getPathname(), 'rb'),
                    'ContentType' => 'image/svg+xml',
                    // 'ACL'    => 'public-read'
                ]);


                $mood->image = $fileName;
            } catch (\Exception $e) {
                return response()->json(['error' => 'Failed to upload image to S3'], 500);
            }
        }

        $mood->save();

        return response()->json(['message' => 'Mood updated successfully']);
    }

}

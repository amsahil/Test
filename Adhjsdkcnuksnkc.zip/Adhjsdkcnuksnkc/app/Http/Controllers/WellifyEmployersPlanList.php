<?php

namespace App\Http\Controllers;

use App\Models\WellifyPlans;
use App\Models\WellifyTimezone;
use App\Models\WellifySubscription;
use App\Models\WellifyUser;
use Carbon\Carbon;
use Illuminate\Http\Request;

class WellifyEmployersPlanList extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $timezones = WellifyTimezone::all();
        $plans = WellifyPlans::with('ranges')
            ->where('status', 1)
            ->get();

        if ($user->hasRole('Employer')) {
            $existingSub = WellifySubscription::where('employer_id', $user->id)->first();

            if (!$existingSub) {
                $defaultPlan = WellifyPlans::where('is_default', true)->first();

                if ($defaultPlan) {
                    $programPeriodDays = $user->program_periods ?? 30;

                    WellifySubscription::create([
                        'employer_id' => $user->id,
                        'plan_id' => $defaultPlan->id,
                        'start_date' => Carbon::today(),
                        'end_date' => Carbon::today()->addDays($programPeriodDays),
                        'platform' => 'stripe',
                        'status' => 'active',
                        'is_employer_sponsored' => true,
                    ]);
                }
            }
        }

        return view('wellifyemployerplans.index', compact('plans'));
    }
}

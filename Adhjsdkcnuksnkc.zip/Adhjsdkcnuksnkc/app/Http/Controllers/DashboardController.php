<?php

namespace App\Http\Controllers;

use App\Models\WellifyPlans;
use App\Models\WellifyTimezone;
use App\Models\WellifySubscription;
use App\Models\WellifyUser;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $timezones = WellifyTimezone::all();

        // Fetch all active plans with user range pricing
        // $plans = WellifyPlans::with('ranges')
        //     ->where('status', 1)
        //     ->get();

        return view('superAdmin.dashboard', compact('timezones'));
    }


}

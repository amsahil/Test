<?php

namespace App\Http\Controllers;

use Stripe\Stripe;
use Stripe\Webhook;
use Stripe\Customer;
use Stripe\PaymentIntent;
use Stripe\PaymentMethod;
use App\Models\WellifyUser;
use Illuminate\Http\Request;
use Stripe\Checkout\Session;
use App\Models\EmployerPayment;
use App\Mail\EmployerCreatedMail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class WellifyStripeWebhookController extends Controller
{

    public function handle(Request $request)
    {
        \Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));

        $payload = $request->getContent();
        $sigHeader = $request->header('Stripe-Signature');
        $endpointSecret = env('STRIPE_WEBHOOK_SECRET');

        try {
            $event = \Stripe\Webhook::constructEvent($payload, $sigHeader, $endpointSecret);

            if ($event->type === 'checkout.session.completed') {
                $session = $event->data->object;
                Log::info('Webhook Session Data1: ', (array) $session);

                $employerId = $session->metadata->employer_id ?? null;
                $user = WellifyUser::find($employerId);

                if ($user && !$user->setup_fee_paid) {
                    $paymentIntent = \Stripe\PaymentIntent::retrieve($session->payment_intent);
                    $paymentMethod = $paymentIntent->payment_method ? \Stripe\PaymentMethod::retrieve($paymentIntent->payment_method) : null;

                    $user->setup_fee_paid = true;
                    $user->stripe_customer_id = $session->customer;
                    $user->charged_setup_fee_usd = $session->metadata->setup_fee_usd ?? ($session->amount_total / 100);
                    $user->save();

                    // Retrieve fallback customer email
                    $customerEmail = $session->customer_email ?? optional(\Stripe\Customer::retrieve($session->customer))->email;

                    // Create employer payment record
                    \App\Models\EmployerPayment::create([
                        'employer_id' => $user->id,
                        'stripe_payment_id' => $paymentIntent->id,
                        'stripe_checkout_session_id' => $session->id,
                        'stripe_customer_id' => $session->customer,
                        'amount_paid' => $session->amount_total / 100,
                        'custom_fee_usd' => $session->metadata->setup_fee_usd ?? ($session->amount_total / 100),
                        'currency' => strtoupper($session->currency),
                        'status' => $session->payment_status,
                        'paid_at' => now(),
                        'payment_method' => $paymentMethod?->type,
                        'card_brand' => $paymentMethod?->card?->brand,
                        'card_last4' => $paymentMethod?->card?->last4,
                        'receipt_url' => $session->payment_status === 'paid' ? $session->url : null,
                        'customer_email' => $customerEmail,
                    ]);


                    $decryptedPassword = null;

                    if (isset($session->success_url)) {
                        $query = parse_url($session->success_url, PHP_URL_QUERY);
                        parse_str($query, $params);
                        if (isset($params['token'])) {
                            try {
                                $decryptedPassword = decrypt($params['token']);
                            } catch (\Exception $e) {
                                Log::warning("Webhook: Unable to decrypt password: " . $e->getMessage());
                            }
                        }
                    }

                    if ($decryptedPassword) {
                        try {
                            Mail::to($user->email)->send(new EmployerCreatedMail($user, $decryptedPassword));
                            $user->welcome_email_sent = now();
                            $user->save();
                            Log::info("Welcome email sent to employer: " . $user->email);
                        } catch (\Exception $e) {
                            Log::error("Failed to send welcome email: " . $e->getMessage());
                        }
                    } else {
                        Log::warning("Welcome email not sent — password missing or decryption failed.");
                    }

                    Log::info('Webhook Session Data2: ', (array) $session);
                }

                Log::info('Webhook Session Data3: ', (array) $session);
            }

            return response()->json(['status' => 'webhook received']);
        } catch (\Exception $e) {
            Log::error('Stripe Webhook Error: ' . $e->getMessage());
            return response()->json(['error' => 'Invalid signature'], 400);
        }
    }

    // public function handle(Request $request)
    // {
    //     \Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));

    //     $payload = $request->getContent();
    //     $sigHeader = $request->header('Stripe-Signature');
    //     $endpointSecret = env('STRIPE_WEBHOOK_SECRET');

    //     try {
    //         $event = Webhook::constructEvent($payload, $sigHeader, $endpointSecret);

    //         if ($event->type === 'checkout.session.completed') {
    //             $session = $event->data->object;

    //             $employerId = $session->metadata->employer_id;
    //             $user = WellifyUser::find($employerId);

    //             if ($user && !$user->setup_fee_paid) {
    //                 // Retrieve payment and method
    //                 $paymentIntent = PaymentIntent::retrieve($session->payment_intent);
    //                 $paymentMethod = $paymentIntent->payment_method
    //                     ? PaymentMethod::retrieve($paymentIntent->payment_method)
    //                     : null;

    //                 $customerEmail = $session->customer_email;

    //                 if (!$customerEmail && $session->customer) {
    //                     try {
    //                         $customerObject = Customer::retrieve($session->customer);
    //                         $customerEmail = $customerObject->email;
    //                     } catch (\Exception $e) {
    //                        Log::error("Failed to retrieve Stripe customer email: " . $e->getMessage());
    //                         return response()->json(['error' => 'Unable to retrieve customer email'], 400);
    //                     }
    //                 }

    //                 if (!$customerEmail) {
    //                     Log::error("Stripe Webhook: customer_email is null after fallback.");
    //                     return response()->json(['error' => 'Customer email is required.'], 400);
    //                 }


    //                 $user->setup_fee_paid = true;
    //                 $user->stripe_customer_id = $session->customer;
    //                 $user->charged_setup_fee_usd = $session->metadata->setup_fee_usd ?? ($session->amount_total / 100);
    //                 $user->save();


    //                 EmployerPayment::create([
    //                     'employer_id' => $user->id,
    //                     'stripe_payment_id' => $paymentIntent->id,
    //                     'stripe_checkout_session_id' => $session->id,
    //                     'stripe_customer_id' => $session->customer,
    //                     'amount_paid' => $session->amount_total / 100,
    //                     'custom_fee_usd' => $session->metadata->setup_fee_usd ?? null,
    //                     'currency' => strtoupper($session->currency),
    //                     'status' => $session->payment_status,
    //                     'paid_at' => now(),
    //                     'payment_method' => $paymentMethod?->type,
    //                     'card_brand' => $paymentMethod?->card?->brand,
    //                     'card_last4' => $paymentMethod?->card?->last4,
    //                     'receipt_url' => $session->payment_status === 'paid' ? $session->url : null,
    //                     'customer_email' => $customerEmail,
    //                 ]);
    //             }
    //         }

    //         return response()->json(['status' => 'webhook received']);
    //     } catch (\Exception $e) {
    //         Log::error('Stripe Webhook Error: ' . $e->getMessage());
    //         return response()->json(['error' => 'Invalid webhook signature or payload'], 400);
    //     }
    // }

    // public function handle(Request $request)
    // {
    //     \Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));

    //     $payload = $request->getContent();
    //     $sigHeader = $request->header('Stripe-Signature');
    //     $endpointSecret = env('STRIPE_WEBHOOK_SECRET');

    //     try {
    //         $event = \Stripe\Webhook::constructEvent($payload, $sigHeader, $endpointSecret);

    //         if ($event->type === 'checkout.session.completed') {
    //             $session = $event->data->object;

    //             $employerId = $session->metadata->employer_id ?? null;
    //             if (!$employerId) {
    //                 Log::error("Stripe Webhook: Missing employer_id in metadata.");
    //                 return response()->json(['error' => 'Missing employer_id'], 400);
    //             }

    //             $user = \App\Models\WellifyUser::find($employerId);
    //             if (!$user || $user->setup_fee_paid) {
    //                 return response()->json(['message' => 'Already processed or invalid user.'], 200);
    //             }

    //             // Retrieve payment intent and method
    //             $paymentIntent = \Stripe\PaymentIntent::retrieve($session->payment_intent);
    //             $paymentMethod = $paymentIntent->payment_method
    //                 ? \Stripe\PaymentMethod::retrieve($paymentIntent->payment_method)
    //                 : null;

    //             // ✅ Safely get customer email
    //             $customerEmail = $session->customer_email;

    //             if (!$customerEmail && $session->customer) {
    //                 try {
    //                     $customer = \Stripe\Customer::retrieve($session->customer);
    //                     $customerEmail = $customer->email ?? null;
    //                 } catch (\Exception $e) {
    //                     Log::error("Failed to retrieve Stripe customer email: " . $e->getMessage());
    //                     return response()->json(['error' => 'Unable to retrieve customer email'], 400);
    //                 }
    //             }

    //             if (!$customerEmail) {
    //                 Log::error("Stripe Webhook: customer_email is null after fallback.");
    //                 return response()->json(['error' => 'Customer email is required.'], 400);
    //             }

    //             // ✅ Update employer record
    //             $user->setup_fee_paid = true;
    //             $user->stripe_customer_id = $session->customer;
    //             $user->charged_setup_fee_usd = $session->metadata->setup_fee_usd ?? ($session->amount_total / 100);
    //             $user->save();

    //             // ✅ Record payment
    //             \App\Models\EmployerPayment::create([
    //                 'employer_id' => $user->id,
    //                 'stripe_payment_id' => $paymentIntent->id,
    //                 'stripe_checkout_session_id' => $session->id,
    //                 'stripe_customer_id' => $session->customer,
    //                 'amount_paid' => $session->amount_total / 100,
    //                 'custom_fee_usd' => $session->metadata->setup_fee_usd ?? null,
    //                 'currency' => strtoupper($session->currency),
    //                 'status' => $session->payment_status,
    //                 'paid_at' => now(),
    //                 'payment_method' => $paymentMethod?->type,
    //                 'card_brand' => $paymentMethod?->card?->brand,
    //                 'card_last4' => $paymentMethod?->card?->last4,
    //                 'receipt_url' => $session->payment_status === 'paid' ? $session->url : null,
    //                 'customer_email' => $customerEmail, // ✅ not null here
    //             ]);
    //         }

    //         return response()->json(['status' => 'webhook received']);
    //     } catch (\Exception $e) {
    //         Log::error('Stripe Webhook Error: ' . $e->getMessage());
    //         return response()->json(['error' => 'Invalid webhook signature or payload'], 400);
    //     }
    // }
}
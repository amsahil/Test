<?php

namespace App\Http\Controllers;

use Aws\S3\S3Client;
use App\Models\WellifySeed;
use App\Models\WellifyGrowthStageMedia;
use Illuminate\Http\Request;
use Aws\S3\Exception\S3Exception;
use Illuminate\Support\Facades\Storage;
use Yajra\DataTables\Facades\DataTables;
use Aws\Exception\AwsException;

class WellifySeedController extends Controller
{
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = WellifySeed::select('*');

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('dummy', function ($row) {
                    return '';
                })
                ->addColumn('image', function ($row) {
                    if (!$row->image) {
                        $defaultImageUrl = Storage::disk('s3')->temporaryUrl(
                            'staging/public/default_logo.jfif',
                            now()->addHour()
                        );
                        return '<a href="' . $defaultImageUrl . '" target="_blank" class="logo_outer border-0">
                            <img src="' . $defaultImageUrl . '" alt="Default Image" class="table_logo_img">
                        </a>';
                    }

                    try {
                        $s3 = new S3Client([
                            'version' => 'latest',
                            'region' => env('AWS_DEFAULT_REGION'),
                            'credentials' => [
                                'key' => env('AWS_ACCESS_KEY_ID'),
                                'secret' => env('AWS_SECRET_ACCESS_KEY'),
                            ],
                        ]);

                        $key = env('S3_SEEDS') . $row->image;
                        $cmd = $s3->getCommand('GetObject', [
                            'Bucket' => env('AWS_BUCKET'),
                            'Key'    => $key,
                            'ContentType' => 'image/svg+xml',
                        ]);

                        $request = $s3->createPresignedRequest($cmd, '+20 minutes');
                        $url = (string) $request->getUri();

                        return '<a href="' . $url . '" target="_blank" class="logo_outer border-0">
                            <img src="' . $url . '" alt="Seed Image" class="table_logo_img">
                        </a>';
                    } catch (\Exception $e) {
                        $s3IconUrl = Storage::disk('s3')->temporaryUrl(
                            'staging/public/default_logo.jfif',
                            now()->addHour()
                        );
                        return '<a href="' .  $s3IconUrl . '" target="_blank" class="logo_outer border-0">
                            <img src="' .  $s3IconUrl . '" alt="Default Image" class="table_logo_img">
                        </a>';
                    }
                })
                ->addColumn('seed_description', function ($row) {
                    return '<span class="text-wrap">'.e($row->seed_description).'</span>';
                })
                ->addColumn('growth_stages', function ($row) {
                    $count = WellifyGrowthStageMedia::where('seed_id', $row->id)->where('is_update', 1)->count('growth_stage_id');
                    $noun = $count > 1 ? 'Stages' : 'Stage';
                    $url = route('wellify_seeds.growthStages', ['seed_id' => $row->id]);

                    $seedName = $row->seed_name ?? $row->title ?? $row->name ?? 'Seed';
                    $urlWithSeed = $url . '?seed=' . urlencode($seedName);

                    $addIcon = asset('assets/images/Add_icon.svg');

                    return '
                        <small class="d-inline-flex px-3 py-1 fw-semibold border border-primary-subtle rounded-4 cursor-pointer"
                            onclick="window.location.href=\'' . $urlWithSeed . '\'">
                            ' . $count . ' ' . $noun . '
                        </small>
                        ';
                })

                ->addColumn('status', function ($row) {
                    $checked = $row->status ? 'checked' : '';
                    return '<div class="flipswitch">
                        <input ' . $checked . ' class="flipswitch-cb" name="flipswitch" type="checkbox" id="fs-' . $row->id . '" data-id="' . $row->id . '">
                        <label for="fs-' . $row->id . '" class="flipswitch-label">
                            <span class="flipswitch-inner d-block"></span>
                            <span class="flipswitch-switch d-block"></span>
                        </label>
                    </div>';
                })
                ->addColumn('action', function ($row) {
                    return '<div class="action_td">
                        <span class="seed_edit_icon" title="Edit" data-bs-toggle="modal" data-bs-target="#edit_seed" data-id="'.$row->id.'">
                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                                <path d="M14.666 2.49993C14.8849 2.28106 15.1447 2.10744 15.4307 1.98899C15.7167 1.87054 16.0232 1.80957 16.3327 1.80957C16.6422 1.80957 16.9487 1.87054 17.2347 1.98899C17.5206 2.10744 17.7805 2.28106 17.9993 2.49993C18.2182 2.7188 18.3918 2.97863 18.5103 3.2646C18.6287 3.55057 18.6897 3.85706 18.6897 4.16659C18.6897 4.47612 18.6287 4.78262 18.5103 5.06859C18.3918 5.35455 18.2182 5.61439 17.9993 5.83326L6.74935 17.0833L2.16602 18.3333L3.41602 13.7499L14.666 2.49993Z" stroke="#A25AD9" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </span>
                        <span class="delete_icon" title="Delete" data-bs-toggle="modal" data-bs-target="#delete_seed" data-id="' . $row->id . '">
                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                                <path d="M3 5.00033H4.66667M4.66667 5.00033H18M4.66667 5.00033V16.667C4.66667 17.109 4.84226 17.5329 5.15482 17.8455C5.46738 18.1581 5.89131 18.3337 6.33333 18.3337H14.6667C15.1087 18.3337 15.5326 18.1581 15.8452 17.8455C16.1577 17.5329 16.3333 17.109 16.3333 16.667V5.00033H4.66667ZM7.16667 5.00033V3.33366C7.16667 2.89163 7.34226 2.46771 7.65482 2.15515C7.96738 1.84259 8.39131 1.66699 8.83333 1.66699H12.1667C12.6087 1.66699 13.0326 1.84259 13.3452 2.15515C13.6577 2.46771 13.8333 2.89163 13.8333 3.33366V5.00033M8.83333 9.16699V14.167M12.1667 9.16699V14.167" stroke="#F54E51" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </span>
                    </div>';
                })
                ->rawColumns(['dummy', 'image', 'status', 'action', 'seed_description', 'growth_stages'])
                ->make(true);
        }

        return view('wellify_seeds.index');
    }


    public function store(Request $request)
    {
        $request->validate([
            'seed_name' => 'required|string|max:255',
            'image' => 'required|mimes:svg,svg+xml',
            'seed_description' => 'required|string',
        ]);

        try {
            $seed = new WellifySeed();
            $seed->seed_name = $request->seed_name;
            $seed->seed_description = $request->seed_description;
            $seed->status = 1;

            // Upload image to S3
            if ($request->hasFile('image')) {
                $file = $request->file('image');
                $originalFilename = $file->getClientOriginalName();
                $filename = time() . '_' . $originalFilename;

                $s3 = new S3Client([
                    'version' => 'latest',
                    'region' => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ]
                ]);

                $keynameSeed = env('S3_SEEDS') . $filename;
                $keynameGrowth = env('S3_SEEDS_STAGING') . $filename;

                try {
                    $s3->putObject([
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $keynameSeed,
                        'Body'   => fopen($file->getRealPath(), 'r'),
                        'ContentType' => 'image/svg+xml',
                    ]);

                    $s3->putObject([
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $keynameGrowth,
                        'Body'   => fopen($file->getRealPath(), 'r'),
                        'ContentType' => 'image/svg+xml',
                    ]);

                    $seed->image = $filename;
                } catch (S3Exception $e) {
                    return response()->json(['success' => false, 'message' => 'Image upload failed.'], 500);
                }
            }

            $seed->save();

            // Add 5 growth stages
            $growthStageIds = [1, 2, 3, 4, 5];
            $description = "All seeds being planted are a seed sprouting";

            foreach ($growthStageIds as $index => $growthStageId) {
                WellifyGrowthStageMedia::create([
                    'growth_stage_id' => $growthStageId,
                    'seed_id' => $seed->id,
                    'media' => $filename,
                    'media_type' => 'image',
                    'description' => $description,
                    'status' => 1,
                    'is_update' => ($index === 0) ? 1 : 0,
                ]);
            }

            return response()->json([
                'success' => true,
                'message' => 'Seed and growth stages added successfully',
                'seed_id' => $seed->id
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error adding seed: ' . $e->getMessage()
            ], 500);
        }
    }




    public function toggleStatus($id)
    {
        $seed = WellifySeed::findOrFail($id);
        $seed->status = !$seed->status;
        $seed->save();

        return response()->json(['success' => true, 'new_status' => $seed->status]);
    }

    public function edit($id)
    {
        $seed = WellifySeed::findOrFail($id);

        return response()->json($seed);
    }

    

    public function update(Request $request, $id)
    {
        $request->validate([
            'seed_name' => 'required|string|max:255',
            'seed_description' => 'required|string',
            'image' => 'nullable|mimes:svg,svg+xml|max:2048',
        ]);

        try {
            $seed = WellifySeed::findOrFail($id);
            $seed->seed_name = $request->seed_name;
            $seed->seed_description = $request->seed_description;

            if ($request->hasFile('image')) {
                $file = $request->file('image');

                $mimeType = $file->getMimeType();
                if ($mimeType !== 'image/svg+xml') {
                    return response()->json([
                        'success' => false,
                        'message' => 'Only SVG images are allowed.'
                    ], 422);
                }

                $filename = 'seed_' . time() . '_' . uniqid() . '.svg';
                $keyname = env('S3_SEEDS') . $filename;

                $filePath = $file->getRealPath();

                if (!file_exists($filePath)) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Uploaded file is missing on server.'
                    ], 500);
                }

                $stream = fopen($filePath, 'r');
                if (!$stream) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Unable to read the uploaded file.'
                    ], 500);
                }

                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ],
                ]);

                try {

                    $result = $s3->putObject([
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $keyname,
                        'Body'   => $stream,
                        'ContentType' => $mimeType,
                    ]);


                    $seed->image = $filename;

                } catch (S3Exception $e) {

                    return response()->json([
                        'success' => false,
                        'message' => 'Failed to upload image to S3: ' . $e->getAwsErrorMessage(),
                        'exception' => $e->__toString(),
                    ], 500);
                } finally {
                    if (is_resource($stream)) {
                        fclose($stream);
                    }
                }
            }

            $seed->save();

            return response()->json([
                'success' => true,
                'message' => 'Seed updated successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Update failed: ' . $e->getMessage()
            ], 500);
        }
    }

    // public function destroy($id)
    // {
    //     try {
    //         $seed = WellifySeed::findOrFail($id);

    //         $growthStageMedia = WellifyGrowthStageMedia::find($id);
    //         if ($growthStageMedia) {
    //             $growthStageMedia->delete();
    //         }

    //         if ($seed->image) {
    //             Storage::disk('s3')->delete('staging/seeds/' . $seed->image);
    //         }

    //         if (method_exists($seed, 'forceDelete')) {
    //             $seed->forceDelete();
    //         } else {
    //             $seed->delete();
    //         }

    //         return response()->json([
    //             'success' => true,
    //             'message' => 'Seed and growth stage media deleted successfully'
    //         ]);
    //     } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Seed not found'
    //         ], 404);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Error deleting records: ' . $e->getMessage()
    //         ], 500);
    //     }
    // }

    public function destroy($id)
    {
        try {
            $seed = WellifySeed::findOrFail($id);
            $growthStageMediaList = WellifyGrowthStageMedia::where('seed_id', $seed->id)->get();

            foreach ($growthStageMediaList as $media) {
                if ($media->media) {
                    Storage::disk('s3')->delete(env('S3_SEEDS_STAGING') . $media->media);
                }
                $media->delete();
            }

            if ($seed->image) {
                Storage::disk('s3')->delete(env('S3_SEEDS') . $seed->image);
            }

            if (method_exists($seed, 'forceDelete')) {
                $seed->forceDelete();
            } else {
                $seed->delete();
            }

            return response()->json([
                'success' => true,
                'message' => 'Seed and related media deleted successfully'
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Seed not found'
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting records: ' . $e->getMessage()
            ], 500);
        }
    }




    public function getSeedImageUrl($id)
    {
        $seed = WellifySeed::findOrFail($id);

        if ($seed->image) {
            $s3 = new S3Client([
                'version' => 'latest',
                'region'  => env('AWS_DEFAULT_REGION'),
                'credentials' => [
                    'key'    => env('AWS_ACCESS_KEY_ID'),
                    'secret' => env('AWS_SECRET_ACCESS_KEY'),
                ],
            ]);

            $cmd = $s3->getCommand('GetObject', [
                'Bucket' => env('AWS_BUCKET'),
                'Key'    => env('S3_SEEDS') . $seed->image,
            ]);

            $request = $s3->createPresignedRequest($cmd, '+20 minutes');
            $url = (string) $request->getUri();

            return response()->json([
                'success' => true,
                'url' => $url,
            ]);
        }

        return response()->json(['success' => false, 'url' => null]);
    }


    // Show the page with the growth stages DataTable
    public function showGrowthStages($seed_id)
    {
        $seed = WellifySeed::findOrFail($seed_id);
        return view('wellify_seeds.seeds_growth', compact('seed'));
    }

    // Return JSON for DataTable AJAX call
    public function getGrowthStagesData($seed_id)
    {
        $growthStages = WellifyGrowthStageMedia::where('seed_id', $seed_id)
            ->with('growthStage')
            ->get();

        return datatables()->of($growthStages)
            ->addIndexColumn()
            ->addColumn('growth_stage', function ($row) {
                return $row->growthStage->title ?? 'N/A';
            })

            ->addColumn('stage_image', function ($row) {
                    if (!$row->media) {
                        return '<a href="'.asset('assets/images/default_logo.jfif').'" target="_blank" class="logo_outer border-0">
                            <img src="'.asset('assets/images/default_logo.jfif').'" alt="Default Image" class="table_logo_img">
                        </a>';
                    }

                    try {
                        $s3 = new S3Client([
                            'version' => 'latest',
                            'region' => env('AWS_DEFAULT_REGION'),
                            'credentials' => [
                                'key' => env('AWS_ACCESS_KEY_ID'),
                                'secret' => env('AWS_SECRET_ACCESS_KEY'),
                            ],
                        ]);

                        $key = env('S3_SEEDS_STAGING') . $row->media;
                        $cmd = $s3->getCommand('GetObject', [
                            'Bucket' => env('AWS_BUCKET'),
                            'Key'    => $key,
                            'ContentType' => 'image/svg+xml',
                        ]);

                        $request = $s3->createPresignedRequest($cmd, '+20 minutes');
                        $url = (string) $request->getUri();

                        return '<a href="'.$url.'" target="_blank" class="logo_outer border-0">
                            <img src="'.$url.'" alt="Seed Image" class="table_logo_img">
                        </a>';
                    } catch (\Exception $e) {
                        return '<a href="'.asset('assets/images/default_logo.jfif').'" target="_blank" class="logo_outer border-0">
                            <img src="'.asset('assets/images/default_logo.jfif').'" alt="Default Image" class="table_logo_img">
                        </a>';
                    }
            })

            ->addColumn('description', function ($row) {
                return $row->description ?? '-';
            })
            ->addColumn('action', function ($row) {
                return '<div class="action_td">
                    <span class="seed_edit_icon"
                        title="Edit"
                        data-id="'.$row->id.'"
                        data-name="'.($row->growthStage->title ?? 'N/A').'"
                        data-description="'.e($row->description).'"
                        data-media="'.($row->media ?? '').'">
                        <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                            <path d="M14.666 2.49993C14.8849 2.28106 15.1447 2.10744 15.4307 1.98899C15.7167 1.87054 16.0232 1.80957 16.3327 1.80957C16.6422 1.80957 16.9487 1.87054 17.2347 1.98899C17.5206 2.10744 17.7805 2.28106 17.9993 2.49993C18.2182 2.7188 18.3918 2.97863 18.5103 3.2646C18.6287 3.55057 18.6897 3.85706 18.6897 4.16659C18.6897 4.47612 18.6287 4.78262 18.5103 5.06859C18.3918 5.35455 18.2182 5.61439 17.9993 5.83326L6.74935 17.0833L2.16602 18.3333L3.41602 13.7499L14.666 2.49993Z" stroke="#A25AD9" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </span>
                </div>';
            })
            ->rawColumns(['stage_image', 'action'])
            ->make(true);
    }

    public function showGrowthStageMedia($id)
    {
        try {
            $media = WellifyGrowthStageMedia::with('growthStage')->findOrFail($id);

            $url = null;

            if ($media->media) {
                $s3 = new S3Client([
                    'version' => 'latest',
                    'region' => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key' => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ],
                ]);

                $key = env('S3_SEEDS_STAGING') . $media->media;
                $cmd = $s3->getCommand('GetObject', [
                    'Bucket' => env('AWS_BUCKET'),
                    'Key' => $key,
                ]);

                $request = $s3->createPresignedRequest($cmd, '+20 minutes');
                $url = (string) $request->getUri();
            }

            return response()->json([
                'success' => true,
                'data' => $media,
                'image_url' => $url,
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Growth stage media not found',
            ], 404);
        }
    }


    public function updateGrowthStageMedia(Request $request, $id)
    {
        $request->validate([
            'description' => 'nullable|string',
            'stageImage' => 'nullable|mimes:svg,svg+xml',
        ]);

        $growthStageMedia = WellifyGrowthStageMedia::findOrFail($id);

        // Load related seed explicitly just in case
        $seed = $growthStageMedia->seed()->first();

        if ($request->filled('description')) {
            $growthStageMedia->description = $request->description;
        }

        if ($request->hasFile('stageImage')) {
            $file = $request->file('stageImage');
            $filename = time() . '_' . $file->getClientOriginalName();

            $s3 = new S3Client([
                'version' => 'latest',
                'region'  => env('AWS_DEFAULT_REGION'),
                'credentials' => [
                    'key'    => env('AWS_ACCESS_KEY_ID'),
                    'secret' => env('AWS_SECRET_ACCESS_KEY'),
                ]
            ]);

            try {
                // Upload to growth-stage-media folder in S3
                $keynameGrowth = env('S3_SEEDS_STAGING') . $filename;
                $s3->putObject([
                    'Bucket' => env('AWS_BUCKET'),
                    'Key'    => $keynameGrowth,
                    'Body'   => fopen($file->getRealPath(), 'r'),
                    'ContentType' => 'image/svg+xml',
                ]);

                $growthStageMedia->media = $filename;

                // If this is the first growth stage media (sequence_no == 1), update seed image too
                if ($growthStageMedia->growth_stage_id == 1 && $seed) {
                    $keynameSeed = env('S3_SEEDS') . $filename;
                    $s3->putObject([
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $keynameSeed,
                        'Body'   => fopen($file->getRealPath(), 'r'),
                        'ContentType' => 'image/svg+xml',
                    ]);

                    // Update seed image filename and save
                    $seed->image = $filename;
                    $seed->save();
                }
            } catch (AwsException $e) {
                return response()->json([
                    'success' => false,
                    'message' => 'Image upload failed: ' . $e->getMessage()
                ], 500);
            }
        }
        

        // Mark this growth stage media as updated
        $growthStageMedia->is_update = 1;
        $growthStageMedia->save();

        return response()->json([
            'success' => true,
            'message' => 'Growth stage updated successfully',
            'media' => $growthStageMedia->media,
        ]);
    }






}

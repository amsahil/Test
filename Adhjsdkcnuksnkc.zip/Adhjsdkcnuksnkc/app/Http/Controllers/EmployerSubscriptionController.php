<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Mail\UserLaunchCredentials;
use App\Mail\SlotsPaymentConfirmedMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Stripe\Stripe;
use Stripe\PaymentIntent;
use Stripe\Checkout\Session;
use App\Models\WellifyUser;
use App\Models\EmployerPayment;
use App\Models\Employer\Employee;
use App\Models\WellifySubscription;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class EmployerSubscriptionController extends Controller
{
    public function payPerUser(Request $request)
    {
        $user = Auth::user();
        $userIds = $request->user_ids;
        $count = count($userIds);

        if ($count === 0) {
            return response()->json(['error' => 'No employees selected.'], 422);
        }

        Stripe::setApiKey(env('STRIPE_SECRET'));

        $session = Session::create([
            'payment_method_types' => ['card'],
            'customer_email' => $user->email,
            'line_items' => [[
                'price_data' => [
                    'currency' => 'usd',
                    'product_data' => ['name' => '$1/User Program Fee'],
                    'unit_amount' => 100,
                ],
                'quantity' => $count,
            ]],
            'mode' => 'payment',
            'success_url' => route('stripe.per_user.success', [
                'employer_id' => $user->id,
                'count' => $count
            ]) . '&session_id={CHECKOUT_SESSION_ID}',
            'cancel_url' => route('stripe.cancel'),
            'metadata' => [
                'employer_id' => $user->id,
                'selected_user_ids' => implode(',', $userIds),
            ],
        ]);

        return response()->json(['session_url' => $session->url]);
    }

    public function handlePerUserPaymentSuccess(Request $request)
    {
        $session_id = $request->get('session_id');
        $employer_id = $request->get('employer_id');
        $count = $request->get('count');

        Stripe::setApiKey(env('STRIPE_SECRET'));

        try {
            $session = Session::retrieve($session_id);
            $paymentIntent = PaymentIntent::retrieve($session->payment_intent);

            $employer = WellifyUser::findOrFail($employer_id);
            $userIds = explode(',', $session->metadata->selected_user_ids);
            $chargeId = $paymentIntent->latest_charge;
            $charge = \Stripe\Charge::retrieve($chargeId);

            Log::info('Session Retrieved', ['session' => $session]);
            Log::info('PaymentIntent Retrieved', ['intent' => $paymentIntent]);
            Log::info('Stripe details', [
                'stripe_customer_id' => $paymentIntent->customer,
                'card_brand' => $charge->payment_method_details->card->brand ?? null,
                'card_last4' => $charge->payment_method_details->card->last4 ?? null
            ]);

            $payment = EmployerPayment::create([
                'employer_id' => $employer->id,
                'stripe_payment_id' => $paymentIntent->id,
                'stripe_checkout_session_id' => $session->id,
                'stripe_customer_id' => $paymentIntent->customer,
                'amount_paid' => $paymentIntent->amount / 100,
                'currency' => $paymentIntent->currency,
                'status' => $paymentIntent->status,
                'payment_method' => $paymentIntent->payment_method_types[0] ?? null,
                'card_brand' => $charge->payment_method_details->card->brand ?? null,
                'card_last4' => $charge->payment_method_details->card->last4 ?? null,
                'receipt_url' => $charge->receipt_url ?? null,
                'customer_email' => $session->customer_email,
                'app_users_count' => count($userIds),
            ]);

            Log::info('Payment saved', ['payment_id' => $payment->id]);

            $programDays = $employer->program_periods ?? 30;
            $startDate = Carbon::now();
            $endDate = $startDate->copy()->addDays($programDays);

            foreach ($userIds as $appUserId) {
                $subscription = WellifySubscription::create([
                    'employer_id' => $employer->id,
                    'plan_id' => 1,
                    'app_user_id' => $appUserId,
                    'start_date' => $startDate,
                    'end_date' => $endDate,
                    'platform' => 'stripe',
                    'status' => 'active',
                    'is_employer_sponsored' => true,
                ]);

                Employee::where('id', $appUserId)->update(['status' => 1, 'plan_status' => 1]);

                Log::info('Subscription created', ['sub_id' => $subscription->id, 'user_id' => $appUserId]);
            }
            Log::info('Sending SlotsPaymentConfirmedMail', [
                'email' => $employer->email,
                'count' => $count
            ]);

            // ✅ Send confirmation email after slots payment
            Mail::to($employer->email)->send(new SlotsPaymentConfirmedMail($employer, $count));

            return redirect()->route('wellify_employees.index')->with('success', 'Payment completed. Subscriptions started.');
        } catch (\Exception $e) {
            Log::error("Stripe payment failed", ['error' => $e->getMessage()]);
            return redirect()->route('wellify_employees.index')->with('error', 'Payment failed.');
        }
    }

    public function launchUser(Request $request)
    {
        $userId = $request->user_id;
        $user = Employee::findOrFail($userId);

        // Generate new password
        $plainPassword = Str::random(8);
        $user->password = bcrypt($plainPassword);
        $user->save();

        // Send credentials email
        Mail::to($user->email)->send(new UserLaunchCredentials($user->email, $plainPassword));

        return response()->json(['success' => true, 'message' => 'User launched successfully and credentials emailed.']);
    }
}

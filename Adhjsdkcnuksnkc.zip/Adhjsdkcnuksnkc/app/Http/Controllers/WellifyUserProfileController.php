<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\WellifyUser; 
use Exception;
use Aws\S3\S3Client;
use Illuminate\Support\Str;
use App\Models\WellifyTimezone;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
use Aws\S3\Exception\S3Exception;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Yajra\DataTables\Facades\DataTables;
use App\Models\Employer\Department;
use Illuminate\Support\Facades\Validator;

class WellifyUserProfileController extends Controller
{
    // public function show($id)
    // {
    //     $user = WellifyUser::with(['timezone','employees','departments','employees.classProgress','employees.activityProgress'])->where('id', Auth::user()->id)->first();
    //     $totalEmployees = $user ? $user->employees->count() : 0;
    //     $totalDepartments = $user ? $user->departments->count() : 0;
    //     $totalCompletedClasses = $user ? $user->total_completed_classes : 0;
    //     $totalCompletedActivities = $user ? $user->total_completed_activities : 0;
    //     $timezones = WellifyTimezone::all();
    //     return view('profile.show', compact(['user','timezones','totalEmployees','totalDepartments','totalCompletedClasses','totalCompletedActivities']));
    // }
    public function show($id)
    {
        $user = WellifyUser::with('timezone')->where('id', Auth::user()->id)->first();
        $totalEmployees = $user ? $user->employees->count() : 0;
        $totalDepartments = $user ? $user->departments->count() : 0;
        $totalCompletedClasses = $user ? $user->total_completed_classes : 0;
        $totalCompletedActivities = $user ? $user->total_completed_activities : 0;
        $timezones = WellifyTimezone::all();

        return view('profile.show', compact('user', 'timezones', 'totalEmployees', 'totalDepartments', 'totalCompletedClasses', 'totalCompletedActivities'));
    }


    public function update(Request $request)
    {
        $user = Auth::user();

        try {
            $validated = $request->validate([
                'username' => 'nullable|string|max:255|unique:wellify_users,username,' . $user->id,
                'first_name' => 'nullable|string|max:255',
                'last_name' => 'nullable|string|max:255',
                'mobile_phone' => 'nullable|string|max:20',
                'work_phone' => 'nullable|string|max:20',
                'city' => 'nullable|string|max:100',
                'state' => 'nullable|string|max:100',
                'country' => 'nullable|string|max:100',
                'timezone_id' => 'nullable',
                'status' => 'nullable|boolean',
                'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg,svg|max:2048',
            ]);

            $user->username = $validated['username'];
            $user->first_name = $validated['first_name'];
            $user->last_name = $validated['last_name'];
            $user->mobile_phone = $validated['mobile_phone'] ?? $user->mobile_phone;
            $user->work_phone = $validated['work_phone'] ?? $user->work_phone;
            $user->city = $validated['city'] ?? $user->city;
            $user->state = $validated['state'] ?? $user->state;
            $user->country = $validated['country'] ?? $user->country;
            $user->user_timezone_id = $validated['timezone_id'] ?? $user->user_timezone_id;
            $user->status = $validated['status'] ?? $user->status;

            if ($request->hasFile('profile_picture')) {
                // Initialize S3 Client
                $s3 = new S3Client([
                    'version' => 'latest',
                    'region' => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ],
                ]);

                $image = $request->file('profile_picture');
                $originalFilename = $image->getClientOriginalName();
                $imageName = time() . '_' . $originalFilename;

                // Delete old image from S3 if exists
                if ($user->profile_picture) {
                    try {
                        $s3->deleteObject([
                            'Bucket' => env('AWS_BUCKET'),
                            'Key'    => env('S3_USER') . $user->profile_picture,
                        ]);
                    } catch (S3Exception $e) {
                        Log::error('Failed to delete old profile image from S3: ' . $e->getMessage());
                    }
                }

                try {
                    // Upload new image to S3
                    $s3->putObject([
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => env('S3_USER') . $imageName,
                        'Body'   => fopen($image->getRealPath(), 'r'),
                        'ContentType' => $image->getMimeType(),
                    ]);
                    // Save new image name to user model
                    $user->profile_picture = $imageName;
                } catch (S3Exception $e) {
                    Log::error('Failed to upload profile picture to S3: ' . $e->getMessage());
                    return redirect()->back()->with('error', 'Failed to upload profile picture.');
                }
            }

            $user->save();

            return redirect()->back()->with('success', 'Profile updated successfully.');
        } catch (ValidationException $e) {
            $errors = $e->validator->errors()->all();
            return redirect()->back()->with('error', $errors[0]);
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Failed to update profile.');
        }
    }




}

<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class StaffCreatedMail extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    public $password;
    public $link;

    /**
     * Create a new message instance.
     */
    public function __construct($user, $password, $link)
    {
        $this->user = $user;
        $this->password = $password;
        $this->link = $link;
    }

    /**
     * Build the message.
     */
    public function build()
    {
        return $this->subject('Welcome to Wellify!')
            ->view('emails.staff_created')
            ->with([
                'first_name' => $this->user->first_name,
                'email' => $this->user->email,
                'username' => $this->user->username,
                'password' => $this->password,
                'link' => $this->link,
            ]);
    }
}

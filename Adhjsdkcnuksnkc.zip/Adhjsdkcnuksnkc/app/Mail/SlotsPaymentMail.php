<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use App\Models\WellifyUser;

class SlotsPaymentMail extends Mailable
{
    use Queueable, SerializesModels;

    public $employer;
    public $amount;
    public $paymentLink;

    public function __construct(WellifyUser $employer, $amount, $paymentLink)
    {
        $this->employer = $employer;
        $this->amount = $amount;
        $this->paymentLink = $paymentLink;
    }

    public function build()
    {
        return $this->subject('Complete Payment for Additional Slots')
            ->view('emails.slots_payment')
            ->with([
                'employer' => $this->employer,
                'amount' => $this->amount,
                'paymentLink' => $this->paymentLink,
            ]);
    }
}


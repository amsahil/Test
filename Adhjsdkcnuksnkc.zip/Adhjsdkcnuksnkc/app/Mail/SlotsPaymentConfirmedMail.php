<?php

namespace App\Mail;

use App\Models\WellifyUser;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SlotsPaymentConfirmedMail extends Mailable
{
    use Queueable, SerializesModels;

    public $employer;
    public $count;

    public function __construct(WellifyUser $employer, $count)
    {
        $this->employer = $employer;
        $this->count = $count;
    }

    public function build()
    {
        return $this->subject('Payment Confirmed for Additional Slots')
            ->view('emails.slots_payment_confirmed')
            ->with([
                'employer' => $this->employer,
                'count' => $this->count,
            ]);
    }
}

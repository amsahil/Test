<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use app\Models\Employer\Employee;

class EmployeeCreatedMail extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    public $link;
    public $password;

    public function __construct(Employee $user,$password,$link)
    {
        $this->user = $user;
        $this->password = $password;
        $this->link = $link;
    }

    public function build()
    {

        return $this->subject('Welcome to Wellify!')
            ->view('emails.employee_created')
            ->with([
                'first_name' => $this->user->first_name,
                'email' => $this->user->email,
                'username' => $this->user->username,
                'password' => $this->password,
                'link'=> $this->link

            ]);
    }
}

$(document).ready(function() {
    let classId = "{{ $class->id }}";
    let ajaxUrl = '/wellify/class/' + $('#class_id').val() + '/media-data';

            $('#classMediaTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: ajaxUrl,
                columns: [
                    { data: null, defaultContent: '', orderable: false, searchable: false },
                    { data: 'id',orderable: true, searchable: true },
                    { data: 'image', orderable: true, searchable: true },
                    { data: 'description', orderable: true, searchable: true },
                    { data: 'action', orderable: false, searchable: false }
                ]
            });
    $('#add-more-upload').click(function () {
        const block = `
        <div class="row media-upload-block">
            <div class="col-12 mb-3">
                <label class="form-label">Upload Image</label>
                <input type="file" name="media[]" class="form-control input media-input" required>
            </div>
            <div class="col-12 mb-3">
                <label class="form-label">Description</label>
                <textarea name="description[]" class="form-control input rounded-3" rows="3" required></textarea>
            </div>
        </div>`;
        $('#media-upload-container').append(block);
    });

    // Submit form
    $('#uploadMediaForm').on('submit', function (e) {
        e.preventDefault();

        let formData = new FormData(this);

        $.ajax({
            // url: '{{ route("class-media.upload") }}',
            url: wellifyUploadMediaDataUrl,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                if (response.success) {
                    $('#add_new').modal('hide');
                    $('#uploadMediaForm')[0].reset();
                    $('.media-upload-block').not(':first').remove(); // Keep only one block
                    $('#yourDataTableId').DataTable().ajax.reload(); // Replace with actual DataTable ID
                } else {
                    alert(response.message || 'Upload failed.');
                }
            },
            error: function (xhr) {
                alert(xhr.responseJSON.message || 'Server error.');
            }
        });
    });
    // Open modal and populate fields
    $(document).on('click', '.edit_icon', function () {
        const mediaId = $(this).data('id');
        const url = `/class-media/${mediaId}`; // Assumes route: Route::get('/class-media/{id}', 'show');

        // Clear previous content
        $('#edit_media_id').val('');
        $('#imageDesc').val('');
        $('#currentImagePreview').attr('src', '');

        // Fetch media data
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                $('#edit_media_id').val(response.id);
                $('#imageDesc').val(response.description);

                if (response.preview_url) {
                    $('#currentImagePreview').attr('src', response.preview_url + '?t=' + new Date().getTime()).show();
                } else {
                    $('#currentImagePreview').hide();
                }
            },
            error: function () {
                alert('Failed to fetch image data.');
            }
        });
    });

    $('#editImageForm').on('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(this);

        $.ajax({
            url: '/class-media/update',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                if (response.success) {
                    $('#edit_user3').modal('hide');
                    alert('Updated successfully');
                    // Optionally refresh the media list
                }
            },
            error: function (xhr) {
                alert('Update failed');
                console.log(xhr.responseJSON);
            }
        });
    });


    // Submit edit form
    $('#editMediaForm').on('submit', function (e) {
        e.preventDefault();
        let formData = new FormData(this);
        formData.append('_token', '{{ csrf_token() }}');
        formData.append('_method', 'POST');

        $.ajax({
            // url: '{{ route("class-media.update") }}',
            url: wellifyUpdateMediaData,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.success) {
                    $('#edit_user').modal('hide');
                    $('#yourDataTableId').DataTable().ajax.reload();
                } else {
                    alert(res.message || 'Update failed');
                }
            },
            error: function (xhr) {
                alert(xhr.responseJSON.message || 'Server error');
            }
        });
    });


    let deleteId = null;

    $(document).on('click', '.delete_icon', function () {
        deleteId = $(this).data('id');
        $('#delete_media_id').val(deleteId);
        $('#delete_user').modal('show');
    });

    $('.warning_button').on('click', function () {
        let id = $('#delete_media_id').val();

        $.ajax({
            url: `/class-media/delete/${id}`,
            method: 'DELETE',
            data: {
                _token: $('meta[name="csrf-token"]').attr('content')
            },
            success: function () {
                $('#delete_user').modal('hide');
                $('#media-table').DataTable().ajax.reload(null, false);
            },
            error: function () {
                alert('Failed to delete image.');
            }
        });
    });
});

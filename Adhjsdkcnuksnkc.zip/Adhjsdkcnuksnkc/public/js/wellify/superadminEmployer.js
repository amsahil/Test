$(document).ready(function () {
    // const userRole = "{{ auth()->user()->getRoleNames()->first() }}";
    $("#employersTable").DataTable({
        paging: true,
        scrollCollapse: true,
        scrollX: true,
        processing: true,
        serverSide: true,
        ajax: {
            url: wellifyUsersDataUrl,
            type: "GET",
            data: function (d) {
                d.sort_filter = $("#sortFilter").val();
            },
            error: function (xhr, error, thrown) {
                console.log("AJAX Error:", xhr.responseText);
            },
        },
        columns: [
            { data: "dummy", orderable: false, searchable: false },
            { data: "organization" },
            { data: "email" },
            { data: "username" },
            { data: "mobile_phone" },
            { data: "contact_person" },
            { data: "CRM_link" },
            { data: "timezone" },
            { data: "payment_status" },
            {
                data: "action",
                render: function (data, type, row) {
                    return data;
                },
                title: "Action",
                orderable: false,
                searchable: false,
            },
        ],
        responsive: false,
        pageLength: 10,
        order: [[14, "desc"]],
    });

    // Inactive Employers Table
  $("#inactiveEmployersTable").DataTable({

        paging: true,
        scrollCollapse: true,
        scrollX: true,
        processing: true,
        serverSide: true,
        ajax: {
            url: wellifyUsersDeletedData,
            type: "GET",
            data: function (d) {
                d.is_deleted = true;
                d.sort_filter = $("#sortFilter").val();
            },
            error: function (xhr, error, thrown) {
                console.log("AJAX Error:", xhr.responseText);
            },
        },

        columns: [
            {
                data: "checkbox",
                name: "checkbox",
                orderable: false,
                searchable: false,
            },
            { data: "organization" },
            { data: "email" },
            { data: "username" },
            { data: "mobile_phone" },
            { data: "contact_person" },
            { data: "timezone" },
            { data: "deleted_at" },
            {
                data: "action",
                orderable: false,
                searchable: false,
                render: function (data, type, row) {
                    return data;
                },
            },
        ],
        responsive: false,
        pageLength: 10,
        order: [[7, "desc"]],
    });

    /**
     * employees code
     */
    let columns = [
        // {
        //     data: null,
        //     title: '<input type="checkbox" id="select-all-emails1" class="form-check-input select-all1">',
        //     render: function (data, type, row) {
        //         return `<input type="checkbox" class="email-checkbox1 form-check-input"
        //             data-id="${row.id}"
        //             data-paid="${row.plan_status}"
        //             data-email="${row.email}"
        //             data-username="${row.username}">`;
        //     },
        //     orderable: false,
        //     searchable: false,
        // },
        {
            data: null,
            title: "S.No.",
            render: function (data, type, row, meta) {
                return meta.row + 1;
            },
            orderable: false,
            searchable: false,
        },
        { data: "employee_name", title: "Employee Username" },
        { data: "email", title: "Email" },
        { data: "mobile_no", title: "Mobile No" },
        { data: "address", title: "Address" },
        {
            data: "payment_status",
            title: "Payment Status",
            render: function (data, type, row) {
                return row.plan_status == 1
                    ? '<span class="status_btn bg_active"><svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M5 10C4.30833 10 3.65833 9.86866 3.05 9.606C2.44167 9.34333 1.9125 8.98716 1.4625 8.5375C1.0125 8.08783 0.656334 7.55866 0.394 6.95C0.131667 6.34133 0.000333966 5.69133 6.32911e-07 5C-0.0003327 4.30867 0.131001 3.65867 0.394 3.05C0.657 2.44133 1.01317 1.91217 1.4625 1.4625C1.91183 1.01283 2.441 0.656667 3.05 0.394C3.659 0.131333 4.309 0 5 0C5.691 0 6.341 0.131333 6.95 0.394C7.559 0.656667 8.08816 1.01283 8.5375 1.4625C8.98683 1.91217 9.34316 2.44133 9.60649 3.05C9.86983 3.65867 10.001 4.30867 9.99999 5C9.99899 5.69133 9.86766 6.34133 9.60599 6.95C9.34433 7.55866 8.98816 8.08783 8.5375 8.5375C8.08683 8.98716 7.55766 9.3435 6.95 9.6065C6.34233 9.8695 5.69233 10.0007 5 10Z" fill="#52AB17" /> </svg>Paid</span>' : '<span class="status_btn bg_delete"><svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5 10C4.30833 10 3.65833 9.86866 3.05 9.606C2.44167 9.34333 1.9125 8.98716 1.4625 8.5375C1.0125 8.08783 0.656334 7.55866 0.394 6.95C0.131667 6.34133 0.000333966 5.69133 6.32911e-07 5C-0.0003327 4.30867 0.131001 3.65867 0.394 3.05C0.657 2.44133 1.01317 1.91217 1.4625 1.4625C1.91183 1.01283 2.441 0.656667 3.05 0.394C3.659 0.131333 4.309 0 5 0C5.691 0 6.341 0.131333 6.95 0.394C7.559 0.656667 8.08816 1.01283 8.5375 1.4625C8.98683 1.91217 9.34316 2.44133 9.60649 3.05C9.86983 3.65867 10.001 4.30867 9.99999 5C9.99899 5.69133 9.86766 6.34133 9.60599 6.95C9.34433 7.55866 8.98816 8.08783 8.5375 8.5375C8.08683 8.98716 7.55766 9.3435 6.95 9.6065C6.34233 9.8695 5.69233 10.0007 5 10Z" fill="#52AB17"></path> </svg> Not Paid</span>';
            },

        },
        { data: "status", title: "Status" },
        {
            data: "action",
            render: function (data, type, row) {
                return data;
            },
            title: "Action",
            orderable: false,
            searchable: false,
        },
    ];

    if (userRole !== "Employer") {
        // console.log('hii');
        columns.splice(2, 0, {
            data: "employer_id",
            title: "Employer Name",
        });
    }

    $("#employeesTable").DataTable({
        paging: true,
        scrollCollapse: true,
        scrollX: true,
        processing: true,
        serverSide: true,
        ajax: {
            url: wellifyEmployeesDataUrl,
            type: "GET",
            data: function (d) {
                d.sort_filter = $("#sortFilter1").val();
                d.employer_id = $("#employer_name").val();
            },
            error: function (xhr, error, thrown) {
                console.log("AJAX Error:", xhr.responseText);
            },
        },
        columns: columns,
        responsive: false,
        pageLength: 10,
        order: [[1, "desc"]],
    });

    $("#employeesTable").on("change", ".flipswitch-cb", function () {
        var checkbox = $(this);
        var userId = checkbox.data("id");
        var newStatus = checkbox.is(":checked") ? 1 : 0;

        $.ajax({
            url: "/employee-toggle-status-endpoint",
            method: "POST",
            data: {
                id: userId,
                isActive: newStatus,
            },
            success: function (response) {
                Swal.fire({
                    icon: "success",
                    title: "Success",
                    text: "Status updated successfully!",
                });
                console.log("Status updated");
            },
            error: function (xhr) {
                Swal.fire({
                    icon: "error",
                    title: "Error",
                    text: "Failed to update status: " + xhr.responseText,
                });
                // revert checkbox on error
                checkbox.prop("checked", !newStatus);
            },
        });
    });

    $("#employer_name").on("change", function () {
        $("#employeesTable").DataTable().ajax.reload();
        $("#skipped-employees-datatable").DataTable().ajax.reload();
        $("#inactive-employees-datatable").DataTable().ajax.reload();
    });

    $("#inactive-employees-datatable").DataTable({
        paging: true,
        scrollCollapse: true,
        scrollX: true,
        processing: true,
        serverSide: true,
        ajax: {
            url: wellifyAppUsersDeletedData,
            type: "GET",
            data: function (d) {
                d.is_deleted = true;
                d.sort_filter = $("#sortFilter1").val();
                d.employer_id = $("#employer_name").val();
            },
        },
        columns: [
            {
                data: "checkbox",
                name: "checkbox",
                orderable: false,
                searchable: false,
            },
            { data: "organization" },
            { data: "email" },
            { data: "created_by" },
            { data: "mobile_phone" },
            { data: "address" },
            {
                data: "action",
                orderable: false,
                searchable: false,
                render: function (data, type, row) {
                    return data;
                },
            },
        ],
        responsive: false,
        pageLength: 10,
        order: [[14, "desc"]],
    });

    /**
     * for skipped employee datatable
     */
    var columns1 = [
        {
            data: "checkbox",
            name: "checkbox",
            orderable: false,
            searchable: false,
            title: '<input type="checkbox" id="selectAllEmployeeExport">',
        },
        { data: "name", name: "first_name", title: "Employee Name" },
        { data: "email", name: "email", title: "Employee Email" },
        { data: "mobile_phone", name: "mobile_phone", title: "Employee Phone" },
        { data: "address", name: "address", title: "Employee Address" },
        {
            data: "error_message",
            name: "error_message",
            title: "Error message",
        },
    ];
    if (userRole !== "Employer") {
        columns1.splice(1, 0, {
            data: "employer",
            name: "employer.username",
            title: "Employer Name",
        });
    }
    var skippedTable = $("#skipped-employees-datatable").DataTable({
        paging: true,
        scrollCollapse: true,
        scrollX: true,
        processing: true,
        serverSide: true,
        ajax: {
            url: wellifyAppUsersSkippedData,
            type: "GET",
            data: function (d) {
                d.sort_filter = $("#sortFilter1").val();
                d.employer_id = $("#employer_name").val();
            },
        },
        columns: columns1,
        responsive: false,
        pageLength: 10,
        order: [[1, "desc"]],
    });






    $("#sortFilter").change(function () {
        $("#employersTable").DataTable().ajax.reload();
        $("#inactiveEmployersTable").DataTable().ajax.reload();
    });
    $("#sortFilter1").change(function () {
        $("#employeesTable").DataTable().ajax.reload();
        $("#inactive-employees-datatable").DataTable().ajax.reload();
        $("#skipped-employees-datatable").DataTable().ajax.reload();
    });

    $('button[data-bs-toggle="tab"]').on('shown.bs.tab', function (e) {
            activeTab = $(e.target).attr('data-bs-target') === '#nav-home' ? 'active' : 'inactive';
        });

    $("#sortFilter #sortFilter1").on("change", function () {
        if (activeTab === "active") {
            activeTable.ajax.reload();
        } else {
            inactiveTable.ajax.reload();
        }
    });
});
$(document).on("change", "#selectAllEmployeeExport", function () {
    $(".skipped-employee-checkbox").prop("checked", this.checked);
});
$(document).on("click", ".skipped-employee-checkbox", function () {
    if ($(this).is(":checked") === false) {
        $("#selectAllEmployeeExport").prop("checked", false);
    } else {
        if (
            $(".skipped-employee-checkbox:checked").length ===
            $(".skipped-employee-checkbox").length
        ) {
            $("#selectAllEmployeeExport").prop("checked", true);
        }
    }
});

// Export Button Click Handler
$(document).on("click", "#bulk_employees_export", function () {
    // Validate if at least one checkbox is selected
    var selectedIds = $(".skipped-employee-checkbox:checked")
        .map(function () {
            return $(this).val();
        })
        .get();

    if (selectedIds.length === 0) {
        Swal.fire({
            icon: "warning",
            title: "No Employee Selected",
            text: "Please select at least one employee to export.",
        });
        return;
    }

    // Set the selected IDs in the hidden input field
    $("#exportIds").val(selectedIds.join(","));
    // Submit the hidden form to initiate the download
    $("#exportForm").submit();
});

let userIdToDelete = null;
$(document).on("click", ".delete_icon", function () {
    userIdToDelete = $(this).data("id");
    $("#delete_user_id").val(userIdToDelete);
});

$("#deleteUserForm").on("submit", function (e) {
    e.preventDefault();
    const userId = $("#delete_user_id").val();
    $.ajax({
        url: "/wellify_users/" + userId,
        type: "DELETE",
        success: function (response) {
            if (response.success) {
                $("#delete_user").modal("hide");
                location.reload();
            } else {
                alert(response.message);
            }
        },
        error: function () {
            alert("Something went wrong while deleting the user.");
        },
    });
});

$(document).on("click", ".edit_icon", function () {
    const userId = $(this).data("id");
    const modal = $("#edit_user");

    $("#editUserErrors").addClass("d-none").html("");
    $("#editUserForm")[0].reset();
    $("#currentProfilePicture").html("");

    modal.modal("show");

    $.get("/wellify_users/" + userId + "/edit", function (response) {
        if (response.success) {
            const user = response.user;
            const timezones = response.timezones;

            $("#editUserForm").attr("action", "/wellify_users/" + userId);
            $("#organization1").val(user.organization);
            $("#first_name1").val(user.first_name);
            $("#last_name1").val(user.last_name);
            $("#email1").val(user.email);
            $("#licenses1").val(user.licenses);
            $("#CRM_link1").val(user.CRM_link);
            $("#notes1").val(user.notes);
            $("#phone1").val(user.mobile_phone);
            $("#username1").val(user.username);
            $("#office1").val(user.office);
            $("#city1").val(user.city);
            $("#state1").val(user.state);
            $("#country1").val(user.country);
            $("#number_of_users1").val(user.number_of_users);

            const timezoneSelect = $("#user_timezone1");
            timezoneSelect
                .empty()
                .append('<option value="">Select Timezone</option>');

            // timezones.forEach(tz => {
            //     const selected = user.user_timezone === tz.utc_offset ? 'selected' : '';
            //     timezoneSelect.append(`<option value="${tz.utc_offset}" ${selected}>${tz.utc_offset} (${tz.utc_offset})</option>`);
            // });
            timezones.forEach((tz) => {
                const selected =
                    user.user_timezone_id === tz.id ? "selected" : "";
                timezoneSelect.append(
                    `<option value="${tz.id}" ${selected}>${tz.utc_offset} (${tz.utc_offset})</option>`
                );
            });

            $.get(
                "/wellify_users/" + userId + "/profile-picture-url",
                function (urlResponse) {
                    if (urlResponse.success) {
                        $("#currentProfilePicture").html(`
                                <label class="form-label">Current Logo :</label>
                                <img src="${urlResponse.url}"  class="logo-preview">
                            `);
                    }
                }
            );
        }
    }).fail(function (xhr) {
        $("#editUserErrors")
            .removeClass("d-none")
            .html(xhr.responseJSON?.message || "Failed to load employer data");
    });
});

$("#editUserForm").on("submit", function (e) {
    e.preventDefault();
    const form = $(this);
    const formData = new FormData(form[0]);
    toggleButtonLoading("#updateBtn", "#updateSpinner", true);
    $.ajax({
        url: form.attr("action"),
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            toggleButtonLoading("#updateBtn", "#updateSpinner", false);
            window.location.href = "/wellify_users";
        },
        error: function (xhr) {
            toggleButtonLoading("#updateBtn", "#updateSpinner", false);
            if (xhr.status === 422) {
                let errors = xhr.responseJSON.errors;
                let errorHtml = "<ul>";
                $.each(errors, function (key, value) {
                    errorHtml += "<li>" + value[0] + "</li>";
                });
                errorHtml += "</ul>";
                $("#editUserErrors").removeClass("d-none").html(errorHtml);
            } else {
                $("#editUserErrors")
                    .removeClass("d-none")
                    .html(xhr.responseJSON?.message || "An error occurred");
            }
        },
    });
});

$(document).on("click", ".view_icon", function () {
    const userId = $(this).data("id");

    $.ajax({
        url: "/wellify_users/" + userId,
        type: "GET",
        dataType: "json",
        success: function (response) {
            $("#view_user_content").html(response.html);
            $("#view_user").modal("show");
        },
        error: function () {
            alert("Unable to load user data.");
        },
    });
});

$("#addEmployerForm").on("submit", function (e) {
    e.preventDefault();
    $("#formErrors").html("");
    let username = $('[name="username"]').val().trim();
    let usernamePattern = /^[a-zA-Z0-9_]+$/;
    if (!usernamePattern.test(username)) {
        $('[name="username"]').addClass("is-invalid");
        let errorHtml = '<div class="alert alert-danger"><ul>';
        errorHtml +=
            "<li>The username may only contain letters, numbers, and underscores. No spaces allowed.</li>";
        errorHtml += "</ul></div>";
        $("#formErrors").html(errorHtml);
        return false;
    }

    let formData = new FormData(this);
    toggleButtonLoading("#submitBtn", "#submitSpinner", true);
    $.ajax({
        url: wellifyUsersStoreData,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            toggleButtonLoading("#submitBtn", "#submitSpinner", false);
            if (response.success) {
                $("#add_new").modal("hide");
                location.reload();
            }
        },
        error: function (xhr) {
            toggleButtonLoading("#submitBtn", "#submitSpinner", false);
            $(".form-control").removeClass("is-invalid");
            $("#formErrors").html("");

            if (xhr.status === 422) {
                let errors = xhr.responseJSON.errors;
                let errorHtml = '<div class="alert alert-danger"><ul>';
                $.each(errors, function (key, value) {
                    errorHtml += "<li>" + value[0] + "</li>";
                    $('[name="' + key + '"]').addClass("is-invalid");
                });
                errorHtml += "</ul></div>";
                $("#formErrors").html(errorHtml);
            } else {
                alert("An unexpected error occurred. Please try again.");
            }
        },
    });
});
$(document).on("input", 'input[name="mobile_phone"]', function () {
    let input = $(this).val().replace(/\D/g, "");
    if (input.length > 10) input = input.slice(0, 10);
    let formatted = "";
    if (input.length > 6) {
        formatted =
            input.slice(0, 3) + "-" + input.slice(3, 6) + "-" + input.slice(6);
    } else if (input.length > 3) {
        formatted = input.slice(0, 3) + "-" + input.slice(3);
    } else {
        formatted = input;
    }
    $(this).val(formatted);
});

$(".form-control").on("input change", function () {
    var value = $(this).val().trim();

    if (value !== "") {
        if (this.name === "username") {
            var usernamePattern = /^[a-zA-Z0-9_]+$/;
            if (usernamePattern.test(value)) {
                $(this)
                    .removeClass("is-invalid")
                    .addClass("is-valid")
                    .css("background-color", "#e6ffec");
            } else {
                $(this)
                    .removeClass("is-valid")
                    .addClass("is-invalid")
                    .css("background-color", "#ffe6e6");
            }
        } else if (this.name === "email") {
            var emailPattern =
                /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if (emailPattern.test(value)) {
                $(this)
                    .removeClass("is-invalid")
                    .addClass("is-valid")
                    .css("background-color", "#e6ffec");
            } else {
                $(this)
                    .removeClass("is-valid")
                    .addClass("is-invalid")
                    .css("background-color", "#ffe6e6");
            }
        } else if (this.name === "mobile_phone") {
            var phonePattern =
                /^(\+1\d{10})|(\d{10})|(\(\d{3}\)\s\d{3}-\d{4})|(\d{3}-\d{3}-\d{4})$/;
            if (phonePattern.test(value)) {
                $(this)
                    .removeClass("is-invalid")
                    .addClass("is-valid")
                    .css("background-color", "#e6ffec");
            } else {
                $(this)
                    .removeClass("is-valid")
                    .addClass("is-invalid")
                    .css("background-color", "#ffe6e6");
            }
        } else if (
            this.name === "first_name" ||
            this.name === "last_name" ||
            this.name === "organization"
        ) {
            const alphaNumericPattern = /^[A-Za-z0-9 ]+$/;
            if (alphaNumericPattern.test(value)) {
                $(this)
                    .removeClass("is-invalid")
                    .addClass("is-valid")
                    .css("background-color", "#e6ffec");
            } else {
                $(this)
                    .removeClass("is-valid")
                    .addClass("is-invalid")
                    .css("background-color", "#ffe6e6");
            }
        } else {
            $(this)
                .removeClass("is-invalid")
                .addClass("is-valid")
                .css("background-color", "#e6ffec");
        }
    } else {
        $(this).removeClass("is-invalid is-valid").css("background-color", "");
    }
});

$("#add_new").on("hidden.bs.modal", function () {
    $("#addEmployerForm")[0].reset();
    $("#formErrors").html("");
    $("#addEmployerForm .form-control")
        .removeClass("is-valid is-invalid")
        .css("background-color", "");
});
$(document).on("click", ".restore_icon", function () {
    let userId = $(this).data("id");
    $("#restore_user .confirm-restore-btn").data("id", userId);
});
$(document).on("click", ".confirm-restore-btn", function () {
    let userId = $(this).data("id");

    $.ajax({
        url: "/wellify_users/" + userId + "/restore",
        type: "POST",
        data: {},
        success: function () {
            $("#restore_user").modal("hide");
            $(".modal-backdrop").remove();
            $("body").removeClass("modal-open");
            $("body").css("padding-right", "");
            $("#inactiveEmployersTable").DataTable().ajax.reload();
        },
        error: function () {
            alert("Failed to restore employer.");
        },
    });
});

// Select/Deselect all checkboxes
$(document).on("change", "#selectAllRestore", function () {
    $(".restore-checkbox").prop("checked", this.checked);
});
$(document).on("change", ".restore-checkbox", function () {
    if (!$(this).is(":checked")) {
        $("#selectAllRestore").prop("checked", false);
    } else if (
        $(".restore-checkbox:checked").length === $(".restore-checkbox").length
    ) {
        $("#selectAllRestore").prop("checked", true);
    }
});

let selectedBulkIds = [];

$("#bulkRestoreButton").on("click", function () {
    selectedBulkIds = $(".restore-checkbox:checked")
        .map(function () {
            return $(this).val();
        })
        .get();

    if (selectedBulkIds.length === 0) {
        alert("Please select at least one employer to restore.");
        return;
    }
});

$(document).on("click", ".confirm-bulk-restore-btn", function () {
    if (selectedBulkIds.length === 0) return;

    $.ajax({
        url: wellifyUsersBulkRestoreData,
        method: "POST",
        data: {
            ids: selectedBulkIds,
        },

        success: function () {
            $("#bulk_restore_user").modal("hide");
            $(".modal-backdrop").remove();
            $("body").removeClass("modal-open").css("padding-right", "");
            $("#inactiveEmployersTable").DataTable().ajax.reload();
            $("#employersTable").DataTable().ajax.reload();
        },
        error: function () {
            alert("Something went wrong while restoring.");
        },
    });
});
$("input[maxlength]").on("input", function () {
    const maxLength = $(this).attr("maxlength");
    if ($(this).val().length > maxLength) {
        $(this).val($(this).val().substring(0, maxLength));
    }
});
function toggleButtonLoading(buttonId, spinnerId, isLoading) {
    const modal = $(".modal.show");

    if (isLoading) {
        $(buttonId).prop("disabled", true);
        $(spinnerId).removeClass("d-none");
        $(buttonId + " .btn-text").addClass("d-none");

        // Disable all inputs and the Close button (in footer)
        modal
            .find("input, select, textarea, button:not(" + buttonId + ")")
            .prop("disabled", true);
        modal
            .find(".modal-close-btn")
            .prop("disabled", true)
            .css("pointer-events", "none");
    } else {
        $(buttonId).prop("disabled", false);
        $(spinnerId).addClass("d-none");
        $(buttonId + " .btn-text").removeClass("d-none");

        // Re-enable all fields and the Close button
        modal.find("input, select, textarea, button").prop("disabled", false);
        modal.find(".modal-close-btn").css("pointer-events", "auto");
    }
}

//code for employee management
$(document).on("click", "#employee_view_icon", function () {
    const userId = $(this).data("id");
    // alert(userId);
    $.ajax({
        url: "/wellify_app_users/" + userId,
        type: "GET",
        dataType: "json",
        success: function (response) {
            $("#view_app_user_content").html(response.html);
            $("#view_app_user").modal("show");
        },
        error: function () {
            alert("Unable to load user data.");
        },
    });
});
/**
 * ediy code for employees
 */
// Format phone number from DB (digits only) to xxx-xxx-xxxx for display
function formatPhoneToDisplay(phone) {
    if (!phone || phone.length !== 10) return phone;
    return phone.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");
}

// Format phone input live as user types
$(document).on("input", "#phone1", function () {
    let input = $(this);
    let digits = input.val().replace(/\D/g, "").substring(0, 10); // max 10 digits

    let formatted = digits;
    if (digits.length > 6) {
        formatted =
            digits.substring(0, 3) +
            "-" +
            digits.substring(3, 6) +
            "-" +
            digits.substring(6, 10);
    } else if (digits.length > 3) {
        formatted = digits.substring(0, 3) + "-" + digits.substring(3);
    }
    input.val(formatted);
});

// On clicking edit button, load data and format phone for display
$(document).on("click", "#employee_edit_icon", function () {
    const userId = $(this).data("id");
    const modal = $("#edit_app_user");

    $("#editAppUserErrors").addClass("d-none").html("");
    $("#editAppUserForm")[0].reset();
    $("#currentempProfilePicture").html("");

    modal.modal("show");

    $.get("/wellify_app_users/" + userId + "/edit", function (response) {
        if (response.success) {
            const user = response.user;
            const timezones = response.timezones;

            $("#editAppUserForm").attr(
                "action",
                "/wellify_app_users/" + userId
            );
            $("#first_name1").val(user.first_name);
            $("#last_name1").val(user.last_name);
            $("#email1").val(user.email);
            $("#licenses1").val(user.licenses);
            $("#CRM_link1").val(user.CRM_link);
            $("#notes1").val(user.notes);
            $("#phone1").val(formatPhoneToDisplay(user.mobile_phone)); // format here!
            $("#office1").val(user.office);
            $("#city1").val(user.city);
            $("#state1").val(user.state);
            $("#country1").val(user.country);
            $("#user_timezone2").val(user.user_timezone);

            // Timezones dropdown
            const timezoneSelect = $("#user_timezone2");
            timezoneSelect
                .empty()
                .append('<option value="">Select Timezone</option>');
            timezones.forEach((tz) => {
                const selected =
                    user.user_timezone_id === tz.id ? "selected" : "";
                timezoneSelect.append(
                    `<option value="${tz.id}" ${selected}>${tz.abbreviation} (${tz.utc_offset})</option>`
                );
            });

            $.get(
                "/wellify_app_users/" + userId + "/profile-picture-url",
                function (urlResponse) {
                    if (urlResponse.success) {
                        $("#currentempProfilePicture").html(`
                        <label class="form-label">Current Logo :</label>
                        <img src="${urlResponse.url}"  class="logo-preview">
                    `);
                    }
                }
            );
        }
    }).fail(function (xhr) {
        $("#editAppUserErrors")
            .removeClass("d-none")
            .html(xhr.responseJSON?.message || "Failed to load employee data");
    });
});

$(document).on("submit", "#editAppUserForm", function (e) {
    e.preventDefault();

    let phoneInput = $("#phone1");
    let phoneVal = phoneInput.val().trim();

    // Validate phone format xxx-xxx-xxxx using regex
    let phoneRegex = /^\d{3}-\d{3}-\d{4}$/;
    if (!phoneRegex.test(phoneVal)) {
        Swal.fire(
            "Error!",
            "Phone number must be in the format XXX-XXX-XXXX.",
            "error"
        );
        phoneInput.addClass("is-invalid");
        phoneInput.focus();
        return false;
    }

    // Strip dashes for backend storage
    let digitsOnly = phoneVal.replace(/\D/g, "");
    phoneInput.val(digitsOnly);

    // Submit the form normally now
    this.submit();
});

let appUserIdToDelete = null;
$(document).on("click", "#employee_delete_icon", function () {
    appUserIdToDelete = $(this).attr("data-id");
    $("#delete_app_user_id").val(appUserIdToDelete);
});

$("#deleteAppUserForm").on("submit", function (e) {
    e.preventDefault();
    const userId = $("#delete_app_user_id").val();
    $.ajax({
        url: "/wellify_app_users/" + userId,
        type: "DELETE",
        success: function (response) {
            if (response.success) {
                $("#delete_app_user").modal("hide");
                location.reload();
            } else {
                alert(response.message);
            }
        },
        error: function () {
            alert("Something went wrong while deleting the user.");
        },
    });
});

/**
 *  js code for add employees
 */

$("#add_new_app_user").on("hidden.bs.modal", function () {
    $("#addEmployeeForm")[0].reset();
    $("#employeeFormErrors").html("");
    $("#addEmployeeForm .form-control")
        .removeClass("is-valid is-invalid")
        .css("background-color", "");
    $("#mobilePhoneFeedback").hide().text("");
});
function restrictInput(event) {
    const input = $(this);
    const value = input.val();
    if (/^[a-zA-Z\s]*$/.test(value)) {
        input.removeClass("is-invalid").addClass("is-valid");
    } else {
        input.val(value.slice(0, -1)); // Remove last character
        input.removeClass("is-valid").addClass("is-invalid");
    }
}

$("#city, #state, #country").on("input", restrictInput);
$('input[name="mobile_phone"]').on("input", function () {
    let input = this.value.replace(/\D/g, "").slice(0, 10);
    let formatted = "";

    if (input.length <= 3) {
        formatted = input;
    } else if (input.length <= 6) {
        formatted = `${input.slice(0, 3)}-${input.slice(3)}`;
    } else {
        formatted = `${input.slice(0, 3)}-${input.slice(3, 6)}-${input.slice(
            6
        )}`;
    }
    this.value = formatted;
});
$(document).ready(function () {
    $("#addEmployeeForm").on("submit", function (e) {
        e.preventDefault();
        $("#employeeFormErrors").empty();
        $(".form-control").removeClass("is-invalid");
        $("#mobilePhoneFeedback").hide();

        let valid = true;

        // email validation
        const email = $('input[name="email"]').val();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
        if (!emailRegex.test(email)) {
            valid = false;
            $('input[name="email"]').addClass("is-invalid");
            // $("#employeeFormErrors").append(
            //     '<div class="alert alert-danger">Please enter a valid email address.</div>'
            // );
            Swal.fire("Error!", "Please enter a valid email address.", "error");
            return;
        }

        // CRM link validation
        const crmInput = $('input[name="CRM_link"]');
        const crmVal = crmInput.val();
        const urlRegex = /^(https?:\/\/)([\da-z.-]+\.[a-z.]{2,6})([/\w .-]*)*\/?$/i;

        if (crmVal && !urlRegex.test(crmVal)) {
            valid = false;
            crmInput.addClass("is-invalid");
            $("#crmLinkFeedback").text("Please enter a valid CRM URL (e.g., https://crm.example.com)").show();

            Swal.fire("Error!", "Please enter a valid CRM URL (e.g., https://crm.example.com)", "error");
            return;
        } else {
            crmInput.removeClass("is-invalid");
            $("#crmLinkFeedback").hide();
        }

        // phone validation
        const phoneInput = $('input[name="mobile_phone"]');
        const phoneVal = phoneInput.val();
        if (!/^\d{3}-\d{3}-\d{4}$/.test(phoneVal)) {
            valid = false;
            phoneInput.addClass("is-invalid");
            $("#mobilePhoneFeedback")
                .text("Phone number must be in the format XXX-XXX-XXXX.")
                .show();
            Swal.fire(
                "Error!",
                "Phone number must be in the format XXX-XXX-XXXX.",
                "error"
            );
            return;
        }

        // city/state/country validation
        const textRegex = /^[a-zA-Z\s]*$/;
        ["city", "state", "country"].forEach((f) => {
            const field = $(`#${f}`);
            if (field.val() && !textRegex.test(field.val())) {
                valid = false;
                field.addClass("is-invalid");
                $("#employeeFormErrors").append(
                    `<div class="alert alert-danger">${
                        f.charAt(0).toUpperCase() + f.slice(1)
                    } must contain only letters and spaces.</div>`
                );
            }
        });

        if (!valid) return;

        $.ajax({
            url: wellifyAppUsersStoreData,
            type: "POST",
            data: new FormData(this),
            contentType: false,
            processData: false,
            success(res) {
                Swal.fire(
                    "Success!",
                    res.message || "Employee created.",
                    "success"
                ).then(() => location.reload());
            },
            error(xhr) {
                $(".form-control").removeClass("is-invalid");
                $("#employeeFormErrors").empty();

                if (xhr.status === 422) {
                    const errs = xhr.responseJSON.errors;
                    if (errs.mobile_phone) {
                        phoneInput.addClass("is-invalid");
                        $("#mobilePhoneFeedback")
                            .text(errs.mobile_phone[0])
                            .show();
                    }
                    if (errs.email) {
                        $('input[name="email"]').addClass("is-invalid");
                    }
                    if (errs.licenses) {
                        $("#licenses").addClass("is-invalid");
                        Swal.fire("Error!", errs.licenses[0], "error");
                        return;
                    }
                    // List other errors
                    let messages = [].concat(...Object.values(errs));
                    Swal.fire("Error!", messages.join("<br>"), "error");
                } else {
                    Swal.fire(
                        "Error!",
                        "An unexpected error occurred.",
                        "error"
                    );
                }
            },
        });
    });
});

$(document).on("click", ".employee_restore_icon", function () {
    const employeeId = $(this).attr("data-id");
    // $('#restore_user #confirm_restore_app_employee_btn').data('id', userId);
    $("#restore_app_employee_id").val(employeeId);
    $("#restore_app_user_modal").modal("show");
});
$(document).on("click", "#confirm_restore_app_employee_btn", function () {
    let userId = $("#restore_app_employee_id").val();
    $.ajax({
        url: "/wellify_app_users/" + userId + "/restore",
        type: "POST",
        data: {},
        success: function () {
            $("#restore_app_user_modal").modal("hide");
            $(".modal-backdrop").remove();
            $("body").removeClass("modal-open");
            $("body").css("padding-right", "");
            $("#inactive-employees-datatable").DataTable().ajax.reload();
            $("#employeesTable").DataTable().ajax.reload();
        },
        error: function () {
            alert("Failed to restore employer.");
        },
    });
});

// Select/Deselect all checkboxes
$(document).on("change", "#selectAllEmployeeRestore", function () {
    $(".restore-employee-checkbox").prop("checked", this.checked);
});
$(document).on("change", ".restore-employee-checkbox", function () {
    if (!$(this).is(":checked")) {
        $("#selectAllEmployeeRestore").prop("checked", false);
    } else if (
        $(".restore-employee-checkbox:checked").length ===
        $(".restore-employee-checkbox").length
    ) {
        $("#selectAllEmployeeRestore").prop("checked", true);
    }
});

let selectedappBulkIds = [];

$("#bulkEmployeeRestoreButton").on("click", function () {
    selectedappBulkIds = $(".restore-employee-checkbox:checked")
        .map(function () {
            return $(this).val();
        })
        .get();

    if (selectedappBulkIds.length === 0) {
        alert("Please select at least one employer to restore.");
        return;
    }
});

$(document).on("click", ".confirm-bulk-restore-btn", function () {
    if (selectedappBulkIds.length === 0) return;

    $.ajax({
        url: wellifyAppUsersBulkRestoreData,
        method: "POST",
        data: {
            ids: selectedappBulkIds,
        },

        success: function () {
            $("#bulk_restore_user").modal("hide");
            $(".modal-backdrop").remove();
            $("body").removeClass("modal-open").css("padding-right", "");
            $("#inactive-employees-datatable").DataTable().ajax.reload();
            $("#employeesTable").DataTable().ajax.reload();
        },
        error: function () {
            alert("Something went wrong while restoring.");
        },
    });
});
$("input[maxlength]").on("input", function () {
    const maxLength = $(this).attr("maxlength");
    if ($(this).val().length > maxLength) {
        $(this).val($(this).val().substring(0, maxLength));
    }
});

let selectedEmployerId = null;

$(document).on('click', '.send_mail_icon[data-status="new"]', function () {
    console.log("hii");
    selectedEmployerId = $(this).data('id');
    const name = $(this).data('name');
    $('#employerInfo').text(name);
    $('#send_welcome_modal').modal('show');
});

$(document).on('click', '.send_mail_icon[data-status="sent"]', function () {
    selectedEmployerId = $(this).data('id');
    const name = $(this).data('name');
    $('#resendEmployerInfo').text(name);
    $('#resend_welcome_modal').modal('show');
});


$(document).on('click', '.disabled_mail_icon', function () {
    const name = $(this).data('name');
    $('#pendingEmployerInfo').text(name); // sets name in #pending_payment_modal
    $('#pending_payment_modal').modal('show');
});


$('#confirmSendEmail').on('click', function () {
    if (!selectedEmployerId) return;

    $.ajax({
        url: '/admin/employers/send-welcome/' + selectedEmployerId,
        method: 'POST',
        data: {
            _token: $('meta[name="csrf-token"]').attr('content')
        },
        success: function (response) {
            $('#send_welcome_modal').modal('hide');
            // alert(response.message);
            $('#yourDataTable').DataTable().ajax.reload(null, false);
        },
        error: function (xhr) {
            $('#send_welcome_modal').modal('hide');
            alert(xhr.responseJSON.message || 'Failed to send email.');
        }
    });
});


$('#confirmResendEmail').on('click', function () {
    if (!selectedEmployerId) return;

    $.ajax({
        url: '/admin/employers/send-welcome/' + selectedEmployerId,
        method: 'POST',
        data: {
            _token: $('meta[name="csrf-token"]').attr('content')
        },
        success: function (response) {
            $('#resend_welcome_modal').modal('hide');
            // alert(response.message);
            $('#yourDataTable').DataTable().ajax.reload(null, false);
        },
        error: function (xhr) {
            $('#resend_welcome_modal').modal('hide');
            alert(xhr.responseJSON.message || 'Failed to resend email.');
        }
    });
});

function isValidUrl(url) {
    const pattern = new RegExp('^(https?:\\/\\/)' + // http:// or https://
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*))\\.)+([a-z]{2,})' +
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' +
        '(\\?[;&a-z\\d%_.~+=-]*)?' +
        '(\\#[-a-z\\d_]*)?$', 'i');
    return !!pattern.test(url);
}

function handleFormValidation(form) {
    const crmInput = form.find("input[name='CRM_link']");
    const url = crmInput.val().trim();

    crmInput.removeClass("is-invalid");
    form.find(".invalid-feedback").remove();

    if (url && !isValidUrl(url)) {
        crmInput.addClass("is-invalid");
        crmInput.after('<div class="invalid-feedback">Please enter a valid URL (e.g., https://crm.example.com).</div>');
        return false;
    }
    return true;
}

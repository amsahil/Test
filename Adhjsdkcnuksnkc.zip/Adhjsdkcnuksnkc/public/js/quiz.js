document.addEventListener('DOMContentLoaded', function() {
    // Global modal instance
    let quizModal = null;

    // Initialize modal when shown
    document.addEventListener('show.bs.modal', function(event) {
        if (event.target.id === 'addQuizModal') {
            const button = event.relatedTarget;
            const classId = button.getAttribute('data-id');

            // Set the class ID in the modal
            const classIdInput = document.getElementById('class_idQuiz');
            if (classIdInput) {
                classIdInput.value = classId;
            }

            // Reset the form
            const form = document.getElementById('quizForm');
            if (form) {
                form.reset();
                resetOptionsToInitialState();
            }

            // Store modal instance
            quizModal = new bootstrap.Modal(event.target);
        }
    });

    // Function to reset options to initial state
    function resetOptionsToInitialState() {
        const optionsContainer = document.getElementById('addOptions');
        if (optionsContainer) {
            optionsContainer.innerHTML = `
                <div class="option_outer">
                    <div class="option_box mb-3">
                        <label for="option_1" class="form-label">Option 1</label>
                        <input type="text" class="form-control input" id="option_1"
                            placeholder="Enter option" name="options[]" required>
                    </div>
                    <div class="option_box mb-3">
                        <label for="option_2" class="form-label">Option 2</label>
                        <input type="text" class="form-control input" id="option_2"
                            placeholder="Enter option" name="options[]" required>
                    </div>
                    <div class="add_delete-icon mb-3">
                        <img src="/assets/images/Add_icon.svg" alt="add icon" class="img-fluid add-option-btn"
                            style="cursor: pointer;">
                    </div>
                </div>
            `;
        }

        // Reset correct answers checkboxes
        const answersContainer = document.getElementById('correctAnswersContainer');
        if (answersContainer) {
            answersContainer.innerHTML = `
                <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                    <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                        value="0" id="answer_1">
                    <label class="form-check-label mb-0" for="answer_1">
                        Option 1
                    </label>
                </div>
                <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                    <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                        value="1" id="answer_2">
                    <label class="form-check-label mb-0" for="answer_2">
                        Option 2
                    </label>
                </div>
            `;
        }

        // Re-attach event listeners for add option button
        attachAddOptionListener();
    }

    // Function to attach event listener to add option button
    function attachAddOptionListener() {
        const addBtn = document.querySelector('.add-option-btn');
        if (addBtn) {
            addBtn.removeEventListener('click', addOptionField); // Remove existing listener
            addBtn.addEventListener('click', addOptionField);
        }
    }

    // Add new option field function
    function addOptionField() {
        const optionsContainer = document.getElementById('addOptions');
        if (!optionsContainer) return;

        const optionCount = optionsContainer.querySelectorAll('.option_box').length + 1;

        if (optionCount > 10) {
            alert('Maximum 10 options allowed');
            return;
        }

        // Create new option input
        const newOptionDiv = document.createElement('div');
        newOptionDiv.className = 'option_box mb-3';
        newOptionDiv.innerHTML = `
            <label for="option_${optionCount}" class="form-label">Option ${optionCount}</label>
            <input type="text" class="form-control input" id="option_${optionCount}"
                placeholder="Enter option" name="options[]" required>
        `;

        // Insert before the add button
        const addButtonDiv = optionsContainer.querySelector('.add_delete-icon');
        if (addButtonDiv) {
            optionsContainer.insertBefore(newOptionDiv, addButtonDiv);
        }

        // Add corresponding checkbox
        const answersContainer = document.getElementById('correctAnswersContainer');
        if (answersContainer) {
            const newCheckboxDiv = document.createElement('div');
            newCheckboxDiv.className = 'col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3';
            newCheckboxDiv.innerHTML = `
                <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                    value="${optionCount - 1}" id="answer_${optionCount}">
                <label class="form-check-label mb-0" for="answer_${optionCount}">
                    Option ${optionCount}
                </label>
            `;

            answersContainer.appendChild(newCheckboxDiv);
        }
    }

    // Form submission
    const quizForm = document.getElementById('quizForm');
    if (quizForm) {
        quizForm.addEventListener('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(this);
            const classId = document.getElementById('class_idQuiz').value;

            if (!classId) {
                alert('Class ID is required');
                return;
            }

            // Validate correct answers
            const correctCheckboxes = document.querySelectorAll('#addQuizModal input[name="correct_answers[]"]:checked');
            if (correctCheckboxes.length === 0) {
                alert('Please select at least one correct answer');
                return;
            }

            // Add correct answers to form data
            const correctAnswers = Array.from(correctCheckboxes).map(cb => cb.value);

            // Clear existing correct_answers and add new ones
            formData.delete('correct_answers[]');
            correctAnswers.forEach(index => {
                formData.append('correct_answers[]', index);
            });

            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Submitting...';
            submitBtn.disabled = true;

            // Submit via AJAX
            fetch(`/classes/${classId}/quizzes`, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                }
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => { throw err; });
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Show success message
                    alert('Quiz created successfully!');

                    // Update quiz count in the table
                    const quizCountElement = document.querySelector(`[data-id="${classId}"] small`);
                    if (quizCountElement) {
                        quizCountElement.textContent = `${data.quiz_count} Quiz${data.quiz_count !== 1 ? 's' : ''}`;
                    }

                    // Close modal
                    if (quizModal) {
                        quizModal.hide();
                    }

                    // Reset form
                    quizForm.reset();
                    resetOptionsToInitialState();
                } else {
                    // Show validation errors
                    if (data.errors) {
                        let errorMessages = [];
                        for (const [key, messages] of Object.entries(data.errors)) {
                            errorMessages.push(...messages);
                        }
                        alert('Error: ' + errorMessages.join('\n'));
                    } else {
                        alert('Error: ' + data.message);
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
                let message = 'An error occurred while creating the quiz.';
                if (error.message) {
                    message = error.message;
                } else if (error.errors) {
                    let errorMessages = [];
                    for (const [key, messages] of Object.entries(error.errors)) {
                        errorMessages.push(...messages);
                    }
                    message = errorMessages.join('\n');
                }
                alert('Error: ' + message);
            })
            .finally(() => {
                // Reset submit button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            });
        });
    }

    // Initial setup
    attachAddOptionListener();

    // Make addOptionField globally available for inline onclick if needed
    window.addOptionField = addOptionField;
});

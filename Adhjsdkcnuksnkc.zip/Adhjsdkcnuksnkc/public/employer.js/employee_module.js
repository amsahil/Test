
$(document).ready(function () {
    // Initialize variables for the tables
    var assignedTable = null;
    var unassignedTable = null;

    // Check and initialize the assigned departments table
    if (document.querySelector('#depart_datatable')) {
        const columns = [
            {
                data: null,
                title: 'S.No.',
                render: function (data, type, row, meta) {
                    return meta.row + 1;
                },
                orderable: false,
                searchable: false
            },
            { data: 'name', title: 'Department Name' },
            { data: 'description', title: 'Department Description' },
            { data: 'actions', orderable: false, searchable: false, title: 'Action' }
        ];

        // Add employer column only for non-employer roles
        if (userRole !== 'Employer') {
            columns.splice(1, 0, {
                data: 'employer_id',
                title: 'Employer'
            });
        }
        assignedTable = new DataTable('#depart_datatable', {
            ajax: window.routes.departmentsData,
            columns: columns,
            responsive: true
        });
    }

    // Check and initialize the unassigned departments table
    if (document.querySelector('#unassigned_depart_datatable')) {
        unassignedTable = new DataTable('#unassigned_depart_datatable', {
            ajax: window.routes.getunAssignedDepartmentsData,
            columns: [
                {
                    data: null,
                    title: '#',
                    render: function (data, type, row, meta) {
                        return meta.row + 1;
                    },
                    orderable: false,
                    searchable: false
                },
                { data: 'name', title: 'Department Name' },
                { data: 'description', title: 'Department Description' },
                { data: 'actions', orderable: false, searchable: false, title: 'Action' }
            ],
            responsive: true
        });
    }
    // regarding limit set to 25 characters for all inputs
      $('input').on('input', function() {
        if ($(this).val().length > 35) {
            $(this).val($(this).val().substring(0, 35)); // Truncate to 25 characters
        }
    });
// Reset form fields when the modal is hidden
$('#add_new_department').on('hidden.bs.modal', function () {
    // Reset the form
    $('#addDepartmentForm')[0].reset();

    // Clear any validation feedback
    $('.is-invalid').removeClass('is-invalid');
    $('.invalid-feedback').hide().text('');
});
    $('#addDepartmentForm').on('submit', function (e) {
      
        e.preventDefault();

        const form = $(this);
        const url = form.attr('action');
        const data = form.serialize();

        // Clear previous validation feedback
        form.find('.is-invalid').removeClass('is-invalid error_input');
        form.find('.invalid-feedback').hide().text('');
  const departmentName = $('#department_name').val().trim();
    const specialCharPattern = /^[!@#$%^&*(),.?":{}|<>]*$/;
    
    if (specialCharPattern.test(departmentName)) {
        // If the department name contains only special characters
        $('#department_name').addClass('is-invalid error_input');
        $('#nameFeedback').text('Department name cannot contain only special characters.').show();
        swal({
            title: "Validation Error",
            text: "Please enter a valid department name.",
            icon: "warning",
            button: "OK",
        });
        return; // Prevent form submission
    }
        $.ajax({
            type: "POST",
            url: url,
            data: data,
            dataType: 'json', // Explicitly specify JSON data type
            success: function (response) {
                form[0].reset();
                $('#add_new_department').modal('hide');

                swal({
                    title: "Success!",
                    text: response.message,
                    icon: "success",
                    button: "OK",
                }).then(() => {
                    location.reload();
                });
            },
            error: function (xhr) {
                // Log the full error response for debugging
                console.error('Full error response:', xhr);

                // Check for different types of errors
                if (xhr.responseJSON) {
                    const errors = xhr.responseJSON.errors;
                    const message = xhr.responseJSON.message;

                    if (errors) {
                        let firstErrorMessage = "Please fix the errors and try again.";
                        let errorFields = Object.keys(errors);

                        // Dynamically handle error display based on user role
                        errorFields.forEach(field => {
                            // Use the correct input selector based on the field name
                            let inputSelector = field === 'employer_id' ? '#employeer_name' : '#department_name';
                            const input = $(inputSelector);
                            const feedback = $(`#${field}Feedback`);

                            input.addClass('is-invalid error_input');
                            feedback.text(errors[field][0]).show();

                            // Capture first error message
                            if (firstErrorMessage === "Please fix the errors and try again.") {
                                firstErrorMessage = errors[field][0];
                            }
                        });

                        swal({
                            title: "Validation Error",
                            text: firstErrorMessage,
                            icon: "warning",
                            button: "OK",
                        });
                    } else if (message) {
                        // If there's a specific error message
                        swal({
                            title: "Error",
                            text: message,
                            icon: "error",
                            button: "OK",
                        });
                    } else {
                        // Generic error if no specific message
                        swal({
                            title: "Error",
                            text: "An unexpected error occurred. Please try again.",
                            icon: "error",
                            button: "OK",
                        });
                    }
                } else {
                    // Handle non-JSON responses or network errors
                    swal({
                        title: "Network Error",
                        text: "Unable to connect to the server. Please check your internet connection and try again.",
                        icon: "error",
                        button: "OK",
                    });
                }
            }
        });
    });

    // Live remove error styling on typing
    $('#addDepartmentForm input, #addDepartmentForm textarea').on('input', function () {
        $(this).removeClass('is-invalid error_input');
        $('#' + this.id + 'Feedback').hide();
    });

    /**edit department modal*/
    /**edit department modal*/
    $(document).on('click', '.edit-dept-modal', function () {
        var id = $(this).data('id');
        var name = $(this).data('name');
        var description = $(this).data('description');

        // Get employer name from the table row
        var employerName = $(this).closest('tr').find('td:nth-child(2)').text(); // Adjust index based on your table structure

        $('#edit_department_id').val(id);
        $('#edit_department_name').val(name);
        $('#edit_department_description').val(description);
        $('#edit_department_employer').val(employerName);
        $('#edit-department-form').attr('action', '/departments/' + id);
        $('#edit_department_modal').modal('show');
    });

    $('#edit-department-form').on('submit', function (e) {
        e.preventDefault();
        let form = $(this);
        let url = form.attr('action');
        let token = $('input[name="_token"]').val();

        // Clear previous error states
        $('.is-invalid').removeClass('is-invalid');
        $('.invalid-feedback').remove();
  let departmentName = $('#edit_department_name').val().trim();
    const specialCharPattern = /^[!@#$%^&*(),.?":{}|<>]*$/; 
       if (specialCharPattern.test(departmentName)) {
        $('#edit_department_name').addClass('is-invalid');
        $('#edit_department_name').after('<div class="invalid-feedback">Department name cannot contain only special characters.</div>');
        swal("Validation Error", "Please enter a valid department name.", "warning");
        return; // Prevent form submission
    }
        let formData = {
            _method: 'PUT',
            _token: token,
            name: $('#edit_department_name').val(),
            description: $('#edit_department_description').val()
        };

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            success: function (response) {
                $('#edit_department_modal').modal('hide');
                swal("Updated!", "Department updated successfully.", "success")
                    .then(() => {
                        location.reload();
                    });
            },
            error: function (xhr) {
                // Handle validation errors
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;

                    if (errors.name) {
                        // Specific handling for unique department name error
                        if (errors.name.includes('This Department name already exists for your organization.')) {
                            swal("Error", "This Department name already exists for your organization.", "error");
                        } else {
                            $('#edit_department_name')
                                .addClass('is-invalid')
                                .after(`<div class="invalid-feedback">${errors.name[0]}</div>`);

                            swal("Error", "Please check the form for errors.", "error");
                        }
                    } else {
                        swal("Error", "Please check the form for errors.", "error");
                    }
                } else {
                    swal("Error", "Update failed.", "error");
                    console.error(xhr.responseText);
                }
            }
        });
    });

    let selectedDeptId = null;

    $(document).on('click', '.delete-dept-btn', function (e) {
        e.preventDefault();
        selectedDeptId = $(this).data('id');
        $('#delete_department').modal('show');
    });

    $('#delete_department .warning_button').on('click', function (e) {
        e.preventDefault();

        if (!selectedDeptId) return;

        $.ajax({
            url: '/departments/' + selectedDeptId,
            type: 'DELETE',
            data: {
                _token: $('meta[name="csrf-token"]').attr('content')
            },
            success: function (response) {
                $('#delete_department').modal('hide');
                swal("Success", response.message, "success");
                setTimeout(() => {
                    location.reload();
                }, 1500);
            },
            error: function (xhr) {
                const res = xhr.responseJSON;
                $('#delete_department').modal('hide');
                swal("Error", res?.message || "Something went wrong.", "error");
            }
        });
    });
    var activeEmployeeTable = null;
    var inactiveEmployeeTable = null;

    /**Check and initialize the active employee table*/
    if (document.querySelector('#employee-datatable')) {
        let columns = [
            {
                data: null,
                title: '<input type="checkbox" id="select-all-emails" class="form-check-input">',
                render: function (data, type, row) {
                    return `<input type="checkbox" class="email-checkbox form-check-input" 
                        data-id="${row.id}" 
                        data-email="${row.email}" 
                        data-username="${row.name}">`;
                },
                orderable: false,
                searchable: false
            },
            {
                data: null,
                title: 'S.No.',
                render: function (data, type, row, meta) {
                    return meta.row + 1;
                },
                orderable: false,
                searchable: false
            }
        ];

        // Add employer column for non-employer roles
        if (userRole !== 'Employer') {
            columns.push({
                data: 'employer',
                title: 'Employer Name'
            });
        }

        // Rest of the columns
        columns.push(
            { data: 'name', title: 'Staff Name' },
            { data: 'email', title: 'Email' },
            { data: 'department', title: 'Department' },
            {
                data: 'phone',
                title: 'Phone',
                render: function (data, type, row) {
                    if (data && data.length === 10 && /^\d+$/.test(data)) {
                        return data.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
                    }
                    return data || '-';
                }
            },
            { data: 'city', title: 'City' },
            { data: 'state', title: 'State' },
            { data: 'country', title: 'Country' },
            { data: 'status', title: 'Status' },
            { data: 'actions', orderable: false, searchable: false, title: 'Action' }
        );

        activeEmployeeTable = new DataTable('#employee-datatable', {
            ajax: window.routes.employeesData,
            columns: columns,
            responsive: true
        });
    }
       $("#employee-datatable").on("change", ".flipswitch-cb", function () {
        var checkbox = $(this);
        var userId = checkbox.data("id");
        var newStatus = checkbox.is(":checked") ? 1 : 0;

        $.ajax({
            url: "/staff-toggle-status-endpoint",
            method: "POST",
            data: {
                id: userId,
                status: newStatus,
            },
            success: function (response) {
                Swal.fire({
                    icon: "success",
                    title: "Success",
                    text: "Status updated successfully!",
                });
                console.log("Status updated");
            },
            error: function (xhr) {
                Swal.fire({
                    icon: "error",
                    title: "Error",
                    text: "Failed to update status: " + xhr.responseText,
                });
                // revert checkbox on error
                checkbox.prop("checked", !newStatus);
            },
        });
    });

    /**Check and initialize the inactive employee table*/
    if (document.querySelector('#inactive-employee-datatable')) {
        inactiveEmployeeTable = new DataTable('#inactive-employee-datatable', {
            ajax: window.routes.inactiveEmployeesData,
            columns: [
                {
                    data: null,
                    title: '#',
                    render: function (data, type, row, meta) {
                        return meta.row + 1;
                    },
                    orderable: false,
                    searchable: false
                },
                { data: 'name', title: 'Name' },
                { data: 'email', title: 'Email' },
                { data: 'department', title: 'Department' },
                {
                    data: 'phone',
                    title: 'Phone',
                    render: function (data, type, row) {
                        if (data && data.length === 10 && /^\d+$/.test(data)) {
                            return data.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
                        }
                        return data || '-';
                    }
                },
                { data: 'city', title: 'City' },
                { data: 'state', title: 'State' },
                { data: 'country', title: 'Country' },
                { data: 'actions', orderable: false, searchable: false, title: 'Action' }
            ],
            responsive: true
        });
    }

$('#add-new-employee').on('hidden.bs.modal', function () {
    $('#addStaffForm')[0].reset();
    $('.is-invalid').removeClass('is-invalid');
    $('.invalid-feedback').hide().text('');
    $('.is-valid').removeClass('is-valid');
});

$('input[name="phone"]').on('input', function () {
    let input = this.value.replace(/\D/g, '').slice(0, 10);
    let formattedNumber = '';

    if (input.length > 0) {
        if (input.length <= 3) {
            formattedNumber = input;
        } else if (input.length <= 6) {
            formattedNumber = `${input.slice(0, 3)}-${input.slice(3)}`;
        } else {
            formattedNumber = `${input.slice(0, 3)}-${input.slice(3, 6)}-${input.slice(6)}`;
        }
    }
    this.value = formattedNumber;
});

$('input[name="staff_email"]').on('input', function () {
    var value = $(this).val();
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

    if (emailPattern.test(value)) {
        $(this).removeClass('is-invalid').addClass('is-valid').css('background-color', '#e6ffec');
        $('#emailFeedback').text('Valid email address.').removeClass('text-danger').addClass('text-success');
    } else {
        $(this).removeClass('is-valid').addClass('is-invalid').css('background-color', '#ffe6e6');
        $('#emailFeedback').text('Invalid email address.').removeClass('text-success').addClass('text-danger');
    }
});

function restrictInput(event) {
    const input = $(this);
    const value = input.val();

    if (/^[a-zA-Z\s]*$/.test(value)) {
        input.removeClass('is-invalid').addClass('is-valid');
    } else {
        input.val(value.slice(0, -1));
        input.removeClass('is-valid').removeClass('is-invalid');
    }
}

$('#city, #state, #country').on('input', restrictInput);

$('#addStaffForm').on('submit', function (e) {
    e.preventDefault();

    var formData = new FormData(this);
    var emailValue = $('input[name="staff_email"]').val();
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

    if (!emailPattern.test(emailValue)) {
        swal("Error!", "Please enter a valid email address.", "error");
        return;
    }

    var isValid = true;
    var textPattern = /^[a-zA-Z\s]*$/;

    var cityValue = $('input[name="city"]').val();
    if (cityValue && !textPattern.test(cityValue)) {
        $('#cityFeedback').text('City must contain only letters and spaces.').show();
        isValid = false;
        $('#city').removeClass('is-valid').addClass('is-invalid');
    } else {
        $('#cityFeedback').hide();
        if (textPattern.test(cityValue)) {
            $('#city').addClass('is-valid');
        } else {
            $('#city').removeClass('is-valid is-invalid');
        }
    }

    var stateValue = $('input[name="state"]').val();
    if (stateValue && !textPattern.test(stateValue)) {
        $('#stateFeedback').text('State must contain only letters and spaces.').show();
        isValid = false;
        $('#state').removeClass('is-valid').addClass('is-invalid');
    } else {
        $('#stateFeedback').hide();
        if (textPattern.test(stateValue)) {
            $('#state').addClass('is-valid');
        } else {
            $('#state').removeClass('is-valid is-invalid');
        }
    }

    var countryValue = $('input[name="country"]').val();
    if (countryValue && !textPattern.test(countryValue)) {
        $('#countryFeedback').text('Country must contain only letters and spaces.').show();
        isValid = false;
        $('#country').removeClass('is-valid').addClass('is-invalid');
    } else {
        $('#countryFeedback').hide();
        if (textPattern.test(countryValue)) {
            $('#country').addClass('is-valid');
        } else {
            $('#country').removeClass('is-valid is-invalid');
        }
    }

    if (!isValid) {
        return;
    }

    $.ajax({
        url: $(this).attr('action'),
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            swal("Success!", response.message, "success").then(() => location.reload());
        },
        error: function (xhr) {
            var errors = xhr.responseJSON?.errors || null;
            var errorMessage = 'There were some issues with the form submission. Please check the fields.';

            if (errors) {
                // Check specifically for phone error to show custom message alone
                if (errors.phone) {
                    errorMessage = errors.phone[0]; // e.g. "Phone number has already been taken."
                    // Highlight phone input with error
                    $('input[name="phone"]').addClass('is-invalid');
                    $('#phoneFeedback').text(errorMessage).show();
                } else {
                    // Show all other errors concatenated
                    errorMessage = Object.values(errors).flat().join('\n');

                    // Clear previous phone error styling if no phone error
                    $('input[name="phone"]').removeClass('is-invalid');
                    $('#phoneFeedback').hide();
                }
            }

            swal("Error!", errorMessage, "error");
        }
    });
});

    $(document).on('click', '.view-employee-modal', function () {
        const employeeId = $(this).data('id');

        $.ajax({
            url: '/staffs/view/' + employeeId,
            type: 'GET',
            success: function (response) {
                if (response.status) {
                    const data = response.data;
                    $('#view_userName').text(data.userName);
                    $('#view_firstName').text(data.firstName);
                    $('#view_lastName').text(data.lastName);

                    $('#view_email').text(data.email);
                    $('#view_phone').text(data.phone);
                    $('#view_department').text(data.department);
                    $('#view_city').text(data.city);
                    $('#view_state').text(data.state);
                    $('#view_country').text(data.country);

                    $('#employeeViewModal').modal('show');
                } else {
                    alert('Unable to fetch employee data.');
                }
            },
            error: function () {
                alert('Something went wrong while fetching employee data.');
            }
        });
    });
// // Reset form fields when the modal is hidden
// $('#editEmployeeModal').on('hidden.bs.modal', function () {
//     // Reset the form
//     $('#editEmployeeForm')[0].reset();
   
//     // Clear any validation feedback
//     $('.is-invalid').removeClass('is-invalid');
//     $('.invalid-feedback').hide().text('');

//     // Remove any success feedback (correct icons)
//     $('.is-valid').removeClass('is-valid');
// });
//     /**Show Edit Modal and populate data*/
//     $(document).on('click', '.edit-employee-modal', function () {

//         // Get employer information
//         var employerName, departmentId;
        

//         // For Super Admin
//         if ($('#edit_employer').length) {
//             employerName = $(this).closest('tr').find('td:nth-child(3)').text();
//             console.log(employerName,'hii');
            
//             $('#edit_employer').val(employerName);
//         }

//         // Populate hidden fields and employee data
//         $('#edit_employee_id').val($(this).data('id'));
//         $('#edit_first_name').val($(this).data('firstname'));
//         $('#edit_last_name').val($(this).data('lastname'));
//         $('#edit_email').val($(this).data('email'));
//         $('#edit_phone').val($(this).data('phone'));

//         // Get the current department ID
//         departmentId = $(this).data('department_id');

//         // Filter departments based on employer
//         $('#edit_department_id option').each(function () {
//             // Hide all options first
//             $(this).hide();

//             // For Super Admin, show departments matching the employer
//             if ($('#edit_employer').length) {
//                 if (
//                     $(this).data('employer') === employerName ||
//                     $(this).val() == departmentId
//                 ) {
//                     $(this).show();
//                 }
//             } else {
//                 // For Employer, show all their departments
//                 $(this).show();
//             }
//         });

//         $('#edit_department_id').val(departmentId);
//         $('#edit_city').val($(this).data('city'));
//         $('#edit_state').val($(this).data('state'));
//         $('#edit_country').val($(this).data('country'));
//         $('#editEmployeeModal').modal('show');
//     });
//        $('#edit_city, #edit_state, #edit_country').on('input', restrictInput);

//     $('#editEmployeeForm').submit(function (e) {
//         e.preventDefault();
//         var phoneInput = $('#edit_phone');
//         var phoneValue = phoneInput.val().trim();
//         var phoneRegex = /^\d{3}-\d{3}-\d{4}$/;

//         // // Validate phone number
//         // if (!phoneRegex.test(phoneValue)) {
//         //     swal("Invalid Phone Number", "Please enter a valid phone number", "error");
//         //     phoneInput.focus();
//         //     return;
//         // }

//         let formData = $(this).serialize();

//         $.ajax({
//             url: '/staffs/update',
//             method: 'POST',
//             headers: {
//                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//             },
//             data: formData,
//             beforeSend: function () {
//                 $('#editEmployeeSubmitBtn')
//                     .prop('disabled', true)
//                     .html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Updating...');
//             },
//             success: function (response) {
//             if (response.status === 'success') {
//                     $('#editEmployeeModal').modal('hide');
//                     $('#editEmployeeForm')[0].reset();

//                     swal({
//                         title: "Updated!",
//                         text: response.message || "Employee updated successfully.",
//                         icon: "success",
//                         timer: 2000,
//                         buttons: false
//                     });


//                     if ($.fn.DataTable.isDataTable('#employeeTable')) {
//                         $('#employeeTable').DataTable().ajax.reload();
//                     } else {
//                         setTimeout(function () {
//                             location.reload();
//                         }, 2000);
//                     }
//                 } else {
//                     // Handle non-success response
//                     swal("Error", response.message || "Update failed", "error");
//                 }
//             },
//             error: function (xhr) {
//                 // Comprehensive error handling
//                 let errorMessage = "Something went wrong. Please try again.";

//                 if (xhr.responseJSON) {
//                     // Check for specific error types
//                     if (xhr.responseJSON.errors) {
//                         let errors = xhr.responseJSON.errors;
//                         errorMessage = "Please check the following errors:\n";

//                         // Detailed error mapping
//                         const errorMap = {
//                             'mobile_phone': 'Phone Number',
//                             // 'email': 'Email',
//                             'first_name': 'First Name',
//                             'last_name': 'Last Name',
//                             'department_id': 'Department'
//                         };

//                         Object.keys(errorMap).forEach(key => {
//                             if (errors[key]) {
//                                 errorMessage += `- ${errorMap[key]}: ${errors[key][0]}\n`;
//                             }
//                         });
//                     } else if (xhr.responseJSON.message) {
//                         // Use server-provided error message
//                         errorMessage = xhr.responseJSON.message;
//                     }
//                 }

//                 // Show error sweet alert
//                 swal("Validation Error", errorMessage, "error");

//                 // Log error for debugging
//                 console.error('Update Error:', xhr);
//             },
//             complete: function () {
//                 // Re-enable submit button
//                 $('#editEmployeeSubmitBtn')
//                     .prop('disabled', false)
//                     .html('Update Employee');
//             }
//         });
//     });



// Format phone number as xxx-xxx-xxxx
function formatPhone(phone) {
    if (!phone) return '';
    phone = phone.toString().replace(/\D/g, ''); // Remove non-digits
    if (phone.length > 10) phone = phone.substring(0, 10); // Limit to 10 digits
    return phone.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
}

// Format phone input live while typing
$('#edit_phone').on('input', function () {
    let input = $(this).val().replace(/\D/g, '');
    if (input.length > 10) input = input.slice(0, 10);

    const formatted = input.replace(/(\d{0,3})(\d{0,3})(\d{0,4})/, function (_, p1, p2, p3) {
        let result = p1;
        if (p2) result += '-' + p2;
        if (p3) result += '-' + p3;
        return result;
    });

    $(this).val(formatted);
});

// Reset form when modal closes
$('#editEmployeeModal').on('hidden.bs.modal', function () {
    $('#editEmployeeForm')[0].reset();
    $('.is-invalid').removeClass('is-invalid');
    $('.invalid-feedback').hide().text('');
    $('.is-valid').removeClass('is-valid');
});

/** Show Edit Modal and populate fields **/
$(document).on('click', '.edit-employee-modal', function () {
    let employerName, departmentId;

    if ($('#edit_employer').length) {
        employerName = $(this).closest('tr').find('td:nth-child(3)').text();
        $('#edit_employer').val(employerName);
    }

    $('#edit_employee_id').val($(this).data('id'));
    $('#edit_first_name').val($(this).data('firstname'));
    $('#edit_last_name').val($(this).data('lastname'));

    // Format and set phone number
    let rawPhone = $(this).data('phone');
    $('#edit_phone').val(formatPhone(rawPhone));

    $('#edit_email').val($(this).data('email'));

    departmentId = $(this).data('department_id');

    $('#edit_department_id option').each(function () {
        $(this).hide();
        if ($('#edit_employer').length) {
            if (
                $(this).data('employer') === employerName ||
                $(this).val() == departmentId
            ) {
                $(this).show();
            }
        } else {
            $(this).show();
        }
    });

    $('#edit_department_id').val(departmentId);
    $('#edit_city').val($(this).data('city'));
    $('#edit_state').val($(this).data('state'));
    $('#edit_country').val($(this).data('country'));

    $('#editEmployeeModal').modal('show');
});

// Restrict input on other fields
$('#edit_city, #edit_state, #edit_country').on('input', restrictInput);

// Submit form
$('#editEmployeeForm').submit(function (e) {
    e.preventDefault();

    const phoneInput = $('#edit_phone');
    const phoneValue = phoneInput.val().trim();
    const phoneRegex = /^\d{3}-\d{3}-\d{4}$/;

    // Validate format
    if (!phoneRegex.test(phoneValue)) {
        swal("Invalid Phone Number", "Please enter a valid phone number (e.g., 123-456-7890)", "error");
        phoneInput.focus();
        return;
    }

    // Strip dashes before submitting
    // phoneInput.val(phoneValue.replace(/\D/g, ''));

    const formData = $(this).serialize();

    $.ajax({
        url: '/staffs/update',
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: formData,
        beforeSend: function () {
            $('#editEmployeeSubmitBtn')
                .prop('disabled', true)
                .html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Updating...');
        },
        success: function (response) {
            if (response.status === 'success') {
                $('#editEmployeeModal').modal('hide');
                $('#editEmployeeForm')[0].reset();

                swal({
                    title: "Updated!",
                    text: response.message || "Employee updated successfully.",
                    icon: "success",
                    timer: 2000,
                    buttons: false
                });

                if ($.fn.DataTable.isDataTable('#employeeTable')) {
                    $('#employeeTable').DataTable().ajax.reload();
                } else {
                    setTimeout(() => location.reload(), 2000);
                }
            } else {
                swal("Error", response.message || "Update failed", "error");
            }
        },
        error: function (xhr) {
            let errorMessage = "Something went wrong. Please try again.";
if (xhr.responseJSON) {
    if (xhr.responseJSON.errors) {
        let errors = xhr.responseJSON.errors;

        // Collect all error messages into an array
        let errorMessages = [];

        const errorMap = {
            'mobile_phone': 'Phone Number',
            'mobile_phone_stripped': 'Phone Number',  // include this as well
            'first_name': 'First Name',
            'last_name': 'Last Name',
            'department_id': 'Department'
        };

        Object.keys(errorMap).forEach(key => {
            if (errors[key]) {
                errorMessages.push(`${errorMap[key]}: ${errors[key][0]}`);
            }
        });

        // Show only phone error message if it's the ONLY error
        if (
            errorMessages.length === 1 &&
            (errors.mobile_phone || errors.mobile_phone_stripped)
        ) {
            errorMessage = errorMessages[0];
        } else {
            // Multiple or other errors, show all nicely
            errorMessage = "Please check the following errors:\n" + errorMessages.map(m => "- " + m).join("\n");
        }
    } else if (xhr.responseJSON.message) {
        errorMessage = xhr.responseJSON.message;
    }
}
            swal("Error", errorMessage, "error");
            console.error('Update Error:', xhr);
        },
        complete: function () {
            $('#editEmployeeSubmitBtn')
                .prop('disabled', false)
                .html('Update Employee');
        }
    });
});


    /**Delete the employer staff */
    let deleteEmployeeId = null;

    $(document).on('click', '.delete-employee-btn', function (e) {
        e.preventDefault();
        deleteEmployeeId = $(this).data('id');
        $('#delete_employee_id').val(deleteEmployeeId);
        $('#delete_staff').modal('show');
    });

    $(document).on('click', '#delete_staff .warning_button', function (e) {
        e.preventDefault();

        const employeeId = $('#delete_employee_id').val();

        if (!employeeId) {
            alert("Invalid employee selected for deletion.");
            return;
        }

        $.ajax({
            url: '/staffs/' + employeeId,
            type: 'DELETE',
            data: {
                _token: $('meta[name="csrf-token"]').attr('content')
            },
            success: function (response) {
                $('#delete_staff').modal('hide');
                // alert(response.message);
                location.reload();
            },
            error: function (xhr) {
                $('#delete_staff').modal('hide');
                const res = xhr.responseJSON;
                alert(res?.message || "Something went wrong.");
            }
        });
    });

    /** Restore the soft delete of department */
    let selectedDeptIdToRestore = null;

    $(document).on('click', '.restore-dept-btn', function () {
        selectedDeptIdToRestore = $(this).data('id');
        $('#restore_department').modal('show');
    });

    $('#restore_department .primary_btn').on('click', function (e) {
        e.preventDefault();

        if (!selectedDeptIdToRestore) return;

        $.post(`/departments/${selectedDeptIdToRestore}/restore`, {
            _token: $('meta[name="csrf-token"]').attr('content'),
            id: selectedDeptIdToRestore // Include the id in the request data
        })
            .done(function (response) {
                $('#restore_department').modal('hide');
                // location.reload();
                window.location.href = window.routes.departmentsIndexUrl;

                // swal("Success", response.message, "success").then(() => {
                //     window.location.href = window.routes.departmentsIndexUrl;
                // });
            })
            .fail(function (xhr) {
                $('#restore_department').modal('hide');
                swal("Error", xhr.responseJSON?.message || "Failed to restore.", "error");
            });
    });


    $(document).on('click', '.restore-employee-btn', function () {
        const employeeId = $(this).data('id');
        $('#restore_employee_id').val(employeeId);
        $('#restore_employee_modal').modal('show');
    });

    // When confirm restore is clicked in modal
    $('#confirm_restore_employee_btn').on('click', function () {
        const employeeId = $('#restore_employee_id').val();

        if (!employeeId) {
            alert("No employee selected for restore.");
            return;
        }

        $.post(`/staffs/${employeeId}/restore`, {
            _token: $('meta[name="csrf-token"]').attr('content')
        })
            .done(function (response) {
                $('#restore_employee_modal').modal('hide');
                // alert(response.message);
                window.location.href = window.routes.employeesIndexUrl;
            })
            .fail(function (xhr) {
                $('#restore_employee_modal').modal('hide');
                alert(xhr.responseJSON?.message || "Failed to restore.");
            });
    });

});

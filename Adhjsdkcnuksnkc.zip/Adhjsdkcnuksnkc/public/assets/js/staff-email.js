
$(document).ready(function () {
    let selectedEmails = [];

    $(document).on('change', '.email-checkbox', function () {
        const employeeId = $(this).data('id');
        const employeeEmail = $(this).data('email');
        const employeeUsername = $(this).data('username');
        if ($(this).is(':checked')) {
            selectedEmails.push({
                id: employeeId,
                email: employeeEmail,
                username: employeeUsername 

            });
        } else {
            selectedEmails = selectedEmails.filter(item => item.id !== employeeId);
        }
        const allCheckboxes = $('.email-checkbox');
        const checkedCheckboxes = $('.email-checkbox:checked');
        $('#select-all-emails').prop('checked', allCheckboxes.length === checkedCheckboxes.length);
        toggleSendEmailButton();
    });

    $('#select-all-emails').on('change', function () {
        $('.email-checkbox').prop('checked', $(this).is(':checked'));

        if ($(this).is(':checked')) {
            selectedEmails = $('.email-checkbox').map(function () {
                return {
                    id: $(this).data('id'),
                    email: $(this).data('email'),
                    username: $(this).data('username') 
                };
            }).get();
        } else {
            selectedEmails = [];
        }
        toggleSendEmailButton();
    });

    function toggleSendEmailButton() {
        $('#send-welcome-emails').removeClass('d-none');
    }

 $('#send-welcome-emails').on('click', function () {
    if (selectedEmails.length === 0) {
        Swal.fire({
            icon: 'warning',
            title: 'No Staff Selected',
            text: 'Please select at least one staff member to send welcome email.',
            position: 'center',
            showConfirmButton: true
        });
        return;
    }

   
    $.ajax({
        url: '/get-welcome-email-template', 
        method: 'GET',
        success: function (templateContent) {
            // Replace actual values with placeholders
            templateContent = templateContent.replace(/{{\s*\$username\s*}}/g, '<span class="non-editable" contenteditable="false">[username]</span>')
                                             .replace(/{{\s*\$email\s*}}/g, '<span class="non-editable" contenteditable="false">[email]</span>')
                                             .replace(/{{\s*\$password\s*}}/g, '<span class="non-editable" contenteditable="false">[password]</span>')
                                             .replace(/Your account has been successfully created\./g, '<span contenteditable="true">Your account has been successfully created.</span>')
                                             .replace(/\s+/g, ' '); // Replace multiple spaces with a single space

            // Use .html() to render the HTML content in the modal
            $('#emailContent').html(templateContent);
            $('#emailEditModal').modal('show');
        },
        error: function () {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Failed to load email template. Please try again.',
                position: 'center',
                showConfirmButton: true
            });
        }
    });
});

$('#sendEditedEmail').on('click', function () {
    // Get the edited content from the contenteditable div
    let editedContent = $('#emailContent').html(); // Use .html() to get the HTML content

    // Create an array to hold personalized content for each employee
    let personalizedContents = selectedEmails.map(employee => {
        return {
            email: employee.email,
            content: editedContent
                .replace(/\[username\]/g, employee.username)
                .replace(/\[email\]/g, employee.email)
                .replace(/\[password\]/g, employee.password) // Assuming you want to send the actual password
        };
    });

    $('#spinner').show();
    $('#buttonText').hide();
    $.ajax({
        url: '/send-bulk-welcome-emails',
        method: 'POST',
        data: {
            employees: selectedEmails, 
            emailContents: personalizedContents, 
            _token: $('meta[name="csrf-token"]').attr('content')
        },
        success: function (response) {
            Swal.fire({
                icon: 'success',
                title: 'Email Sent!',
                text: `${response.successCount} Welcome email(s) sent successfully.`,
                position: 'center',
                showConfirmButton: true
            });
        },
        error: function (xhr) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Failed to send some emails. Please try again.',
                position: 'center',
                showConfirmButton: true
            });
        },
        complete: function () {
            $('#spinner').hide();
            $('#buttonText').show();
            $('.email-checkbox').prop('checked', false);
            selectedEmails = [];
            toggleSendEmailButton();
            $('#emailEditModal').modal('hide');
        }
    });
});
});




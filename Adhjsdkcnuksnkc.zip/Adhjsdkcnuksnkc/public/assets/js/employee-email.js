$(document).ready(function () {
    var selectedEmails1 = [];

    // Handle click on "select all" checkbox in header
    $(document).on("change", ".email-checkbox1", function () {
        var allChecked =
            $(".email-checkbox1").length ===
            $(".email-checkbox1:checked").length;
        $("#select-all-emails1").prop("checked", allChecked);
    });

    $(document).on("change", "#select-all-emails1", function () {
        var isChecked = $(this).is(":checked");

        // Select or deselect all checkboxes on current page
        $(".email-checkbox1").prop("checked", $(this).is(":checked"));

        if ($(this).is(":checked")) {
            selectedEmails1 = $(".email-checkbox1")
                .map(function () {
                    return {
                        id: $(this).data("id"),
                        email: $(this).data("email"),
                        username: $(this).data("username"),
                    };
                })
                .get();
        } else {
            selectedEmails1 = [];
        }

        toggleSendEmployeeEmailButton();
    });

    // Handle click on individual checkbox
    $(document).on("change", ".email-checkbox1", function () {
        var employeeId = $(this).data("id");
        var employeeEmail = $(this).data("email");
        var employeeUsername = $(this).data("username");

        if ($(this).is(":checked")) {
            // Add to selectedEmails1 if not already present
            if (!selectedEmails1.some((emp) => emp.id === employeeId)) {
                selectedEmails1.push({
                    id: employeeId,
                    email: employeeEmail,
                    username: employeeUsername,
                });
            }
        } else {
            // Remove from selectedEmails1
            selectedEmails1 = selectedEmails1.filter(
                (emp) => emp.id !== employeeId
            );
        }

        // Check/uncheck header checkbox based on whether all checkboxes on current page are selected
        var allChecked =
            table
                .rows({ page: "current" })
                .nodes()
                .to$()
                .find(".email-checkbox1:checked").length ===
            table
                .rows({ page: "current" })
                .nodes()
                .to$()
                .find(".email-checkbox1").length;

        $("#select-all-emails1").prop("checked", allChecked);

        toggleSendEmployeeEmailButton();
    });

    // Example function to toggle your email button (adjust as needed)
    function toggleSendEmployeeEmailButton() {
        if (selectedEmails1.length > 0) {
            $("#sendEmailButton").prop("disabled", false);
        } else {
            $("#sendEmailButton").prop("disabled", true);
        }
    }

    // Your existing send email click handler stays unchanged
    $("#send-welcome-emails1").on("click", function () {
        if (selectedEmails1.length === 0) {
            Swal.fire({
                icon: "warning",
                title: "No Employee Selected",
                text: "Please select at least one employee member to send welcome email.",
                position: "center",
                showConfirmButton: true,
            });
            return;
        }
        $.ajax({
            url: "/get-welcome-email-employee-template",
            method: "GET",
            success: function (templateContent) {
                templateContent = templateContent
                    .replace(
                        /{{\s*\$username\s*}}/g,
                        '<span class="non-editable" contenteditable="false">[username]</span>'
                    )
                    .replace(
                        /{{\s*\$email\s*}}/g,
                        '<span class="non-editable" contenteditable="false">[email]</span>'
                    )
                    .replace(
                        /{{\s*\$password\s*}}/g,
                        '<span class="non-editable" contenteditable="false">[password]</span>'
                    )
                    .replace(/\s+/g, " ");

                $("#emailContent1").html(templateContent);
                $("#emailEditModal1").modal("show");
            },
            error: function () {
                swal({
                    icon: "error",
                    title: "Error",
                    text: "Failed to load email template. Please try again.",
                    position: "center",
                    showConfirmButton: true,
                });
            },
        });
    });

    $("#sendEditedEmail1").on("click", function () {
        let editedContent = $("#manualText").val();
        let personalizedContents = selectedEmails1.map((employee) => {
            return {
                email: employee.email,
                content: editedContent
                    .replace(/\[username\]/g, employee.username)
                    .replace(/\[email\]/g, employee.email)
                    .replace(/\[password\]/g, employee.password),
            };
        });

        $("#spinner").show();
        $("#buttonText").hide();

        $.ajax({
            url: "/send-bulk-welcome-employee-emails",
            method: "POST",
            data: { 
                employees: selectedEmails1,
                emailContents: personalizedContents,
                _token: $('meta[name="csrf-token"]').attr("content"),
            },
            success: function (response) {
                Swal.fire({
                    title: "Email Sent!",
                    text: `${response.successCount} Welcome email sent successfully.`,
                    icon: "success",
                    timer: 2000,
                    buttons: false,
                });
            },
            error: function () {
                swal({
                    icon: "error",
                    title: "Error",
                    text: "Failed to send some emails. Please try again.",
                    timer: 3000,
                    buttons: false,
                });
            },
            complete: function () {
                $("#spinner").hide();
                $("#buttonText").show();
                $(".email-checkbox1").prop("checked", false);
                $("#select-all-emails1").prop("checked", false);
                selectedEmails1 = [];
                toggleSendEmployeeEmailButton();
                $("#emailEditModal1").modal("hide");
            },
        });
    });
});
$("#emailEditModal1").on("hidden.bs.modal", function () {
    // Reset the textarea content to default or empty
    $("#manualText").val("");
    $("#manualText").removeClass("is-valid").attr("style", "");
});

$("#modalCloseId").on("click", function () {
    $("#emailEditModal1").modal("hide");
});

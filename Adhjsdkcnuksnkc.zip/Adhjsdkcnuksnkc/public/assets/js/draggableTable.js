(function () {
    const table = document.getElementById('classMediaTable');
    let dragSrcEl = null;

    table.addEventListener('dragstart', function (e) {
        if (e.target.tagName === 'TR') {
            dragSrcEl = e.target;
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/html', dragSrcEl.outerHTML);
        }
    });

    table.addEventListener('dragover', function (e) {
        e.preventDefault();
        const target = e.target.closest('tr');
        if (target && target !== dragSrcEl) {
            target.classList.add('border_draggable');
        }
    });

    table.addEventListener('drop', function (e) {
        e.preventDefault();
        const target = e.target.closest('tr');
        if (dragSrcEl && target && dragSrcEl !== target) {
            const sourceIndex = dragSrcEl.rowIndex;
            const targetIndex = target.rowIndex;

            if (sourceIndex < targetIndex) {
                target.after(dragSrcEl);
            } else {
                target.before(dragSrcEl);
            }

            // Clean up UI classes
            table.querySelectorAll('.border_draggable').forEach(el => el.classList.remove('border_draggable'));

            // ✅ Send new order to server
            let orderedIds = [];
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {
                orderedIds.push(row.getAttribute('data-id'));
            });

            // AJAX to update sequence
            fetch('/class-media/update-sequence', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({ ids: orderedIds })
            })
            .then(response => response.json())
            .then(data => {
                console.log(data.message);
            })
            .catch(error => {
                console.error('Error updating order:', error);
            });
        }
    });

    table.addEventListener('dragend', function () {
        table.querySelectorAll('.border_draggable').forEach(el => el.classList.remove('border_draggable'));
    });
})();

function addOptions() {
            const optionRow = document.getElementById("addOptions");
            optionRow.innerHTML += `<div class="option_outer removediv">
                                <div class="option_box mb-3">
                                    <label for="option_1" class="form-label">Option 3</label>
                                    <input type="text" class="form-control input" id="option_1" placeholder="Enter option"
                                        tabindex="-1">
                                </div>
                                <div class="option_box mb-3">
                                    <label for="option_1" class="form-label">Option 4</label>
                                    <input type="text" class="form-control input" id="option_2" placeholder="Enter option"
                                        tabindex="-1">
                                </div>
                                <div class="add_delete-icon mb-3">
                                    <img src=" assets/images/Add_icon.svg" alt="add icon" class="img-fluid me-2 curser-pointer "
                                        onclick="addOptions();">
                                    <img src=" assets/images/Delete_icon.svg" alt="add icon" class="img-fluid curser-pointer" onclick="deleteOptionRow(this)">
                                </div>
                            </div>`;
        }
        function deleteOptionRow(r) {
            r.parentElement.parentElement.remove();
            let parentelem = document.getElementById("addOptions");
            if (parentelem.children.length == 0) {
                addcontactbtn.classList.remove("d-none");
            }
        }

$(document).ready(function () {

    /*eye password visibility**/
    var $eye = $('#eye_view');
    var $eyeslash = $('#eye_slash');
    var $passInput = $('#loginPassword');


    if ($eye.length && $eyeslash.length && $passInput.length) {
        $eye.on('click', function () {
            $eye.addClass('d-none');
            $eyeslash.removeClass('d-none');
            $passInput.attr('type', 'text');
        });

        $eyeslash.on('click', function () {
            $eye.removeClass('d-none');
            $eyeslash.addClass('d-none');
            $passInput.attr('type', 'password');
        });
    }

    /***Show loader on login*/
    $('form').on('submit', function (e) {
        $('#loader').removeClass('d-none');
    });

    /**sweetalert over logout*/
    $(document).on("click", "#logout-button", function (e) {
        e.preventDefault();

        swal({
            title: "Are you sure?",
            text: "You will be logged out from Wellify.",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willLogout) => {
            if (willLogout) {
                $(".loader-overlay").fadeIn(200);
                setTimeout(function () {
                    $("#logout-form").submit();
                });
            }
        });
    });

    /**countdown for re-send otp */
    // function startOtpCountdown() {
    //     const link = $('#resend-otp-link');
    //     const countdown = $('#countdown');
    //     let seconds = 60;

    //     link.css({ 'pointer-events': 'none', 'color': 'gray' });
    //     countdown.text(`(${seconds}s)`);

    //     const interval = setInterval(() => {
    //         seconds--;
    //         countdown.text(`(${seconds}s)`);
    //         if (seconds <= 0) {
    //             clearInterval(interval);
    //             link.css({ 'pointer-events': 'auto', 'color': '' });
    //             countdown.text('');
    //         }
    //     }, 1000);
    // }
    function startOtpCountdown() {
        const link = $('#resend-otp-link');
        const countdown = $('#countdown');
        let seconds = 300;

        link.css({ 'pointer-events': 'none', 'color': 'gray' });
        updateCountdownDisplay(seconds);

        const interval = setInterval(() => {
            seconds--;
            updateCountdownDisplay(seconds);
            if (seconds <= 0) {
                clearInterval(interval);
                link.css({ 'pointer-events': 'auto', 'color': '' });
                countdown.text('');
            }
        }, 1000);
    }

    function updateCountdownDisplay(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        const formattedTime = `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
        $('#countdown').text(`(${formattedTime})`);
    }

    $(document).on('click', '#resend-otp-link', function (e) {
        e.preventDefault();
        var email = localStorage.getItem('userEmail');
        $.ajax({
            url: resendOtpUrl,
            type: 'POST',
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            data : {email},
            success: function (response) {
                alert(response.message);
                startOtpCountdown();
            },
            error: function (xhr) {
                if (xhr.status === 429) {
                    const response = xhr.responseJSON;
                    alert(response.message);
                } else {
                    alert('Something went wrong. Try again.');
                }
            }
        });
    });

    if ($('#countdown').data('start') == 1) {
        startOtpCountdown();
    }


     // Sidebar collapse function
     var hamburger = document.getElementById("hamburger");
     var sidebar = document.getElementById("sidebar");
     var main = document.getElementById("main");
     var logo_main = document.getElementById("logo_main");
     var logo_small = document.getElementById("logo_small");

     if (hamburger && sidebar && main && logo_main && logo_small) {
         hamburger.addEventListener("click", () => {
             sidebar.classList.toggle("sidebar_collapsed");
             main.classList.toggle("main_collapsed");
             if (sidebar.classList.contains('sidebar_collapsed')) {
                 logo_main.classList.add("d-none");
                 logo_small.classList.remove("d-none");
             } else {
                 logo_main.classList.remove("d-none");
                 logo_small.classList.add("d-none");
             }
         });
     }


    //======================================== Submenu dropdown ==================================================
    var submenu = document.getElementById("cms_submenu");
    var submenunav = document.getElementById("submenu_nav");

    submenunav.addEventListener("click", () =>{
        submenu.classList.toggle("d-none");
    });

    // login icon toggle

    var eye = document.getElementById("eye_view");
    var eyeslash = document.getElementById("eye_slash");
    var passInput = document.getElementById("loginPassword");

    eye.addEventListener("click", () => {
        eye.classList.add("d-none");
        eyeslash.classList.remove("d-none");
        passInput.type = "text"
    });
    eyeslash.addEventListener("click", () => {
        eye.classList.remove("d-none");
        eyeslash.classList.add("d-none");
        passInput.type = "password"
    });

    // ======================================== tooltip scrip ======================================================
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

    // ====================================== Manage Moods for color picker
    var colorinput = document.getElementById("colorPicker");
    var colorCode = document.getElementById("colorCode");
    var textcolor = document.getElementById("moodText_color");
    colorinput.addEventListener("input", () => {
        colorCode.value = colorinput.value;
        colorCode.style.backgroundColor = colorinput.value;
    });
    textcolor.addEventListener("change", () => {
    if (textcolor.value === "1") {
        colorCode.style.color = '#000000';
    };
        if (textcolor.value === "2") {
        colorCode.style.color = '#FFFFFF';
    };
    });
    // ========================================================= tabs section border radius function ============================================
    var tabFirstBtn = document.querySelector(".tabs_buttons").firstElementChild;
    var btnTabs = document.querySelectorAll(".tabs_buttons .nav-link");
    var tabcontent = document.getElementById("nav-tabContent");
    btnTabs.forEach((e, index) => {
    e.addEventListener("click", () => {
        if (tabFirstBtn.classList.contains("active")){
            tabcontent.style.borderRadius = "0 20px 20px 20px"
        }
        else{
            tabcontent.style.borderRadius = "20px 20px 20px 20px"
        }
    });
});

});

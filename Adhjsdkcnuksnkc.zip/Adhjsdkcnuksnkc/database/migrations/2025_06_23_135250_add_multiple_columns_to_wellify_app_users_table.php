<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('wellify_app_users', function (Blueprint $table) {
            $table->string('plan_status')->nullable()->after('remember_token');
            $table->date('trial_start_date')->nullable()->after('plan_status');
            $table->date('trial_end_date')->nullable()->after('trial_start_date');
        });
    }

    public function down(): void
    {
        Schema::table('wellify_app_users', function (Blueprint $table) {
            $table->dropColumn([
                'plan_status', 
                'trial_start_date', 
                'trial_end_date',
            ]);
        });
    }
};

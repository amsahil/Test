<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('wellify_users', function (Blueprint $table) {
            $table->string('title')->after('id')->nullable();
            $table->renameColumn('phone', 'mobile_phone');
            $table->boolean('isActive')->after('username')->comment('1 = true, 0 = false')->default(0);

            // $table->string('department')->after('isActive')->nullable();
            $table->string('work_phone')->after('mobile_phone')->nullable();
            $table->string('organization')->after('work_phone')->nullable();
            $table->string('office')->after('organization')->nullable();
            $table->string('city')->after('office')->nullable();
            $table->string('state')->after('city')->nullable();
            $table->string('country')->after('state')->nullable();
            $table->unsignedBigInteger('supervisor_id')->after('country')->nullable();
            $table->string('usage_location')->after('supervisor_id')->nullable();
            $table->string('licenses')->after('usage_location')->nullable();
            $table->string('CRM_link')->after('licenses')->nullable();
            $table->string('notes')->after('CRM_link')->nullable();
            $table->boolean('status')->comment('1 = Active, 0 = Inactive')->after('supervisor_id')->default(0);

            $table->foreign('supervisor_id')->references('id')->on('wellify_staffs')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('wellify_users', function (Blueprint $table) {
            $table->renameColumn('mobile_phone', 'phone');
            $table->dropColumn(['title', 'isActive', 'supervisor_id','work_phone','organization',
            'office','city','state','country','usage_location','licenses','CRM_link','notes','status']);
        });
    }
};

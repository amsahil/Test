<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('wellify_users', function (Blueprint $table) {
            // Adds a nullable date column for when the program is launched.
            $table->date('program_launch_date')->nullable()->after('number_of_users');
            // Adds an integer column for the duration of the program in days.
            $table->integer('program_duration_days')->default(0)->after('program_launch_date');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('wellify_users', function (Blueprint $table) {
            $table->dropColumn('program_launch_date');
            $table->dropColumn('program_duration_days');
        });
    }
};
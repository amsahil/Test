<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wellify_temp_app_users', function (Blueprint $table) {
            $table->id();
            $table->string('import_id', length: 50)->nullable(); // this will help to identify records which are imported in multiple imports
            $table->string('title')->nullable();
            $table->string('first_name', length: 50)->nullable();
            $table->string('last_name', length: 50)->nullable();
            $table->string('username')->nullable();   
            $table->string('email')->nullable();   
            $table->string('mobile_phone')->nullable();
            $table->string('organization')->nullable();
            $table->string('office')->nullable();
            $table->string('city')->nullable();
            $table->string('state')->nullable();
            $table->string('country')->nullable();
            $table->string('licenses')->nullable();
            $table->unsignedBigInteger('department_id')->nullable();
            $table->unsignedBigInteger('staff_id')->nullable();
            $table->unsignedBigInteger('employer_id')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->string('error_message')->nullable();
                               
            $table->timestamps();

            $table->foreign('department_id')->references('id')->on('wellify_departments')->onDelete('set null');
            $table->foreign('staff_id')->references('id')->on('wellify_staffs')->onDelete('set null');
            $table->foreign('created_by')->references('id')->on('wellify_users')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wellify_temp_app_users');
    }
};

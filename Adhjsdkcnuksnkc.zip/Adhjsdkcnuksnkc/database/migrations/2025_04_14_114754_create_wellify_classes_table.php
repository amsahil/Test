<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wellify_classes', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('background_image')->nullable();     
            $table->string('category_id')->nullable();
            $table->unsignedBigInteger('mood_id')->nullable();
            $table->unsignedBigInteger('level_id')->nullable();
            $table->integer('duration')->nullable();
            $table->unsignedBigInteger('points_on_completion')->nullable();
            $table->unsignedBigInteger('seeds_on_completion')->nullable();
            $table->string('prerequisite_course')->nullable();
            $table->string('prerequisite_alternate')->nullable();
            
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('category_id')->references('id')->on('wellify_class_categories')->onDelete('set null');
            $table->foreign('mood_id')->references('id')->on('wellify_moods')->onDelete('set null');
            $table->foreign('level_id')->references('id')->on('wellify_levels')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wellify_classes');
    }
};

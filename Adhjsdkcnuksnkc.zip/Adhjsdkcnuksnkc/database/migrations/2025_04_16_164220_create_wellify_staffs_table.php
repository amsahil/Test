<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wellify_staffs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->string('display_name')->nullable();
            $table->string('username')->unique();
            $table->string('mobile_phone')->unique();
            $table->string('profile_picture')->nullable();
            $table->string('email')->unique();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('title')->nullable();
            $table->unsignedBigInteger('department_id')->nullable();
            // $table->string('department')->nullable();
            $table->string('city')->nullable();
            $table->string('country')->nullable();
            $table->string('office')->nullable();
            $table->string('state')->nullable();
            $table->string('usage_location')->nullable();
            $table->string('licenses')->nullable(); 
            $table->string('CRM_link')->nullable();
            $table->string('notes')->nullable();
            $table->string('password')->nullable(); 
            $table->boolean('status')->comment('1 = Active, 0 = Inactive')->default(0);

            $table->timestamps();
            $table->softDeletes();
            
            $table->foreign('created_by')->references('id')->on('wellify_users')->onDelete('set null');
            $table->foreign('department_id')->references('id')->on('wellify_departments')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wellify_staffs');
    }
};

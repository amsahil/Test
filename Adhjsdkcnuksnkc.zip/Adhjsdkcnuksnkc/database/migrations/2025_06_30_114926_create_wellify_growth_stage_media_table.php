
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wellify_growth_stage_media', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('growth_stage_id')->nullable(); 
            $table->unsignedBigInteger('seed_id')->nullable(); 
            $table->string('media');
            $table->enum('media_type', ['image', 'video', 'gif'])->default('image');
            $table->longText('description');
            $table->boolean('status')->comment('1 = Active, 0 = Inactive')->default(0);
            $table->tinyInteger('is_update')->default(0);
            $table->unsignedBigInteger('sequence_no')->default(0);

            $table->timestamps();
            $table->softDeletes();

            $table->foreign('growth_stage_id')->references('id')->on('wellify_growth_stages')->onDelete('set null');
            $table->foreign('seed_id')->references('id')->on('wellify_seeds')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wellify_growth_stage_media');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wellify_app_user_class_progress', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->unsignedBigInteger('mood_id')->nullable();
            $table->string('class_id')->nullable();
            $table->boolean('is_completed')->comment('1 = true, 0 = false')->default(false);
            $table->timestamp('completed_at')->nullable();

            $table->timestamps();
            $table->softDeletes();

            $table->foreign('user_id')->references('id')->on('wellify_app_users')->onDelete('set null');
            $table->foreign('mood_id')->references('id')->on('wellify_moods')->onDelete('set null');
            $table->foreign('class_id')->references('id')->on('wellify_classes')->onDelete('set null');                      
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wellify_app_user_class_progress');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('wellify_activities', function (Blueprint $table) { 
                       
            $table->dropForeign(['class_id']);
            $table->dropForeign(['mood_id']);
            $table->dropColumn(['class_id', 'mood_id']);
            if (!Schema::hasColumn('wellify_activities', 'prerequisite_class')) {
                 $table->string('prerequisite_class')->nullable();
            }
            $table->foreign('prerequisite_class')->references('id')->on('wellify_classes')->onDelete('set null');
            $table->renameColumn('id', 'activity_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('wellify_activities', function (Blueprint $table) {
            $table->renameColumn('activity_id', 'id');
            $table->dropForeign(['prerequisite_class']);
            $table->dropColumn(['prerequisite_class']);
            $table->string('class_id')->after('activity_category_id')->nullable();
            $table->unsignedBigInteger('mood_id')->after('class_id')->nullable();
            $table->foreign('class_id')->references('id')->on('wellify_classes')->onDelete('set null');
            $table->foreign('mood_id')->references('id')->on('wellify_moods')->onDelete('set null');
        });
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateSubscriptionAndPaymentTables extends Migration
{
    public function up(): void
    {
        // Rename user_id to employer_id in wellify_subscriptions
        Schema::table('wellify_subscriptions', function (Blueprint $table) {
            // First drop foreign key constraint
            $table->dropForeign(['user_id']);

            // Rename column
            $table->renameColumn('user_id', 'employer_id');
        });

        // Re-add foreign key with new column name
        Schema::table('wellify_subscriptions', function (Blueprint $table) {
            $table->foreign('employer_id')
                ->references('id')->on('wellify_users')
                ->onDelete('cascade');

            // Add new app_user_id field
            $table->unsignedBigInteger('app_user_id')->nullable()->after('employer_id');

            $table->foreign('app_user_id')
                ->references('id')->on('wellify_app_users')
                ->onDelete('cascade');
        });

        // Add app_user_id to employer_payments table
        Schema::table('employer_payments', function (Blueprint $table) {
            $table->unsignedBigInteger('app_user_id')->nullable()->after('employer_id');

            $table->foreign('app_user_id')
                ->references('id')->on('wellify_app_users')
                ->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::table('wellify_subscriptions', function (Blueprint $table) {
            $table->dropForeign(['employer_id']);
            $table->dropForeign(['app_user_id']);
            $table->dropColumn('app_user_id');
            $table->renameColumn('employer_id', 'user_id');
            $table->foreign('user_id')
                ->references('id')->on('wellify_users')
                ->onDelete('cascade');
        });

        Schema::table('employer_payments', function (Blueprint $table) {
            $table->dropForeign(['app_user_id']);
            $table->dropColumn('app_user_id');
        });
    }
}

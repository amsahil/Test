<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wellify_moods', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description');
            $table->string('color_code');
            $table->string('text_code');
            $table->string('image')->nullable();  
            $table->unsignedBigInteger('wellify_type_id')->nullable();
            $table->boolean('status')->comment('1 = Active, 0 = Inactive')->default(0);
            // $table->enum('media_status', ['Not-Started', 'Completed', 'In-Progress'])->after('class_status')->default('Not-Started');
            $table->unsignedBigInteger('sequence_no')->nullable();

            $table->timestamps();
            $table->softDeletes();

            $table->foreign('wellify_type_id')->references('id')->on('wellify_types')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wellify_moods');
    }
};

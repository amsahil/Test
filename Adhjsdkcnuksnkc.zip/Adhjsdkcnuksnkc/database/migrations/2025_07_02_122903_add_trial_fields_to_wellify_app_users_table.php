<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('wellify_app_users', function (Blueprint $table) {
            $table->boolean('is_trial_active')->default(false)->after('plan_status');
            $table->date('trial_start_date')->nullable()->after('is_trial_active');
            $table->date('trial_end_date')->nullable()->after('trial_start_date');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::table('wellify_app_users', function (Blueprint $table) {
            $table->dropColumn(['is_trial_active', 'trial_start_date', 'trial_end_date']);
        });
    }
};

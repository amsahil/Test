<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wellify_activities', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('background_image')->nullable();  
            $table->string('activity_category_id')->nullable(); 
            $table->string('class_id')->nullable();          
            $table->unsignedBigInteger('mood_id')->nullable();
            $table->unsignedBigInteger('level_id')->nullable();
            //$table->enum('media_type', ['image', 'GIF', 'video'])->default('GIF');
            $table->integer('points_on_completion')->nullable();
            $table->integer('water_on_completion')->nullable(); 
            $table->string('prerequisite_class')->nullable();
            $table->boolean('status')->comment('1 = Active, 0 = Inactive')->default(0);
            $table->enum('media_status', ['Not-Started', 'Completed', 'In-Progress'])->default('Not-Started');

            $table->timestamps();      
            $table->softDeletes();

            $table->foreign('class_id')->references('id')->on('wellify_classes')->onDelete('set null');
            $table->foreign('activity_category_id')->references('id')->on('wellify_activity_categories')->onDelete('set null');
            $table->foreign('mood_id')->references('id')->on('wellify_moods')->onDelete('set null');
            $table->foreign('level_id')->references('id')->on('wellify_levels')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wellify_activities');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wellify_app_users', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable();
            $table->string('first_name', length: 50);
            $table->string('last_name', length: 50)->nullable();
            $table->string('username')->unique();   
            $table->string('email')->unique();
            $table->string('password');                     
            $table->string('profile_picture')->nullable();
            $table->string('mobile_phone')->nullable();
            $table->string('work_phone')->nullable();  
            $table->string('organization')->nullable();
            $table->string('office')->nullable();
            $table->string('city')->nullable();
            $table->string('state')->nullable();
            $table->string('country')->nullable();
            $table->unsignedBigInteger('department_id')->nullable();
            $table->unsignedBigInteger('supervisor_id')->nullable();
            $table->foreignId('user_timezone_id')->nullable()->index(); 
            $table->string('usage_location')->nullable();
            $table->string('licenses')->nullable();            
            $table->boolean('isActive')->comment('1 = true, 0 = false')->default(0);     
            $table->timestamp('email_verified_at')->nullable();
            $table->boolean('agree_tnc')->default(0);
            $table->boolean('status')->comment('1 = Active, 0 = Inactive')->default(0);
            $table->rememberToken();             
                               
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('department_id')->references('id')->on('wellify_departments')->onDelete('set null');
            $table->foreign('supervisor_id')->references('id')->on('wellify_staffs')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wellify_app_users');
    }
};

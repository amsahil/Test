<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('wellify_subscription_employees', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('subscription_id');
            $table->unsignedBigInteger('user_id');
            $table->date('trial_start_date')->nullable();
            $table->date('trial_end_date')->nullable();
            $table->enum('status', ['active', 'cancelled', 'expired'])->default('active');
            $table->timestamps();

            $table->foreign('subscription_id')->references('id')->on('wellify_subscriptions')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('wellify_app_users')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('wellify_subscription_employees');
    }
};

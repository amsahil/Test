<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('wellify_classes', function (Blueprint $table) {
            $table->boolean('class_status')->comment('1 = Active, 0 = Inactive')->after('prerequisite_alternate')->default(0);
            $table->enum('media_status', ['Not-Started', 'Completed', 'In-Progress'])->after('class_status')->default('Not-Started');
            $table->dropForeign(['mood_id']);
            $table->dropColumn('mood_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('wellify_classes', function (Blueprint $table) {
              $table->dropColumn(['class_status', 'media_status']);

            // Re-add the dropped column (adjust type based on your schema)
            $table->unsignedBigInteger('mood_id')->nullable()->after('category_id');

            // Re-add the foreign key if it existed before
            $table->foreign('mood_id')->references('id')->on('wellify_moods')->onDelete('set null');
        });
    }
};

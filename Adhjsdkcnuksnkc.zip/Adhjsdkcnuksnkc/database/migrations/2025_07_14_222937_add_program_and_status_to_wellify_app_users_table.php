<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('wellify_app_users', function (Blueprint $table) {
            // Adds a boolean column to track if an employee is active. Default to true.
            $table->boolean('is_active')->default(true)->after('status');
            // Adds nullable date columns for the individual employee's program start and end dates.
            $table->date('program_start_date')->nullable()->after('is_active');
            $table->date('program_end_date')->nullable()->after('program_start_date');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('wellify_app_users', function (Blueprint $table) {
            $table->dropColumn('is_active');
            $table->dropColumn('program_start_date');
            $table->dropColumn('program_end_date');
        });
    }
};
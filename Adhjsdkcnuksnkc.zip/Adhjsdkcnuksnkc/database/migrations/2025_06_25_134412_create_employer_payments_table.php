<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployerPaymentsTable extends Migration
{
    public function up()
    {
        Schema::create('employer_payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employer_id')->constrained('wellify_users')->onDelete('cascade');
            $table->string('stripe_payment_id');
            $table->string('stripe_checkout_session_id');
            $table->string('stripe_customer_id')->nullable();
            $table->decimal('amount_paid', 10, 2);
            $table->string('currency');
            $table->string('status');
            $table->timestamp('paid_at');
            $table->string('payment_method')->nullable();
            $table->string('card_brand')->nullable();
            $table->string('card_last4')->nullable();
            $table->string('receipt_url')->nullable();
            $table->string('customer_email');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('employer_payments');
    }
}

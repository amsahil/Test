<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('wellify_users', function (Blueprint $table) {
            // Remove the old foreign key
            $table->dropForeign(['supervisor_id']);

            // Add new foreign key that references wellify_users.id
            $table->foreign('supervisor_id')
                ->references('id')
                ->on('wellify_users')
                ->onDelete('set null');
        });
    }

    public function down()
    {
        Schema::table('wellify_users', function (Blueprint $table) {
            $table->dropForeign(['supervisor_id']);
            // You would need to recreate the old staff foreign key here if rolling back
        });
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wellify_app_user_plant_seed_coordinates', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->unsignedBigInteger('seed_id')->nullable();
            $table->decimal('x_axis', 10, 6)->default(4.000000)->nullable();
            $table->decimal('y_axis', 10, 6)->default(6.000000)->nullable();

            $table->timestamps();
            $table->softDeletes();

            $table->foreign('user_id')->references('id')->on('wellify_app_users')->onDelete('set null');
            $table->foreign('seed_id')->references('id')->on('wellify_seeds')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wellify_app_user_plant_seed_coordinates');
    }
};

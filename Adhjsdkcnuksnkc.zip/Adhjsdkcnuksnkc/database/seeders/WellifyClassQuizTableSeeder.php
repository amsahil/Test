<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class WellifyClassQuizTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $quiz = [
            [
                "class_id" => "NUT-101",                
                "title" => "Herbal teas and water-rich foods count towards daily water goal?",
                "media" => "NUT 101 Class_10.svg",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NUT-101",                
                "title" => "What do red fruits and vegetables support?",
                "media" => "NUT 101 Class_11.svg",
                "created_at" => Carbon::now(),
            ]
        ];
        DB::table('wellify_class_quiz')->insert($quiz);
    }
}

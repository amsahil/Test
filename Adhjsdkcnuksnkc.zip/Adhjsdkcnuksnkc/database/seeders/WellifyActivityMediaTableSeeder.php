<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class WellifyActivityMediaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
         $media = [
            [
                "activity_id" => "ACT-AX-101",
                "media" => "Activity_BreathingBackground.png",
                "media_type" => "image",
                "description" => "Welcome to Box Breathing, a simple technique that helps with relaxation. 
Settle into a comfortable position with spine straight. You will be taking 4 deep 
inhales through the nose, pause, and 4 exhales through the mouth. Simply follow 
along with the plant's movement…",
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-AX-101",
                "media" => "Begin_Breathing.png",
                "media_type" => "image",
                "description" => "",
                "created_at" => Carbon::now(),
            ],
             [
                "activity_id" => "ACT-AX-101",
                "media" => "ActivityBreathingBush.gif",
                "media_type" => "gif",
                "description" => "",
                "created_at" => Carbon::now(),
            ],
        ];
        DB::table('wellify_activity_media')->insert($media);
    }
}

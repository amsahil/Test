<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;

class WellifyTimezonesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $timezones = [
            ['abbreviation' => 'UTC', 'full_name' => 'Coordinated Universal Time', 'utc_offset' => 'UTC±00:00', 'tz_identifier' => 'Etc/UTC', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'GMT', 'full_name' => 'Greenwich Mean Time', 'utc_offset' => 'UTC±00:00', 'tz_identifier' => 'Etc/GMT', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'IST', 'full_name' => 'Indian Standard Time', 'utc_offset' => 'UTC+05:30', 'tz_identifier' => 'Asia/Kolkata', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'CST', 'full_name' => 'China Standard Time', 'utc_offset' => 'UTC+08:00', 'tz_identifier' => 'Asia/Shanghai', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'PST', 'full_name' => 'Pacific Standard Time', 'utc_offset' => 'UTC-08:00', 'tz_identifier' => 'America/Los_Angeles', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'PDT', 'full_name' => 'Pacific Daylight Time', 'utc_offset' => 'UTC-07:00', 'tz_identifier' => 'America/Los_Angeles', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'MST', 'full_name' => 'Mountain Standard Time', 'utc_offset' => 'UTC-07:00', 'tz_identifier' => 'America/Denver', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'MDT', 'full_name' => 'Mountain Daylight Time', 'utc_offset' => 'UTC-06:00', 'tz_identifier' => 'America/Denver', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'CST', 'full_name' => 'Central Standard Time', 'utc_offset' => 'UTC-06:00', 'tz_identifier' => 'America/Chicago', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'CDT', 'full_name' => 'Central Daylight Time', 'utc_offset' => 'UTC-05:00', 'tz_identifier' => 'America/Chicago', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'EST', 'full_name' => 'Eastern Standard Time', 'utc_offset' => 'UTC-05:00', 'tz_identifier' => 'America/New_York', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'EDT', 'full_name' => 'Eastern Daylight Time', 'utc_offset' => 'UTC-04:00', 'tz_identifier' => 'America/New_York', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'BST', 'full_name' => 'British Summer Time', 'utc_offset' => 'UTC+01:00', 'tz_identifier' => 'Europe/London', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'CET', 'full_name' => 'Central European Time', 'utc_offset' => 'UTC+01:00', 'tz_identifier' => 'Europe/Berlin', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'CEST', 'full_name' => 'Central European Summer Time', 'utc_offset' => 'UTC+02:00', 'tz_identifier' => 'Europe/Berlin', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'EET', 'full_name' => 'Eastern European Time', 'utc_offset' => 'UTC+02:00', 'tz_identifier' => 'Europe/Helsinki', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'EEST', 'full_name' => 'Eastern European Summer Time', 'utc_offset' => 'UTC+03:00', 'tz_identifier' => 'Europe/Helsinki', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'JST', 'full_name' => 'Japan Standard Time', 'utc_offset' => 'UTC+09:00', 'tz_identifier' => 'Asia/Tokyo', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'KST', 'full_name' => 'Korea Standard Time', 'utc_offset' => 'UTC+09:00', 'tz_identifier' => 'Asia/Seoul', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'AEDT', 'full_name' => 'Australian Eastern Daylight Time', 'utc_offset' => 'UTC+11:00', 'tz_identifier' => 'Australia/Sydney', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'AEST', 'full_name' => 'Australian Eastern Standard Time', 'utc_offset' => 'UTC+10:00', 'tz_identifier' => 'Australia/Sydney', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'ACDT', 'full_name' => 'Australian Central Daylight Time', 'utc_offset' => 'UTC+10:30', 'tz_identifier' => 'Australia/Adelaide', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'ACST', 'full_name' => 'Australian Central Standard Time', 'utc_offset' => 'UTC+09:30', 'tz_identifier' => 'Australia/Adelaide', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'AWST', 'full_name' => 'Australian Western Standard Time', 'utc_offset' => 'UTC+08:00', 'tz_identifier' => 'Australia/Perth', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'WET', 'full_name' => 'Western European Time', 'utc_offset' => 'UTC±00:00', 'tz_identifier' => 'Europe/Lisbon', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'WEST', 'full_name' => 'Western European Summer Time', 'utc_offset' => 'UTC+01:00', 'tz_identifier' => 'Europe/Lisbon', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'MSK', 'full_name' => 'Moscow Standard Time', 'utc_offset' => 'UTC+03:00', 'tz_identifier' => 'Europe/Moscow', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'NST', 'full_name' => 'Newfoundland Standard Time', 'utc_offset' => 'UTC-03:30', 'tz_identifier' => 'America/St_Johns', 'created_at' => '2025-04-16 22:26:20'],
            ['abbreviation' => 'NDT', 'full_name' => 'Newfoundland Daylight Time', 'utc_offset' => 'UTC-02:30', 'tz_identifier' => 'America/St_Johns', 'created_at' => '2025-04-16 22:26:20'],
        ];

        DB::table('wellify_timezones')->insert($timezones);
    }
}

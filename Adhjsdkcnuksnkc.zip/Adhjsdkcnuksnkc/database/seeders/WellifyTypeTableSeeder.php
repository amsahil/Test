<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class WellifyTypeTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
    $types = [
            [
                "name" => "Positive",
                "created_at" => Carbon::now(),
            ],
           [
                "name" => "Negative",
                "created_at" => Carbon::now(),
           ],
           [
                "name" => "Neutral",
                "created_at" => Carbon::now(),
            ]
        ];
        DB::table('wellify_types')->insert($types);
    }
}

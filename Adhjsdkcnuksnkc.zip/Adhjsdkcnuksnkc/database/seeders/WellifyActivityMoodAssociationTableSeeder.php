<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class WellifyActivityMoodAssociationTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
         $moods_manage = [
            [
                "activity_id" => "ACT-ST-101",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-ST-101",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-ST-101",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-AX-101",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-AX-101",
                "mood_id" => "10",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-AX-101",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-EX-101",
                "mood_id" => "1",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-EX-101",
                "mood_id" => "2",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-EX-101",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-GR-101",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-GR-101",
                "mood_id" => "4",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-ST-102",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-ST-102",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-ST-102",
                "mood_id" => "6",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-AX-102",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-AX-102",
                "mood_id" => "10",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-AX-102",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-EX-102",
                "mood_id" => "1",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-EX-102",
                "mood_id" => "4",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-GR-102",
                "mood_id" => "7",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-GR-102",
                "mood_id" => "10",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-GR-102",
                "mood_id" => "12",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-SL-102",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-SL-102",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-ST-103",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-ST-103",
                "mood_id" => "10",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-AX-103",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-AX-103",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "activity_id" => "ACT-AX-103",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],                                        
        ];

        DB::table('wellify_activity_mood_associations')->insert($moods_manage);
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class WellifyClassMoodAssociationTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
         $moods_manage = [
            [
                "class_id" => "ST-101",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-101",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-101",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "AX-101",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "AX-101",
                "mood_id" => "10",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "AX-101",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "EX-101",
                "mood_id" => "1",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "EX-101",
                "mood_id" => "2",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "EX-101",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "GR-101",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "GR-101",
                "mood_id" => "4",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-102",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-102",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-102",
                "mood_id" => "6",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "AX-102",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "AX-102",
                "mood_id" => "10",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "AX-102",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "EX-102",
                "mood_id" => "1",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "EX-102",
                "mood_id" => "4",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "GR-102",
                "mood_id" => "7",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "GR-102",
                "mood_id" => "10",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "GR-102",
                "mood_id" => "12",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "SL-102",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "SL-102",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-103",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-103",
                "mood_id" => "10",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "AX-103",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "AX-103",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "AX-103",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "BA-101",
                "mood_id" => "9",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "BA-101",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "GR-101",
                "mood_id" => "5",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "GR-101",
                "mood_id" => "5",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NU-101",
                "mood_id" => "10",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NU-101",
                "mood_id" => "11",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "SL-101",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "SL-101",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "BA-102",
                "mood_id" => "5",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "BA-102",
                "mood_id" => "4",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NU-102",
                "mood_id" => "2",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NU-102",
                "mood_id" => "6",     
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "BA-103",
                "mood_id" => "6",     
                "created_at" => Carbon::now(),
            ],
             [
                "class_id" => "BA-103",
                "mood_id" => "12",     
                "created_at" => Carbon::now(),
             ],
              [
                "class_id" => "EX-103",
                "mood_id" => "7",     
                "created_at" => Carbon::now(),
              ],
              [
                "class_id" => "EX-103",
                "mood_id" => "1",     
                "created_at" => Carbon::now(),
              ],
              [
                "class_id" => "EX-103",
                "mood_id" => "10",     
                "created_at" => Carbon::now(),
              ],
              [
                "class_id" => "GR-103",
                "mood_id" => "4",     
                "created_at" => Carbon::now(),
              ],
              [
                "class_id" => "GR-103",
                "mood_id" => "2",     
                "created_at" => Carbon::now(),
              ],
              [
                "class_id" => "NU-103",
                "mood_id" => "3",     
                "created_at" => Carbon::now(),
              ],
              [
                "class_id" => "NU-103",
                "mood_id" => "10",     
                "created_at" => Carbon::now(),
              ],
              [
                "class_id" => "SL-103",
                "mood_id" => "9",     
                "created_at" => Carbon::now(),
              ],
              [
                "class_id" => "SL-103",
                "mood_id" => "2",     
                "created_at" => Carbon::now(),
              ],
              [
                "class_id" => "NUT-101",
                "mood_id" => "8",     
                "created_at" => Carbon::now(),
            ]
                                                    
        ];

        DB::table('wellify_class_mood_associations')->insert($moods_manage);
    }
}

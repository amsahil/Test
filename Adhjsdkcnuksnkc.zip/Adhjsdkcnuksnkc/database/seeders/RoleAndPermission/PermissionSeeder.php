<?php

namespace Database\Seeders\RoleAndPermission;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Permission;


class PermissionSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            ['name' => 'Manage-Employers', 'guard_name' => 'web'],
            ['name' => 'Manage-Employees', 'guard_name' => 'web'],
            ['name' => 'Manage-Staffs', 'guard_name' => 'staff'],
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate([
                'name' => $permission['name'],
                'guard_name' => $permission['guard_name']
            ]);
        }
    }
}

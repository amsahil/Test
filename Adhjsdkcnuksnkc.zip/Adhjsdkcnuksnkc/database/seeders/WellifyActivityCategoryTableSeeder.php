<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class WellifyActivityCategoryTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
     {
        $category = [
            [
                "id" => "ACT-ST",
                "title" => "Stress",
                "short_description" => "Stress Management",
                "detailed_description" => "Learn stress management techniques",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "ACT-AX",
                "title" => "Anxiety",
                "short_description" => "Anxious Thinking",
                "detailed_description" => "Managing anxiety techniques",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "ACT-BA",
                "title" => "Balance",
                "short_description" => "Find Your Balance",
                "detailed_description" => "Try out tips to find your balance",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "ACT-EX",
                "title" => "Exercise",
                "short_description" => "Exercise & Physical Fitness",
                "detailed_description" => "Simple exercises and adding movement into daily life",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "ACT-GR",
                "title" => "Gratitude",
                "short_description" => "Practicing Gratitude",
                "detailed_description" => "Mindfulness activities",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "ACT-NU",
                "title" => "Nutrition",
                "short_description" => "Healthy Eating",
                "detailed_description" => "Tips to improve nutrition",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "ACT-SL",
                "title" => "Sleep",
                "short_description" => "Sleep Science",
                "detailed_description" => "Techniques to build better sleep hygiene",
                "created_at" => Carbon::now(),
            ]
        ];

        DB::table('wellify_activity_categories')->insert($category);
    }
}

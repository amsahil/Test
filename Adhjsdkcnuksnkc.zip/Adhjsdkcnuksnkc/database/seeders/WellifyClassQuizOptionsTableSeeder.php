<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;


class WellifyClassQuizOptionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
          $quiz = [
            [
                "quiz_id" => "1", 
                "class_id" => "NUT-101", 
                "option" => "True",    
                "media" => "NUT 101 Class_10.svg",       
                "isAnswer" => "1",    
                "description" => "Herbal teas and water-rich foods count towards meeting your daily water intake of about half your body weight.",
                "created_at" => Carbon::now(),
            ],
            [
                "quiz_id" => "1", 
                "class_id" => "NUT-101", 
                "option" => "False",    
                "media" => "NUT 101 Class_10.svg",       
                "isAnswer" => "0",    
                "description" => "",
                "created_at" => Carbon::now(),
            ],
            [
                "quiz_id" => "2", 
                "class_id" => "NUT-101", 
                "option" => "Immunity",    
                "media" => "NUT 101 Class_11.svg",       
                "isAnswer" => "0",    
                "description" => "",
                "created_at" => Carbon::now(),
            ],
            [
                "quiz_id" => "2", 
                "class_id" => "NUT-101", 
                "option" => "Heart Health",    
                "media" => "NUT 101 Class_11.svg",       
                "isAnswer" => "1",    
                "description" => "Eating red fruits and vegetables such as tomatoes and strawberries support heart health.",
                "created_at" => Carbon::now(),
            ],
            [
                "quiz_id" => "2", 
                "class_id" => "NUT-101", 
                "option" => "Detoxification",    
                "media" => "NUT 101 Class_11.svg",       
                "isAnswer" => "0",    
                "description" => "",
                "created_at" => Carbon::now(),
            ]
            
        ];
        DB::table('wellify_class_quiz_options')->insert($quiz);
    }
}

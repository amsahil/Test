<?php

namespace Database\Seeders;

use App\Models\WellifyUser;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Employer\Staff;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;

class WellifyAssignRolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    { {
            $superAdmin = WellifyUser::where('email', 'anurag@yopmail.com')->first();
            if ($superAdmin) {
                $superAdmin->assignRole('Super Admin');
            }

            /**assign "Employer" to a specific user*/
            $employer = WellifyUser::where('username', 'a.singh.13794')->first();
            if ($employer) {
                $employer->assignRole('Employer');
            }

            /**assign "Employer" to a specific user*/
            $staffUser = Staff::where('email', 'abc2@yopmail.com')->first();
            if ($staffUser) {
                $staffUser->assignRole('User Staff');
            }









            // if ($employer) {
            //     $employer->assignRole('Employer');
            // }

            //  $staffUser = Staff::firstOrCreate(
            //     ['email' => 'staff@chetu.com'],
            //     [
            //         'first_name' => 'Staff',
            //         'last_name' => 'User',
            //         'username' => 'staffuser',
            //         'mobile_phone' => '1234567890',
            //         'state' => 'Noida',
            //         'city' => 'City',
            //         'country' => 'Country',
            //         'department_id' => 1,
            //         'password' => Hash::make('password123'),
            //     ]
            // );

        }
    }
}

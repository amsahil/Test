<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class WellifySeedsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $seeds = [
            [
                "seed_name" => "Apple Tree (Malus pumila)",
                "image" => "apple-tree.svg",
                "seed_description" => "Information under the seed name: 
                The apple's skin provides great source of Vitamin C and the powerful antioxidant polyphenol. 
                Also contain pectin, a fiber that is great for your gut microbiome.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Borage (Borago officinalis)",
                "image" => "borage.svg",
                "seed_description" => "Information under the seed name:
Also known as “starflower”, this herb has multiple medicinal uses. Leaves and flowers are edible, sometimes used as garnish, in teas, and as a seed oil for topical use.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Butterfly Bush (Buddleja davidii)",
                "image" => "butterfly-bush.svg",
                "seed_description" => "Information under the seed name: 
Low maintenance shrub, with 5-12” long fragrant flowers that attract butterflies, bees, hummingbirds. Hardy and grows very fast, reaching up to 10' tall.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Calendula (Calendula officinalis)",
                "image" => "calendula.svg",
                "seed_description" => "Information under the seed name: 
Considered an anti-inflammatory, studies have shown using may help wounds heal & benefit some skin conditions.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Chamomile (Matricaria chamomilla L.)",
                "image" => "chamomile.svg",
                "seed_description" => "Information to add under the seed name: 
Studies indicate therapeutic benefits such as antioxidant, anti-inflammatory, antibacterial, antifungal. Chamomile is widely used for sleep, digestion and calming.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Cherry Tomatoes (Solanum lycopersicum)",
                "image" => "cherry-tomatoes.svg",
                "seed_description" => "Information under the seed name: 
Nutrient-dense, rich in calcium, manganese, phosphorus, potassium. High concentration of antioxidants, good source of fiber, Vitamins A & C.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Columbine (Aquilegia caerulea)",
                "image" => "columbine.svg",
                "seed_description" => "Information under the seed name:
Mostly found in aspen groves, meadows, and forests, also used in gardens. White, violet, lavender or blue blooms, the State Flower of Colorado.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Echinacea (Echinacea purpurea)",
                "image" => "echinacea.svg",
                "seed_description" => "Information under the seed name: 
Many clinical studies have shown medicinal benefits of using, including as an anti-inflammatory, for anxiety & to help immune system.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Hibiscus (Hibiscus moscheutos)",
                "image" => "hibiscus.svg",
                "seed_description" => "Information under the seed name: 
Many varieties of Hibiscus, some are medicinal and used in teas, to reduce swelling and pain from insect stings. The Rose Mallow Hibiscus blooms can be up to 10” wide.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Nasturtium (Tropaeolum majus)",
                "image" => "nasturtium.svg",
                "seed_description" => "Information under the seed name: 
Considered a medicinal plant, contains trace elements and bioactive compounds. The flowers sometimes used decoratively as an edible addition to food.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Oyster Mushroom (Pleurotus ostreatus)",
                "image" => "oyster-mushroom.svg",
                "seed_description" => "Information under the seed name: 
Rich in nutrients including niacin, fiber, protein, B5, iron. Good source of antioxidants and are often used in soups, stews and pasta dishes.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Passionflower (Passiflora incarnata)",
                "image" => "passionflower.svg",
                "seed_description" => "Information under the seed name: 
Viney and native to the southeast, produces sweet fruit and has been used in herbal medicines. A low-maintenance perennial that can spread rapidly and reach up to 25'.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Poppy (Papaver rhoeas)",
                "image" => "poppy.svg",
                "seed_description" => "Information under the seed name: 
Annual that can grow up to 3' tall, blooms of red, pink, yellow, violet, orange, or white.
Flowers can be single or double, and generally bloom spring through summer.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Scarlet Beebalm (Monarda didyma)",
                "image" => "scarlet-beebalm.svg",
                "seed_description" => "Information under the seed name: 
Aromatic perennial herb that's part of mint family. Considered to have medicinal use, it may help soothe skin and treat bee stings.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Sunflower (Helianthus annuus)",
                "image" => "sunflower.svg",
                "seed_description" => "Information under the seed name: 
Small mammals, finches and insects eat the seeds of this annual plant. Spiral pattern is an example of the Fibonacci series in the plant world.",
                "created_at" => Carbon::now(),
            ],
            [
                "seed_name" => "Zucchini (Cucurbita pepo)",
                "image" => "zucchini.svg",
                "seed_description" => "Information under the seed name: 
Has a high content of vitamins, minerals and antioxidants. Contains both soluble and insoluble fiber, aiding in digestion.",
                "created_at" => Carbon::now(),
            ],

        ];

        DB::table('wellify_seeds')->insert($seeds);
    }
}

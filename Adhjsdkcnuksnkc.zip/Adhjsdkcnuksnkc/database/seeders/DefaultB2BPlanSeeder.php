<?php

namespace Database\Seeders;

use App\Models\WellifyPlans;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class DefaultB2BPlanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        WellifyPlans::updateOrCreate(
            ['id' => 1],
            [
                'name' => 'Default B2B Plan',
                'duration' => 'monthly',
                'trial_days' => null,
                'class_limit' => null,
                'activity_limit' => null,
                'is_freemium' => false,
                'status' => 1,
                'notes' => 'Auto-assigned to employers without a plan'
            ]
        );
    }
}

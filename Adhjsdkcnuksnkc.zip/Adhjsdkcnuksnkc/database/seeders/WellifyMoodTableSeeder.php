<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class WellifyMoodTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $moods = [
            [
                "title" => "Happy","description" => "Happy","color_code" => "9dcd5a","text_code" => "000000",
                "status" => "1","sequence_no" => "1",
                "image" => "happy_header.svg","wellify_type_id" => "1","created_at" => Carbon::now(),
            ],
            [
                "title" => "Inspired","description" => "Inspired","color_code" => "50b87c", "text_code" => "000000",
                "status" => "1","sequence_no" => "2",
                "image" => "inspired_header.svg","wellify_type_id" => "1","created_at" => Carbon::now(),
            ],
            [
                "title" => "Low-Energy","description" => "Low-Energy","color_code" => "56aeff","text_code" => "000000",
                "status" => "1","sequence_no" => "3",
                "image" => "low-energy_header.svg","wellify_type_id" => "2","created_at" => Carbon::now(),
            ],
            [
                "title" => "Excited","description" => "Excited","color_code" => "53ae17", "text_code" => "000000",
                "status" => "1","sequence_no" => "4",
                "image" => "excited_header.svg","wellify_type_id" => "1","created_at" => Carbon::now(),
            ],
            [
                "title" => "Centered","description" => "Centered","color_code" => "b1d8b7", "text_code" => "000000",
                "status" => "1","sequence_no" => "5",
                "image" => "centered_header.svg","wellify_type_id" => "1","created_at" => Carbon::now(),
            ],
            [
                "title" => "Indifferent","description" => "Indifferent","color_code" => "bec4ed", "text_code" => "000000",
                "status" => "1","sequence_no" => "6",
                "image" => "indifferent_header.svg","wellify_type_id" => "3","created_at" => Carbon::now(),
            ],
            [
                "title" => "Content","description" => "Content","color_code" => "69418b", "text_code" => "FFFFFF",
                "status" => "1","sequence_no" => "7",
                "image" => "content_header.svg","wellify_type_id" => "3","created_at" => Carbon::now(),
            ],
            [
                "title" => "Stressed","description" => "Stressed","color_code" => "145da0", "text_code" => "FFFFFF",
                "status" => "1","sequence_no" => "8",
                "image" => "stressed_header.svg","wellify_type_id" => "2","created_at" => Carbon::now(),
            ],
            [
                "title" => "Exhausted","description" => "Exhausted","color_code" => "c0f0f7", "text_code" => "000000",
                "status" => "1","sequence_no" => "9",
                "image" => "exhausted_header.svg","wellify_type_id" => "2","created_at" => Carbon::now(),
            ],
            [
                "title" => "Irritable","description" => "Irritable","color_code" => "88a9c3", "text_code" => "000000", 
                "status" => "1","sequence_no" => "10",
                "image" => "irritable_header.svg ","wellify_type_id" => "2","created_at" => Carbon::now(),
            ],
            [
                "title" => "Anxious","description" => "Anxious","color_code" => "6da7cc", "text_code" => "000000", 
                "status" => "1","sequence_no" => "11",
                "image" => "anxious_header.svg","wellify_type_id" => "2","created_at" => Carbon::now(),
            ],
            [
                "title" => "Grateful","description" => "Grateful","color_code" => "87cb28", "text_code" => "000000",
                "status" => "1","sequence_no" => "12", 
                "image" => "grateful_header.svg","wellify_type_id" => "1","created_at" => Carbon::now(),
            ],
             [
                "title" => "Cheerful","description" => "Cheerful","color_code" => "43b14b", "text_code" => "000000",
                "status" => "1","sequence_no" => "13", 
                "image" => "grateful_header.svg","wellify_type_id" => "1","created_at" => Carbon::now(),
             ],
             [
                "title" => "Joyful","description" => "Joyful","color_code" => "a5e8d3", "text_code" => "000000",
                "status" => "0","sequence_no" => "14", 
                "image" => "grateful_header.svg","wellify_type_id" => "1","created_at" => Carbon::now(),
             ],
             [
                "title" => "Optimistic","description" => "Optimistic","color_code" => "16a637", "text_code" => "000000",
                "status" => "0","sequence_no" => "15", 
                "image" => "grateful_header.svg","wellify_type_id" => "1","created_at" => Carbon::now(),
             ],
             [
                "title" => "Energetic","description" => "Energetic","color_code" => "7cc644", "text_code" => "000000",
                "status" => "0","sequence_no" => "16", 
                "image" => "grateful_header.svg","wellify_type_id" => "1","created_at" => Carbon::now(),
             ],
             [
                "title" => "Strong","description" => "Strong","color_code" => "29741d", "text_code" => "000000",
                "status" => "0","sequence_no" => "17", 
                "image" => "grateful_header.svg","wellify_type_id" => "1","created_at" => Carbon::now(),
             ],
             [
                "title" => "Mellow","description" => "Mellow","color_code" => "7f73e3", "text_code" => "000000",
                "status" => "0","sequence_no" => "18",  
                "image" => "grateful_header.svg","wellify_type_id" => "3","created_at" => Carbon::now(),
             ],
             [
                "title" => "Peaceful","description" => "Peaceful","color_code" => "ab52c5", "text_code" => "000000",
                "status" => "0","sequence_no" => "19",  
                "image" => "grateful_header.svg","wellify_type_id" => "3","created_at" => Carbon::now(),
             ],
             [
                "title" => "Calm","description" => "Calm","color_code" => "4d429a", "text_code" => "000000",
                "status" => "0","sequence_no" => "20",  
                "image" => "grateful_header.svg","wellify_type_id" => "3","created_at" => Carbon::now(),
             ],
             [
                "title" => "Grumpy","description" => "Grumpy","color_code" => "1f628e", "text_code" => "000000",
                "status" => "0","sequence_no" => "21",  
                "image" => "grateful_header.svg","wellify_type_id" => "2","created_at" => Carbon::now(),
             ],
             [
                "title" => "Gloomy","description" => "Gloomy","color_code" => "345e7d", "text_code" => "000000",
                "status" => "0","sequence_no" => "22", 
                "image" => "grateful_header.svg","wellify_type_id" => "2","created_at" => Carbon::now(),
             ],
             [
                "title" => "Tense","description" => "Tense","color_code" => "0c6980", "text_code" => "000000",
                "status" => "0","sequence_no" => "23", 
                "image" => "grateful_header.svg","wellify_type_id" => "2","created_at" => Carbon::now(),
             ],
             [
                "title" => "Tired","description" => "Tired","color_code" => "145da0", "text_code" => "000000",
                "status" => "0","sequence_no" => "24", 
                "image" => "grateful_header.svg","wellify_type_id" => "2","created_at" => Carbon::now(),
             ],
              [
                "title" => "Frustrated","description" => "Frustrated","color_code" => "76b9f0", "text_code" => "000000",
                "status" => "0","sequence_no" => "25", 
                "image" => "grateful_header.svg","wellify_type_id" => "2","created_at" => Carbon::now(),
            ]
        ];
        DB::table('wellify_moods')->insert($moods);
    }
}

<?php

namespace Database\Seeders;

use App\Models\WellifyDepartment;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class WellifyDepartmentTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $departments = [
            ['name' => 'Executive Leadership/C-Suite', 'description' => 'CEO, COO, CTO, CFO, etc.'],
            ['name' => 'Human Resources (HR)', 'description' => 'Recruiting, employee relations, benefits, compensation, training'],
            ['name' => 'Finance/Accounting', 'description' => 'Budgeting, financial reporting, accounts payable/receivable, payroll'],
            ['name' => 'Marketing', 'description' => 'Brand management, advertising, digital marketing, market research'],
            ['name' => 'Sales', 'description' => 'Business development, account management, sales operations'],
            ['name' => 'Customer Service/Support', 'description' => 'Customer assistance, technical support, customer success'],
            ['name' => 'Operations', 'description' => 'Day-to-day business processes, facilities management'],
            ['name' => 'Information Technology (IT)', 'description' => 'Technical infrastructure, software development, cybersecurity'],
            ['name' => 'Research & Development (R&D)', 'description' => 'Product innovation, research, new technology development'],
            ['name' => 'Legal/Compliance', 'description' => 'Legal advice, regulatory compliance, contracts, intellectual property'],
            ['name' => 'Product Development/Management', 'description' => 'Product strategy, roadmap planning, feature prioritization'],
            ['name' => 'Production/Manufacturing', 'description' => 'Product creation, quality control'],
            ['name' => 'Supply Chain/Logistics', 'description' => 'Procurement, inventory management, distribution'],
            ['name' => 'Public Relations (PR)', 'description' => 'Media relations, corporate communications, crisis management'],
        ];
    
        foreach ($departments as $dept) {
            WellifyDepartment::firstOrCreate(['name' => $dept['name']], $dept);
        }
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;


class WellifyRolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        $superAdmin = Role::where('name', 'Super Admin')->where('guard_name', 'web')->first();
        if ($superAdmin) {
            $superAdmin->syncPermissions(Permission::where('guard_name', 'web')->get());
        }

        $employer = Role::where('name', 'Employer')->where('guard_name', 'web')->first();
        if ($employer) {
            $permissions = Permission::where('name', 'Manage-Employees')->where('guard_name', 'web')->get();
            $employer->syncPermissions($permissions);
        }

        $employee = Role::where('name', 'Employee')->where('guard_name', 'web')->first();
        if ($employee) {
            $employee->syncPermissions([]); // no permissions for now
        }

        $staff = Role::where('name', 'Staff')->where('guard_name', 'staff')->first();
        if ($staff) {
            $permissions = Permission::where('name', 'Manage-Staffs')->where('guard_name', 'staff')->get();
            $staff->syncPermissions($permissions);
        }
    }
}

// class WellifyRolePermissionSeeder extends Seeder
// {
//     /**
//      * Run the database seeds.
//      */
//     public function run(): void
//     {
//          $superAdmin = Role::where('name', 'Super Admin')->first();
//         if ($superAdmin) {
//             $superAdmin->syncPermissions(Permission::all());
//         }

//         /**Assign selected permission to Employer*/ 
//         $employer = Role::where('name', 'Employer')->first();
//         if ($employer) {
//             $employer->syncPermissions(['Manage-Employees']);
//         }

//         /**Assign no permissions to Employee */ 
//         $employee = Role::where('name', 'Employee')->first();
//         if ($employee) {
//             $employee->syncPermissions([]); // Or later
//         }

//         $staff = Role::where('name', 'Staff')->first();
//         if ($staff) {
//             $staff->syncPermissions(['Manage-Staffs']);
//         }
//     }
// }

// class WellifyRolePermissionSeeder extends Seeder
// {
//     public function run(): void
//     {
//         // Assign all permissions to Super Admin (web guard)
//         $superAdmin = Role::where('name', 'Super Admin')->where('guard_name', 'web')->first();
//         if ($superAdmin) {
//             $superAdmin->syncPermissions(Permission::where('guard_name', 'web')->get());
//         }

//         // Assign selected permission to Employer (web guard)
//         $employer = Role::where('name', 'Employer')->where('guard_name', 'web')->first();
//         if ($employer) {
//             $employer->syncPermissions(Permission::where('name', 'Manage-Employees')->where('guard_name', 'web')->get());
//         }


//         // Assign Manage-Staffs permission to Staff (web guard)
//         $staff = Role::where('name', 'User Staff')->where('guard_name', 'web')->first();
//         if ($staff) {
//             $staff->syncPermissions(Permission::where('name', 'Manage-Staffs')->where('guard_name', 'web')->get());
//         }









//         // Remove or comment this block if 'Employee' role does not exist or is unused
//         /*
//         $employee = Role::where('name', 'Employee')->first();
//         if ($employee) {
//             $employee->syncPermissions([]); // No permissions assigned yet
//         }
//         */
//     }
// }

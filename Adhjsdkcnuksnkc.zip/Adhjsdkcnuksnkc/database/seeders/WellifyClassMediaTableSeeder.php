<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class WellifyClassMediaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $moods = [
            [
                "class_id" => "NUT-101",
                "media" => "NUT 101 Class.svg",
                "media_type" => "image",
                "status" => "1",
                "sequence_no" => "1",
                // "media_type_id" => "1",
                "description" => "Welcome to Nutrition 101! In this class you'll learn the basics of nutrition to support overall health and well-being.",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NUT-101",
                "media" => "NUT 101 Class_1.svg",
                "media_type" => "image",
                "status" => "1",
                "sequence_no" => "2",
                "description" => "Have you ever heard that you should “Eat the Rainbow”? 
                This means eating a variety of colorful fruits and vegetables provides a broad spectrum of vitamins, minerals, and phytonutrients.",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NUT-101",
                "media" => "NUT 101 Class_2.svg",
                "media_type" => "image",
                "status" => "1",
                "sequence_no" => "3",
                "description" => "Healthy fats are essential for brain function, hormone regulation, and heart health. Sources of healthy unsaturated fats are avocados, olive oil, nuts and seeds.",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NUT-101",
                "media" => "NUT 101 Class_3.svg",
                "media_type" => "image",
                "status" => "1",
                "sequence_no" => "4",
                "description" => "Antioxidants protect the body from oxidative stress and free radical damage. Green tea, dark chocolate, grapes, almonds & citrus are great sources of antioxidants.",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NUT-101",
                "media" => "NUT 101 Class_4.svg",
                "media_type" => "image",
                "status" => "1",
                "sequence_no" => "5",
                "description" => "Great Job! You just completed Nutrition 101 Class, earning 3 points and a seed to plant in your garden!",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NUT-101",
                "media" => "NUT 101 Class_5.svg",
                "media_type" => "image",
                "status" => "1",
                "sequence_no" => "6",
                "description" => "For example, red tomatoes and strawberries support heart health. Orange and Yellow contain Vitamin C which boosts immunity. Green vegetables like spinach and broccoli contain chlorophyll which supports detoxification. Blue and purple foods have antioxidant properties (blueberries, eggplant) protecting cells from damage.",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NUT-101",
                "media" => "NUT 101 Class_6.svg",
                "media_type" => "image",
                "status" => "1",
                "sequence_no" => "7",
                "description" => "Water is essential for digestion, nutrient absorption, and toxin removal. A good rule of thumb is to drink about half of your body's weight of water in ounces. Herbal teas and water-rich foods like watermelon, celery, cucumbers count towards that goal!",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NUT-101",
                "media" => "NUT 101 Class_7.svg",
                "media_type" => "image",
                "status" => "1",
                "sequence_no" => "8",
                "description" => "A healthy gut supports digestion, immunity, and overall health. Ways to promote gut health is through eating fiber-rich foods like garlic, onions, asparagus that feed good gut bacteria. Probiotics add beneficial bacteria to the gut, fermented foods like yogurt, kimchi, sauerkraut are great to eat - your gut will thank you!",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NUT-101",
                "media" => "NUT 101 Class_9.svg",
                "media_type" => "image",
                "status" => "1",
                "sequence_no" => "9",
                "description" => "Pop Quiz!",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NUT-101",
                "media" => "NUT 101 Class_10.svg",
                "media_type" => "image",
                "description" => "",
                "status" => "1",
                "sequence_no" => "10",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "NUT-101",
                "media" => "NUT 101 Class_11.svg",
                "media_type" => "image",
                "description" => "",
                "status" => "1",
                "sequence_no" => "11",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-102",
                "media" => "garden_background.svg",
                "media_type_id" => "1",
                "status" => "1",
                "sequence_no" => "12",
                "description" => "Welcome to Stress 102 Class! In this class you'll learn the basics of stress to support overall health and well-being.",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-102",
                "media" => "garden_background.svg",
                "media_type_id" => "1",
                "status" => "1",
                "sequence_no" => "13",
                "description" => "Stress images commonly depict situations or scenarios that represent feeling overwhelmed, anxious, or tense",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-102",
                "media" => "garden_background.svg",
                "media_type_id" => "1",
                "status" => "1",
                "sequence_no" => "14",
                "description" => "Stress images commonly depict situations or scenarios that represent feeling overwhelmed, anxious, or tense",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-101",
                "media" => "garden_background.svg",
                "media_type_id" => "1",
                "status" => "1",
                "sequence_no" => "15",
                "description" => "Welcome to Stress 102 Class! In this class you'll learn the basics of stress to support overall health and well-being.",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-102",
                "media" => "garden_background.svg",
                "media_type_id" => "1",
                "status" => "1",
                "sequence_no" => "16",
                "description" => "Stress images commonly depict situations or scenarios that represent feeling overwhelmed, anxious, or tense.",
                "created_at" => Carbon::now(),
            ],
            [
                "class_id" => "ST-102",
                "media" => "garden_background.svg",
                "media_type_id" => "1",
                "status" => "1",
                "sequence_no" => "17",
                "description" => "Stress images commonly depict situations or scenarios that represent feeling overwhelmed, anxious, or tense.",
                "created_at" => Carbon::now(),
            ]
        ];
        DB::table('wellify_classes_media')->insert($moods);
    }
}

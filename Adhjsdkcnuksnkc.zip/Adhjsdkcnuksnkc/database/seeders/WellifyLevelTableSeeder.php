<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class WellifyLevelTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $levels = [
            [
                "title" => "Beginner",
                "created_at" => Carbon::now(),
            ],
            [
                "title" => "Intermediate",
                "created_at" => Carbon::now(),
            ],
            [
                "title" => "Expert",
                "created_at" => Carbon::now(),
            ]            
        ];
        DB::table('wellify_levels')->insert($levels);
    }
}

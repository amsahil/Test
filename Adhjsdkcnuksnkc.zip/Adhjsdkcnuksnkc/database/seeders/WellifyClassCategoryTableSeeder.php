<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class WellifyClassCategoryTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            [
                "id" => "MI-1",
                "title" => "Mindfulness",
                "short_description" => "Find your inner peace for gentle awareness",
                "detailed_description" => "Find your inner peace for gentle awareness",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "NU-1",
                "title" => "Nutrition",
                "short_description" => "Nutrition",
                "detailed_description" => "Nutrition",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "PA-1",
                "title" => "Physical Activity",
                "short_description" => "Physical Activity",
                "detailed_description" => "Physical Activity",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "SH-1",
                "title" => "Self-help Stratergies",
                "short_description" => "Self-help Stratergies",
                "detailed_description" => "Self-help Stratergies",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "SL-1",
                "title" => "Sleep",
                "short_description" => "Sleep",
                "detailed_description" => "Sleep",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "ST-1",
                "title" => "Stress",
                "short_description" => "Stress Management",
                "detailed_description" => "Stress Management",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "AX-1",
                "title" => "Anxiety",
                "short_description" => "Anxiety Management",
                "detailed_description" => "Anxiety Management",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "EX-1",
                "title" => "Exercise",
                "short_description" => "Exercise",
                "detailed_description" => "Exercise",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "BA-1",
                "title" => "Balance",
                "short_description" => "Balance",
                "detailed_description" => "Balance",
                "created_at" => Carbon::now(),
            ],
            [
                "id" => "GR-1",
                "title" => "Gratitude",
                "short_description" => "Gratitude",
                "detailed_description" => "Gratitude",
                "created_at" => Carbon::now(),
            ]
        ];

        DB::table('wellify_class_categories')->insert($categories);
    }
}

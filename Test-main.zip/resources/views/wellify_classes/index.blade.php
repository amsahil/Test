@extends('layouts.app')
@include('common.header')
@include('common.sidebar')

    <!-- Datatable to Show Classes List-->
    <section class="main_card">
        <nav>
            <div class="nav nav-tabs d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block justify-content-between" id="nav-tab" role="tablist">
                <div class="tabs_buttons d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">
                    <button class="nav-link active mb-xxl-0 mb-xl-0  mb-lg-0 mb-md-0 mb-2" id="nav-home-tab" data-bs-toggle="tab"
                        data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home"
                        aria-selected="true">Active Classes</button>
                    <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab"
                        data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile"
                        aria-selected="false">Deleted Classes</button>
                </div>
            </div>
        </nav>
        <div class="tab-content" id="nav-tabContent">
            <!-- Active Activities Tab -->
            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"
                tabindex="0">
                <div class="container-fluid">
                    <div class="row">
                        <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                            <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Manage Classes</h5>
                            <button class="button primary_btn" type="button" data-bs-toggle="modal"
                                data-bs-target="#add_new">
                                Add New
                            </button>
                        </div>
                    </div>
                    <div class="row pt_24">
                        <div class="col-12">
                            <table id="classesTable" class="table table-striped datatable">
                                <thead>
                                    <tr>
                                        <th scope="col"></th>
                                        <th scope="col">Class ID</th>
                                        <th scope="col">Class Name</th>
                                        <th scope="col">Points</th>
                                        <th scope="col">Associated Moods</th>
                                        <th scope="col">Images Status</th>
                                        <th scope="col">Class Images</th>
                                        <th scope="col">Quiz</th>
                                        <th scope="col">Added On</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>

                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0">
                <div class="container-fluid">
                    <div class="row">
                        <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                            <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Deleted Classes</h5>
                            <div class="button_group d-flex gap-3">
                            <button class="button secondary_btn" type="button" data-bs-target="#bulk_restore_user"
                                data-bs-toggle="modal" id="bulkRestoreButton">
                                Restore
                            </button>
                        </div>
                        </div>
                    </div>
                    <div class="row pt_24">
                        <div class="col-12">
                            <table id="inactiveClassesTable" class="table table-striped datatable">
                                <thead>
                                    <tr>
                                        <th scope="col"><input type="checkbox" id="selectAllRestore"></th>
                                        <th scope="col"></th>
                                        <th scope="col">Class ID</th>
                                        <th scope="col">Class Name</th>
                                        <th scope="col">Points</th>
                                        <th scope="col">Associated Moods</th>
                                        <th scope="col">Class Images</th>
                                        <th scope="col">Quiz</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Add New Class Modal Completed -->
    <div class="modal fade" id="add_new" tabindex="-1" data-bs-keyboard="false"  aria-labelledby="add_newLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <form id="addClassForm" enctype="multipart/form-data" class="d-flex align-items-center justify-content-between w-100">
                    <h3 class="modal-title fs-5">Add New Class</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="id" class="form-label">Class ID<span class="text-danger">*</span></label>
                                <input type="text" class="form-control input" name="id" placeholder="Enter class ID"
                                    required tabindex="-1">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Class Name<span class="text-danger">*</span></label>
                                <input type="text" name="title" class="form-control input" required placeholder="Enter class name">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Points<span class="text-danger">*</span></label>
                                <input type="number" name="points_on_completion" class="form-control input" placeholder="Enter points"
                                    required tabindex="-1">
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label input">Seeds<span class="text-danger">*</span></label>
                                <input type="number" name="seeds_on_completion" class="form-control input" placeholder="Enter seeds"
                                    required tabindex="-1">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Select Moods<span class="text-danger">*</span></label>
                                <select name="moods[]" id="choices-multiple-remove-button" class="form-select form-control input" placeholder="Select moods" multiple tabindex="-1">
                                    @foreach ($moods as $mood)
                                        <option value="{{ $mood->id }}">{{ $mood->title }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label input">Category ID<span class="text-danger">*</span></label>
                                <select class="form-select form-control input" tabindex="-1" id="categoryID" name="category_id" required>
                                    <option value="">Select Category</option>
                                    @foreach($categories as $category)
                                    <option value="{{ $category->id }}"> {{$category->id }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Level<span class="text-danger">*</span></label>
                                <select name="level_id" class="form-select form-control input" aria-label="Default select example"
                                    tabindex="-1" required>
                                    @foreach ($levels as $level)
                                        <option value="{{ $level->id }}">{{ $level->title }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label ">Background Image</label>
                                <input type="file" name="background_image" class="form-control input" id="upload-img" accept=".svg" required>
                                    <small class="text-muted">Only SVG files are allowed</small>
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Description<span class="text-danger">*</span></label>
                                <textarea name="description" class="form-control input rounded-3 desc-field"  placeholder="Enter Description"
                                    id="exampleFormControlTextarea1" rows="2" required tabindex="-1"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                        tabindex="-1">Close</button>
                        <button type="submit" class="button primary_btn m-0" tabindex="-1">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Add Class Images Modal through +  Completed -->
    <div class="modal fade" id="addimagesModal" aria-hidden="true" aria-labelledby="addImagesModalLabel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5">Add Class Images</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <form id="uploadImageForm" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="class_id" id="uploadClassId">

                        <div class="container-fluid p-0" id="addImages_main">
                            <div class="row align-items-center add_newrow">
                                <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-12 mb-3">
                                    <div class="uploader">
                                        <input type="file" name="media[]" accept=".svg" class="file-upload d-none" required>
                                        <label class="py-2 px-3 d-flex image_label rounded-3 file-label">
                                            <img class="file-image d-none" src="#" alt="Preview">
                                            <span class="start text-center w-100">
                                                <span class="d-block">Select a file</span>
                                                <span class="btn btn-success my-2">Select a file</span>
                                            </span>
                                        </label>
                                    </div>
                                </div>

                                <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-12 mb-3">
                                    <textarea name="description[]" class="form-control input rounded-3" placeholder="Enter Description" rows="3" required></textarea>
                                </div>

                                <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-2 col-12 mb-3 text-center">
                                             @php
                                $addImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/Add_icon.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                    <img src="{{$addImageUrl}}" alt="add icon" class="img-fluid add-more" style="cursor:pointer;">
                                </div>
                            </div>
                        </div>

                        <div class="modal-footer gap-3">
                            <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="button primary_btn m-0">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- View Images Modal Completed-->
    <div class="modal fade" id="viewImagesModal" tabindex="-1" aria-labelledby="viewImagesLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Uploaded Images</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="imageGallery">
                <!-- Dynamic content goes here -->
            </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editMediaModal" tabindex="-1" aria-labelledby="editMediaLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form id="editMediaForm" enctype="multipart/form-data">
                @csrf
                <input type="hidden" id="editMediaId" name="media_id">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Media</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="editDescription" class="form-label">Description</label>
                            <input type="text" class="form-control" id="editDescription" name="description" required>
                        </div>\
                        <div class="mb-3">
                            <label for="editFile" class="form-label">Replace File (optional)</label>
                            <input type="file" class="form-control" id="editFile" name="media">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Save Changes</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Edit Class Completed-->
    {{-- <div class="modal fade" id="edit_user" data-bs-keyboard="false" tabindex="-1" aria-labelledby="edit_userLabel"aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="edit_userLabel">Edit Class</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        tabindex="-1"></button>
                </div>
                <form id="editClassForm" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="_method" value="PUT">
                    <div class="modal-body">
                        <div class="container-fluid p-0">
                            <div class="row">
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_class_id" class="form-label">Class ID</label>
                                    <input type="text" class="form-control input" id="edit_class_id" name="id" readonly>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_title" class="form-label">Class Name</label>
                                    <input type="text" class="form-control input" id="edit_title" name="title" required>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_moods" class="form-label">Select Moods</label>
                                    <select id="edit_moods" class="form-select form-control input" name="moods[]" multiple>
                                        @foreach($moods as $mood)
                                            <option value="{{ $mood->id }}">{{ $mood->title }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_points" class="form-label">Points</label>
                                    <input type="number" class="form-control input" id="edit_points" name="points_on_completion" required>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_seeds" class="form-label">Seeds</label>
                                    <input type="number" class="form-control input" id="edit_seeds" name="seeds_on_completion" required>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_category_id" class="form-label">Category</label>
                                    <select class="form-select form-control input " id="edit_category_id" name="category_id" disabled>
                                        @foreach($categories as $category)
                                            <option value="{{ $category->title }}">{{ $category->title }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_level_id" class="form-label">Level</label>
                                    <select class="form-select form-control input" id="edit_level_id" name="level_id">
                                        @foreach($levels as $level)
                                            <option value="{{ $level->id }}">{{ $level->title }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_background_image" class="form-label">Thumbnail Image</label>
                                    <input type="file" class="form-control input" id="edit_background_image" name="background_image">
                                    <small class="text-muted">Current: <span id="current_image_name"></span></small>
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="edit_description" class="form-label">Description</label>
                                    <textarea class="form-control input rounded-3" id="edit_description" name="description" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                            tabindex="-1">Close</button>
                        <button type="submit" class="button primary_btn m-0">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div> --}}

    <!-- Modal Edit Class Completed-->
    <div class="modal fade" id="edit_user" data-bs-keyboard="false" tabindex="-1" aria-labelledby="edit_userLabel"aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="edit_userLabel">Edit Class</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        tabindex="-1"></button>
                </div>
                <form id="editClassForm" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="_method" value="PUT">
                    <div class="modal-body">
                        <div class="container-fluid p-0">
                            <div class="row">
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_class_id" class="form-label">Class ID<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control input" id="edit_class_id" name="id" readonly style="background-color: #f0f0f0; color: #6c757d; cursor: not-allowed;">
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_title" class="form-label">Class Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control input" id="edit_title" name="title" required>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_moods" class="form-label">Select Moods<span class="text-danger">*</span></label>
                                    <select id="edit_moods" class="form-select form-control input" name="moods[]" multiple>
                                        @foreach($moods as $mood)
                                            <option value="{{ $mood->id }}">{{ $mood->title }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_points" class="form-label">Points<span class="text-danger">*</span></label>
                                    <input type="number" class="form-control input" id="edit_points" name="points_on_completion" required>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_seeds" class="form-label">Seeds<span class="text-danger">*</span></label>
                                    <input type="number" class="form-control input" id="edit_seeds" name="seeds_on_completion" required>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_category_display" class="form-label">Category<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control input" id="edit_category_display"
                                        value="{{ $class->category->title ?? '' }}" readonly style="background-color: #f0f0f0; color: #6c757d; cursor: not-allowed;">
                                    <input type="hidden" id="edit_category_id" name="category_id" value="{{ $class->category_id ?? '' }}">
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_level_id" class="form-label">Level<span class="text-danger">*</span></label>
                                    <select class="form-select form-control input" id="edit_level_id" name="level_id">
                                        @foreach($levels as $level)
                                            <option value="{{ $level->id }}">{{ $level->title }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="edit_background_image" class="form-label">Thumbnail Image</label>
                                    <input type="file" class="form-control input" id="edit_background_image" name="background_image" accept=".svg,image/svg+xml">
                                    <small class="text-muted">Current: <span id="current_image_name"></span></small>
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="edit_description" class="form-label">Description<span class="text-danger">*</span></label>
                                    <textarea class="form-control input rounded-3" id="edit_description" name="description" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                            tabindex="-1">Close</button>
                        <button type="submit" class="button primary_btn m-0">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal View Classes Completed-->
    <div class="modal fade" id="view_user" data-bs-keyboard="false" tabindex="-1" aria-labelledby="view_userLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="view_userLabel">View Class</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid p-0">
                        <div class="row">
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Class ID</label>
                                <p class="mb-0" id="view_class_id"></p>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Class Name</label>
                                <p class="mb-0" id="view_class_name"></p>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <div class="row">
                                    <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12">
                                        <label class="form-label">Points</label>
                                        <p class="mb-0" id="view_points"></p>
                                    </div>
                                    <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12">
                                        <label class="form-label">Seeds</label>
                                        <p class="mb-0" id="view_seeds"></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Category ID</label>
                                <p class="mb-0" id="view_category_id"></p>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Level ID</label>
                                <p class="mb-0" id="view_level_id"></p>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label class="form-label">Status</label>
                                <span id="view_status" class="status_btn bg_active mb-3">
                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M5 10C4.30833 10 3.65833 9.86866 3.05 9.606C2.44167 9.34333 1.9125 8.98716 1.4625 8.5375C1.0125 8.08783 0.656334 7.55866 0.394 6.95C0.131667 6.34133 0.000333966 5.69133 6.32911e-07 5C-0.0003327 4.30867 0.131001 3.65867 0.394 3.05C0.657 2.44133 1.01317 1.91217 1.4625 1.4625C1.91183 1.01283 2.441 0.656667 3.05 0.394C3.659 0.131333 4.309 0 5 0C5.691 0 6.341 0.131333 6.95 0.394C7.559 0.656667 8.08816 1.01283 8.5375 1.4625C8.98683 1.91217 9.34316 2.44133 9.60649 3.05C9.86983 3.65867 10.001 4.30867 9.99999 5C9.99899 5.69133 9.86766 6.34133 9.60599 6.95C9.34433 7.55866 8.98816 8.08783 8.5375 8.5375C8.08683 8.98716 7.55766 9.3435 6.95 9.6065C6.34233 9.8695 5.69233 10.0007 5 10Z"
                                            fill="#52AB17" />
                                    </svg>
                                    Active
                                </span>
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Associated Moods</label>
                                <div class="d-flex gap-2 flex-wrap" id="view_moods">
                                    <!-- Moods will be appended here -->
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Description</label>
                                <p id="view_description"></p>
                            </div>

                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                    <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                        tabindex="-1">Close</button>
                </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Modal Delete Class Completed-->
    <div class="modal fade" id="delete_class_modal" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete_userLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body delete">
                    <div class="container-fluid px-0 py-3">
                        <div class="row">
                            <div class="col-12 text-center">
                                <img src="assets/images/warning.svg" alt="warning icon" class="img-fluid">
                                <h4 class="mt-4 text-danger">Delete This Class?</h4>
                                <p class="mt-3 line_height_30"> This Class will move to recently deleted <br>
                                    Are you sure you want to continue?</p>
                                    <input type="hidden" id="delete_class_id">
                            </div>
                            <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                                    tabindex="-1">Cancel</button>
                                <button class="button primary_btn m-0 warning_button" type="submit"
                                    tabindex="-1" id="confirm_delete_class">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Class Modal -->
    {{-- <div class="modal fade" id="delete_class_modal" tabindex="-1" aria-labelledby="deleteClassModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Delete Class</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this class?</p>
                    <input type="hidden" id="delete_class_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="button cancel_button" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="button danger_btn" id="confirm_delete_class">Delete</button>
                </div>
            </div>
        </div>
    </div> --}}

@include('wellify_classes.quiz_modal')
<script src="assets/js/choice.js"></script>
{{-- <script src="{{ asset('js/quiz.js') }}"></script> --}}

<script>
    $(document).ready(function () {
     var multipleCancelButton = new Choices('#choices-multiple-remove-button, #choices-multiple-remove-button2' , {
         removeItemButton: true,
        //  searchResultLimit: 5,
        //  renderChoiceLimit: 5
        });
    });
</script>

<script>
    $(document).on('click', '.view_icon1', function () {
        const classId = $(this).data('id');

        $.ajax({
            url: '/wellify-classes/' + classId,
            method: 'GET',
            success: function (res) {
                $('#view_userLabel').text('View Class');

                let moodHTML = '';
                res.moods.forEach(mood => {
                    moodHTML += `
                        <span class="px-3 py-1 fw-semibold rounded-pill d-inline-block"
                              style="background-color: #${mood.color_code}; color: #${mood.text_code}; border: 1px solid #${mood.text_code};">
                            ${mood.title}
                        </span>
                    `;
                });

                const modalBody = `
                    <div class="row">
                        <div class="col-xxl-4 col-md-6 mb-3">
                            <label class="form-label">Class ID</label>
                            <p class="mb-0">${res.id}</p>
                        </div>

                        <div class="col-xxl-4 col-md-6 mb-3">
                            <label class="form-label">Class Name</label>
                            <p class="mb-0">${res.title}</p>
                        </div>

                        <div class="col-xxl-4 col-md-6 mb-3">
                            <div class="row">
                                <div class="col-6">
                                    <label class="form-label">Points</label>
                                    <p class="mb-0">${res.points}</p>
                                </div>
                                <div class="col-6">
                                    <label class="form-label">Seeds</label>
                                    <p class="mb-0">${res.seeds_on_completion}</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-4 col-md-6 mb-3">
                            <label class="form-label">Category ID</label>
                            <p class="mb-0">${res.category_id}</p>
                        </div>

                        <div class="col-xxl-4 col-md-6 mb-3">
                            <label class="form-label">Level</label>
                            <p class="mb-0">${res.level_title}</p>
                        </div>



                        <div class="col-12 mb-3">
                            <label class="form-label">Associated Moods</label>
                            <div class="d-flex gap-2 flex-wrap">${moodHTML}</div>
                        </div>

                        <div class="col-12 mb-3">
                            <label class="form-label">Description</label>
                            <p>${res.description || ''}</p>
                        </div>

                        <div class="col-md-6 mb-3">
                            <div class="alert alert-success d-flex align-items-center" role="alert">
                                <span>
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M16.24 3.5H7.73999C6.41391 3.5 5.14214 4.02678 4.20446 4.96447C3.26677 5.90215 2.73999 7.17392 2.73999 8.5V15.5C2.73999 16.1566 2.86932 16.8068 3.12059 17.4134C3.37187 18.02 3.74016 18.5712 4.20446 19.0355C5.14214 19.9732 6.41391 20.5 7.73999 20.5H16.24C16.8966 20.5 17.5468 20.3707 18.1534 20.1194C18.76 19.8681 19.3112 19.4998 19.7755 19.0355C20.2398 18.5712 20.6081 18.02 20.8594 17.4134C21.1107 16.8068 21.24 16.1566 21.24 15.5V8.5C21.24 7.84339 21.1107 7.19321 20.8594 6.58658C20.6081 5.97995 20.2398 5.42876 19.7755 4.96447C19.3112 4.50017 18.76 4.13188 18.1534 3.8806C17.5468 3.62933 16.8966 3.5 16.24 3.5Z"
                                            stroke="#0a3622" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                        <path
                                            d="M2.98999 17L5.73999 13.8C6.09983 13.4426 6.5721 13.2205 7.07687 13.1713C7.58164 13.1221 8.08791 13.2488 8.50999 13.53C8.93207 13.8112 9.43834 13.9379 9.94311 13.8887C10.4479 13.8395 10.9201 13.6174 11.28 13.26L13.61 10.93C14.2795 10.2582 15.1659 9.8462 16.111 9.76744C17.0562 9.68868 17.9985 9.94831 18.77 10.5L21.26 12.43M7.98999 10.17C8.20798 10.17 8.42384 10.1271 8.62525 10.0436C8.82665 9.96022 9.00964 9.83794 9.16379 9.6838C9.31793 9.52965 9.44021 9.34665 9.52363 9.14525C9.60705 8.94385 9.64999 8.72799 9.64999 8.51C9.64999 8.292 9.60705 8.07614 9.52363 7.87474C9.44021 7.67334 9.31793 7.49035 9.16379 7.3362C9.00964 7.18206 8.82665 7.05978 8.62525 6.97636C8.42384 6.89294 8.20798 6.85 7.98999 6.85C7.54973 6.85 7.1275 7.02489 6.81619 7.3362C6.50488 7.64751 6.32999 8.06974 6.32999 8.51C6.32999 8.95026 6.50488 9.37249 6.81619 9.6838C7.1275 9.99511 7.54973 10.17 7.98999 10.17Z"
                                            stroke="#0a3622" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>
                                </span>
                                <span class="ms-3">
                                    ${res.image_count} ${res.image_count === 1 ? 'Image' : 'Images'} Uploaded
                                </span>
                            </div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <div class="alert alert-primary d-flex align-items-center" role="alert">
                                <span>
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M8.5 7.5C8.5 6.487 9.395 5.5 10.5 5.5C11.605 5.5 12.5 6.32 12.5 7.333C12.5 7.698 12.384 8.038 12.183 8.324C11.585 9.176 10.5 9.987 10.5 11M10.5 13.5H10.509M8 19.5C9.05 20.37 10.315 20.924 11.764 21.019C12.905 21.094 14.097 21.094 15.237 21.019C15.6444 20.9908 16.045 20.9004 16.425 20.751C16.835 20.584 17.039 20.501 17.144 20.514C17.248 20.526 17.399 20.636 17.701 20.856C18.234 21.244 18.905 21.522 19.901 21.499C20.404 21.487 20.656 21.48 20.768 21.291C20.881 21.101 20.741 20.839 20.46 20.314C20.07 19.586 19.824 18.753 20.198 18.085C20.841 17.131 21.388 16.002 21.468 14.782C21.511 14.127 21.511 13.448 21.468 12.792C21.4159 12.0004 21.2235 11.2243 20.9 10.5"
                                            stroke="#052c65" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                        <path
                                            d="M12.2371 17.019C13.8554 16.912 15.3796 16.2204 16.5258 15.0729C17.672 13.9254 18.3619 12.4004 18.4671 10.782C18.5111 10.127 18.5111 9.448 18.4671 8.792C18.3617 7.17374 17.6716 5.64897 16.5255 4.50171C15.3793 3.35446 13.8552 2.66295 12.2371 2.556C11.0806 2.48147 9.92053 2.48147 8.76406 2.556C7.14546 2.66272 5.62086 3.35423 4.47432 4.5017C3.32777 5.64916 2.63748 7.17432 2.53206 8.793C2.48801 9.4556 2.48801 10.1204 2.53206 10.783C2.61206 12.003 3.15906 13.132 3.80206 14.085C4.17606 14.753 3.92906 15.586 3.54006 16.315C3.26006 16.839 3.12006 17.101 3.23206 17.291C3.34506 17.481 3.59606 17.486 4.10006 17.499C5.09506 17.523 5.76606 17.244 6.29906 16.856C6.60106 16.636 6.75206 16.526 6.85606 16.514C6.96006 16.502 7.16606 16.584 7.57606 16.751C7.94406 16.901 8.37106 16.993 8.76406 17.019C9.90306 17.094 11.0941 17.094 12.2371 17.019Z"
                                            stroke="#052c65" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>
                                </span>
                                <span class="ms-3">
                                    ${res.quiz_count} ${res.quiz_count === 1 ? 'Quiz' : 'Quizzes'} Added
                                </span>
                            </div>
                        </div>
                    </div>
                `;

                $('#view_user .modal-body').html(modalBody);
                $('#view_user').modal('show');
            },
            error: function () {
                alert('Error fetching class details.');
            }
        });
    });
</script>

<script>
    $(document).ready(function() {
        // Active Classes Table
        $('#classesTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('wellify_classes.classes.data') }}",
            columns: [
                { data: 'dummy', orderable: false, searchable: false },
                { data: 'id', name: 'id' },
                { data: 'title', name: 'title' },
                { data: 'points_on_completion', name: 'points_on_completion' },
                { data: 'associated_moods', name: 'associated_moods', orderable: false },
                { data: 'media_status', name: 'media_status', orderable: false },
                { data: 'class_images', name: 'class_images', orderable: false },
                { data: 'quiz', name: 'quiz', orderable: false },
                { data: 'created_at', name: 'created_at' },
                { data: 'class_status', name: 'class_status', orderable: false },
                { data: 'actions', name: 'actions', orderable: false }
            ]
        });

        // Deleted Classes Table
        $('#inactiveClassesTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('wellify_classes.deleted') }}",
                type: 'GET'
            },
            columns: [
                {data: 'checkbox', orderable: false, searchable: false},
                { data: 'dummy', orderable: false, searchable: false },
                { data: 'id'},
                { data: 'title'},
                { data: 'points_on_completion'},
                { data: 'associated_moods'},
                { data: 'class_images'},
                { data: 'quiz'},
                {data: 'actions',orderable: false,searchable: false}
            ],
            order: [[2, 'desc']]
        });

        // Handle bulk restore
        $('#bulkRestoreButton').click(function() {
            const ids = $('.restore-checkbox:checked').map(function() {
                return $(this).val();
            }).get();

            if (ids.length === 0) {
                alert('Please select at least one class to restore');
                return;
            }

            $.ajax({
                url: '/wellify-classes/bulk-restore',
                type: 'POST',
                data: { ids: ids },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    $('#inactiveClassesTable').DataTable().ajax.reload();
                    alert(response.message);
                }
            });
        });


        $('#classesTable').on('change', '.toggle-status', function () {
            const classId = $(this).data('id');
            const newStatus = $(this).is(':checked') ? 1 : 0;

            $.ajax({
                url: '/wellify-classes/update-status/' + classId,
                type: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    class_status: newStatus
                },
                success: function () {
                    $('#classesTable').DataTable().ajax.reload(null, false);
                },
                error: function () {
                    alert('Error updating status');
                }
            });
        });

        $(document).on('change', '.image_status_select', function () {
            const classId = $(this).data('id');
            const status = $(this).val(); // '1', '2', or '3'

            $.ajax({
                url: '{{ route("wellify_classes.update_images_status") }}',
                method: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    id: classId,
                    media_status: status
                },
                success: function (res) {
                    if (res.success) {
                        $('#classesTable').DataTable().ajax.reload(null, false);
                    }
                },
                error: function () {
                    alert('Failed to update manual status.');
                }
            });
        });


        $(document).on('click', '.upload_icon', function () {
            const classId = $(this).data('id');
            $('#media_class_id').val(classId);
            $('#uploadClassId').val(classId);

            // Load images in gallery
            $.ajax({
                url: '/wellify-classes/' + classId + '/media/images',
                type: 'GET',
                success: function (response) {
                    const gallery = $('#imageGallery');
                    gallery.empty();

                    if (response.length === 0) {
                        gallery.append('<p>No images uploaded.</p>');
                    } else {
                        response.forEach(item => {
                            gallery.append(`
                                <div class="media-item mb-3 p-2 border rounded" data-id="${item.id}">
                                    <img src="${item.url}" class="img-fluid rounded mb-2" alt="${item.name}" style="max-height: 300px;" />
                                    <p><strong>${item.name}</strong><br class="media-desc">${item.description || 'No description'}</p>
                                    <div class="action-buttons">
                                        <button class="btn btn-sm btn-warning edit-media" data-id="${item.id}" data-description="${item.description || ''}"><i class="bi bi-pencil"></i> Edit</button>
                                        <button class="btn btn-danger btn-sm delete-media" data-id="${item.id}"><i class="bi bi-trash"></i> Delete</button>
                                    </div>

                                    <form class="edit-media-form mt-2 d-none" data-id="${item.id}" enctype="multipart/form-data">
                                        <input type="text" name="description" class="form-control mb-2" value="${item.description || ''}" required>
                                        <input type="file" name="media" class="form-control mb-2">
                                        <button type="submit" class="btn btn-success btn-sm me-2">Save</button>
                                        <button type="button" class="btn btn-secondary btn-sm cancel-edit">Cancel</button>
                                    </form>
                                </div>
                            `);
                        });
                    }
                },
                error: function () {
                    $('#imageGallery').html('<p class="text-danger">Failed to load images.</p>');
                }
            });
        });

        $('#addMoreMedia').click(function () {
            $('#mediaInputsContainer').append(`
                <div class="media-input-group mb-3">
                    <input type="file" name="media[]" class="form-control" required>
                    <input type="text" name="description[]" class="form-control mt-2" placeholder="Description" required>
                </div>
            `);
        });

        $('#uploadMediaForm').on('submit', function (e) {
            e.preventDefault();
            let formData = new FormData(this);

            $.ajax({
                url: '{{ route("wellify_classes.media.upload") }}',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function () {
                    alert('Media uploaded successfully!');
                    $('#upload_media_modal').modal('hide');
                    $('#classesTable').DataTable().ajax.reload();
                },
                error: function () {
                    alert('Upload failed.');
                }
            });
        });

        function loadMedia(classId) {
            $.ajax({
                url: `/wellify-classes/${classId}/media`,
                type: 'GET',
                success: function(data) {
                    let mediaContainer = $('#mediaPreview');
                    mediaContainer.empty();

                    data.forEach(item => {
                        let mediaTag = '';
                        if (item.media_type_id == 1 || item.media_type_id == 3) {
                            mediaTag = `<img src="${item.media_url}" class="img-thumbnail mb-2" width="100" />`;
                        } else if (item.media_type_id == 2) {
                            mediaTag = `<a href="${item.media_url}" target="_blank">View PDF</a>`;
                        }

                        mediaContainer.append(`
                            <div class="media-item mb-3 p-2 border rounded" data-id="${item.id}">
                                ${mediaTag}
                                <p class="mb-1"><strong>${item.name || 'Untitled'}</strong></p>
                                <p class="mb-2">${item.description || 'No description'}</p>
                                <button class="btn btn-danger btn-sm delete-media" data-id="${item.id}">Delete</button>
                            </div>
                        `);
                    });
                },
                error: function () {
                    $('#mediaPreview').html('<p class="text-danger">Failed to load media.</p>');
                }
            });
        }

        $('#mediaUploadModal').on('show.bs.modal', function (e) {
            const classId = $(e.relatedTarget).data('id');
            $('#uploadClassId').val(classId);
            loadMedia(classId);
        });

        $(document).on('click', '.delete-media', function () {
            const id = $(this).data('id');
            // console.log(id,'hii');
            if (confirm('Are you sure you want to delete this media?')) {
                $.ajax({
                    url: `/wellify-classes/media/${id}`,
                    type: 'DELETE',
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    success: function () {
                        $(`.media-item[data-id="${id}"]`).remove();
                    },
                    error: function () {
                        alert('Failed to delete media.');
                    }
                });
            }
        });
        $(document).on('click', '.edit-media', function () {
            const card = $(this).closest('.media-item');
            card.find('.edit-media-form').removeClass('d-none');
            card.find('.action-buttons, .media-desc').hide();
        });
        $(document).on('click', '.cancel-edit', function () {
            const form = $(this).closest('.edit-media-form');
            form.addClass('d-none');
            form.closest('.media-item').find('.action-buttons, .media-desc').show();
        });
        $(document).on('submit', '.edit-media-form', function (e) {
            e.preventDefault();
            const form = $(this);
            const mediaId = form.data('id');
            const formData = new FormData(this);

            $.ajax({
                url: `/wellify-classes/media/${mediaId}/edit`,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function () {
                    alert('Media updated!');
                    $('#upload_icon').trigger('click'); // reload modal gallery
                },
                error: function () {
                    alert('Failed to update media.');
                }
            });
        });
    });
</script>

<script>
    $('#addClassForm').on('submit', function (e) {
    e.preventDefault();

    let form = $(this)[0];
    let formData = new FormData(form);

    // Fix: Append moods[] manually
    let moods = $('#choices-multiple-remove-button').val(); // Get selected moods
    if (moods && Array.isArray(moods)) {
        moods.forEach(id => formData.append('moods[]', id));
    }

    $.ajax({
        url: "{{ route('wellify-classes.store') }}",
        method: "POST",
        data: formData,
        contentType: false,
        processData: false,
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        success: function (response) {
            if (response.success) {
                $('#add_new').modal('hide');
                $('#addClassForm')[0].reset();
                $('#classesTable').DataTable().ajax.reload(null, false);
                location.reload();
            }
        },
        error: function (xhr) {
            let errors = xhr.responseJSON.errors;
            Object.values(errors).forEach(msgs => {
                toastr.error(msgs[0]);
            });
        }
    });
    });
</script>

<script>
    // Global variable to hold the Choices instance
    let editMoodsSelect;

    // Initialize Choices on page load
    document.addEventListener('DOMContentLoaded', function() {
        editMoodsSelect = new Choices('#edit_moods', {
            removeItemButton: true,
            searchEnabled: true,
            shouldSort: false,
        });
    });

    // Edit icon click handler
    $(document).on('click', '.edit_icon1', function () {
        const classId = $(this).data('id');

        $.ajax({
            url: '/wellify-classes/' + classId + '/edit',
            method: 'GET',
            success: function (res) {
                $('#edit_class_id').val(res.id);
                $('#edit_title').val(res.title);
                $('#edit_points').val(res.points_on_completion);
                $('#edit_seeds').val(res.seeds_on_completion);
                $('#edit_description').val(res.description);

                // Set category display and hidden value
               $('#edit_category_display').val(res.category_title);
               $('#edit_category_id').val(res.category_id);

                $('#edit_level_id').val(res.level_id);
                $('#current_image_name').text(res.background_image || 'No image uploaded');

                // set form action
                $('#editClassForm').attr('action', '/wellify-classes/' + res.id);

                // Load moods
                if (editMoodsSelect) {
                    editMoodsSelect.clearChoices();
                    editMoodsSelect.setChoices([
                        @foreach ($moods as $mood)
                            { value: '{{ $mood->id }}', label: '{{ $mood->title }}', selected: false },
                        @endforeach
                    ], 'value', 'label', false);

                    res.moods.forEach(function (moodId) {
                        editMoodsSelect.setChoiceByValue(moodId.toString());
                    });
                }

                $('#edit_user').modal('show');
            },
            error: function () {
                alert('Error fetching class details.');
            }
        });
    });

    // Submit handler
    $('#editClassForm').on('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(this);
        const classId = $('#edit_class_id').val();
        const url = '/wellify-classes/' + classId;

        $.ajax({
            url: url,
            type: 'POST', // IMPORTANT: Keep as POST
            data: formData,
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),

            },
            success: function (res) {
                if (res.success) {
                    $('#edit_user').modal('hide');
                    location.reload();
                }
            },
            error: function (xhr) {
                let errors = xhr.responseJSON.errors;
                let errorMessages = [];

                for (let field in errors) {
                    errorMessages.push(errors[field][0]);
                }

                alert('Error: ' + errorMessages.join('\n'));
            }
        });
    });
</script>

<script>
    var addcontactbtn = document.getElementById("adcontact-btn");
        addcontactbtn.addEventListener("click", () => {
            addcontactbtn.classList.add("d-none");
        });

        function addFn() {
            const divEle = document.getElementById("addImages_main");
            divEle.innerHTML += `
                                <div class="row align-items-center removediv">
                                    <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-12 mb-3">
                                        <form id="file-upload-form" class="uploader">
                                            <input id="file-upload" type="file" name="fileUpload" accept=".svg" tabindex="-1">
                                        <label for="file-upload" id="file-drag" class="py-2 px-3 d-flex image_label rounded-3">
                                        <img id="file-image" src="#" alt="Preview" class="hidden file-image">
                                        <span id="start" class="start text-center">
                                            <i class="fa fa-download" aria-hidden="true"></i>
                                            <span class="d-block">Select a file or drag here</span>
                                            <span id="file-upload-btn" class="btn btn-success my-2">Select a file</span>
                                        </span>
                                        <span id="response" class="hidden text-start ms-3 response">
                                            <span id="messages" class="messages"></span>
                                        </span>
                                    </label>
                                </form>
                            </div>
                            <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-12 mb-3">
                                <textarea class="form-control input rounded-3" placeholder="Enter Description"
                                    id="Textarea1" rows="3" tabindex="-1"></textarea>
                            </div>
                            <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-2 col-12 d-flex gap-3 mb-3">
                                     @php
                                $addImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/Add_icon.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                            <img src="  $addImageUrl" alt="add icon" class="img-fluid curser-pointer " onclick="addFn();">
                                  @php
                                $deleteImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/Delete_icon.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                    <img src="$deleteImageUrl " alt="delete icon" class="img-fluid curser-pointer " onclick="deleteRow(this)">
                            </div>
                        </div>`;
        }
        function deleteRow(r) {
            r.parentElement.parentElement.remove();
            let parentelem = document.getElementById("addImages_main");
            if (parentelem.children.length == 0) {
                addcontactbtn.classList.remove("d-none");
            }
        }
</script>

<script>
    const MAX_UPLOADS = 4;

    function getRowHtml() {
        return `
        <div class="row align-items-center add_newrow">
            <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-12 mb-3">
                <div class="uploader">
                    <input type="file" name="media[]" accept=".svg" class="file-upload d-none" required>
                    <label class="py-2 px-3 d-flex image_label rounded-3 file-label">
                        <img class="file-image d-none" src="#" alt="Preview">
                        <span class="start text-center w-100">
                            <span class="d-block">Select a file</span>
                            <span class="btn btn-success my-2">Select a file</span>
                        </span>
                    </label>
                </div>
            </div>
            <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-12 mb-3">
                <textarea name="description[]" class="form-control input rounded-3" placeholder="Enter Description" rows="3" required></textarea>
            </div>
            <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-2 col-12 mb-3 text-center">
                @php
                                $addImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/Add_icon.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
            <img src="{{ $addImageUrl }}" alt="add icon" class="img-fluid add-more" style="cursor:pointer;">
            </div>
        </div>`;
    }

    $(document).on('click', '.open-upload-modal', function () {
        $('#uploadClassId').val($(this).data('id'));
        $('#addimagesModal').modal('show');
        $('#addImages_main').html(getRowHtml());
    });

    $(document).on('click', '.add-more', function () {
        const count = $('#addImages_main .add_newrow').length;
        if (count < MAX_UPLOADS) {
            $('#addImages_main').append(getRowHtml());
            if (count + 1 === MAX_UPLOADS) {
                $('.add-more').remove();
            }
        }
    });

    $(document).on('change', '.file-upload', function () {
        const input = this;
        const label = $(input).siblings('.file-label');
        const preview = label.find('.file-image');
        const file = input.files[0];
        // const reader = new FileReader();
        // reader.onload = function (e) {
        //         preview.attr('src', e.target.result).removeClass('d-none');
        //         label.find('.start').hide();
        //     };
        // if (file && file.type !== 'image/svg+xml') {
        //     toastr.error('Only SVG files are allowed.');
        //     valid = false;
        //     return false;
        // }

        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                preview.attr('src', e.target.result).removeClass('d-none');
                label.find('.start').hide();
            };
            reader.readAsDataURL(file);
        }
    });


    $(document).on('click', '.file-label', function () {
        $(this).siblings('.file-upload').click();
    });

    $('#uploadImageForm').on('submit', function (e) {
        // console.log('hii');
        e.preventDefault();
        //     // Client-side validation
        // let valid = true;
        // $('.desc-field').each(function () {
        //     if ($(this).val().length > 255) {
        //         toastr.error('Description cannot exceed 255 characters.');
        //         valid = false;
        //         return false;
        //     }
        // });
        // $('.file-upload').each(function () {
        // const file = this.files[0];
        //     if (file && file.type !== 'image/svg+xml') {
        //         toastr.error('Only SVG files are allowed.');
        //         valid = false;
        //         return false;
        //     }
        // });

        // if (!valid) return;
        let formData = new FormData(this);

        $.ajax({
            url: "{{ route('class-media.upload') }}",
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.success) {
                    // alert('Uploaded successfully!');
                    $('#addimagesModal').modal('hide');
                    $('#uploadImageForm')[0].reset();
                    $('#addImages_main').html(getRowHtml());
                        location.reload();
                    // Optional: refresh DataTable here
                } else {
                    alert(res.message || 'Upload failed!');
                }
            },
            error: function (xhr) {
                alert(xhr.responseJSON?.message || 'Server error!');
            }
        });
    });
</script>

<script>
    $(document).on('click', '.delete_icon1', function () {
        const classId = $(this).data('id');
        $('#delete_class_id').val(classId);
        $('#delete_class_modal').modal('show');
    });

    // Confirm delete
    $('#confirm_delete_class').on('click', function () {
        const classId = $('#delete_class_id').val();

        $.ajax({
            url: '/wellify-classes/' + classId,
            type: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function (res) {
                if (res.success) {
                    $('#delete_class_modal').modal('hide');
                    location.reload(); // or refresh DataTable
                } else {
                    alert('Delete failed: ' + (res.message || 'Unknown error'));
                }
            },
            error: function (xhr) {
                alert('Error deleting class.');
            }
        });
    });
    // Handle restore
    $(document).on('click', '.btn-restore', function () {
        const classId = $(this).data('id');

        $.ajax({
            url: `/wellify-classes/${classId}/restore`,
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function (res) {
                if (res.success) {
                    $('#inactiveClassesTable').DataTable().ajax.reload(null, false);
                    $('#activeClassesTable').DataTable().ajax.reload(null, false);
                    // Show success message
                    showToast('success', res.message);
                } else {
                    showToast('error', res.message || 'Restore failed');
                }
            },
            error: function (xhr) {
                let errorMsg = 'Error restoring class.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMsg = xhr.responseJSON.message;
                }
                showToast('error', errorMsg);
            }
        });
    });
    function showToast(type, message) {
        // Example using Bootstrap toast - adjust based on your UI framework
        const toast = `<div class="toast align-items-center text-white bg-${type} border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>`;

        $('#toastContainer').append(toast);
        $('.toast').toast('show');

        // Remove toast after it hides
        $('.toast').on('hidden.bs.toast', function () {
            $(this).remove();
        });
    }


</script>

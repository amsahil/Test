<div class="modal fade" id="addQuizModal" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2"
    tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title fs-5">Add Class Quiz</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                    tabindex="-1"></button>
            </div>
            <div class="modal-body">
            <form id="quizForm" enctype="multipart/form-data">
                @csrf
                <div class="container-fluid p-0" id="addQuiz_main">
                    <div class="row align-items-center">
                        <h5 class="mb-3">Quiz Details</h5>
                        <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                            <label for="class_idQuiz" class="form-label">Class ID<span class="text-danger">*</span></label>
                            <input type="text" class="form-control input" id="class_idQuiz"
                                value="" name="class_id" readonly>
                        </div>
                        <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                            <label for="classBackgroundImg" class="form-label">Background Image<span class="text-danger">*</span></label>
                            <input type="file" class="form-control input" id="classBackgroundImg"
                                name="media" accept=".svg,image/svg+xml" required>
                        </div>
                        <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-12 mb-3">
                            <label for="Textareaquiz" class="form-label">Enter Question<span class="text-danger">*</span></label>
                            <textarea class="form-control input rounded-3" placeholder="Enter question"
                                id="Textareaquiz" name="question" rows="3" required></textarea>
                        </div>
                        <div class="col-12">
                            <hr class="hr">
                            <h5 class="mb-3">Answer Details<span class="text-danger">*</span></h5>
                        </div>
                        <div class="col-12" id="addOptions">
                            <div class="option_outer">
                                <div class="option_box mb-3 position-relative">
                                    <label for="option_1" class="form-label">Option 1</label>
                                    <input type="text" class="form-control input" id="option_1"
                                        placeholder="Enter option" name="options[]" required>
                                </div>
                                <div class="option_box mb-3 position-relative">
                                    <label for="option_2" class="form-label">Option 2</label>
                                    <input type="text" class="form-control input" id="option_2"
                                        placeholder="Enter option" name="options[]" required>
                                </div>
                                <div class="add_delete-icon mb-3">
                                       @php
                                $addImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/Add_icon.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                    <img src="{{  $addImageUrl }}" alt="add icon" class="img-fluid add-option-btn"
                                        style="cursor: pointer;">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <hr class="hr">
                            <h5 class="mb-3">Correct Answers<span class="text-danger">*</span></h5>
                            <div class="row" id="correctAnswersContainer">
                                <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                                    <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                                        value="0" id="answer_1">
                                    <label class="form-check-label mb-0" for="answer_1">
                                        Option 1
                                    </label>
                                </div>
                                <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                                    <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                                        value="1" id="answer_2">
                                    <label class="form-check-label mb-0" for="answer_2">
                                        Option 2
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-12 mb-3">
                            <label for="answerdecription" class="form-label">Answer Description<span class="text-danger">*</span></label>
                            <textarea class="form-control input rounded-3" placeholder="Enter answer description"
                                id="answerdecription" name="description" rows="3" required></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer gap-3">
                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="button primary_btn m-0">Submit</button>
            </div>
        </form>
    </div>
</div>
</div>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
    $(document).ready(function() {
        let quizModal = null;
        const MAX_OPTIONS = 4; // Set maximum options to 4

        // Reload when modal is closed
        $('#addQuizModal').on('submit', function () {
            // location.reload();
        });

        // Reload when cancel button is clicked
        $('.cancel_button').on('click', function() {
            location.reload();
        });

        // Initialize modal when shown
        $(document).on('show.bs.modal', function(event) {
            if (event.target.id === 'addQuizModal') {
                const button = $(event.relatedTarget);
                const classId = button.data('class-id');

                // Set the class ID in the modal
                $('#class_idQuiz').val(classId).attr('value', classId);

                // Reset the form
                $('#quizForm')[0].reset();
                resetOptionsToInitialState();

                // Store modal instance
                quizModal = new bootstrap.Modal(event.target);
            }
        });

        // Function to reset options to initial state
        function resetOptionsToInitialState() {
            $('#addOptions').html(`
                <div class="option_outer">
                    <div class="option_box mb-3 position-relative">
                        <label for="option_1" class="form-label">Option 1</label>
                        <input type="text" class="form-control input" id="option_1"
                            placeholder="Enter option" name="options[]" required>
                    </div>
                    <div class="option_box mb-3 position-relative">
                        <label for="option_2" class="form-label">Option 2</label>
                        <input type="text" class="form-control input" id="option_2"
                            placeholder="Enter option" name="options[]" required>
                    </div>
                    <div class="add_delete-icon mb-3">
                        <img src="/assets/images/Add_icon.svg" alt="add icon" class="img-fluid add-option-btn"
                            style="cursor: pointer;">
                    </div>
                </div>
            `);

            $('#correctAnswersContainer').html(`
                <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                    <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                        value="0" id="answer_1">
                    <label class="form-check-label mb-0" for="answer_1">
                        Option 1
                    </label>
                </div>
                <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                    <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                        value="1" id="answer_2">
                    <label class="form-check-label mb-0" for="answer_2">
                        Option 2
                    </label>
                </div>
            `);

            attachAddOptionListener();
        }

        // Function to attach event listener to add option button
        function attachAddOptionListener() {
            $('.add-option-btn').off('click').on('click', addOptionField);
        }

        // Add new option field function
        function addOptionField() {
            const $optionsContainer = $('#addOptions');
            const optionCount = $optionsContainer.find('.option_box').length + 1;

            if (optionCount > MAX_OPTIONS) {
                swal("Limit Reached", `Maximum ${MAX_OPTIONS} options allowed`, "warning");
                return;
            }

            // Create new option input with delete button (except for first two required options)
            const newOptionDiv = $(`
                <div class="option_box mb-3 position-relative">
                    <label for="option_${optionCount}" class="form-label">Option ${optionCount}</label>
                    <input type="text" class="form-control input" id="option_${optionCount}"
                        placeholder="Enter option" name="options[]" required>
                    ${optionCount > 2 ? `<button type="button" class="btn btn-sm btn-danger position-absolute delete-option" style="right: 10px; top: 35px;">
                        <i class="fa fa-trash" aria-hidden="true"></i>
                    </button>` : ''}
                </div>
            `);

            // Insert before the add button
            $optionsContainer.find('.add_delete-icon').before(newOptionDiv);

            // Add corresponding checkbox
            $('#correctAnswersContainer').append(`
                <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                    <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                        value="${optionCount - 1}" id="answer_${optionCount}">
                    <label class="form-check-label mb-0" for="answer_${optionCount}">
                        Option ${optionCount}
                    </label>
                </div>
            `);

            // Hide add button if we've reached max options
            if (optionCount >= MAX_OPTIONS) {
                $('.add-option-btn').hide();
            }

            // Attach delete handler to the new button
            if (optionCount > 2) {
                newOptionDiv.find('.delete-option').on('click', function() {
                    deleteOption($(this), optionCount - 1);
                });
            }
        }

        // Delete option function
        function deleteOption(button, index) {
            // Remove the option box
            button.closest('.option_box').remove();

            // Remove the corresponding checkbox
            $(`#correctAnswersContainer input[value="${index}"]`).closest('.col-xxl-3').remove();

            // Renumber remaining options and checkboxes
            renumberOptions();

            // Show add button if we're below max options
            if ($('#addOptions .option_box').length < MAX_OPTIONS) {
                $('.add-option-btn').show();
            }
        }

        // Renumber options after deletion
        function renumberOptions() {
            $('#addOptions .option_box').each(function(index) {
                const newIndex = index + 1;
                $(this).find('label').text(`Option ${newIndex}`);
                $(this).find('input').attr('id', `option_${newIndex}`);

                // Update corresponding checkbox
                const checkboxDiv = $(`#correctAnswersContainer .col-xxl-3:nth-child(${index + 1})`);
                checkboxDiv.find('input').attr({
                    'value': index,
                    'id': `answer_${newIndex}`
                });
                checkboxDiv.find('label').text(`Option ${newIndex}`).attr('for', `answer_${newIndex}`);
            });
        }

        // Form submission
        $('#quizForm').on('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const classId = $('#class_idQuiz').val();

            if (!classId) {
                swal("Missing Information", "Class ID is required", "error");
                return;
            }

            const correctCheckboxes = $('#addQuizModal input[name="correct_answers[]"]:checked');
            if (correctCheckboxes.length === 0) {
                swal("Validation Error", "Please select at least one correct answer", "error");
                return;
            }

            // Add correct answers to form data
            const correctAnswers = correctCheckboxes.map(function() { return this.value; }).get();
            formData.delete('correct_answers[]');
            correctAnswers.forEach(function(index) {
                formData.append('correct_answers[]', index);
            });

            // Show loading state
            const $submitBtn = $(this).find('button[type="submit"]');
            const originalText = $submitBtn.text();
            $submitBtn.text('Submitting...').prop('disabled', true);

            $.ajax({
                url: `/classes/${classId}/quizzes`,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(data) {
                    if (data.success) {
                        swal({
                            title: "Question Created!",
                            text: `Question created successfully!\nTotal questions: ${data.quiz_count}`,
                            icon: "success"
                        }).then(() => {
                            location.reload();
                        });

                        $(`[data-class-id="${classId}"] small`).text(
                            `${data.quiz_count} Quiz${data.quiz_count !== 1 ? 's' : ''}`
                        );

                        if (quizModal) quizModal.hide();
                        $('#quizForm')[0].reset();
                        resetOptionsToInitialState();
                    } else {
                        let errorMessages = [];
                        if (data.errors) {
                            errorMessages = Object.values(data.errors).flat();
                        } else {
                            errorMessages.push(data.message || 'Unknown error occurred');
                        }

                        swal("Submission Failed", errorMessages.join("\n"), "error");
                    }
                },
                error: function(xhr) {
                    let message = 'An error occurred while creating the quiz.';
                    if (xhr.responseJSON) {
                        const error = xhr.responseJSON;
                        if (error.errors) {
                            message = Object.values(error.errors).flat().join("\n");
                        } else if (error.message) {
                            message = error.message;
                        }
                    }

                    swal("Request Failed", message, "error");
                },
                complete: function() {
                    $submitBtn.text(originalText).prop('disabled', false);
                }
            });
        });

        // Make addOptionField globally available for inline onclick if needed
        window.addOptionField = addOptionField;
            $('.btn-close').on('click', function() {
            location.reload(); // Reload the page
        });
    });
</script>

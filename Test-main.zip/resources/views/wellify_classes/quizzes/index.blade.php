@extends('layouts.app')
@include('common.header')
@include('common.sidebar')

@section('content')
<section class="main_card">
    <div class="container-fluid">
        <div class="row">
            <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Manage Question - ({{ $class->id ?? '' }})</h5>
                <button class="button primary_btn" type="button" id="add_new" data-bs-toggle="modal"
                    data-bs-target="#addQuizModal" data-class-id="{{ $class->id ?? '' }}">
                    Add New
                </button>
            </div>
        </div>

        @foreach($quizzes as $quiz)
        <div class="container-fluid card_quiz mt_24" id="quizcard_{{ $quiz->id }}">
            <div class="row">
                <div class="title_section d-flex w-100">
                    <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Question - {{ $loop->iteration }}</h5>
                    <div class="dropdown ms-auto">
                        <button class="btn dropdown-toggle icon_dropdown" type="button" data-bs-toggle="dropdown">
                                     @php
                                $menuImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/menu.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                            <img src="{{ $menuImageUrl }}" alt="menu icon" class="img-fluid">
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item edit-quiz-btn" href="#" data-quiz-id="{{ $quiz->id }}">Edit</a></li>
                            <li><a class="dropdown-item text-danger delete-quiz-btn" href="#" data-quiz-id="{{ $quiz->id }}">Delete</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-xxl-8 col-xl-12 col-lg-12 col-md-12 col-12 profile_left mt-3">
                    <div class="mb-3">
                        <label class="form-label mb-0" for="question_{{ $quiz->id }}">Question:</label>
                        <textarea class="form-control rounded-3 form_profile quiz_textarea quiz-question"
                                  placeholder="Enter question"
                                  id="question_{{ $quiz->id }}"
                                  rows="2"
                                  tabindex="1"
                                  disabled>{{ $quiz->title }}</textarea>
                    </div>

                    <div class="row">
                        @foreach($quiz->options as $option)
                            <div class="col-xxl-3 col-xl-6 col-lg-6 col-md-6 col-12 form-check gap-2 d-flex align-items-center mb-3">
                                <input class="form-check-input ms-0 mt-0 answer_optn quiz-answer"
                                       type="checkbox"
                                       data-option-id="{{ $option->id }}"
                                       {{ $option->isAnswer ? 'checked' : '' }}
                                       >
                                <label class="form-check-label mb-0 answerlebel quiz-option-text"
                                       contenteditable="false"
                                       data-option-id="{{ $option->id }}">{{ $option->option }}</label>
                            </div>
                        @endforeach
                    </div>

                    <div class="col-12 mb-3">
                        <hr class="hr mt-2">
                        <label class="form-label mb-0" for="answer_{{ $quiz->id }}">Answer Description:</label>
                        <textarea class="form-control rounded-3 form_profile quiz_textarea quiz-description"
                                  placeholder="Enter answer"
                                  id="answer_{{ $quiz->id }}"
                                  rows="2"
                                  tabindex="7"
                                  disabled>{{ $quiz->options->where('isAnswer', 1)->first()->description ?? '' }}</textarea>
                    </div>
                </div>

                <div class="col-xxl-4 col-xl-12 col-lg-12 col-md-12 col-12 d-flex justify-content-center align-items-center flex-column gap-3 mt-xxl-0 mt-xl-3 mt-lg-3 mt-md-3 mt-3">
                    @if($quiz->media)
                    <div class="avatar-preview rounded-circle position-relative">
                        <div class="avatar-edit d-none" id="avatar-edit-{{ $quiz->id }}">
                            <input type="file" id="imageUpload_{{ $quiz->id }}" accept=".png, .jpg, .jpeg" data-quiz-id="{{ $quiz->id }}">
                            <label for="imageUpload_{{ $quiz->id }}"
                                   class="d-flex align-items-center justify-content-center bg-white rounded-circle mb-0 editavatar_icon">
                                            @php
                                $editImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/edit.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{$editImageUrl  }}" alt="">
                            </label>
                        </div>
                        <div id="imagePreview_{{ $quiz->id }}" class="rounded-circle managQuizImage">
                            <img src="{{ $quiz->media_url }}" class="rounded-circle managQuizImage" />
                        </div>
                    </div>
                    @else
                    <div class="avatar-preview rounded-circle position-relative">
                        <div class="avatar-edit d-none" id="avatar-edit-{{ $quiz->id }}">
                            <input type="file" id="imageUpload_{{ $quiz->id }}" accept=".png, .jpg, .jpeg" data-quiz-id="{{ $quiz->id }}">
                            <label for="imageUpload_{{ $quiz->id }}"
                                   class="d-flex align-items-center justify-content-center bg-white rounded-circle mb-0 editavatar_icon">
                               @php
                                $editImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/edit.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{$editImageUrl  }}" alt="">
                            </label>
                        </div>
                        <div id="imagePreview_{{ $quiz->id }}" class="rounded-circle managQuizImage">
                            <p>No image available</p>
                        </div>
                    </div>
                    @endif

                    <div class="gap-3 w-100 d-flex justify-content-center d-none mt-2 update-buttons" id="updates_buttons_{{ $quiz->id }}">
                        <button type="button" class="button cancel_button m-0 cancel-edit-btn" data-quiz-id="{{ $quiz->id }}">Cancel</button>
                        <button class="button primary_btn m-0 save-quiz-btn" type="button" data-quiz-id="{{ $quiz->id }}">Save</button>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</section>
<div class="modal fade" id="addQuizModal" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2"
    tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title fs-5">Add Class Quiz</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                    tabindex="-1"></button>
            </div>

            <div class="modal-body">
                <form id="quizForm" enctype="multipart/form-data">
                    @csrf
                    <div class="container-fluid p-0" id="addQuiz_main">
                        <div class="row align-items-center">
                            <h5 class="mb-3">Quiz Details</h5>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="class_idQuiz" class="form-label">Class ID</label>
                                <input type="text" class="form-control input" id="class_idQuiz"
                                    value="" name="class_id" readonly>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                <label for="classBackgroundImg" class="form-label">Background Image<span class="text-danger">*</span></label>
                                <input type="file" class="form-control input" id="classBackgroundImg"
                                    name="media" accept=".svg,image/svg+xml" required>
                            </div>
                            <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-12 mb-3">
                                <label for="Textareaquiz" class="form-label">Enter Question<span class="text-danger">*</span></label>
                                <textarea class="form-control input rounded-3" placeholder="Enter question"
                                    id="Textareaquiz" name="question" rows="3" required></textarea>
                            </div>
                            <div class="col-12">
                                <hr class="hr">
                                <h5 class="mb-3">Answer Details</h5>
                            </div>
                            <div class="col-12" id="addOptions">
                                <div class="row">
                                    <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-12 mb-3">
                                        <label for="option_1" class="form-label">Option 1</label>
                                        <input type="text" class="form-control input" id="option_1"
                                            placeholder="Enter option" name="options[]" required>
                                    </div>
                                    <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-12 mb-3">
                                        <label for="option_2" class="form-label">Option 2</label>
                                        <input type="text" class="form-control input" id="option_2"
                                            placeholder="Enter option" name="options[]" required>
                                    </div>
                                    <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-2 col-12 d-flex align-items-center justify-content-center add_delete-icon ">
                                        @php
                                $addImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/Add_icon.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                    <img src="{{ $addImageUrl }}" alt="add icon" class="img-fluid add-option-btn"
                                            style="cursor: pointer;">
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <hr class="hr">
                                <h5 class="mb-3">Correct Answers<span class="text-danger">*</span></h5>
                                <div class="row" id="correctAnswersContainer">
                                    <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                                        <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                                            value="0" id="answer_1">
                                        <label class="form-check-label mb-0" for="answer_1">
                                            Option 1
                                        </label>
                                    </div>
                                    <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                                        <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                                            value="1" id="answer_2">
                                        <label class="form-check-label mb-0" for="answer_2">
                                            Option 2
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-12 mb-3">
                                <label for="answerdecription" class="form-label">Answer Description<span class="text-danger">*</span></label>
                                <textarea class="form-control input rounded-3" placeholder="Enter answer description"
                                    id="answerdecription" name="description" rows="3" required></textarea>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer gap-3">
                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="button primary_btn m-0" form="quizForm">Submit</button>
            </div>
        </div>
    </div>
</div>
<!-- Delete Quiz Modal -->
<div class="modal fade" id="delete_user" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete_userLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                                @php
                                $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/warning.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                            <img src="{{  $warningImageUrl }}" alt="warning icon" class="img-fluid">
                            <h4 class="mt-4 text-danger">Delete This Quiz?</h4>
                            <p class="mt-3 line_height_30">
                                This quiz will be deleted.<br>
                                Are you sure you want to continue?
                            </p>
                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="button primary_btn m-0 warning_button" id="confirmDeleteBtn">Delete</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Edit Quiz functionality
        document.querySelectorAll('.edit-quiz-btn').forEach(button => {
            button.addEventListener('click', function (e) {
                e.preventDefault();
                const quizId = this.dataset.quizId;
                const parentCard = document.querySelector(`#quizcard_${quizId}`);

                // Enable editing mode
                enableEditMode(parentCard, quizId);
            });
        });

        // Cancel Edit functionality
        document.querySelectorAll('.cancel-edit-btn').forEach(button => {
            button.addEventListener('click', function (e) {
                e.preventDefault();
                const quizId = this.dataset.quizId;
                const parentCard = document.querySelector(`#quizcard_${quizId}`);

                // Disable editing mode
                disableEditMode(parentCard, quizId);
            });
        });

        // Save Quiz functionality
        document.querySelectorAll('.save-quiz-btn').forEach(button => {
            button.addEventListener('click', function (e) {
                e.preventDefault();
                const quizId = this.dataset.quizId;
                const parentCard = document.querySelector(`#quizcard_${quizId}`);

                // Save the quiz
                saveQuiz(parentCard, quizId);
            });
        });

        // Image upload functionality
        document.querySelectorAll('[id^="imageUpload_"]').forEach(input => {
            input.addEventListener('change', function() {
                const quizId = this.dataset.quizId;
                const file = this.files[0];

                if (file) {
                    // Preview the image
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const preview = document.querySelector(`#imagePreview_${quizId}`);
                        preview.innerHTML = `<img src="${e.target.result}" class="rounded-circle managQuizImage" />`;
                    };
                    reader.readAsDataURL(file);
                }
            });
        });

        function enableEditMode(parentCard, quizId) {
            // Enable question textarea
            const questionTextarea = parentCard.querySelector('.quiz-question');
            questionTextarea.disabled = false;
            questionTextarea.classList.add('input');

            // Enable answer description textarea
            const descriptionTextarea = parentCard.querySelector('.quiz-description');
            descriptionTextarea.disabled = false;
            descriptionTextarea.classList.add('input');

            // Enable option checkboxes
            parentCard.querySelectorAll('.quiz-answer').forEach(checkbox => {
                checkbox.disabled = false;
            });

            // Enable option labels for editing
            parentCard.querySelectorAll('.quiz-option-text').forEach(label => {
                label.setAttribute('contenteditable', 'true');
                label.style.border = '1px dashed #ccc';
                label.style.padding = '2px 5px';
            });

            // Show update buttons
            const updateButtons = document.querySelector(`#updates_buttons_${quizId}`);
            updateButtons.classList.remove('d-none');

            // Show avatar edit
            const avatarEdit = document.querySelector(`#avatar-edit-${quizId}`);
            if (avatarEdit) {
                avatarEdit.classList.remove('d-none');

                // Get the file input inside the avatarEdit block (adjust selector if needed)
                const fileInput = avatarEdit.querySelector('input[type="file"]');
                if (fileInput) {
                    fileInput.setAttribute("accept", ".svg,image/svg+xml");
                }
            }
        }

        function disableEditMode(parentCard, quizId) {
            // Disable question textarea
            const questionTextarea = parentCard.querySelector('.quiz-question');
            questionTextarea.disabled = true;
            questionTextarea.classList.remove('input');

            // Disable answer description textarea
            const descriptionTextarea = parentCard.querySelector('.quiz-description');
            descriptionTextarea.disabled = true;
            descriptionTextarea.classList.remove('input');

            // Disable option checkboxes
            parentCard.querySelectorAll('.quiz-answer').forEach(checkbox => {
                checkbox.disabled = true;
            });

            // Disable option labels for editing
            parentCard.querySelectorAll('.quiz-option-text').forEach(label => {
                label.setAttribute('contenteditable', 'false');
                label.style.border = 'none';
                label.style.padding = '0';
            });

            // Hide update buttons
            const updateButtons = document.querySelector(`#updates_buttons_${quizId}`);
            updateButtons.classList.add('d-none');

            // Hide avatar edit
            const avatarEdit = document.querySelector(`#avatar-edit-${quizId}`);
            if (avatarEdit) {
                avatarEdit.classList.add('d-none');
            }
        }

        function saveQuiz(parentCard, quizId) {
            // Collect form data
            const question = parentCard.querySelector('.quiz-question').value;
            const description = parentCard.querySelector('.quiz-description').value;

            const options = [];
            parentCard.querySelectorAll('.quiz-option-text').forEach((label, index) => {
                const optionId = label.dataset.optionId;
                const checkbox = parentCard.querySelector(`.quiz-answer[data-option-id="${optionId}"]`);

                options.push({
                    id: optionId,
                    option: label.textContent.trim(),
                    isAnswer: checkbox.checked ? 1 : 0,
                    description: checkbox.checked ? description : ''
                });
            });

            // Prepare form data for file upload
            const formData = new FormData();
            formData.append('title', question);
            formData.append('options', JSON.stringify(options));

            // Add image if selected
            const imageInput = document.querySelector(`#imageUpload_${quizId}`);
            if (imageInput && imageInput.files[0]) {
                formData.append('media', imageInput.files[0]);
            }

            // AJAX update
            fetch(`/wellify/quizzes/${quizId}/update`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // alert('Quiz updated successfully!');
                    // Disable edit mode
                    disableEditMode(parentCard, quizId);

                    // Reload page to show updated data
                    location.reload();
                } else {
                    alert('Update failed: ' + (data.message || 'Unknown error'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the quiz.');
            });
        }
        let quizIdToDelete = null;

        document.querySelectorAll('.delete-quiz-btn').forEach(button => {
            button.addEventListener('click', function (e) {
                e.preventDefault();
                quizIdToDelete = this.dataset.quizId;

                // Show the delete confirmation modal
                const modal = new bootstrap.Modal(document.getElementById('delete_user'));
                modal.show();
            });
        });

        document.getElementById('confirmDeleteBtn').addEventListener('click', function () {
            if (!quizIdToDelete) return;

            fetch(`/wellify/quizzes/${quizIdToDelete}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                },
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Remove the card from DOM
                    const quizCard = document.getElementById(`quizcard_${quizIdToDelete}`);
                    if (quizCard) quizCard.remove();

                    // Hide modal
                    const modal = bootstrap.Modal.getInstance(document.getElementById('delete_user'));
                    modal.hide();
                } else {
                    alert('Delete failed: ' + (data.message || 'Unknown error'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while deleting the quiz.');
            });
        });
    });
</script>
<script>
    $(document).ready(function() {
        let quizModal = null;

        // Initialize modal when shown
        $('#addQuizModal').on('show.bs.modal', function(event) {
            const button = $(event.relatedTarget);
            const classId = button.data('class-id');

            // Set the class ID in the modal
            $('#class_idQuiz').val(classId).attr('value', classId);

            // Reset the form
            $('#quizForm')[0].reset();
            resetOptionsToInitialState();

            // Store modal instance
            quizModal = new bootstrap.Modal(event.target);
        });

        // Function to reset options to initial state
        function resetOptionsToInitialState() {
            $('#addOptions').html(`
                <div class="row">
                    <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-12 mb-3">
                        <label for="option_1" class="form-label">Option 1</label>
                        <input type="text" class="form-control input" id="option_1"
                            placeholder="Enter option" name="options[]" required>
                    </div>
                    <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-12 mb-3">
                        <label for="option_2" class="form-label">Option 2</label>
                        <input type="text" class="form-control input" id="option_2"
                            placeholder="Enter option" name="options[]" required>
                    </div>
                    <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-2 col-12 d-flex align-items-center justify-content-center add_delete-icon ">
                          @php
                                $addImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/Add_icon.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                    <img src="{{ $addImageUrl }}" alt="add icon" class="img-fluid add-option-btn"
                            style="cursor: pointer;">
                    </div>
                </div>
            `);

            $('#correctAnswersContainer').html(`
                <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                    <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                        value="0" id="answer_1">
                    <label class="form-check-label mb-0" for="answer_1">
                        Option 1
                    </label>
                </div>
                <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                    <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                        value="1" id="answer_2">
                    <label class="form-check-label mb-0" for="answer_2">
                        Option 2
                    </label>
                </div>
            `);

            attachAddOptionListener();
        }

        // Function to attach event listener to add option button
        function attachAddOptionListener() {
            $('.add-option-btn').off('click').on('click', addOptionField);
        }

        // Add new option field function
        function addOptionField() {
            const $optionsContainer = $('#addOptions');
            const optionCount = $optionsContainer.find('.option_box').length + 1;

            if (optionCount > 10) {
                swal("Limit Reached", "Maximum 10 options allowed", "warning");
                return;
            }

            // Create new option input
            const newOptionDiv = $(`
                <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-12 mb-3">
                    <label for="option_${optionCount}" class="form-label">Option ${optionCount}</label>
                    <input type="text" class="form-control input" id="option_${optionCount}"
                        placeholder="Enter option" name="options[]" required>
                </div>
            `);

            // Insert before the add button
            $optionsContainer.find('.add_delete-icon').before(newOptionDiv);

            // Add corresponding checkbox
            $('#correctAnswersContainer').append(`
                <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-12 d-flex align-items-center gap-2 mb-3">
                    <input class="form-check-input ms-0 mt-0" type="checkbox" name="correct_answers[]"
                        value="${optionCount - 1}" id="answer_${optionCount}">
                    <label class="form-check-label mb-0" for="answer_${optionCount}">
                        Option ${optionCount}
                    </label>
                </div>
            `);
        }

        // Form submission
        $('#quizForm').on('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const classId = $('#class_idQuiz').val();

            if (!classId) {
                swal("Missing Information", "Class ID is required", "error");
                return;
            }

            const correctCheckboxes = $('#addQuizModal input[name="correct_answers[]"]:checked');
            if (correctCheckboxes.length === 0) {
                swal("Validation Error", "Please select at least one correct answer", "error");
                return;
            }

            // Add correct answers to form data
            const correctAnswers = correctCheckboxes.map(function() { return this.value; }).get();
            formData.delete('correct_answers[]');
            correctAnswers.forEach(function(index) {
                formData.append('correct_answers[]', index);
            });

            // Show loading state
            const $submitBtn = $(this).find('button[type="submit"]');
            const originalText = $submitBtn.text();
            $submitBtn.text('Submitting...').prop('disabled', true);

            $.ajax({
                url: `/classes/${classId}/quizzes`,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(data) {
                    if (data.success) {
                        swal("Question Created!", `Question created successfully!\nTotal questions: ${data.quiz_count}`, "success");

                        $(`[data-class-id="${classId}"] small`).text(
                            `${data.quiz_count} Quiz${data.quiz_count !== 1 ? 's' : ''}`
                        );
                        location.reload();

                        if (quizModal) quizModal.hide();
                        $('#quizForm')[0].reset();
                        resetOptionsToInitialState();
                        windows.reload();
                    } else {
                        let errorMessages = [];
                        if (data.errors) {
                            errorMessages = Object.values(data.errors).flat();
                        } else {
                            errorMessages.push(data.message || 'Unknown error occurred');
                        }

                        swal("Submission Failed", errorMessages.join("\n"), "error");
                    }
                },
                error: function(xhr) {
                    let message = 'An error occurred while creating the quiz.';
                    if (xhr.responseJSON) {
                        const error = xhr.responseJSON;
                        if (error.errors) {
                            message = Object.values(error.errors).flat().join("\n");
                        } else if (error.message) {
                            message = error.message;
                        }
                    }

                    swal("Request Failed", message, "error");
                },
                complete: function() {
                    $submitBtn.text(originalText).prop('disabled', false);
                }
            });
        });

        // Initialize the add option listener
        attachAddOptionListener();

    });

</script>
@endsection

@extends('layouts.app')
@extends("employer.index")
@section("employee")
<!-- Employee Listing -->
<section class="main_card">
    <nav>
        <div class="nav nav-tabs d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block justify-content-between" id="employee-tab" role="tablist">
            <div class="tabs_buttons d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">
                <button class="nav-link active mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3" id="nav-staff-tab" data-bs-toggle="tab" data-bs-target="#nav-staff"
                    type="button" role="tab" aria-controls="nav-staff" aria-selected="true">Active Staff</button>
                <button class="nav-link mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3" id="nav-inactive-tab" data-bs-toggle="tab" data-bs-target="#nav-inactive"
                    type="button" role="tab" aria-controls="nav-inactive" aria-selected="false">Inactive Staff</button>
            </div>
        </div>
    </nav>

    <div class="tab-content" id="employee-tabContent">
        <!-- Staff List Tab -->
        <div class="tab-pane fade show active" id="nav-staff" role="tabpanel" aria-labelledby="nav-staff-tab" tabindex="0">
            <div class="container-fluid">
                <div class="row">
                    <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                        <h5 class="mb-xl-0 mb-lg-0 mb-md-0 mb-3">Active Staffs</h5>
                        <div class="button_group d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block gap-3">
                            <button class="button secondary_btn mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3" type="button" data-bs-toggle="modal" data-bs-target="#upload_files">
                                Bulk Upload
                            </button>
                            <button class="button primary_btn mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3" type="button" data-bs-toggle="modal" data-bs-target="#add-new-employee">
                                Add New
                            </button>
                            <button id="send-welcome-emails" class="button send_mailButton mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">
                                Send Mail
                            </button>
                        </div>
                    </div>
                </div>
                <div class="row pt_24">
                    <div class="col-12">
                        <table id="employee-datatable" class="table table-striped datatable mt-2 order-column nowrap dataTable">
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Department</th>
                                    <th scope="col">Phone</th>
                                    <th scope="col">City</th>
                                    <th scope="col">State</th>
                                    <th scope="col">Country</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Active employee data -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Inactive Staff Tab -->
        <div class="tab-pane fade" id="nav-inactive" role="tabpanel" aria-labelledby="nav-inactive-tab" tabindex="0">
            <div class="container-fluid">
                <div class="row">
                    <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                        <h5 class="mb-xl-0 mb-lg-0 mb-md-0 mb-3">Inactive Staff List</h5>
                        <!-- Optional re-assign/invite button -->
                    </div>
                </div>
                <div class="row pt_24">
                    <div class="col-12">
                        <table id="inactive-employee-datatable" class="table table-striped datatable">
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Department</th>
                                    <th scope="col">Phone</th>
                                    <th scope="col">City</th>
                                    <th scope="col">State</th>
                                    <th scope="col">Country</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Inactive employee data -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
    const userRole = "{{ auth()->user()->getRoleNames()->first() }}";

</script>

<!-- this div will will display modal that contains edit email template -->
<div class="modal fade" id="emailEditModal" tabindex="-1" role="dialog" aria-labelledby="emailEditModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="emailEditModalLabel">Edit Welcome Email</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="emailContent" style="max-height: 400px; overflow-y: auto; white-space: pre-wrap; border: 1px solid #ccc; padding: 10px; border-radius: 5px;">
                    <!-- The email template content will be loaded here -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <!-- <button type="button" id="sendEditedEmail" class="btn btn-primary">Send Email</button> -->
                <button type="button" id="sendEditedEmail" class="btn btn-primary">
                    <span id="buttonText">Send Email</span>
                    <span id="spinner" class="spinner-border spinner-border-sm" role="status" style="display: none;"></span>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- modal for add new Employee -->
<div class="modal fade" id="add-new-employee" data-bs-keyboard="false" tabindex="-1" aria-labelledby="add-new-employeeLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <form id="addStaffForm" action="{{ route('staffs.store') }}" method="POST" autocomplete="off">
                @csrf
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="add-new-employeeLabel">Add Staff</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid p-0">
                        <div class="row">
                            <!-- Employer Details Section -->
                            <h5 class="mb-3">Staff Details</h5>
                            <!--  Dummy fields to confuse browser autofill -->
                            <input type="text" name="fake_email" id="fake_email" style="display: none;">
                            <input type="password" name="fake_password" id="fake_password" style="display: none;">
                            @if(Auth::user()->hasRole('Super Admin'))
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="employer_select" class="form-label">Select Employer <span class="text-danger">*</span></label>
                                <select name="employer_id" id="employer_name" class="form-control input" required>
                                    <option value="" disabled selected>Select an Employer</option>
                                    @foreach($employees as $employee)
                                    <option value="{{ $employee->id }}" {{ old('employer_id') == $employee->id ? 'selected' : '' }}>
                                        {{ $employee->username }}
                                    </option>

                                    @endforeach
                                </select>
                                <div class="invalid-feedback" id="employerFeedback"></div>
                            </div>
                            @endif

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="department_id" class="form-label">Department <span class="text-danger">*</span></label>
                                <select class="form-control input" id="department_id" name="department_id" required>
                                    <option value="" disabled selected>Select Department</option>
                                </select>
                                <div class="invalid-feedback" id="departmentFeedback"></div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="firstName" class="form-label">First Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="firstName" name="firstName" placeholder="Enter first name" required>
                                <div class="invalid-feedback" id="firstNameFeedback"></div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="secondName" class="form-label">Last Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="secondName" name="secondName" placeholder="Enter last name" required>
                                <div class="invalid-feedback" id="secondNameFeedback"></div>
                            </div>

                            <!-- Email -->
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="email" id="staff_email" name="staff_email"
                                    class="form-control input" placeholder="Enter staff email"
                                    autocomplete="off" required>
                                <div class="invalid-feedback" id="emailFeedback"></div>
                            </div>


                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="phone" class="form-label">Phone <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control input" id="phone" name="phone" placeholder="XXX-XXX-XXXX" required>
                                <div class="invalid-feedback" id="phoneFeedback"></div>
                            </div>

                            <!-- <h5 class="mb-3">Address Details</h5> -->

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="city" class="form-label">City</label>
                                <input type="text" class="form-control input" id="city" name="city" placeholder="Enter city">
                                <div class="invalid-feedback" id="cityFeedback"></div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="state" class="form-label">State</label>
                                <input type="text" class="form-control input" id="state" name="state" placeholder="Enter state">
                                <div class="invalid-feedback" id="stateFeedback"></div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="country" class="form-label">Country</label>
                                <input type="text" class="form-control input" id="country" name="country" placeholder="Enter country">
                                <div class="invalid-feedback" id="countryFeedback"></div>
                            </div>

                            <!-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="licenses" class="form-label">Licenses</label>
                                <input type="text" class="form-control input" id="licenses" name="licenses" placeholder="Enter licenses">
                                <div class="invalid-feedback" id="licensesFeedback"></div>
                            </div> -->

                            <!-- Password -->
                            <!-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control input" id="password" name="password" autocomplete="new-password" placeholder="Enter password">
                                <div class="invalid-feedback" id="passwordFeedback"></div>
                            </div> -->
                        </div>
                    </div>
                </div>
                <div class="modal-footer gap-3">
                    <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal" tabindex="-1">Close</button>
                    <button class="button primary_btn m-0" type="submit" tabindex="-1">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit User-->
<div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-labelledby="editEmployeeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <form id="editEmployeeForm">
                <input type="hidden" name="id" id="edit_employee_id">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="editEmployeeModalLabel">Edit Staff</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
                </div>

                <div class="modal-body">
                    <div class="container-fluid p-0">
                        <div class="row">
                            <!-- Employee Details Section -->
                            <h5 class="mb-3">Staff Details</h5>
                            @if(Auth::user()->hasRole('Super Admin'))
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="edit_employer" class="form-label">Employer</label>
                                <input type="text" class="form-control input" id="edit_employer" name="employer" disabled>
                            </div>
                            @endif
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="edit_first_name" class="form-label">First Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="edit_first_name" name="first_name" required>
                                <div class="invalid-feedback" id="editFirstNameFeedback"></div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="edit_last_name" class="form-label">Last Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="edit_last_name" name="last_name" required>
                                <div class="invalid-feedback" id="editLastNameFeedback"></div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="edit_email" class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control input" id="edit_email" name="email" required autocomplete="off" disabled>
                                <div class="invalid-feedback" id="editEmailFeedback"></div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="edit_phone" class="form-label">Phone <span class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="edit_phone" name="mobile_phone" required>
                                <div class="invalid-feedback" id="editPhoneFeedback"></div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="edit_department_id" class="form-label">Department</label>
                                <select class="form-control input" id="edit_department_id" name="department_id" required>
                                    <option value="" disabled selected>Select Department</option>
                                    @foreach ($departments as $department)
                                    <option
                                        value="{{ $department->id }}"
                                        data-employer="{{ $department->employer ? $department->employer->username : 'N/A' }}"
                                        data-employer-id="{{ $department->employer_id }}">
                                        {{ $department->name }}
                                    </option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback" id="editDepartmentFeedback"></div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="edit_city" class="form-label">City</label>
                                <input type="text" class="form-control input" id="edit_city" name="city">
                                <div class="invalid-feedback" id="editCityFeedback"></div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="edit_state" class="form-label">State</label>
                                <input type="text" class="form-control input" id="edit_state" name="state">
                                <div class="invalid-feedback" id="editStateFeedback"></div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="edit_country" class="form-label">Country</label>
                                <input type="text" class="form-control input" id="edit_country" name="country">
                                <div class="invalid-feedback" id="editCountryFeedback"></div>
                            </div>

                            <!-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="edit_licenses" class="form-label">Licenses</label>
                                <input type="text" class="form-control input" id="edit_licenses" name="licenses">
                                <div class="invalid-feedback" id="editLicensesFeedback"></div>
                            </div> -->
                        </div>
                    </div>
                </div>

                <div class="modal-footer gap-3">
                    <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal" tabindex="-1">Close</button>
                    <button class="button primary_btn m-0" type="submit" tabindex="-1">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal delete User-->
<div class="modal fade" id="delete_user" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete_userLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form action="#">
                <div class="modal-body">
                    <div class="container-fluid px-0 py-3">
                        <div class="row">
                            <div class="col-12 text-center">
                                <!-- <img src="{{ asset('assets/images/warning.svg') }}" alt="warning icon" class="img-fluid"> -->
                                <h4 class="mt-4 text-danger">Delete This Staff?</h4>
                                <p class="mt-3 line_height_30"> This staff will move to recently deleted <br>
                                    Are you sure you want to continue?</p>
                            </div>
                            <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                                    tabindex="-1">Cancel</button>
                                <button class="button primary_btn m-0 warning_button" type="submit"
                                    tabindex="-1">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Employee View Modal -->
<div class="modal fade" id="employeeViewModal" tabindex="-1" aria-labelledby="employeeViewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title fs-5" id="employeeViewModalLabel">View Staff</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
            </div>
            <div class="modal-body">
                <div class="container-fluid p-0">
                    <div class="row">
                        <h5 class="mb-3">Staff Details</h5>

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                            <label class="form-label">User Name:</label>
                            <p id="view_userName" class="mb-0 text-muted">—</p>
                        </div>

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                            <label class="form-label">First Name:</label>
                            <p id="view_firstName" class="mb-0 text-muted">—</p>
                        </div>

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                            <label class="form-label">Last Name:</label>
                            <p id="view_lastName" class="mb-0 text-muted">—</p>
                        </div>

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                            <label class="form-label">Email:</label>
                            <p id="view_email" class="mb-0 text-muted">—</p>
                        </div>

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                            <label class="form-label">Phone:</label>
                            <p id="view_phone" class="mb-0 text-muted">—</p>
                        </div>

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                            <label class="form-label">Department:</label>
                            <p id="view_department" class="mb-0 text-muted">—</p>
                        </div>

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                            <label class="form-label">City:</label>
                            <p id="view_city" class="mb-0 text-muted">—</p>
                        </div>

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                            <label class="form-label">State:</label>
                            <p id="view_state" class="mb-0 text-muted">—</p>
                        </div>

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                            <label class="form-label">Country:</label>
                            <p id="view_country" class="mb-0 text-muted">—</p>
                        </div>

                        <!-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                            <label class="form-label">Licenses:</label>
                            <p id="view_licenses" class="mb-0 text-muted">—</p>
                        </div> -->
                    </div>
                </div>
            </div>
            <div class="modal-footer gap-3">
                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal" tabindex="-1">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Staff Modal -->
<div class="modal fade" id="delete_staff" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete_staffLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form action="#">
                <div class="modal-body">
                    <div class="container-fluid px-0 py-3">
                        <div class="row">
                            <div class="col-12 text-center">
                                @php
                                $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/warning.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{ $warningImageUrl }}" alt="warning icon" class="img-fluid">
                                <!-- <img src="{{ asset('assets/images/warning.svg') }}" alt="warning icon" class="img-fluid"> -->
                                <h4 class="mt-4 text-danger">Delete This Staff?</h4>
                                <p class="mt-3 line_height_30">
                                    This staff will move to Recently Deleted.<br>
                                    Are you sure you want to continue?
                                </p>
                                <!--Hidden Input to Store ID -->
                                <input type="hidden" id="delete_employee_id">
                            </div>
                            <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal" tabindex="-1">Cancel</button>
                                <button class="button primary_btn m-0 warning_button" type="submit" tabindex="-1">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!--department for inactive employes-->
<!-- <div class="modal fade" id="restore_employee_modal" tabindex="-1" aria-labelledby="restore_employee_modalLabel" aria-hidden="true">
    <div class="modal-dialog mt-5">
        <div class="modal-content">
            <form id="restore_employee_form">
                @csrf
                <input type="hidden" id="restore_employee_id" name="employee_id">

                <div class="modal-header">
                    <h5 class="modal-title" id="restore_employee_modalLabel">Assign Department</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <label for="restore_department_id" class="form-label">Select Department <span class="text-danger">*</span></label>
                    <select class="form-control input" name="department_id" id="restore_department_id" required>
                        <option value="" disabled selected>Select Department</option>
                        @foreach ($departments as $department)
                        <option value="{{ $department->id }}">{{ $department->name }}</option>
                        @endforeach
                    </select>
                    <div id="restore_feedback" class="mt-2 text-danger d-none"></div>
                </div>

                <div class="modal-footer gap-3">
                    <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="button primary_btn m-0" id="confirm_restore_employee_btn">Assign & Restore</button>
                </div>
            </form>
        </div>
    </div>
</div> -->
<div class="modal fade" id="restore_employee_modal" data-bs-keyboard="false" tabindex="-1" aria-labelledby="restore_employee_label" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                              @php
                                $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/warning.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{ $warningImageUrl }}" alt="warning icon" class="img-fluid">
                            <!-- <img src="{{ asset('assets/images/warning.svg') }}" alt="warning icon" class="img-fluid"> -->
                            <h4 class="mt-4 text-success">Restore Staff?</h4>
                            <p class="mt-3 line_height_30"> Selected employee will be restored.<br>
                                Are you sure you want to continue?</p>
                            <div id="restore_feedback" class="validation_text text-center mt-2" style="display: none;"></div>
                        </div>

                        <!-- Hidden input to store employee ID -->
                        <input type="hidden" id="restore_employee_id">

                        <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal" tabindex="-1">Cancel</button>
                            <button class="button primary_btn m-0" id="confirm_restore_employee_btn" type="submit" tabindex="-1">Restore</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<form id="bulkImport" action="{{ route('staffs.import') }}" method="POST" enctype="multipart/form-data">
    @csrf <!-- Include CSRF token for security -->
    <div class="modal fade" id="upload_files" data-bs-keyboard="false" tabindex="-1" aria-labelledby="button primary_btnLabel"
        aria-hidden="true">

        <div class="modal-body">
            <div class="container-fluid p-0">
                <div class="row">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title fs-5" id="upload_filesLabel">Bulk Upload</h3>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                                    tabindex="-1"></button>
                            </div>

                            <div class="modal-body">
                                <div class="container-fluid p-0">
                                    <div class="row">
                                        @if(Auth::user()->hasRole('Super Admin'))
                                        <div class="col-12 mb-3">
                                            <label for="employer_select" class="form-label">Select Employer</label>
                                            <select name="employer_id" id="employeer_name" class="form-select input form-control">
                                                <option value="">Select an Employeer</option>
                                                @foreach($employees as $employee)
                                                <option value="{{ $employee->id }}" {{ old('employer_id') == $employee->id ? 'selected' : '' }}>
                                                    {{ $employee->username }}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        @endif
                                        <div class="col-12 mb-3">
                                            <div class="file-upload-contain position-relative">
                                                <input id="multiplefileupload" name="file" type="file" accept=".csv, .xlsx, .PNG" multiple
                                                    tabindex="-1">
                                            </div>
                                        </div>
                                        <small class="alert alert-success" role="alert">
                                            You can download your manage staffs excel file <a href="{{ route('download.staff.excel') }}" class="text-primary ms-2" download>
                                                here
                                            </a>
                                        </small>
                                    </div>
                                </div>
                            </div>
                            <!-- <small class="text-muted d-block mt-1">
                                Don't have an excel file?
                                <a href="{{ route('download.staff.excel') }}" class="text-primary" download>
                                    Download Excel File
                                </a>
                            </small> -->

                            <div class="modal-footer gap-3">
                                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                                    tabindex="-1">Close</button>
                                <button class="button primary_btn m-0" type="submit" id="bulkSubmit" tabindex="-1">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
</form>



<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $(document).ready(function() {
        const userRole = "{{ auth()->user()->getRoleNames()->first() }}";
        $('#upload_files').on('hidden.bs.modal', function() {
            // Reset the form
            $('#bulkImport')[0].reset();

            // Clear any validation feedback
            $('.is-invalid').removeClass('is-invalid');
            $('.invalid-feedback').hide().text('');
        });
        $('#bulkImport').on('submit', function(e) {
            e.preventDefault();
            var employerId = null;
            if (userRole !== 'Employer') {
                employerId = $('select[id="employeer_name"]').val();
                // console.log(employerId);
                if (!employerId) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Employer Required',
                        text: 'Please select an employer!'
                    });
                    return false;
                }
            }
            var file = $('input[name="file"]')[0].files[0];

            if (!file) {
                Swal.fire({
                    icon: 'warning',
                    title: 'File Required',
                    text: 'Please select a file to upload!'
                });
                return false;
            }

            var allowedTypes = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel', 'text/csv'];
            if (!allowedTypes.includes(file.type)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Type',
                    text: 'Please upload only Excel (.xlsx) or CSV files!'
                });
                return false;
            }

            var formData = new FormData(this);

            // If user is an Employer, remove employer_id from form data
            if (userRole === 'Employer') {
                formData.delete('employer_id');
            }

            $.ajax({
                url: $(this).attr('action'),
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function() {
                    // Show loading spinner
                    Swal.fire({
                        title: 'Uploading...',
                        html: 'Please wait while we process your file',
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    // Disable submit button during upload
                    $('#bulkImport button[type="submit"]')
                        .prop('disabled', true)
                        .html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...');
                },
                success: function(response) {
                    // Close loading spinner
                    Swal.close();

                    // Scenario 1: All employees are new
                    if (response.import_details.new_employees_count > 0 &&
                        (!response.skipped_employees || response.skipped_employees.length === 0)) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Import Successful',
                            text: `${response.import_details.new_employees_count} new employees added.`,
                            width: '600px'
                        }).then(() => {
                            $('#upload_files').modal('hide');
                            $('#bulkImport')[0].reset();
                            location.reload();
                        });
                        return;
                    }

                    // Scenario 2: No new employees, but some were skipped or existed
                    if (response.import_details.new_employees_count === 0) {
                        // Prepare detailed skipped employees list
                        let skippedEmployeesList = response.skipped_employees.map(emp =>
                            `${emp.first_name} ${emp.last_name} - ${emp.reason}`
                        ).join('<br>');

                        // Prepare existing employees list
                        let existingEmployeesList = (response.existing_employees || []).map(emp =>
                            `${emp.first_name} ${emp.last_name}`
                        ).join('<br>');

                        Swal.fire({
                            icon: 'info',
                            title: 'Import Result',
                            html: `
                                <p>No new employees were added.</p>

                                ${response.skipped_employees && response.skipped_employees.length > 0 ? `
                                    <h5>Skipped Employees (${response.skipped_employees.length}):</h5>
                                    <div style="max-height: 300px; overflow-y: auto; text-align: left; padding: 10px; background-color: #f8f9fa; border-radius: 5px;">
                                        ${skippedEmployeesList}
                                    </div>
                                ` : ''}

                                ${response.existing_employees && response.existing_employees.length > 0 ? `
                                    <h5>Existing Employees (${response.existing_employees.length}):</h5>
                                    <div style="max-height: 300px; overflow-y: auto; text-align: left; padding: 10px; background-color: #f8f9fa; border-radius: 5px;">
                                        ${existingEmployeesList}
                                    </div>
                                ` : ''}
                            `,
                            width: '600px',
                            confirmButtonText: 'Close'
                        });
                        return;
                    }

                    // Scenario 3: Some new employees, some skipped
                    if (response.import_details.new_employees_count > 0 &&
                        response.skipped_employees && response.skipped_employees.length > 0) {

                        // Prepare skipped employees list with reasons
                        let skippedEmployeesList = response.skipped_employees.map(emp =>
                            `${emp.first_name} ${emp.last_name} - ${emp.reason}`
                        ).join('<br>');

                        Swal.fire({
                            icon: 'warning',
                            title: 'Partial Import',
                            html: `
                            <p>${response.import_details.new_employees_count} new employees added. ${response.skipped_employees.length} employees were skipped.</p>
                            <h5>Skipped Employees:</h5>
                            <div style="max-height: 300px; overflow-y: auto; text-align: left; padding: 10px; background-color: #f8f9fa; border-radius: 5px;">
                                ${skippedEmployeesList}
                            </div>
                        `,
                            width: '600px',
                            confirmButtonText: 'Close'
                        }).then(() => {
                            $('#upload_files').modal('hide');
                            $('#bulkImport')[0].reset();
                            location.reload();
                        });
                    }
                },
                error: function(xhr) {
                    // Close loading spinner
                    Swal.close();

                    // Parse error response
                    var response = xhr.responseJSON || {};

                    // Default error message
                    var errorMessage = response.message || 'An unexpected error occurred during import.';

                    // Prepare detailed error information
                    let errorDetails = '';

                    // Add skipped employees if available
                    if (response.skipped_employees && response.skipped_employees.length > 0) {
                        let skippedEmployeesList = response.skipped_employees.map(emp =>
                            `${emp.first_name} ${emp.last_name} - ${emp.reason}`
                        ).join('<br>');

                        errorDetails = `
                            <h5>Skipped Employees (${response.skipped_employees.length}):</h5>
                            <div style="max-height: 300px; overflow-y: auto; text-align: left; padding: 10px; background-color: #f8f9fa; border-radius: 5px;">
                                ${skippedEmployeesList}
                            </div>
                        `;
                    }
                    // Error message with optional details
                    Swal.fire({
                        icon: 'error',
                        title: 'Import Failed',
                        html: `
                            <p>${errorMessage}</p>
                            ${errorDetails}
                        `,
                        width: '600px'
                    });
                },
                complete: function() {
                    // Re-enable submit button
                    $('#bulkImport button[type="submit"]')
                        .prop('disabled', false)
                        .html('Submit');
                }
            });
        });
    });
</script>
<script>
    $(document).ready(function() {
        var allDepartments = @json($departments);

        var userRole = "{{ auth()->user()->getRoleNames()->first() }}";
        var userEmployerId = "{{ Auth::user()->id }}";

        // Function to populate departments
        function populateDepartments(employerId) {
            // Filter departments based on the employer
            var filteredDepartments = allDepartments.filter(function(department) {
                return department.employer_id == employerId;
            });

            // Clear existing options
            $('#department_id').empty();
            $('#department_id').append('<option value="" disabled selected>Select Department</option>');

            // Add filtered departments
            filteredDepartments.forEach(function(department) {
                $('#department_id').append(
                    `<option value="${department.id}">${department.name}</option>`
                );
            });
        }

        if (userRole === 'Employer') {
            // Populate departments for the logged-in employer
            populateDepartments(userEmployerId);

            // Hide employer selection dropdown
            $('#employer_name').closest('.col-xxl-4').hide();
        }

        // For Super Admin, keep existing change event
        $('#employer_name').on('change', function() {
            var selectedEmployerId = $(this).val();
            populateDepartments(selectedEmployerId);
        });

        // Optional: If you want to pre-select the user's current department
        @if(auth() -> user() -> department_id)
        $('#department_id').val("{{ auth()->user()->department_id }}");
        @endif
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const employerInput1 = document.getElementById('edit_employer');

        // Prevent attribute modification
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes' && mutation.attributeName === 'disabled') {
                    employerInput1.setAttribute('disabled', 'disabled');
                }
            });
        });

        // Start observing the input element
        observer.observe(employerInput1, {
            attributes: true,
            attributeFilter: ['disabled']
        });

        // Additional protection against removing disabled attribute
        Object.defineProperty(employerInput1, 'disabled', {
            configurable: false,
            writable: false,
            value: true
        });

        // Prevent direct manipulation via console
        employerInput1.addEventListener('keydown', function(e) {
            e.preventDefault();
        });
    });
</script>
<!-- to prevent changes in staff email on edit functionlity through user -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
    const staffEmailInput = document.getElementById('edit_email');

    // Prevent attribute modification
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.type === 'attributes' && mutation.attributeName === 'disabled') {
                staffEmailInput.setAttribute('disabled', 'disabled');
            }
        });
    });
        const staffEmailInput = document.getElementById('edit_email');

        // Prevent attribute modification
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes' && mutation.attributeName === 'disabled') {
                    staffEmailInput.setAttribute('disabled', 'disabled');
                }
            });
        });

    // Start observing the input element
    observer.observe(staffEmailInput, {
        attributes: true,
        attributeFilter: ['disabled']
    });
        // Start observing the input element
        observer.observe(staffEmailInput, {
            attributes: true,
            attributeFilter: ['disabled']
        });

        // Additional protection against removing disabled attribute
        Object.defineProperty(staffEmailInput, 'disabled', {
            configurable: false,
            writable: false,
            value: true
        });

        // Prevent direct manipulation via console
        staffEmailInput.addEventListener('keydown', function(e) {
            e.preventDefault();
        });
    });
</script>
@endsection

@extends('layouts.app')
@extends("employer.index")

@section("department")
<section class="main_card">
    {{-- <nav>
        <div class="nav nav-tabs d-flex justify-content-between" id="nav-tab" role="tablist">
            <div class="tabs_buttons">
            </div>
        </div>
    </nav> --}}
    <!-- Departments Tab -->
    <div class="container-fluid">
        <div class="row">
            <div class="title_section d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Department List</h5>
                <button class="button primary_btn" type="button" data-bs-toggle="modal" data-bs-target="#add_new_department">
                    Add New
                </button>
            </div>
        </div>
        <div class="row pt_24">
            <div class="col-12">
                <table id="depart_datatable" class="table table-striped datatable mt-2">
                    <thead>
                        <tr>
                            <th scope="col"></th>
                            <th scope="col">Dept Name</th>
                            <th scope="col">Dept Description</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Data for assigned departments -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<script>
    const userRole = "{{ auth()->user()->getRoleNames()->first() }}";
</script>
<!-- modal for add new Department -->
<div class="modal fade" id="add_new_department" data-bs-keyboard="false" tabindex="-1" aria-labelledby="add_new_departmentLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="addDepartmentForm" method="POST" class="w-100" action="{{ route('departments.store') }}">
                @csrf
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="add_new_departmentLabel">Add Department</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid p-0">
                        <div class="row">
                            <!-- Employeee Name -->
                            @if(Auth::user()->hasRole('Super Admin'))
                            <div class="col-12 mb-3 {{ $errors->has('employer_id') ? 'error_input' : ''}}">
                                <label for="employer_id" class="form-label">Select Employer <span class="text-danger">*</span></label>
                                <select name="employer_id" id="employeer_name" class="form-select form-control input">
                                    <option value="">Select an Employer</option>
                                    @foreach($employees as $employee)
                                    <option value="{{ $employee->id }}" {{ old('employer_id') == $employee->id ? 'selected' : '' }}>
                                        {{ $employee->username }}
                                    </option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback" id="employer_idFeedback"></div>
                            </div>
                            @endif
                            <!-- Department Name -->

                            <div class="col-12 mb-3 {{ $errors->has('name') ? 'error_input' : ''}}">
                                <label for="name" class="form-label">Department Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" id="department_name" class="form-control input" placeholder="Enter Department Name" value="{{ old('name') }}">
                                <div class="invalid-feedback" id="nameFeedback"></div>
                            </div>

                            <!-- Department Description -->
                            <div class="col-12 mb-3">
                                <label for="description" class="form-label">Department Description<span class="text-danger">*</label>
                                <textarea class="form-control input rounded-3" id="description" name="description" rows="3" placeholder="Optional description..." required></textarea>
                                <div class="invalid-feedback" id="descriptionFeedback"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer gap-3">
                    <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Close</button>
                    <button class="button primary_btn m-0" type="submit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Edit Department Modal -->

<div class="modal fade" id="edit_department_modal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form id="edit-department-form" method="POST" class="w-100">
            @csrf
            @method('PUT')
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-white">Edit Department</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <input type="hidden" name="id" id="edit_department_id">
 @if(Auth::user()->hasRole('Super Admin'))
                         <div class="mb-3">
                        <label for="edit_department_employer" class="form-label">Employer</label>
                        <input type="text" class="form-control input" id="edit_department_employer" disabled>
                    </div>
                    @endif
                    <div class="mb-3">
                        <label for="edit_department_name" class="form-label">Department Name <span class="text-danger">*</label>
                        <input type="text" class="form-control input" name="name" id="edit_department_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_department_description" class="form-label">Description<span class="text-danger">*</label>
                        <textarea class="form-control input rounded-3" name="description" id="edit_department_description" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="button primary_btn">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Modal Edit dept-->
<div class="modal fade" id="edit_user" data-bs-keyboard="false" tabindex="-1" aria-labelledby="edit_userLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <form action="#">
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="edit_userLabel">Edit Employer</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                        tabindex="-1"></button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid p-0">
                        <div class="row">
                            <h5 class="mb-3">Basic Details</h5>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="name2" class="form-label">Employer Name</label>
                                <input type="text" class="form-control input" id="name2" value="Romaguera LLC"
                                    required tabindex="-1">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="email" 2 class="form-label">Employer Email</label>
                                <input type="email" class="form-control input" id="email2"
                                    value="info@creativerhye.com" required tabindex="-1">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="phon2e" class="form-label">Employer Phone</label>
                                <input type="tel" class="form-control input" id="phone2" value="996-552-2300"
                                    required tabindex="-1">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="file2" class="form-label">Employer Logo</label>
                                <input type="file" class="form-control input" id="file2" tabindex="-1">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="timezone2" class="form-label">Timezone</label>
                                <input type="time" class="form-control input" id="timezone2" tabindex="-1">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="contact_person2" class="form-label">Contact Person</label>
                                <input type="text" class="form-control input" id="contact_person2" tabindex="-1"
                                    value="Natali Craig">
                            </div>
                            <div class="col-12">
                                <hr class="hr">
                            </div>
                            <h5 class="mb-3">Address Details</h5>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="address_12" class="form-label">Address line 1</label>
                                <input type="text" class="form-control input" id="address_12" tabindex="-1"
                                    value="134 A /12">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="address_22" class="form-label">Address line 2</label>
                                <input type="text" class="form-control input" id="address_22" tabindex="-1"
                                    value="main street 3">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="city2" class="form-label">City</label>
                                <input type="text" class="form-control input" id="city2" tabindex="-1"
                                    value="novorpnoye">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="state2" class="form-label">State</label>
                                <input type="text" class="form-control input" id="state2" tabindex="-1"
                                    value="Texas">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="zip2" class="form-label">Zip Code</label>
                                <input type="text" class="form-control input" id="zip2" tabindex="-1"
                                    value="123456">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer gap-3">
                    <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                        tabindex="-1">Close</button>
                    <button class="button primary_btn m-0" type="submit" tabindex="-1">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal delete dept-->
<div class="modal fade" id="delete_department" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete_departmentLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form action="#">
                <div class="modal-body">
                    <div class="container-fluid px-0 py-3">
                        <div class="row">
                            <div class="col-12 text-center">
                                  @php
                                $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/warning.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{   $warningImageUrl  }}" alt="warning icon" class="img-fluid">
                                <h4 class="mt-4 text-danger">Delete This Department?</h4>
                                <p class="mt-3 line_height_30"> This will unassign the department and move it to the Inactive Departments list.</p>
                            </div>
                            <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                                    tabindex="-1">Cancel</button>
                                <button class="button primary_btn m-0 warning_button" type="submit"
                                    tabindex="-1">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Restore dept-->
<div class="modal fade" id="restore_department" data-bs-keyboard="false" tabindex="-1" aria-labelledby="restore_userLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                            <img src="assets/images/warning.svg" alt="warning icon" class="img-fluid">
                            <h4 class="mt-4 text-success">Restore This Department?</h4>
                            <p class="mt-3 line_height_30"> This Department will be restored,<br>
                                Are you sure you want to continue?</p>
                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                                tabindex="-1">Cancel</button>
                            <button class="button primary_btn m-0" type="submit" tabindex="-1">Restore</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- to prevent changes in employer name on edit functionlity through user -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
    const employerInput = document.getElementById('edit_department_employer');

    // Prevent attribute modification
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.type === 'attributes' && mutation.attributeName === 'disabled') {
                employerInput.setAttribute('disabled', 'disabled');
            }
        });
    });

    // Start observing the input element
    observer.observe(employerInput, {
        attributes: true,
        attributeFilter: ['disabled']
    });

    // Additional protection against removing disabled attribute
    Object.defineProperty(employerInput, 'disabled', {
        configurable: false,
        writable: false,
        value: true
    });

    // Prevent direct manipulation via console
    employerInput.addEventListener('keydown', function(e) {
        e.preventDefault();
    });
});
</script>
@endsection

@extends('superAdmin.auth.layout')
@section('title', 'Forgot-Password')
@section('content')
<div class="col-xxl-7 col-xl-7 col-lg-6 col-md-12 col-12 d-flex align-items-center justify-content-center h-100">
    <div class="form_login text-center col-xxl-6 col-xl-7 col-lg-10 col-md-8 col-12">
        <img src="assets/images/wellify-logo.svg" alt="" class="logo-img text-center">
        <h2 class="text-center text-white">Forgot Password</h2>
        <p class="login_subtitle mb_30">Please enter your email address,<br>
            and we will send you an OTP to reset your password.</p>

        <form action="{{ route('send.otp') }}" method="POST" onsubmit="saveEmail()">
            @csrf
            <div class="mb_30">
                <div class="position-relative">
                    <input type="email"
                        name="email"
                        class="form-control @error('email') error_input @enderror"
                        id="loginEmail"
                        placeholder="Email"
                        value="{{ old('email') }}"
                        required>
                    <div class="input_icons">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M8 12C8 13.0609 8.42143 14.0783 9.17157 14.8284C9.92172 15.5786 10.9391 16 12 16C13.0609 16 14.0783 15.5786 14.8284 14.8284C15.5786 14.0783 16 13.0609 16 12C16 10.9391 15.5786 9.92172 14.8284 9.17157C14.0783 8.42143 13.0609 8 12 8C10.9391 8 9.92172 8.42143 9.17157 9.17157C8.42143 9.92172 8 10.9391 8 12Z"
                                stroke="#999999" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                            <path
                                d="M16 11.9998V13.4998C16 14.1629 16.2634 14.7988 16.7322 15.2676C17.2011 15.7365 17.837 15.9998 18.5 15.9998C19.163 15.9998 19.7989 15.7365 20.2678 15.2676C20.7366 14.7988 21 14.1629 21 13.4998V11.9998C21.0025 10.0659 20.382 8.18269 19.2304 6.62904C18.0788 5.07539 16.4574 3.934 14.6064 3.37395C12.7554 2.81389 10.7732 2.86497 8.95343 3.51961C7.13371 4.17425 5.57324 5.39763 4.50321 7.00852C3.43317 8.61942 2.91047 10.5321 3.01255 12.4633C3.11463 14.3945 3.83605 16.2415 5.06995 17.7306C6.30385 19.2197 7.98459 20.2718 9.86319 20.7309C11.7418 21.1901 13.7183 21.0319 15.5 20.2798"
                                stroke="#999999" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </div>
                </div>

                @error('email')
                    <p class="validation_text">{{ $message }}</p>
                @enderror
            </div>

            <div class="d-grid gap-2">
                <button class="btn primary_btn" type="submit">Send OTP</button>
            </div>
        </form>

        <a href="{{ route('login') }}" class="a_login">Back to Login</a>
    </div>
</div>

<!-- Include jQuery (if not already included in your layout) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    function saveEmail() {
        const email = document.getElementById('loginEmail').value;
        localStorage.setItem('userEmail', email);
    }
</script>
@endsection

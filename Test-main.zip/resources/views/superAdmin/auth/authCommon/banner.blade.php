<!-- Image with text section -->
<div class="col-xxl-5 col-xl-5 col-lg-6 col-md-12 col-12 login_banner h-100">
    <div class="glass_box col-xxl-10 col-xl-10 col-lg-10">
        <div class="text-section">
            <h1 class="text-center">Your Virtual Garden</h1>
            <h5 class="text-center">Nurture your seeds by gently planting them, and add a sprinkle of water
                droplets to help them thrive</h5>
        </div>
    </div>
</div>
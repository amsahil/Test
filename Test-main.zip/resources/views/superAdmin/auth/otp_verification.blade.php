@extends('superAdmin.auth.layout')
@section('title', 'OTP-Verification')
@section('content')
    <!-- form section -->
    <div class="col-xxl-7 col-xl-7 col-lg-6 col-md-12 col-12 d-flex align-items-center justify-content-center h-100">
        <div class="form_login text-center col-xxl-5 col-xl-6 col-lg-10 col-md-8 col-12">
            <img src="assets/images/wellify-logo.svg" alt="" class="logo-img text-center">
            <h2 class="text-center text-white">Enter OTP</h2>
            <p class="login_subtitle mb_30">Please enter the OTP we sent you on your email address,<br> to continue resetting your password.</p>
            <!-- <p>Email: <strong>{{ session('email') }}</strong></p> Show the email here -->
            <!-- <form method="POST" action="{{ route('verify.otp') }}">
                @csrf
                <div class="mb_30">
                    <div class="position-relative d-flex otp_input @error('otp') error_input @enderror">
                        <input type="tel" name="otp[]" class="form-control" required maxlength="1">
                        <input type="tel" name="otp[]" class="form-control" required maxlength="1">
                        <input type="tel" name="otp[]" class="form-control" required maxlength="1">
                        <input type="tel" name="otp[]" class="form-control" required maxlength="1">
                    </div>
                </div>
                <div class="d-grid gap-2">
                    <button class="btn primary_btn" type="submit">Submit OTP</button>
                </div>
                  @error('otp')
                    <p class="validation_text">{{ $message }}</p>
                @enderror
                <p class="resend_otp">
                    Didn't receive a code?
                    <a href="#" id="resend-otp-link">Send again</a>
                    <span id="countdown" data-start="{{ session('last_otp_sent_at') ? 1 : 0 }}"></span>
                </p>
               
            </form> -->
            <form method="POST" action="{{ route('verify.otp') }}">
                @csrf
                <div class="mb_30">
                    <div class="position-relative d-flex otp_input @error('otp') error_input @enderror">
                        <input type="tel" name="otp[]" class="form-control otp-field" required maxlength="1">
                        <input type="tel" name="otp[]" class="form-control otp-field" required maxlength="1">
                        <input type="tel" name="otp[]" class="form-control otp-field" required maxlength="1">
                        <input type="tel" name="otp[]" class="form-control otp-field" required maxlength="1">
                    </div>
                </div>
                <div class="d-grid gap-2">
                    <button class="btn primary_btn" type="submit">Submit OTP</button>
                </div>
                @error('otp')
                    <p class="validation_text">{{ $message }}</p>
                @enderror
            </form>
            <a href="{{ route('login') }}" class="a_login">Back to Login</a>
        </div>
          
    </div>
    <script>
    const resendOtpUrl = "{{ route('resend.otp') }}";
    const csrfToken = "{{ csrf_token() }}";
    </script>
    <script src="{{ asset('assets/js/bootstrap.bundle.js') }}"></script>
    <script src="{{ asset('assets/js/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/js/script.js') }}"></script>

@endsection

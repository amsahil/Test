@extends('superAdmin.auth.layout')
@section('title', 'Reset Password')
@section('content')
<!-- Reset Password Form Section -->
<div class="col-xxl-7 col-xl-7 col-lg-6 col-md-12 col-12 d-flex align-items-center justify-content-center h-100">
    <div class="form_login text-center col-xxl-6 col-xl-7 col-lg-10 col-md-8 col-12">
        @php
        $wellifyLogoUrl = Storage::disk('s3')->temporaryUrl(
        'staging/public/wellify-logo.svg',
        now()->addHour()
        );
        @endphp
        <img src="{{$wellifyLogoUrl }}" alt="Wellify Logo" class="logo-img text-center">

        <h2 class="text-center text-white">Reset Password</h2>
        <p class="login_subtitle mb_30">Please enter your new password and confirm it below.</p>

        <!-- Reset Password Form -->
        <form method="POST" action="{{ route('reset.password.submit') }}">
            @csrf

            <!-- Hidden email field -->
            <input type="hidden" name="email" value="{{ old('email', request('email')) }}">

            <div class="mb_30 position-relative">
                <input type="password" name="password" id="password" class="form-control @error('password') is-invalid @enderror" placeholder="New Password" required>
                <div class="input_icons view_password">
                    <span>
                        @php
                        $eyeImageUrl = Storage::disk('s3')->temporaryUrl(
                        'staging/public/eye_view.svg',
                        now()->addHour() // Link expires in 1 hour
                        );
                        @endphp
                        <img src="{{ $eyeImageUrl }}" alt="Show" id="eye_view1">
                        @php
                        $eyeSlashImageUrl = Storage::disk('s3')->temporaryUrl(
                        'staging/public/eye_slash.svg',
                        now()->addHour() // Link expires in 1 hour
                        );
                        @endphp
                        <img src="{{ $eyeSlashImageUrl}}" alt="Hide" id="eye_slash1" class="d-none">
                    </span>
                </div>
                @error('password')
                <small class="text-danger mt-1 d-block">
                    @if(str_contains($message, 'regex'))
                    Password: 8 chars, upper, lower, digit & special char.
                    @else
                    {{ $message }}
                    @endif
                </small>
                @enderror
            </div>

            <div class="mb_30 position-relative">
                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control @error('password_confirmation') is-invalid @enderror" placeholder="Confirm Password" required>
                <div class="input_icons view_password">
                    <span>
                        @php
                        $eyeImageUrl = Storage::disk('s3')->temporaryUrl(
                        'staging/public/eye_view.svg',
                        now()->addHour() // Link expires in 1 hour
                        );
                        @endphp
                        <img src="{{ $eyeImageUrl }}" alt="Show" id="eye_view2">
                        @php
                        $eyeSlashImageUrl = Storage::disk('s3')->temporaryUrl(
                        'staging/public/eye_slash.svg',
                        now()->addHour() // Link expires in 1 hour
                        );
                        @endphp
                        <img src="{{$eyeSlashImageUrl}}" alt="Hide" id="eye_slash2" class="d-none">
                    </span>
                </div>
            </div>



            <div class="d-grid gap-2">
                <button class="btn primary_btn" type="submit">Reset Password</button>
            </div>
        </form>

        <a href="{{ route('login') }}" class="a_login mt-3 d-block">Back to Login</a>
    </div>
</div>

<!-- Scripts -->
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>

<script src="{{ asset('assets/js/bootstrap.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.bundle.js') }}"></script>
<script src="{{ asset('assets/js/script.js') }}"></script>


<script>
    //   var $eye1 = $('#eye_view1');
    //     var $eyeslash1 = $('#eye_slash1');
    //     var $passInput1 = $('#password');

    //     if ($eye1.length && $eyeslash1.length && $passInput1.length) {
    //         $eye1.on('click', function () {
    //             $eye1.addClass('d-none');
    //             $eyeslash1.removeClass('d-none');
    //             $passInput1.attr('type', 'text');
    //         });

    //         $eyeslash1.on('click', function () {
    //             $eye1.removeClass('d-none');
    //             $eyeslash1.addClass('d-none');
    //             $passInput1.attr('type', 'password');
    //         });

    //     }
    //         var $eye2 = $('#eye_view2');
    //         var $eyeslash2 = $('#eye_slash2');
    //         var $passInput2 = $('#password_confirmation');

    //         if ($eye2.length && $eyeslash2.length && $passInput2.length) {
    //             $eye2.on('click', function () {
    //                 $eye2.addClass('d-none');
    //                 $eyeslash2.removeClass('d-none');
    //                 $passInput2.attr('type', 'text');
    //             });

    //             $eyeslash2.on('click', function () {
    //                 $eye2.removeClass('d-none');
    //                 $eyeslash2.addClass('d-none');
    //                 $passInput2.attr('type', 'password');
    //             });
    //         }

    $(document).ready(function() {
        // Toggle visibility for password fields
        setupPasswordToggle('eye_view1', 'eye_slash1', 'password');
        setupPasswordToggle('eye_view2', 'eye_slash2', 'password_confirmation');

        // Remove is-invalid class and error message on input
        $('#password, #password_confirmation').on('input', function() {
            const $input = $(this);

            // Remove red border
            $input.removeClass('is-invalid');

            // Remove the related <small class="text-danger ..."> element
            $input.nextAll('small.text-danger').first().remove();
        });
    });

    // Helper function for show/hide password
    function setupPasswordToggle(viewId, slashId, inputId) {
        const $eye = $('#' + viewId);
        const $eyeSlash = $('#' + slashId);
        const $input = $('#' + inputId);

        if ($eye.length && $eyeSlash.length && $input.length) {
            $eye.on('click', function() {
                $eye.addClass('d-none');
                $eyeSlash.removeClass('d-none');
                $input.attr('type', 'text');
            });

            $eyeSlash.on('click', function() {
                $eye.removeClass('d-none');
                $eyeSlash.addClass('d-none');
                $input.attr('type', 'password');
            });
        }
    }
</script>




@endsection
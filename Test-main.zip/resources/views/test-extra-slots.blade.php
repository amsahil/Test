<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Test Extra Slots</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <!-- Bootstrap 5 Bundle JS (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="p-5">

    <button class="btn btn-primary" id="launch-users-btn">Simulate Slot Check</button>

    <!-- Modal -->
    <div class="modal fade" id="extraSlotsModal" tabindex="-1" aria-labelledby="extraSlotsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="extraSlotsForm">
                    <div class="modal-body text-center">
                        <h5>Pay for Additional Slots</h5>
                        <p>
                            <strong>Total Uploaded:</strong> <span id="totalUploadedDisplay">15</span><br>
                            <strong>Paid Slots:</strong> <span id="paidSlotsDisplay">10</span><br>
                            <strong>Extra Needed:</strong> <span id="remainingSlotsCountDisplay" class="text-danger fw-bold">5</span>
                        </p>
                        <p class="fw-bold text-primary">You will pay $<span id="paymentAmountDisplay">5</span></p>
                        <button type="submit" class="btn btn-success w-100 mt-3" id="payNowBtn">Pay Now</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // CSRF token for AJAX
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Simulate button click to show modal
        $('#launch-users-btn').on('click', function () {
            // In real use, call your /check-launch-quota route
            $('#extraSlotsModal').modal('show');
        });

        // Form submit handler
        $('#extraSlotsForm').on('submit', function (e) {
            e.preventDefault();

            let slots = parseInt($('#remainingSlotsCountDisplay').text().trim());
            if (!slots || slots <= 0) {
                alert('Invalid slot count.');
                return;
            }

            $('#payNowBtn').text('Redirecting...').prop('disabled', true);

            $.ajax({
                url: "{{ route('employer.request.extra.slots') }}",
                method: 'POST',
                data: { additional_slots: slots },
                success: function (res) {
                    console.log('Stripe session response:', res);
                    if (res.session_url) {
                        window.location.href = res.session_url;
                    } else {
                        alert('Session URL not returned.');
                        $('#payNowBtn').text('Pay Now').prop('disabled', false);
                    }
                },
                error: function (xhr) {
                    alert('AJAX error: ' + xhr.status);
                    console.log(xhr.responseText);
                    $('#payNowBtn').text('Pay Now').prop('disabled', false);
                }
            });
        });
    </script>
</body>
</html>

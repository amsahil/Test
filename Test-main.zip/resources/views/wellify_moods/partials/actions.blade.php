<div class="d-flex gap-2">
    <button class="btn btn-sm btn-primary">Edit</button>
    <button class="btn btn-sm btn-danger">Delete</button>
</div>

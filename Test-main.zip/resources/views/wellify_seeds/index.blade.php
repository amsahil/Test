@extends('layouts.app')
@include('common.header')
@include('common.sidebar')


    <section class="main_card">
        <div class="container-fluid">
            <div class="row">
                <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                    <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Manage Seeds</h5>
                    <button class="button primary_btn" type="button" data-bs-toggle="modal" data-bs-target="#add_new">
                        Add New
                    </button>
                </div>
            </div>
            <div class="row pt_24">
                <div class="col-12">
                    <table id="wellifySeedsTable" class="table table-striped datatable">
                        <thead>
                            <tr>
                                <th scope="col"></th>
                                <th scope="col">ID</th>
                                <th scope="col">Seed Name</th>
                                <th scope="col">Image</th>
                                <th scope="col">Description</th>
                                <th scope="col">Groth Stages</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

    <!-- Add Seed Modal -->
    <div class="modal fade" id="add_new" data-bs-keyboard="false" tabindex="-1" aria-labelledby="add_newLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
                </div>
                <form id="addSeedForm" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">
                        <div class="container-fluid p-0">
                            <div class="row">
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label for="seed_name" class="form-label">Seed Name</label>
                                    <input type="text" class="form-control input" id="seed_name" name="seed_name" placeholder="Enter seed name" >
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label for="image" class="form-label">Seed Image</label>
                                    <input type="file" class="form-control input" id="image" name="image" accept=".svg, image/svg+xml" >
                                    <div id="imagePreview" class="mt-2"></div>
                                </div>
                                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-12 mb-3">
                                    <label for="seed_description" class="form-label">Description</label>
                                    <textarea class="form-control input rounded-3" placeholder="Enter Description" id="seed_description" name="seed_description" rows="2" ></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal" tabindex="-1">Close</button>
                        <button type="submit" class="button primary_btn m-0" id="submitSeedBtn">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Edit Seed -->
    <div class="modal fade" id="edit_seed" data-bs-keyboard="false" tabindex="-1" aria-labelledby="edit_seedLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <form id="editSeedForm" method="POST" enctype="multipart/form-data">
                    <div class="modal-header">
                        <h3 class="modal-title fs-5">Edit Seed</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" class="form-control input" id="edit_seed_id" name="id">
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label class="form-label">Seed Name</label>
                                <input type="text" class="form-control input" id="edit_name" name="seed_name" >
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Seed Image (SVG only)</label>
                                <input type="file" class="form-control input" id="edit_image" name="image" accept=".svg,image/svg+xml">
                                <div id="edit_imagePreview" class="mt-2"></div>
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Description</label>
                                <textarea class="form-control input rounded-3" id="edit_description" name="seed_description" rows="3" ></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="button primary_btn m-0" id="updateSeedBtn">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Delete Seed -->
    <div class="modal fade" id="delete_seed" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete_seedLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body delete">
                    <div class="container-fluid px-0 py-3">
                        <div class="row">
                            <div class="col-12 text-center">
                                  @php
                                $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/warning.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{ $warningImageUrl }}" alt="warning icon" class="img-fluid">
                                <h4 class="mt-4 text-danger">Delete This Seed?</h4>
                                <p class="mt-3 line_height_30">This Seed will be deleted.<br>
                                    Are you sure you want to continue?</p>
                            </div>
                            <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button>
                                <button id="confirmDelete" class="button primary_btn m-0 warning_button" type="button">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
    $(document).ready(function() {
        $('#wellifySeedsTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('wellify-seeds.index') }}",
            columns: [
                {data: 'dummy', name: 'dummy', orderable: false, searchable: false},
                {data: 'id', name: 'id'},
                {data: 'seed_name', name: 'seed_name'},
                {data: 'image', name: 'image', orderable: false, searchable: false},
                {data: 'seed_description', name: 'seed_description'},
                {data: 'growth_stages', name: 'growth_stages', orderable: false, searchable: false},
                {data: 'status', name: 'status', orderable: false, searchable: false},
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ],
            order: [[1, 'asc']]
        });
        $('#wellifySeedsTable').on('change', '.flipswitch-cb', function() {
            var seedId = $(this).attr('id').replace('fs-', '');
            var isChecked = $(this).is(':checked');

            $.ajax({
                url: "{{ route('wellify-seeds.toggle-status', '') }}/" + seedId,
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    status: isChecked ? 1 : 0
                },
                success: function(response) {
                    location.reload();
                    if (!response.success) {
                        // Revert the toggle if the request failed
                        $('#fs-'+seedId).prop('checked', !isChecked);
                        toastr.error('Failed to update status');
                    }
                },
                error: function() {
                    // Revert the toggle on error
                    $('#fs-'+seedId).prop('checked', !isChecked);
                    toastr.error('Error updating status');
                }
            });
        });
        let currentSeedId = null;

        // Handle delete icon click - show modal
        $(document).on('click', '.delete_icon', function() {
            currentSeedId = $(this).data('id');
            $('#delete_seed').modal('show');
        });

        // Handle confirm delete button click
        $('#confirmDelete').click(function() {
            if (!currentSeedId) return;

            $.ajax({
                url: `/wellify-seeds/${currentSeedId}`,
                type: 'DELETE',
                data: {
                    _token: "{{ csrf_token() }}"
                },
                beforeSend: function() {
                    $('#confirmDelete').prop('disabled', true).html();
                },
                complete: function() {
                    $('#confirmDelete').prop('disabled', false).text('Delete');
                },
                success: function(response) {
                    $('#delete_seed').modal('hide');
                    if (response.success) {
                        swal(
                            "success", 
                            "Seed deleted successfully", 
                            "success"
                        );
                        $('#wellifySeedsTable').DataTable().ajax.reload();
                        window.location.reload();
                        // toastr.success('Seed deleted successfully');
                    } else {
                        toastr.error(response.message || 'Failed to delete seed');
                    }
                },
                error: function() {
                    $('#delete_seed').modal('hide');
                    toastr.error('Error deleting seed');
                }
            });
        });

        // Reset currentSeedId when modal hides
        $('#delete_seed').on('hidden.bs.modal', function() {
            currentSeedId = null;
        });

        // Image preview handler
        $('#image').change(function () {
            const file = this.files[0];
            if (file) {
                if (file.type !== 'image/svg+xml') {
                    toastr.error('Only SVG images are allowed.');
                    $('#image').val('');
                    $('#imagePreview').empty();
                    return;
                }

                const reader = new FileReader();
                reader.onload = function (e) {
                    $('#imagePreview').html('<img src="' + e.target.result + '" class="img-thumbnail" width="100">');
                };
                reader.readAsDataURL(file);
            }
        });


        $('#seed_name').on('input', function() {
            var val = $(this).val();
            var clean = val.replace(/[^a-zA-Z0-9 ]/g, '');
            if (clean.length > 35) {
                clean = clean.substring(0, 35);
            }
            if (val !== clean) {
                $(this).val(clean);
            }
        });

        // Handle form submission
        // $('#addSeedForm').submit(function (e) {
        //     e.preventDefault();

        //     var formData = new FormData(this);
        //     var submitBtn = $('#submitSeedBtn');

        //     if (!$('#seed_name').val() || !$('#seed_description').val() || !$('#image')[0].files[0]) {
        //         toastr.error('Please fill all required fields');
        //         return false;
        //     }

        //     const file = $('#image')[0].files[0];
        //     if (file && file.type !== 'image/svg+xml') {
        //         toastr.error('Only SVG images are allowed.');
        //         return false;
        //     }

        //     $.ajax({
        //         url: "{{ route('wellify-seeds.store') }}",
        //         type: "POST",
        //         data: formData,
        //         processData: false,
        //         contentType: false,
        //         beforeSend: function () {
        //             submitBtn.prop('disabled', true).html();
        //         },
        //         complete: function () {
        //             submitBtn.prop('disabled', false).text('Submit');
        //         },
        //         success: function (response) {
        //             location.reload();
        //             if (response.success) {
        //                 // location.reload();
        //                 $('#add_new').modal('hide');
        //                 $('#addSeedForm')[0].reset();
        //                 location.reload();
        //                 $('#imagePreview').empty();
        //                 $('#wellifySeedsTable').DataTable().ajax.reload();
        //                 toastr.success(response.message);
        //             } else {
        //                 toastr.error(response.message);
        //             }
        //         },
        //         error: function (xhr) {
        //             var errors = xhr.responseJSON.errors;
        //             $.each(errors, function (key, value) {
        //                 toastr.error(value[0]);
        //             });
        //         }
        //     });
        // });

        $('#addSeedForm').submit(function(e) {
            e.preventDefault();

            var seedName = $('#seed_name').val().trim();
            var description = $('#seed_description').val().trim();
            var fileInput = $('#image')[0];
            var file = fileInput.files[0];

            // Validate seed name
            if (!seedName) {
                swal("Error", "Seed name cannot be empty.", "error");
                return false;
            }
            if (seedName.length > 35) {
                swal("Error", "Seed name cannot be longer than 35 characters.", "error");
                return false;
            }
            // Already restricted input, but double-check no special chars
            if (/[^a-zA-Z0-9 ]/.test(seedName)) {
                swal("Error", "Seed name can only contain letters, numbers and spaces.", "error");
                return false;
            }
            // Validate description
            if (!description) {
                swal("Error", "Description cannot be empty.", "error");
                return false;
            }
            // Validate image
            if (!file) {
                swal("Error", "Please select an SVG image.", "error");
                return false;
            }
            var ext = file.name.split('.').pop().toLowerCase();
            if (ext !== 'svg') {
                swal("Error", "Only SVG images are allowed.", "error");
                return false;
            }

            var formData = new FormData(this);
            var submitBtn = $('#submitSeedBtn');

            $.ajax({
                url: "{{ route('wellify-seeds.store') }}",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function() {
                    submitBtn.prop('disabled', true);
                },
                complete: function() {
                    submitBtn.prop('disabled', false).text('Submit');
                },
                success: function(response) {
                    if (response.success) {
                        $('#add_new').modal('hide');
                        $('#addSeedForm')[0].reset();
                        $('#imagePreview').empty();
                        $('#wellifySeedsTable').DataTable().ajax.reload();
                        swal("Success", response.message, "success");
                        window.location.reload();
                    } else {
                        swal("Error", response.message, "error");
                    }
                },
                error: function(xhr) {
                    var errors = xhr.responseJSON.errors;
                    $.each(errors, function(key, value) {
                        swal("Error", value[0], "error");
                    });
                }
            });

        });



        // Reset form when modal closes
        $('#add_new').on('hidden.bs.modal', function () {
            $('#addSeedForm')[0].reset();
            $('#imagePreview').empty();
        });

        // Open modal with data
       $(document).on('click', '.seed_edit_icon', function () {
            var seedId = $(this).data('id');

            $.ajax({
                url: '/wellify-seeds/' + seedId + '/edit',
                type: 'GET',
                success: function (response) {

                    // Fill modal inputs with seed data
                    $('#edit_seed_id').val(response.id);
                    $('#edit_name').val(response.seed_name);
                    $('#edit_description').val(response.seed_description);

                    // Clear current image preview before loading new one
                    $('#edit_imagePreview').empty();

                    // Now fetch the presigned S3 URL for the seed image
                    $.get('/wellify-seeds/' + seedId + '/image-url', function (urlResponse) {
                        if (urlResponse.success) {
                            $('#edit_imagePreview').html(`
                                <label class="form-label">Current Image:</label>
                                <img src="${urlResponse.url}" class="img-thumbnail" width="100" alt="Seed Image">
                            `);
                        }
                    });

                    // Show the modal
                    $('#edit_seed').modal('show');
                },
                error: function(xhr, status, error) {
                    alert('Failed to fetch seed details. Please try again.');
                    console.error('Error fetching seed:', error);
                }
            });
        });




        // Preview new image
        // $('#edit_image').change(function () {
        //     const file = this.files[0];
        //     if (file && file.type !== 'image/svg+xml') {
        //         toastr.error('Only SVG images are allowed.');
        //         $(this).val('');
        //         $('#edit_imagePreview').empty();
        //         return;
        //     }

        //     const reader = new FileReader();
        //     reader.onload = function (e) {
        //         $('#edit_imagePreview').html('<img src="' + e.target.result + '" class="img-thumbnail" width="100">');
        //     };
        //     reader.readAsDataURL(file);
        // });

        $('#edit_name').on('input', function() {
            var val = $(this).val();
            var clean = val.replace(/[^a-zA-Z0-9 ]/g, '');
            if (clean.length > 35) {
                clean = clean.substring(0, 35);
            }
            if (val !== clean) {
                $(this).val(clean);
            }
        });

        $('#edit_image').on('change', function () {
            const file = this.files[0];

            if (!file) {
                $('#edit_imagePreview').empty();
                return;
            }
            if (file.type !== 'image/svg+xml') {
                toastr.error('Only SVG images are allowed.');
                $(this).val('');
                $('#edit_imagePreview').empty();
                return;
            }

            const reader = new FileReader();

            reader.onload = function (e) {
                $('#edit_imagePreview').html(`<img src="${e.target.result}" class="img-thumbnail" width="100" alt="Preview Image">`);
            };

            reader.readAsDataURL(file);
        });


        // Submit Edit Form
        // $('#editSeedForm').submit(function (e) {
        //     e.preventDefault();

        //     var formData = new FormData(this);
        //     var id = $('#edit_seed_id').val();

        //     $.ajax({
        //         url: '/wellify-seeds/' + id,
        //         type: 'POST',
        //         data: formData,
        //         processData: false,
        //         contentType: false,
        //         headers: {
        //             'X-HTTP-Method-Override': 'PUT'
        //         },
        //         beforeSend: function () {
        //             $('#updateSeedBtn').prop('disabled', true).text('Updating...');
        //         },
        //         success: function (response) {
        //             $('#edit_seed').modal('hide');
        //             $('.modal-backdrop').remove();
        //             $('body').removeClass('modal-open');
        //             $('body').css('padding-right', '');

        //             $('#editSeedForm')[0].reset();
        //             $('#edit_imagePreview').empty();
        //             $('#wellifySeedsTable').DataTable().ajax.reload(null, false);
        //         },
        //         error: function (xhr) {
        //             var errors = xhr.responseJSON.errors;
        //             $.each(errors, function (key, value) {
        //                 toastr.error(value[0]);
        //             });
        //         },
        //         complete: function () {
        //             $('#updateSeedBtn').prop('disabled', false).text('Update');
        //         }
        //     });
        // });

        $('#editSeedForm').submit(function (e) {
            e.preventDefault();

            // Validation
            var seedName = $('#edit_name').val().trim();
            var description = $('#edit_description').val().trim();
            var fileInput = $('#edit_image')[0];
            var file = fileInput.files[0];

            // Seed name required
            if (!seedName) {
                swal("Error", "Seed name cannot be empty.", "error");
                return false;
            }

            // Seed name max 35 chars
            if (seedName.length > 35) {
                swal("Error", "Seed name cannot be longer than 35 characters.", "error");
                return false;
            }

            // Seed name no special chars (only letters, numbers, spaces)
            if (/[^a-zA-Z0-9 ]/.test(seedName)) {
                swal("Error", "Seed name can only contain letters, numbers, and spaces.", "error");
                return false;
            }

            // Description required
            if (!description) {
                swal("Error", "Description cannot be empty.", "error");
                return false;
            }

            // Image validation if a file is chosen
            if (file) {
                var ext = file.name.split('.').pop().toLowerCase();
                if (ext !== 'svg') {
                    swal("Error", "Only SVG images are allowed.", "error");
                    return false;
                }
            }

            // If validation passes, continue with AJAX submit

            var formData = new FormData(this);
            var id = $('#edit_seed_id').val();

            $.ajax({
                url: '/wellify-seeds/' + id,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-HTTP-Method-Override': 'PUT'
                },
                beforeSend: function () {
                    $('#updateSeedBtn').prop('disabled', true).text('Updating...');
                },
                success: function (response) {
                    $('#edit_seed').modal('hide');
                    $('.modal-backdrop').remove();
                    $('body').removeClass('modal-open');
                    $('body').css('padding-right', '');

                    $('#editSeedForm')[0].reset();
                    $('#edit_imagePreview').empty();
                    $('#wellifySeedsTable').DataTable().ajax.reload(null, false);

                    swal("Success", "Seed updated successfully.", "success");
                },
                error: function (xhr) {
                    var errors = xhr.responseJSON.errors;
                    $.each(errors, function (key, value) {
                        toastr.error(value[0]);
                    });
                },
                complete: function () {
                    $('#updateSeedBtn').prop('disabled', false).text('Update');
                }
            });
        });


    });
</script>


@extends('layouts.app')
@include('common.header')
@include('common.sidebar')

        <section class="main_card">
            <div class="container-fluid">
                <div class="row">
                    <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                        <h5 id="seed-name-header" class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3"></h5>
                        <!-- <button id="addNewBtn" class="button primary_btn" type="button" data-bs-toggle="modal" data-bs-target="#add_new">
                            Add New
                        </button> -->
                    </div>
                </div>
                <div class="row pt_24">
                    <div class="col-12">
                        <table id="growthStagesTable" class="table table-striped datatable mt-2 order-column nowrap ">
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col">Growth Stage Name</th>
                                    <th scope="col">Stage Image</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    <!---------------------------------------------- Add seeds ------------------------------------------------------------->

    <form id="addGrowthStageForm" method="POST" action="{{ route('growth-stage-media.store') }}" enctype="multipart/form-data">
        @csrf
        <div class="modal fade" id="add_new" data-bs-keyboard="false" tabindex="-1" aria-labelledby="add_newLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-scrollable modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title fs-5" id="add_newLabel">Add Seed Growth</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                            tabindex="-1"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container-fluid p-0">
                            <div class="row">
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label for="growth_stage_id" class="form-label">Growth Stage</label>
                                    <select class="form-select form-control input" id="growth_stage_id" name="growth_stage_id" required tabindex="-1">
                                        <!-- options loaded via JS -->
                                    </select>
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label for="media" class="form-label">Stage Image</label>
                                    <input type="file" class="form-control input" id="media" name="media" required tabindex="-1" accept="image/*">
                                </div>
                                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-12 mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control input rounded-3" id="description" name="description" rows="3" placeholder="Optional description..."></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer gap-3">
                        <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                            tabindex="-1">Close</button>
                        <button class="button primary_btn m-0" type="submit" tabindex="-1">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <div class="modal fade" id="editGrowth" data-bs-keyboard="false" tabindex="-1" aria-labelledby="add_newLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable modal-dialog-centered">
        <div class="modal-content">
        <form id="editGrowthForm" enctype="multipart/form-data">
            <div class="modal-header">
            <h3 class="modal-title fs-5" id="editGrowthLabel">Edit Seed Growth</h3>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" tabindex="-1"></button>
            </div>
            <div class="modal-body">
            <div class="container-fluid p-0">
                <div class="row">
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                    <label for="growthName" class="form-label">Name</label>
                    <input type="text" class="form-control input" id="growthName" name="growthName" value="Seeding" tabindex="-1" disabled/>
                </div>
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                    <label for="stageImage" class="form-label">Stage Image</label>
                    <input type="file" class="form-control input" id="stageImage" name="stageImage" tabindex="-1" />
                    <div id="currentImagePreview" class="mt-2" style="width: 100px;height:100px;"></div>
                </div>
                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-12 mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control input" id="stage_description" name="description" rows="4" tabindex="-1"></textarea>
                </div>
                </div>
            </div>
            </div>
            <div class="modal-footer gap-3">
            <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal" tabindex="-1">Close</button>
            <button class="button primary_btn m-0" type="submit" tabindex="-1">Submit</button>
            <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
        </div>
    </div>
    </div>



    <!-- Modal delete plan-->
    <div class="modal fade" id="delete_user" data-bs-keyboard="false" tabindex="-1" aria-labelledby="delete_userLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body delete">
                    <div class="container-fluid px-0 py-3">
                        <div class="row">
                            <div class="col-12 text-center">
                                <img src="assets/images/warning.svg" alt="warning icon" class="img-fluid">
                                <h4 class="mt-4 text-danger">Delete This Plan?</h4>
                                <p class="mt-3 line_height_30"> This pricing plan will be deleted,<br>
                                    Are you sure you want to continue?</p>
                            </div>
                            <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                                    tabindex="-1">Cancel</button>
                                <button class="button primary_btn m-0 warning_button" type="submit"
                                    tabindex="-1">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function getQueryParam(param) {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get(param);
        }

        document.addEventListener('DOMContentLoaded', function () {
            const seedName = getQueryParam('seed');
            if (seedName) {
                // Update the <h5> text with the seed name from URL
                document.getElementById('seed-name-header').textContent = decodeURIComponent(seedName);
            }
        });
        $(document).ready(function() {
                var table = $('#growthStagesTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: '{{ route("wellify_seeds.growthStages.data", $seed->id) }}',
                columns: [
                    { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                    { data: 'growth_stage', name: 'growth_stage' },
                    { data: 'stage_image', name: 'stage_image', orderable: false, searchable: false },
                    { data: 'description', name: 'description' },
                    { data: 'action', name: 'action', orderable: false, searchable: false },
                ],
                order: [[1, 'asc']],
                drawCallback: function(settings) {
                    var api = this.api();
                    var rowCount = api.rows({page: 'current'}).data().length;

                    if (rowCount >= 5) {
                        $('.primary_btn').hide();
                    } else {
                        $('.primary_btn').show();
                    }
                }
            });

            $(document).on('click', '.seed_edit_icon', function () {
                var id = $(this).data('id');
                $('#editGrowthForm').data('id', id);

                $('#growthName').val('');
                $('#description').val('');
                $('#currentImagePreview').html('');

                $.ajax({
                    url: '/admin/show-growth-stage-media/' + id,
                    method: 'GET',
                    success: function (response) {
                        if (response.success) {
                            var data = response.data;

                            var name = data.growth_stage && data.growth_stage.title ? data.growth_stage.title : '';
                            $('#growthName').val(name);
                            $('#stage_description').val(data.description || '');

                            if (response.data.is_update == 1) {
                                $('#currentImagePreview').html(
                                    '<img src="' + response.image_url + '" alt="Current Stage Image" style="max-width: 100%; height: auto;" />'
                                );
                            } else {
                                $('#currentImagePreview').html('');
                            }

                            $('#editGrowth').modal('show');
                        } else {
                            alert('Failed to fetch growth stage media.');
                        }
                    },
                    error: function () {
                        alert('An error occurred while fetching data.');
                    }
                });
            });

            $('#stageImage').on('change', function() {
                const file = this.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        $('#currentImagePreview').html('<img src="' + e.target.result + '" alt="Selected Image" style="max-width: 100%; height: auto;" />');
                    }
                    reader.readAsDataURL(file);
                } else {
                    $('#currentImagePreview').html('');
                }
            });

            $('#editGrowthForm').on('submit', function(e) {
                e.preventDefault();

                var description = $('#stage_description').val().trim();
                if (!description) {
                    swal("Error", "Description cannot be empty.", "error");
                    return;
                }

                var fileInput = $('#stageImage')[0];

                // Function to do the AJAX update call
                function doUpdate() {
                    var id = $('#editGrowthForm').data('id'); // safer to select form by ID again
                    var formData = new FormData($('#editGrowthForm')[0]);

                    $.ajax({
                        url: '/admin/update-growth-stage-media/' + id,
                        method: 'POST',
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(response) {
                            if(response.success) {
                                swal("Success", "Updated Successfully", "success");
                                $('#editGrowth').modal('hide');
                                $('#growthStagesTable').DataTable().ajax.reload(null, false);
                            } else {
                                swal("Error", "Update failed: " + response.message, "error");
                            }
                        },
                        error: function() {
                            alert('An error occurred while updating.');
                        }
                    });
                }

                if (fileInput.files.length === 0) {
                    // No image selected, ask for confirmation
                    swal({
                        title: "Are you sure?",
                        text: "You are about to update without an image.",
                        icon: "warning",
                        buttons: ["Cancel", "OK"],
                        dangerMode: true,
                    }).then(function(willUpdate) {
                        if (willUpdate) {
                            doUpdate();
                        }
                    });
                } else {
                    // Image is selected, validate extension first
                    var file = fileInput.files[0];
                    var ext = file.name.split('.').pop().toLowerCase();
                    if (ext !== 'svg') {
                        swal("Error", "Only SVG images are allowed.", "error");
                        return;
                    }
                    doUpdate();
                }
            });







        });
    </script>
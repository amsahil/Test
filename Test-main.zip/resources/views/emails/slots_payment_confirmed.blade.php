<!DOCTYPE html>
<html>
<head>
    <title>Payment Confirmed</title>
</head>
<body>
    <h2>Hello {{ $employer->first_name }},</h2>

    <p>Your payment for <strong>{{ $count }}</strong> additional slots has been successfully received.</p>

    <p>You can now continue to launch your additional employees.</p>

    <p>Thank you for using Wellify!</p>
</body>
</html>

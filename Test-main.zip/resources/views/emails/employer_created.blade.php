{{-- <!DOCTYPE html>
<html>
<head>
    <title>Welcome to Wellify</title>
</head>
<body>
    <h2>Welcome to Wellify!</h2>
    <p>Dear {{ $first_name }},</p>
    <p>Your account has been successfully created.</p>
    <p>Here are your login credentials:</p>
    <ul>
        <li><strong>Email:</strong> {{ $email }}</li>
        <li><strong>Username:</strong> {{ $username }}</li>
    </ul>
    <p>Please log in and set your password.</p>
    <p>Best regards,<br>Wellify Team</p>
</body>
</html> --}}
<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
  xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="x-apple-disable-message-reformatting">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap"
    rel="stylesheet">
  <title>Account Credentials</title>

  <style type="text/css">
    * { margin: 0; padding: 0 }
    .logo { max-width: 180px; }
    .footer_link { padding: 10px 30px; }
    .footer_link a { padding: 10px 15px; font-size: 14px; }
    p { margin-bottom: 1rem; }
    @media (max-width:600px) {
      .logo { max-width: 150px; }
      .footer_link { padding: 5px; }
      .footer_link a { padding: 5px; font-size: 12px; }
    }

  </style>
</head>

<body style="margin: 0;padding: 0;background-color: #ffffff;color: #000000;font-family: 'Poppins', sans-serif;">

  <table role="presentation" width="100%" cellspacing="0" cellpadding="0"
    style="max-width:600px; margin: auto; box-shadow: 0 0 5px #00000030;">
    <tbody>

      <tr>
        <td style="background-color: #073029;text-align: center;padding:1rem;">
            @php
          $wellifyLogoUrl = Storage::disk('s3')->temporaryUrl(
          'staging/public/wellify-logo.svg',
          now()->addHour()
          );
          @endphp
        <img src="{{  $wellifyLogoUrl}}" alt="Wellify Logo" class="logo" style="max-width: 180px; width: 100%; height: auto; display: block; margin: auto;">
        </td>
      </tr>

      <tr>
        <td style="background-color: #fff;text-align: center;padding:1rem;">
            @php
          $wellifyOtpUrl = Storage::disk('s3')->temporaryUrl(
          'staging/public/otp.png',
          now()->addHour()
          );
          @endphp

          <img src="{{ $wellifyOtpUrl }}" alt="OTP" style="max-width: 200px;">
          <h2 style="margin: 20px 0 0 0; color: #161616; font-size: 26px; font-weight: 600;">
            Welcome to Wellify!
          </h2>
        </td>
      </tr>

      <tr>
        <td style="padding: 1rem;">
          <p style="color: #161616;">Dear <span style="color:#50b80a;font-weight: 500;">{{ $first_name }},</span>,</p>
          <p style="margin-bottom: 1rem;">
            Your account has been successfully created.
          </p>

          <h4 style="text-align: center;margin-bottom: 1rem;">Here are your login credentials:</h4>

          <h4>
            <li><strong>Email:</strong> {{ $email }}</li>
            <li><strong>Username:</strong> {{ $username }}</li>
            <li><strong>Password:</strong> {{ $password }}</li>

          </h4>
            {{-- <p>Please click on <a href="{{ route('forgot.password') }}">Forgot Password</a> and set your new password.</p> --}}

            <p>Best regards,<br>Wellify Team</p>
        </td>

      </tr>

      <tr>
        <td style="background-color: #104038;" align="center" class="footer_link">
          <div style="text-align:center;">
            <a href="#" style="color: #ddd;text-decoration: none;">FAQs</a>
            <span style="color:#fff;"> | </span>
            <a href="#" style="color: #ddd;text-decoration: none;">Terms &amp; Conditions</a>
            <span style="color:#fff;"> | </span>
            <a href="#" style="color: #ddd;text-decoration: none;">Contact Us</a>
          </div>
          <hr style="border-top: 1px solid #b4b4b4;">
        </td>
      </tr>

      <tr>
        <td style="background-color: #104038; text-align: center; padding-bottom: 10px;">
          <a href="#"><img src="{{ Storage::disk('s3')->temporaryUrl('staging/public/twitter.png', now()->addHour()) }}" alt="Twitter" width="32" style="width: 32px; height: 32px; margin: 0 5px;"></a>
          <a href="#"><img src="{{ Storage::disk('s3')->temporaryUrl('staging/public/Linkedin.png', now()->addHour()) }}" alt="LinkedIn" width="32" style="width: 32px; height: 32px; margin: 0 5px;"></a>
          <a href="#"><img src="{{ Storage::disk('s3')->temporaryUrl('staging/public/instagram.png', now()->addHour()) }}" alt="Instagram" width="32" style="width: 32px; height: 32px; margin: 0 5px;"></a>
          <hr style="border-top: 1px solid #b4b4b4;">
        </td>
      </tr>

      <tr>
        <td style="background-color: #104038; color: #a3b2c3; text-align: center; padding: 10px 0;">
          <p style="margin: 0; font-size: 14px;">
            Copyright &copy; 2025 <a href="#" style="color: #a3b2c3;">Wellify</a> | All rights reserved
          </p>
        </td>
      </tr>
    </tbody>
  </table>
</body>
</html>

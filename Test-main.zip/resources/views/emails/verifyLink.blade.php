<p>Hi [User Name],</p>
<p>Welcome to Wellify! We're thrilled to have you join us.</p>
<p>To complete your registration and access all the features, please verify your email address by clicking the link below:</p>
<p>
    <a href="{{ url('/verify-email?token='.$token) }}">Email Verification Link</a>
</p>
<p>If the link doesn't work, you can copy and paste this into your browser: [Link URL]</p>
<p>If you have any questions, please don't hesitate to contact us at .
<p><a href="mailto:someone@example.com">Wellify Support Email Address</a></p>
</p>
<p>Thanks,</p>
<p>The Wellify Team</p>
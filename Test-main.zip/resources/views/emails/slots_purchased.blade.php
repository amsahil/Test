<!DOCTYPE html>
<html>
<head>
    <title>Slots Purchased</title>
</head>
<body>
    <h2>Hello {{ $employer->name }}</h2>
    <p>You have successfully purchased {{ $slots }} slot(s).</p>
    <p>Thank you for your purchase!</p>
</body>
</html>

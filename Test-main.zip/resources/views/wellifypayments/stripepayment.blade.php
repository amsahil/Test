<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Stripe Payment</title>
    <script src="https://js.stripe.com/v3/"></script>
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .card {
            background: #fff;
            padding: 30px 40px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            width: 350px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
            color: #32325d;
        }
        label {
            display: block;
            text-align: left;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }
        input[type=number] {
            width: 100%;
            padding: 10px 12px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ccd0d5;
            margin-bottom: 20px;
            box-sizing: border-box;
        }
        #card-element {
            padding: 10px 12px;
            border: 1px solid #ccd0d5;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        button {
            background-color: #6772e5;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            padding: 12px 0;
            width: 100%;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #5469d4;
        }
        #error-message {
            color: #fa755a;
            margin-top: 12px;
            min-height: 18px;
            font-weight: 500;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>Make a Payment</h2>

    <form id="payment-form">
        <label for="amount">Amount (USD):</label>
        <input type="number" id="amount" name="amount" min="1" required placeholder="Enter amount" />

        <button id="pay-button" type="submit">Pay</button>
        <div id="error-message"></div>
    </form>
</div>

<script>
    const stripe = Stripe("{{ config('services.stripe.key') }}");

    const form = document.getElementById('payment-form');
    const errorMessage = document.getElementById('error-message');
    const payButton = document.getElementById('pay-button');

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        errorMessage.textContent = '';
        payButton.disabled = true;
        payButton.textContent = 'Processing...';

        const amount = document.getElementById('amount').value;

        if (!amount || amount < 1) {
            errorMessage.textContent = 'Please enter a valid amount.';
            payButton.disabled = false;
            payButton.textContent = 'Pay';
            return;
        }

        try {
            const response = await fetch("{{ route('wellifypayments.process') }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                },
                body: JSON.stringify({ amount }),
            });

            const session = await response.json();

            if (session.error) {
                errorMessage.textContent = session.error;
                payButton.disabled = false;
                payButton.textContent = 'Pay';
                return;
            }

            // Redirect to Stripe Checkout
            const result = await stripe.redirectToCheckout({
                sessionId: session.id,
            });

            if (result.error) {
                errorMessage.textContent = result.error.message;
                payButton.disabled = false;
                payButton.textContent = 'Pay';
            }

        } catch (err) {
            errorMessage.textContent = 'An error occurred. Please try again.';
            payButton.disabled = false;
            payButton.textContent = 'Pay';
        }
    });
</script>

</body>
</html>

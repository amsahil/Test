<!DOCTYPE html>
<html>
<head>
    <title>Create Stripe Plan</title>
    <!-- Bootstrap CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body>
<div class="container my-5">

    <h1 class="mb-4">Create Stripe Plan</h1>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <!-- Create Plan Form -->
    <form method="POST" action="{{ route('plans.store') }}" enctype="multipart/form-data" class="mb-5">
        @csrf
        <div class="row g-3">
            <div class="col-md-6">
                <label for="name" class="form-label">Plan Name</label>
                <input type="text" name="name" id="name" class="form-control" value="{{ old('name') }}" required>
            </div>

            <div class="col-md-3">
                <label for="amount" class="form-label">Amount (in dollars)</label>
                <input type="number" name="amount" id="amount" class="form-control" value="{{ old('amount') }}" step="0.01" min="1" required>
            </div>

            <div class="col-md-3">
                <label for="currency" class="form-label">Currency</label>
                <input type="text" name="currency" id="currency" class="form-control" value="{{ old('currency', 'usd') }}" required>
            </div>

            <div class="col-md-3">
                <label for="interval" class="form-label">Interval</label>
                <select name="interval" id="interval" class="form-select" required>
                    <option value="day" {{ old('interval') == 'day' ? 'selected' : '' }}>Day</option>
                    <option value="week" {{ old('interval') == 'week' ? 'selected' : '' }}>Week</option>
                    <option value="month" {{ old('interval', 'month') == 'month' ? 'selected' : '' }}>Month</option>
                    <option value="year" {{ old('interval') == 'year' ? 'selected' : '' }}>Year</option>
                </select>
            </div>

            <div class="col-md-6">
                <label for="image" class="form-label">Plan Image</label>
                <input type="file" name="image" id="image" class="form-control" accept="image/*" required>
            </div>

            <div class="col-12">
                <button type="submit" class="btn btn-primary mt-3">Create Plan</button>
            </div>
        </div>
    </form>

    <hr>

    <h2 class="mb-4">Available Plans</h2>

    @if($plans->isEmpty())
        <p>No plans available yet.</p>
    @else
        <div class="row row-cols-1 row-cols-md-3 g-4">
            @foreach($plans as $plan)
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        @if($plan->image_url)
                            <img src="{{ $plan->image_url }}" class="card-img-top" alt="{{ $plan->name }}" style="height: 180px; object-fit: cover;">
                        @else
                            <img src="https://via.placeholder.com/350x180?text=No+Image" class="card-img-top" alt="No Image">
                        @endif
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">{{ $plan->name }}</h5>
                            <p class="card-text mb-1"><strong>Price:</strong> ${{ number_format($plan->amount / 100, 2) }} {{ strtoupper($plan->currency) }}</p>
                            <p class="card-text mb-1"><strong>Interval:</strong> {{ ucfirst($plan->interval) }}</p>
                            <p class="card-text text-muted"><small>Stripe Product ID: {{ $plan->stripe_product_id }}</small></p>

                            <button class="btn btn-success mt-auto subscribe-btn"
                                    data-plan-id="{{ $plan->id }}">
                                Subscribe for $0 Now
                            </button>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @endif

</div>

<!-- Bootstrap JS Bundle (Optional for interactivity) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://js.stripe.com/v3/"></script>
<script>
    const stripe = Stripe("{{ config('services.stripe.key') }}");

    document.querySelectorAll('.subscribe-btn').forEach(button => {
        button.addEventListener('click', async (e) => {
            const planId = e.target.dataset.planId;

            const response = await fetch("{{ route('subscription.create') }}", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
                },
                body: JSON.stringify({ plan_id: planId })
            });

            const session = await response.json();

            if (session.error) {
                alert(session.error);
                return;
            }

            const result = await stripe.redirectToCheckout({
                sessionId: session.id
            });

            if (result.error) {
                alert(result.error.message);
            }
        });

    });
</script>
</body>
</html>

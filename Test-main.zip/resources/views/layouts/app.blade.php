<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title', 'Wellify')</title>

    {{-- Core CSS --}}
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/responsive.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/upload.css') }}">

    {{-- DataTables CSS --}}
    <link rel="stylesheet" href="{{ asset('assets/css/datatable.bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/datatable_responsive.css') }}">

    {{-- SweetAlert --}}
    <script src="{{ asset('assets/js/sweetalert.min.js') }}"></script>
    {{-- jQuery (needed before DataTables) --}}
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

    {{-- Page-Specific CSS (via @push) --}}
    @stack('styles')
</head>
<body>

    @yield('content')

    {{-- Bootstrap and Scripts --}}
    <script src="{{ asset('assets/js/staff-email.js') }}"></script>
    <script src="{{ asset('assets/js/employee-email.js') }}"></script>
    <script src="{{ asset('assets/js/popperjs.js') }}"></script>
    <script src="{{ asset('assets/js/bootstrap.js') }}"></script>
    <script src="{{ asset('assets/js/script.js') }}"></script>

    {{-- DataTables --}}
    <script src="{{ asset('assets/js/datatable.js') }}"></script>
    <script src="{{ asset('assets/js/datatable_bootstrap.js') }}"></script>
    <script src="{{ asset('assets/js/datatable_responsive.js') }}"></script>
    <script src="{{ asset('assets/js/file_upload.js') }}"></script>

    <!-- Stripe cdn -->
    <script src="https://js.stripe.com/v3/"></script>
    <!-- Stripe cdn -->

    {{-- AWS S3 SDK (used in media page) --}}
    <script src="https://sdk.amazonaws.com/js/aws-sdk-2.1.0.min.js"></script>

    {{-- CSRF Token setup for AJAX --}}
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        });
    </script>

    {{-- Global Script --}}

    <script src="{{ asset('js/wellify/superadminEmployer.js') }}"></script>
    {{-- <script src="{{ asset('js/wellify/ClassesImage.js') }}"></script> --}}

    {{-- Config Routes for Employers (optional here, not for media page) --}}
    <script>
        const wellifyUsersDataUrl = "{{ route('wellify_users.data') }}";
        const wellifyUsersDeletedData = "{{ route('wellify_users.deleted.data') }}";
        const wellifyEmployeesDataUrl = "{{ route('wellify_employees.data') }}";
        const wellifyAppUsersDeletedData = "{{ route('wellify_app_users.deleted.data') }}";

        const wellifyUsersStoreData = "{{ route('wellify_users.store') }}";
        const wellifyAppUsersStoreData = "{{ route('wellify_employees.store') }}";
        const wellifyUsersBulkRestoreData = "{{ route('wellify_users.bulk_restore') }}";
        const wellifyAppUsersBulkRestoreData = "{{ route('wellify_app_users.bulk_restore') }}";
        const wellifyAppUsersSkippedData = "{{ route('wellify_app_users.skipped.data') }}";
    </script>
        {{-- Config Routes for media page (optional here, not for media page) --}}
        <script>
            const wellifyUploadMediaDataUrl = "{{ route('class-media.upload') }}";
            const wellifyUpdateMediaData = "{{ route('class-media.update') }}";
            // const wellifyUsersStoreData = "{{ route('wellify_users.store') }}";
            // const wellifyUsersBulkRestoreData = "{{ route('wellify_users.bulk_restore') }}";
        </script>

    {{-- Handle back/forward navigation issues --}}
    <script>
        window.addEventListener('pageshow', function (event) {
            if (event.persisted || (window.performance && window.performance.navigation.type === 2)) {
                window.location.reload();
            }
        });
    </script>

    {{-- Page-Specific Scripts (from @push) --}}
    @stack('scripts')

</body>
</html>

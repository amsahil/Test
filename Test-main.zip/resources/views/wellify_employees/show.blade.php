@extends('layouts.app')
@section('content')
    <div class="container mt-4">
        <h1>Wellify Employees Details</h1>
        <div class="card mb-3">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <h5>Organization:</h5>
                        <p>{{ $user->organization ?? 'N/A' }}</p>
                    </div>
                    <div class="col-md-4">
                        <h5>Name:</h5>
                        <p>{{ $user->first_name }} {{ $user->last_name }}</p>
                    </div>
                    <div class="col-md-4">
                        <h5>Email:</h5>
                        <p>{{ $user->email }}</p>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-4">
                        <h5>Username:</h5>
                        <p>{{ $user->username }}</p>
                    </div>
                    <div class="col-md-4">
                        <h5>Phone Number:</h5>
                        <p>{{ $user->phone }}</p>
                    </div>
                    <div class="col-md-4">
                        <h5>Timezone:</h5>
                        <p>{{ $user->user_timezone }}</p>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-12">
                        <h5>Profile Picture:</h5>
                        @if ($user->profile_picture)
                            <img src="{{ asset('storage/' . $user->profile_picture) }}" alt="Profile Picture" width="200">
                        @else
                            <p>No profile picture available.</p>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <a href="/wellify_users" class="btn btn-secondary">Back to List</a>
    </div>
@endsection

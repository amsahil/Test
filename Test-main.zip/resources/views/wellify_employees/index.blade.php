@extends('layouts.app')
@include('common.header')
@include('common.sidebar')


<meta name="csrf-token" content="{{ csrf_token() }}">
<style>
#pay-per-user-btn:disabled {
    background-color: #d3d3d3 !important;
    /* light gray */
    color: #888 !important;
    cursor: not-allowed;
    border-color: #ccc !important;
    opacity: 0.7;
}

#launch-users-btn:disabled {
    background-color: #d3d3d3 !important;
    /* light gray */
    color: #888 !important;
    cursor: not-allowed;
    border-color: #ccc !important;
    opacity: 0.7;
}
</style>

<!-- Datatable to Show Employees List -->
<section class="main_card">
    <nav>
        <div class="nav nav-tabs d-flex justify-content-between" id="nav-tab" role="tablist">
            <div
                class="tabs_buttons d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">
                <button class="nav-link active mb-xxl-0 mb-xl-0  mb-lg-0 mb-md-0 mb-2" id="nav-home-tab"
                    data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home"
                    aria-selected="true">Active Employees</button>
                <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile"
                    type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Deleted
                    Employees</button>
                <button class="nav-link" id="nav-skipped-tab" data-bs-toggle="tab" data-bs-target="#nav-skipped"
                    type="button" role="tab" aria-controls="nav-skipped" aria-selected="false">Skipped
                    Employees</button>
            </div>
            <div class="filter d-flex align-items-center gap-2 mb-xxl-0 mb-xl-0  mb-lg-0 mb-md-0 mb-5">
                @if(Auth::user()->hasRole('Super Admin'))
                <select name="employer_id" id="employer_name" class="form-select select_box fs_14 employer_select">
                    <option value="" selected>Select Employer</option>
                    @foreach($employees as $employee)
                    <option value="{{ $employee->id }}" {{ old('employer_id') == $employee->id ? 'selected' : '' }}>
                        {{ $employee->username }}
                    </option>
                    @endforeach
                </select>
                @endif
                <select class="form-select select_box fs_14" id="sortFilter1">
                    <option value="">Sort by</option>
                    <option value="today">Today</option>
                    <option value="last_week">Last week</option>
                    <option value="last_month">Last month</option>
                </select>
            </div>
        </div>
    </nav>
    <div class="tab-content" id="nav-tabContent">
        <!-- Active Employers Tab -->
        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"
            tabindex="0">
            <div class="cotainr-fluid">
                <div class="row">
                    <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                        <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Active Employees</h5>
                        <div class="button_group d-flex gap-3">
                            {{-- <button id="pay-per-user-btn" type="button" class="button pay_btn secondary_btn">Pay $1/User</button> --}}
                            {{-- <button class="button primary_btn" type="button" id="pay-per-user-btn">Pay for Selected Users</button> --}}
                            {{-- <button id="pay-per-user-btn" class="button primary_btn" disabled>Pay Now</button> --}}

                            @if(Auth::user()->hasRole('Employer'))
                            <!-- <button id="pay-per-user-btn" class="button primary_btn" disabled data-bs-toggle="modal"
                                data-bs-target="#recurringBillingModal">Pay Now</button> -->
                            <button id="launch-users-btn" class="button primary_btn">Launch</button>

                            @endif
                            <button class="button secondary_btn" type="button" data-bs-toggle="modal"
                                data-bs-target="#upload_files">
                                Bulk Upload
                            </button>
                            <button class="button primary_btn" type="button" data-bs-toggle="modal"
                                data-bs-target="#add_new_app_user">Add New</button>
                            <button id="send-welcome-emails1" class="button send_mailButton">
                                Send Mail
                            </button>
                        </div>
                    </div>
                </div>
                <div class="row pt_24">
                    <div class="col-12">
                        <table id="employeesTable" class="table table-striped datatable">
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col">Employee Name</th>
                                    <th scope="col">Employee Email</th>
                                    <th scope="col">Employer Name</th>
                                    <th scope="col">Employee Phone</th>
                                    <th scope="col">Employee Address</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Inactive Employers Tab -->
        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0">
            <div class="container-fluid">
                <div class="row">
                    <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                        <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Inactive Employees</h5>
                        <div class="button_group d-flex gap-3">
                            <button class="button secondary_btn" type="button" data-bs-target="#bulk_restore_user"
                                data-bs-toggle="modal" id="bulkEmployeeRestoreButton">
                                Restore
                            </button>
                        </div>
                    </div>
                </div>
                <div class="row pt_24">
                    <div class="col-12">
                        <table id="inactive-employees-datatable" class="table table-striped datatable">
                            <thead>
                                <tr>
                                    <th scope="col"><input type="checkbox" id="selectAllEmployeeRestore"></th>
                                    <th scope="col">Employee Name</th>
                                    <th scope="col">Employee Email</th>
                                    <th scope="col">Employer Name</th>
                                    <th scope="col">Employee Phone</th>
                                    <th scope="col">Employee Address</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>

        <!-- Skipped User Tab -->
        <div class="tab-pane fade" id="nav-skipped" role="tabpanel" aria-labelledby="nav-skipped-tab" tabindex="0">
            <div class="container-fluid">
                <div class="row">
                    <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                        <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Skipped Employees</h5>
                        <div class="button_group d-flex gap-3">
                            <button class="button secondary_btn" type="button" data-bs-target="#bulk_export_employees"
                                data-bs-toggle="modal" id="bulk_employees_export">
                                Export
                            </button>
                        </div>
                    </div>
                    <!-- Hidden Form for Exporting Employees -->
                    <form id="exportForm" action="{{ route('wellify_app_users.export') }}" method="POST"
                        style="display: none;">
                        @csrf
                        <input type="hidden" name="ids" id="exportIds" value="">
                    </form>
                </div>
                <div class="row pt_24">
                    <div class="col-12">
                        <table id="skipped-employees-datatable" class="table table-striped datatable">
                            <thead>
                                <tr>
                                    <th scope="col"><input type="checkbox" id="selectAllEmployeeExport"></th>
                                    <th scope="col">Employee Name</th>
                                    <th scope="col">Employee Email</th>
                                    <!-- <th scope="col">Employer Name</th> -->
                                    <th scope="col">Employee Phone</th>
                                    <th scope="col">Employee Address</th>
                                    <th scope="col">Error message</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="modal fade" id="emailEditModal1" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="emailEditModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                            <img src="assets/images/email.svg" alt="warning icon" class="img-fluid">
                            <h4 class="my-3" id="emailEditModalLabel">Type a message to send in welcome email</h4>
                        </div>
                        <div class="col-12 mb-3">
                            <textarea id="manualText" class="form-control" rows="5"
                                placeholder="Enter your message "></textarea>
                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                            <button type="button" id="modalCloseId" class="btn btn-secondary"
                                data-dismiss="modal">Close</button>
                            <button id="sendEditedEmail1" class="btn btn-primary" type="button">
                                <span id="buttonText">Submit</span>
                                <span id="spinner" class="spinner-border spinner-border-sm ml-2" role="status"
                                    aria-hidden="true" style="display:none;"></span>
                            </button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const userRole = "{{ auth()->user()->getRoleNames()->first() }}";
console.log(userRole);
</script>

<!-- Add Employer Modal -->
<div class="modal fade" id="add_new_app_user" data-bs-keyboard="false" aria-labelledby="add_newLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">

            <form id="addEmployeeForm" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="modal-header">
                    <h3 class="modal-title fs-5" id="add_newLabel">Add Employee</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="container-fluid p-0">
                        <div id="employeeFormErrors"></div>
                        <div class="row">
                            <h5 class="mb-3">Basic Details</h5>
                            @if(Auth::user()->hasRole('Super Admin'))
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="employer_select" class="form-label">Select Employer <span
                                        class="text-danger">*</span></label>
                                <select name="employer_id" id="employer_name" class="form-control input" required>
                                    <option value="" disabled selected>Select an Employer</option>
                                    @foreach($employees as $employee)
                                    <option value="{{ $employee->id }}"
                                        {{ old('employer_id') == $employee->id ? 'selected' : '' }}>
                                        {{ $employee->username }}
                                    </option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback" id="employerFeedback"></div>
                            </div>
                            @endif

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="first_name" class="form-label">First Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="first_name" class="form-control input" id="first_name"
                                    value="{{ old('first_name') }}" maxlength="25" pattern="[A-Za-z0-9 ]+" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="last_name" class="form-label">Last Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="last_name" class="form-control input" id="last_name"
                                    value="{{ old('last_name') }}" maxlength="25" pattern="[A-Za-z0-9 ]+" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="file" class="form-label">Employee Logo</label>
                                <input type="file" name="profile_picture" id="profile_picture"
                                    class="form-control input" accept="image/jpeg,image/png,image/jpg,image/gif">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="email" class="form-label">Employee Email<span
                                        class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control input" id="email"
                                    value="{{ old('email') }}" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="mobile_phone" class="form-label">Employee Phone<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="mobile_phone" class="form-control input" id="mobile_phone"
                                    value="{{ old('mobile_phone') }}" required>
                            </div>

                            <!-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="user_timezone" class="form-label">Timezone</label>
                                <select name="user_timezone" id="user_timezone" class="form-control input">
                                    <option value="">Select Timezone</option>
                                    @foreach ($timezones as $timezone)
                                    <option value="{{ $timezone->utc_offset }}" {{ old('user_timezone') == $timezone->utc_offset ? 'selected' : '' }}>
                                        {{ $timezone->tz_identifier }} ({{ $timezone->utc_offset }})
                                    </option>
                                    @endforeach
                                </select>
                            </div> -->
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="licenses" class="form-label">License<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="licenses" class="form-control input" id="licenses"
                                    value="{{ old('licenses') }}" required>
                            </div>
                            <div class="col-12">
                                <hr class="hr">
                            </div>
                            <h5 class="mb-3">Address Details</h5>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="office" class="form-label">Office</label>
                                <input type="text" name="office" class="form-control input" id="office"
                                    value="{{ old('office') }}">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="city" class="form-label">City</label>
                                <input type="text" name="city" class="form-control input" id="city"
                                    value="{{ old('city') }}">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="state" class="form-label">State</label>
                                <input type="text" name="state" class="form-control input" id="state"
                                    value="{{ old('state') }}">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="country" class="form-label">Country</label>
                                <input type="text" name="country" class="form-control input" id="country"
                                    value="{{ old('country') }}">
                            </div>
                            {{-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control input" id="password" required  >
                                 </div> --}}

                        </div>
                    </div>
                </div>
                <div class="modal-footer gap-3">
                    {{-- <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Close</button> --}}
                    <button type="button" class="button cancel_button m-0 modal-close-btn"
                        data-bs-dismiss="modal">Close</button>
                    {{-- <button class="button primary_btn m-0" type="submit"  >Submit</button> --}}
                    <button type="submit" class="button primary_btn m-0" id="submitBtn">
                        <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"
                            id="submitSpinner"></span>
                        <span class="btn-text">Submit</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- View Employees Modal -->
<div class="modal fade" id="view_app_user" data-bs-keyboard="false" aria-labelledby="view_userLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title fs-5" id="view_app_userLabel">View Employee</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="view_app_user_content">
                </div>
            </div>
            <div class="modal-footer gap-3">
                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Employee Modal -->
<div class="modal fade" id="edit_app_user" data-bs-keyboard="false" aria-labelledby="edit_userLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
        <div class="modal-content">

            <div class="modal-header">
                <h3 class="modal-title fs-5" id="edit_userLabel">Edit Employee</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editAppUserForm" action="" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="container-fluid p-0">
                        <div id="editAppUserErrors" class="alert alert-danger d-none"></div>
                        <div class="row">
                            <h5 class="mb-3">Basic Details</h5>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="first_name" class="form-label">First Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="first_name1" name="first_name"
                                    maxlength="25" pattern="[A-Za-z0-9 ]+" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="last_name" class="form-label">Last Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="last_name1" name="last_name"
                                    maxlength="25" pattern="[A-Za-z0-9 ]+" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="email" class="form-label">Employee Email<span
                                        class="text-danger">*</span></label>
                                <input type="email" class="form-control input" id="email1" name="email" disabled>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="mobile_phone" class="form-label">Employee Phone<span
                                        class="text-danger">*</span></label>
                                <input type="tel" class="form-control input" id="phone1" name="mobile_phone" required>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="user_timezone" class="form-label">Timezone</label>
                                <select class="form-control input" id="user_timezone2" name="user_timezone">
                                    <option value="">Select Timezone</option>
                                </select>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="licenses1" class="form-label">License<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="licenses1" name="licenses" required
                                    value="7856987">
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="profile_picture" class="form-label w-100">Employee Logo</label>
                                <input type="file" class="form-control input" id="profile_picture1"
                                    name="profile_picture" accept="image/*">
                                <div id="currentempProfilePicture" class="mt-2"></div>
                            </div>
                            <div class="col-12">
                                <hr class="hr">
                            </div>

                            <h5 class="mb-3">Address Details</h5>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="office" class="form-label">Office</label>
                                <input type="text" class="form-control input" id="office1" name="office">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="city" class="form-label">City</label>
                                <input type="text" class="form-control input" id="city1" name="city">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="state" class="form-label">State</label>
                                <input type="text" class="form-control input" id="state1" name="state">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="country" class="form-label">Country</label>
                                <input type="text" class="form-control input" id="country1" name="country">
                            </div>
                        </div>
                    </div>
            </div>
            <div class="modal-footer gap-3">
                {{-- <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button> --}}
                <button type="button" class="button cancel_button m-0 modal-close-btn"
                    data-bs-dismiss="modal">Cancel</button>
                {{-- <button type="submit" class="button primary_btn m-0">Update</button> --}}
                <button type="submit" class="button primary_btn m-0" id="updateBtn">
                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"
                        id="updateSpinner"></span>
                    <span class="btn-text">Update</span>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Restore Employer Modal -->
<div class="modal fade" id="restore_app_user_modal" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="restore_employee_label" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                            @php
                            $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                            'staging/public/warning.svg',
                            now()->addHour() // Link expires in 1 hour
                            );
                            @endphp
                            <img src="{{  $warningImageUrl}}" alt="warning icon" class="img-fluid">
                            <h4 class="mt-4 text-success">Restore Employee?</h4>
                            <p class="mt-3 line_height_30"> Selected employee will be restored.<br>
                                Are you sure you want to continue?</p>
                            <div id="restore_feedback" class="validation_text text-center mt-2" style="display: none;">
                            </div>
                        </div>

                        <!-- Hidden input to store employee ID -->
                        <input type="hidden" id="restore_app_employee_id">

                        <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                                tabindex="-1">Cancel</button>
                            <button class="button primary_btn m-0" id="confirm_restore_app_employee_btn" type="submit"
                                tabindex="-1">Restore</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Bulk Restore Employer Modal -->
<div class="modal fade" id="bulk_restore_user" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="bulk_restore_userLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                            <img src="assets/images/warning.svg" alt="warning icon" class="img-fluid">
                            <h4 class="mt-4 text-success">Restore Employers?</h4>
                            <p class="mt-3 line_height_30">
                                Selected employers will be restored.<br>
                                Are you sure you want to continue?
                            </p>
                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0"
                                data-bs-dismiss="modal">Cancel</button>
                            <button class="button primary_btn m-0 confirm-bulk-restore-btn"
                                type="button">Restore</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Delete Employer Modal -->
<div class="modal fade" id="delete_app_user" data-bs-keyboard="false" aria-labelledby="delete_userLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="deleteAppUserForm">
                @csrf
                @method('DELETE')
                <input type="hidden" id="delete_app_user_id" name="user_id" value="">
                <div class="modal-body">
                    <div class="container-fluid px-0 py-3">
                        <div class="row">
                            <div class="col-12 text-center">
                                @php
                                $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/warning.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{ $warningImageUrl }}" alt="warning icon" class="img-fluid">
                                <h4 class="mt-4 text-danger">Delete This Employee ?</h4>
                                <p class="mt-3 line_height_30"> This employee will move to recently deleted <br>
                                    Are you sure you want to continue?</p>
                            </div>
                            <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                                <button type="button" class="button cancel_button m-0"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button class="button primary_btn m-0 warning_button" type="submit">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Bulk upload modal -->

<form id="bulkImport" action="{{ route('wellify_employees.import') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="modal fade" id="upload_files" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="button primary_btnLabel" aria-hidden="true">

        <div class="modal-body">
            <div class="container-fluid p-0">
                <div class="row">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title fs-5" id="upload_filesLabel">Bulk Upload</h3>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                                    tabindex="-1"></button>
                            </div>

                            <div class="modal-body">
                                <div class="container-fluid p-0">
                                    <div class="row">
                                        @if(Auth::user()->hasRole('Super Admin'))
                                        <div class="col-12 mb-3">
                                            <label for="employer_select" class="form-label">Select Employer</label>
                                            <select name="employer_id" id="employeer_name"
                                                class="form-select input form-control">
                                                <option value="">Select an Employeer</option>
                                                @foreach($employees as $employee)
                                                <option value="{{ $employee->id }}"
                                                    {{ old('employer_id') == $employee->id ? 'selected' : '' }}>
                                                    {{ $employee->username }}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        @endif
                                        <div class="col-12 mb-3">
                                            <div class="file-upload-contain position-relative">
                                                <input id="multiplefileupload" name="file" type="file"
                                                    accept=".csv, .xlsx, .PNG" multiple tabindex="-1">
                                            </div>
                                        </div>
                                        <small class="alert alert-success" role="alert">
                                            You can download your manage staffs excel file <a
                                                href="{{ route('download.wellify_app_users.excel') }}"
                                                class="text-primary ms-2" download>
                                                here
                                            </a>
                                        </small>
                                    </div>
                                </div>
                            </div>


                            <div class="modal-footer gap-3">
                                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                                    tabindex="-1">Close</button>
                                <button class="button primary_btn m-0" type="submit" id="bulkSubmit"
                                    tabindex="-1">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<!-- Payment Confirmation Modal -->
<div class="modal fade" id="recurringBillingModal" tabindex="-1" aria-labelledby="recurringBillingModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg">
            <div class="modal-header">
                <h5 class="modal-title" id="recurringBillingModalLabel">Recurring Billing Confirmation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <p class="mb-3">Do you want to create the recurring billing for the next cycle?</p>
                <div class="d-flex justify-content-center gap-3">
                    <button type="button" id="recurringYesBtn" class="btn btn-success">Yes</button>
                    <button type="button" id="recurringNoBtn" class="btn btn-secondary"
                        data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="welcomeEmailModal" tabindex="-1" aria-labelledby="welcomeEmailModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                            @php
                            $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                            'staging/public/warning.svg',
                            now()->addHour()
                            );
                            @endphp
                            <img src="{{ $warningImageUrl }}" alt="Warning Icon" class="img-fluid">
                            <h4 id="welcomeModalTitle" class="mt-4" style="color: #52ab17;">Send Welcome Email?</h4>
                            <p class="mt-3 line_height_30" id="welcomeModalMessage">
                                <!-- Message filled dynamically -->
                            </p>
                            <strong id="welcomeUserEmail" class="d-block mt-2 text-dark"></strong>
                        </div>
                        <div class="col-12 d-flex justify-content-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0"
                                data-bs-dismiss="modal">Cancel</button>
                            <button id="confirmWelcomeSendBtn" class="button primary_btn m-0">
                                Send Email
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="resend_welcome_modal" tabindex="-1" aria-labelledby="resendWelcomeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                            @php
                            $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                            'staging/public/warning.svg',
                            now()->addHour()
                            );
                            @endphp
                            <img src="{{ $warningImageUrl }}" alt="Warning Icon" class="img-fluid">
                            <h4 class="mt-4" style="color: #FFA500;">Resend Welcome Email?</h4>
                            <p class="mt-3 line_height_30">
                                Welcome Email has already been sent to:
                                <br>
                                <strong id="resendEmployerInfo" class="d-block mt-2 text-dark"></strong>
                                <br>
                                Do you want to send it again?
                            </p>
                        </div>
                        <div class="col-12 d-flex justify-content-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0"
                                data-bs-dismiss="modal">Cancel</button>
                            <button id="confirmResendEmail" class="button primary_btn m-0"
                                style="background-color: #FFA500; border-color: #FFA500;">
                                Resend Email
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<!-- Extra Slots Modal -->
<div class="modal fade" id="extraSlotsModal" tabindex="-1" role="dialog" aria-labelledby="extraSlotsModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <form id="extraSlotsForm">
        <div class="modal-header">
          <h5 class="modal-title" id="extraSlotsModalLabel">Purchase Extra Slots</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <p>You need to purchase <strong><span id="remainingSlotsCountDisplay">0</span></strong> additional slots.</p>
          <p>Total Uploaded: <span id="totalUploadedDisplay">0</span></p>
          <p>Paid Slots: <span id="paidSlotsDisplay">0</span></p>
          <p>Total Amount: ₹<span id="paymentAmountDisplay">0</span></p>
        </div>
        <div class="modal-footer">
          <button type="submit" id="payNowBtn" class="btn btn-primary">Pay Now</button>
        </div>
      </form>
    </div>
  </div>
</div>



<!-- Already Launched Modal -->
<div class="modal fade" id="alreadyLaunchedModal" tabindex="-1" aria-labelledby="alreadyLaunchedModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center">
                <h4 class="text-danger">Program Already Launched</h4>
                <p>You have already launched your program. You cannot launch again.</p>
                <button type="button" class="button primary_btn mt-3" data-bs-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div>








<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    let modalAlreadyShown = false;

    $(document).ready(function() {
        let alertShown = {
            office: false,
            city: false,
            state: false,
            country: false,
        };

        const specialCharRegex = /[^a-zA-Z\s]/;
        const allowedCharsRegex = /^[a-zA-Z\s]*$/;

        $('#office').on('input', function() {
            let val = $(this).val();
            if (val.length > 30) {
                $(this).val(val.substring(0, 30));
            }
        });

        $('#city, #state, #country').on('input', function() {
            let val = $(this).val();
            if (!allowedCharsRegex.test(val)) {
                const filtered = val.split('').filter(ch => /[a-zA-Z\s]/.test(ch)).join('');
                $(this).val(filtered);
            }
            if (val.length > 30) {
                $(this).val(val.substring(0, 30));
            }
        });

        const userRole = "{{ auth()->user()->getRoleNames()->first() }}";
        $('#bulkImport').on('submit', function(e) {
            e.preventDefault();
            var employerId = null;
            if (userRole !== 'Employer') {
                employerId = $('select[id="employeer_name"]').val();
                if (!employerId) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Employer Required',
                        text: 'Please select an employer!'
                    });
                    return false;
                }
            }
            var file = $('input[name="file"]')[0].files[0];

            if (!file) {
                Swal.fire({
                    icon: 'warning',
                    title: 'File Required',
                    text: 'Please select a file to upload!'
                });
                return false;
            }

            var allowedTypes = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-excel', 'text/csv'
            ];
            if (!allowedTypes.includes(file.type)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Type',
                    text: 'Please upload only Excel (.xlsx) or CSV files!'
                });
                return false;
            }

            var formData = new FormData(this);

            if (userRole === 'Employer') {
                formData.delete('employer_id');
            }

            $.ajax({
                url: $(this).attr('action'),
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function() {

                    Swal.fire({
                        title: 'Uploading...',
                        html: 'Please wait while we process your file',
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                    $('#bulkImport button[type="submit"]')
                        .prop('disabled', true)
                        .html();
                },

                success: function(response) {
                    Swal.close(); // close loader if open

                    if (response.requires_payment && response.extra_slots_needed > 0 && !modalAlreadyShown) {
                        modalAlreadyShown = true;

                        Swal.fire({
                            icon: 'info',
                            title: 'Purchase Extra Slots',
                            html: `
                                <p>You need to purchase <strong>${response.extra_slots_needed}</strong> additional slot(s).</p>
                                <p>Total Uploaded: <strong>${response.total_uploaded}</strong></p>
                                <p>Paid Slots: <strong>${response.paid_slots}</strong></p>
                                <p>Total Amount: $<strong>${response.extra_slots_needed}</strong></p>
                            `,
                            showCancelButton: true,
                            confirmButtonText: 'Pay Now',
                            cancelButtonText: 'Cancel',
                            allowOutsideClick: false,
                            allowEscapeKey: false
                        }).then(result => {
                            modalAlreadyShown = false;

                            if (result.isConfirmed) {
                                // Send AJAX to get Stripe URL
                                $.ajax({
                                    url: "{{ route('employer.request.extra.slots') }}",
                                    method: 'POST',
                                    data: {
                                        additional_slots: response.extra_slots_needed,
                                        _token: '{{ csrf_token() }}'
                                    },
                                    success: function(res) {
                                        if (res.session_url) {
                                            window.location.href = res.session_url;
                                        } else {
                                            Swal.fire('Error', 'Invalid Stripe response.', 'error');
                                        }
                                    },
                                    error: function() {
                                        Swal.fire('Error', 'Something went wrong while redirecting to payment.', 'error');
                                    }
                                });
                            }
                        });

                        return; // stop further logic if payment required
                    }

                    // Scenario 1: All new
                    if (response.import_details.new_employees_count > 0 &&
                        (!response.skipped_employees || response.skipped_employees.length === 0)) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Import Successful',
                            text: `${response.import_details.new_employees_count} new employees added.`,
                            width: '600px'
                        }).then(() => {
                            $('#upload_files').modal('hide');
                            $('#bulkImport')[0].reset();
                            location.reload();
                        });
                        return;
                    }

                    // Scenario 2: No new, only skipped or existing
                    if (response.import_details.new_employees_count === 0) {
                        let skippedEmployeesList = response.skipped_employees?.map(emp =>
                            `${emp.first_name} ${emp.last_name} - ${emp.error_message}`
                        ).join('<br>') || '';

                        let existingEmployeesList = (response.existing_employees || []).map(emp =>
                            `${emp.first_name} ${emp.last_name}`
                        ).join('<br>');

                        Swal.fire({
                            icon: 'info',
                            title: 'Import Result',
                            html: `
                                <p>No new employees were added.</p>
                                ${skippedEmployeesList ? `
                                    <h5>Skipped Employees (${response.skipped_employees.length}):</h5>
                                    <div style="max-height: 300px; overflow-y: auto; text-align: left; padding: 10px; background-color: #f8f9fa; border-radius: 5px;">
                                        ${skippedEmployeesList}
                                    </div>
                                ` : ''}
                                ${existingEmployeesList ? `
                                    <h5>Existing Employees (${response.existing_employees.length}):</h5>
                                    <div style="max-height: 300px; overflow-y: auto; text-align: left; padding: 10px; background-color: #f8f9fa; border-radius: 5px;">
                                        ${existingEmployeesList}
                                    </div>
                                ` : ''}
                            `,
                            width: '600px',
                            confirmButtonText: 'Close'
                        });

                        return;
                    }

                    // Scenario 3: Mixed (some new, some skipped)
                    if (response.import_details.new_employees_count > 0 &&
                        response.skipped_employees && response.skipped_employees.length > 0) {
                        let skippedEmployeesList = response.skipped_employees.map(emp =>
                            `${emp.first_name} ${emp.last_name} - ${emp.error_message}`
                        ).join('<br>');

                        Swal.fire({
                            icon: 'warning',
                            title: 'Partial Import',
                            html: `
                                <p>${response.import_details.new_employees_count} new employees added. ${response.skipped_employees.length} employees were skipped.</p>
                                <h5>Skipped Employees:</h5>
                                <div style="max-height: 300px; overflow-y: auto; text-align: left; padding: 10px; background-color: #f8f9fa; border-radius: 5px;">
                                    ${skippedEmployeesList}
                                </div>
                            `,
                            width: '600px',
                            confirmButtonText: 'Close'
                        }).then(() => {
                            $('#upload_files').modal('hide');
                            $('#bulkImport')[0].reset();
                            location.reload();
                        });
                    }
                },



                error: function(xhr) {
                    Swal.close();

                    // Parse error response
                    var response = xhr.responseJSON || {};

                    // Default error message
                    var errorMessage = response.message ||
                        'An unexpected error occurred during import.';

                    // Prepare detailed error information
                    let errorDetails = '';

                    // Add skipped employees if available
                    if (response.skipped_employees && response.skipped_employees.length > 0) {
                        let skippedEmployeesList = response.skipped_employees.map(emp =>
                            `${emp.first_name} ${emp.last_name} - ${emp.error_message}`
                        ).join('<br>');

                        errorDetails = `
                                    <h5>Skipped Employees (${response.skipped_employees.length}):</h5>
                                    <h6>Find Skipped Employees At Skipped Section<h6>
                                    <div style="max-height: 300px; overflow-y: auto; text-align: left; padding: 10px; background-color: #f8f9fa; border-radius: 5px;">
                                        ${skippedEmployeesList}
                                    </div>
                                `;
                    }

                    Swal.fire({
                        icon: 'error',
                        title: 'Import Failed',
                        html: `
                                    ${errorDetails}
                                `,
                        width: '600px'
                    }).then(() => {
                        $('#skipped-employees-datatable').DataTable().ajax.reload();
                    });
                },

                complete: function() {

                    $('#bulkImport button[type="submit"]')
                        .prop('disabled', false)
                        .html('Submit');
                }
            });
        });

    });

    // Fixed launch users button handler
$('#launch-users-btn').on('click', function () {
    // Add loading state
    $(this).prop('disabled', true).text('Checking...');
    
    $.ajax({
        url: "{{ route('employer.check_launch_quota') }}",
        type: 'POST',
        data: {
            _token: '{{ csrf_token() }}' // Add CSRF token
        },
        success: function (res) {
            console.log('Quota check response:', res); // Debug log
            
            // Update modal display values
            $('#totalUploadedDisplay').text(res.total_uploaded || 0);
            $('#paidSlotsDisplay').text(res.paid_slots || 0);
            $('#remainingSlotsCountDisplay').text(res.remaining_to_pay || 0);
            $('#paymentAmountDisplay').text(res.remaining_to_pay || 0);

            // Check if payment is required and modal hasn't been shown
            if (res.requires_payment && res.remaining_to_pay > 0) {
                console.log('Opening payment modal'); // Debug log
                
                // Reset modal state
                modalAlreadyShown = false;
                
                // Show the modal
                $('#extraSlotsModal').modal('show');
                
                // Set up modal close handler
                $('#extraSlotsModal').off('hidden.bs.modal').on('hidden.bs.modal', function () {
                    modalAlreadyShown = false;
                    // Re-enable the launch button when modal closes
                    $('#launch-users-btn').prop('disabled', false).text('Launch');
                });
            } else {
                // No payment required, proceed with launch
                console.log('No payment required, launching...'); // Debug log
                performLaunch();
            }
        },
        error: function (xhr, status, error) {
            console.error('Quota check error:', error); // Debug log
            console.error('Response:', xhr.responseText); // Debug log
            
            alert("Server error during quota check: " + error);
            
            // Re-enable button on error
            $('#launch-users-btn').prop('disabled', false).text('Launch');
        },
        complete: function() {
            // Re-enable button if not showing modal
            if (!$('#extraSlotsModal').hasClass('show')) {
                $('#launch-users-btn').prop('disabled', false).text('Launch');
            }
        }
    });
});

// Fixed extra slots form submission
$('#extraSlotsForm').on('submit', function (e) {
    e.preventDefault();

    let slots = parseInt($('#remainingSlotsCountDisplay').text().trim());
    if (!slots || slots <= 0) {
        alert('Invalid slot count.');
        return;
    }

    // Update button state
    const $payBtn = $('#payNowBtn');
    $payBtn.text('Processing...').prop('disabled', true);

    $.ajax({
        url: "{{ route('employer.request.extra.slots') }}",
        method: 'POST',
        data: {
            additional_slots: slots,
            _token: '{{ csrf_token() }}'
        },
        success: function (res) {
            if (res.session_url) {
                $payBtn.text('Redirecting to Payment...');
                window.location.href = res.session_url;
            } else {
                alert('Invalid response from payment processor.');
                $payBtn.text('Pay Now').prop('disabled', false);
            }
        },
        error: function (xhr, status, error) {
            console.error('Payment error:', error);
            console.error('Response:', xhr.responseText);
            
            alert('Payment setup failed: ' + error);
            $payBtn.text('Pay Now').prop('disabled', false);
        }
    });
});

// Improved launch function
function performLaunch() {
    $.ajax({
        url: "{{ route('employer.bulk_launch_users') }}",
        type: 'POST',
        data: { 
            _token: '{{ csrf_token() }}' 
        },
        success: function (res) {
            if (res.already_launched) {
                $('#alreadyLaunchedModal').modal('show');
                return;
            }
            
            // Show success message
            if (res.message) {
                alert(res.message);
            }
            
            // Reload the table
            if ($.fn.DataTable.isDataTable('#employeesTable')) {
                $('#employeesTable').DataTable().ajax.reload();
            }
            
            // Re-enable launch button
            $('#launch-users-btn').prop('disabled', false).text('Launch');
        },
        error: function (xhr, status, error) {
            console.error('Launch error:', error);
            console.error('Response:', xhr.responseText);
            
            alert("Launch failed: " + error);
            
            // Re-enable launch button
            $('#launch-users-btn').prop('disabled', false).text('Launch');
        }
    });
}

// Additional debugging for modal
$(document).ready(function() {
    // Debug modal events
    $('#extraSlotsModal').on('show.bs.modal', function () {
        console.log('Extra slots modal is showing');
    });
    
    $('#extraSlotsModal').on('shown.bs.modal', function () {
        console.log('Extra slots modal is shown');
    });
    
    $('#extraSlotsModal').on('hide.bs.modal', function () {
        console.log('Extra slots modal is hiding');
    });
    
    // Check if Bootstrap modal is available
    if (typeof bootstrap === 'undefined') {
        console.error('Bootstrap JavaScript is not loaded');
    }
});

// Alternative modal opening method (if Bootstrap modal fails)
function forceOpenModal() {
    const modalEl = document.getElementById('extraSlotsModal');
    if (modalEl) {
        if (typeof bootstrap !== 'undefined') {
            const modal = new bootstrap.Modal(modalEl);
            modal.show();
        } else {
            // Fallback for older Bootstrap versions
            $('#extraSlotsModal').modal('show');
        }
    }
}
</script>


<script>
    let currentWelcomeUserId = null;
    let welcomeModalMode = 'send'; // or 'resend'

    $(document).on('click', '.send_mail_icon_employee', function() {
        const userId = $(this).data('id');
        const userEmail = $(this).data('email');
        const status = $(this).data('status');

        currentWelcomeUserId = userId;

        if (status === 'sent') {
            welcomeModalMode = 'resend';
            $('#welcomeModalTitle').text('Resend Welcome Email?');
            $('#welcomeModalMessage').html(
                'A welcome email has already been sent to:<br>Do you want to send it again?');
        } else {
            welcomeModalMode = 'send';
            $('#welcomeModalTitle').text('Send Welcome Email?');
            $('#welcomeModalMessage').html('Do you want to send the welcome email to this employee?');
        }

        $('#welcomeUserEmail').text(userEmail);
        $('#welcomeEmailModal').modal('show');
    });

    $('#confirmWelcomeSendBtn').on('click', function() {
        $('#welcomeEmailModal').modal('hide');

        if (!currentWelcomeUserId) return;

        $.ajax({
            url: "{{ route('employer.launch_user1') }}",
            type: 'POST',
            data: {
                user_id: currentWelcomeUserId,
                _token: '{{ csrf_token() }}'
            },
            success: function(res) {
                alert(res.message);
                $('#employeesTable').DataTable().ajax.reload();
            },
            error: function() {
                alert("Failed to send welcome email.");
            }
        });
    });
</script>
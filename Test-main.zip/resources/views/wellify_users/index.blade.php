@extends('layouts.app')
@include('common.header')
@include('common.sidebar')
<!-- Datatable to Show Employers List -->
<section class="main_card">
    <nav>
        <div class="nav nav-tabs d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block justify-content-between" id="nav-tab"
            role="tablist">
            <div
                class="tabs_buttons d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">
                <button class="nav-link active mb-xxl-0 mb-xl-0  mb-lg-0 mb-md-0 mb-2" id="nav-home-tab"
                    data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home"
                    aria-selected="true">Active Employers</button>
                <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile"
                    type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Inactive
                    Employers</button>
            </div>
            <div class="filter d-flex align-items-center gap-2 mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-5">
                <select class="form-select select_box" id="sortFilter">
                    <option value="">Sort by</option>
                    <option value="today">Today</option>
                    <option value="last_week">Last week</option>
                    <option value="last_month">Last month</option>
                </select>
            </div>

        </div>
    </nav>

    <div class="tab-content" id="nav-tabContent">
        <!-- Active Employers Tab -->
        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"
            tabindex="0">
            <div class="cotainr-fluid">
                <div class="row">
                    <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                        <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Active Employers</h5>
                        <button class="button primary_btn" type="button" data-bs-toggle="modal"
                            data-bs-target="#add_new">Add New</button>
                    </div>
                </div>
                <div class="row pt_24">
                    <div class="col-12">
                        <table id="employersTable" class="table table-striped datatable">
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col">Organization Name</th>
                                    <th scope="col">Employer Email</th>
                                    <th scope="col">Username</th>
                                    <th scope="col">Employer Phone</th>
                                    <th scope="col">Contact Person</th>
                                    <th scope="col">CRM Link</th>
                                    {{-- <th scope="col">Notes</th> --}}
                                    <th scope="col">Timezone</th>
                                    <th scope="col">Payment Status</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Inactive Employers Tab -->
        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0">
            <div class="container-fluid">
                <div class="row">
                    <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                        <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">Inactive Employers</h5>
                        <div class="button_group d-flex gap-3">
                            <button class="button secondary_btn" type="button" data-bs-target="#bulk_restore_user"
                                data-bs-toggle="modal" id="bulkRestoreButton">
                                Restore
                            </button>
                        </div>
                    </div>
                </div>
                <div class="row pt_24">
                    <div class="col-12">
                        <table id="inactiveEmployersTable" class="table table-striped datatable">
                            <thead>
                                <tr>
                                    <th scope="col"><input type="checkbox" id="selectAllRestore"></th>
                                    <th scope="col">Employer Name</th>
                                    <th scope="col">Employer Email</th>
                                    <th scope="col">Username</th>
                                    <th scope="col">Employer Phone</th>
                                    <th scope="col">Contact Person</th>
                                    <th scope="col">Time Zone</th>
                                    <th scope="col">Deleted On</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!-- Add Employer Modal -->
<div class="modal fade" id="add_new" data-bs-keyboard="false" aria-labelledby="add_newLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">

            <!-- {{-- <form action="/wellify_users" method="POST" enctype="multipart/form-data"> --}} -->

            <div class="modal-header">
                <h3 class="modal-title fs-5" id="add_newLabel">Add Employer</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="addEmployerForm" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="container-fluid p-0">
                        <!-- {{-- @if ($errors->any())
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif --}} -->
                        <div id="formErrors"></div>
                        <div class="row">
                            <h5 class="mb-3">Basic Details</h5>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="organization" class="form-label">Employer Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="organization" class="form-control input"
                                    placeholder="Enter employer name" id="organization"
                                    value="{{ old('organization') }}" maxlength="50" pattern="[A-Za-z0-9 ]+" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="first_name" class="form-label">First Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="first_name" class="form-control input"
                                    placeholder="Enter first name" id="first_name" value="{{ old('first_name') }}"
                                    maxlength="25" pattern="[A-Za-z0-9 ]+" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="last_name" class="form-label">Last Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="last_name" class="form-control input"
                                    placeholder="Enter last name" id="last_name" value="{{ old('last_name') }}"
                                    maxlength="25" pattern="[A-Za-z0-9 ]+" required>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="file" class="form-label">Employer Logo</label>
                                <input type="file" name="profile_picture" id="profile_picture"
                                    class="form-control input" accept="image/jpeg,image/png,image/jpg,image/gif">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="email" class="form-label">Employer Email<span
                                        class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control input"
                                    placeholder="Enter employer email" id="email" value="{{ old('email') }}" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="mobile_phone" class="form-label">Employer Phone<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="mobile_phone" class="form-control input"
                                    placeholder="Enter employer phone" id="mobile_phone"
                                    value="{{ old('mobile_phone') }}" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="username" class="form-label">Username<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="username" class="form-control input"
                                    placeholder="Enter username" id="username" value="{{ old('username') }}"
                                    maxlength="30" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="user_timezone" class="form-label">Timezone</label>
                                <select name="user_timezone_id" id="user_timezone_id" class="form-control input">
                                    <option value="">Select Timezone</option>
                                    @foreach ($timezones as $timezone)
                                    <option value="{{ $timezone->id }}"
                                        {{ old('user_timezone') == $timezone->id ? 'selected' : '' }}>
                                        {{ $timezone->tz_identifier }} ({{ $timezone->utc_offset }})
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="licenses" class="form-label">License<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="licenses" class="form-control input"
                                    placeholder="Enter license" id="licenses" value="{{ old('licenses') }}"
                                    value="7856987" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="setup_fee" class="form-label">Setup Fee <small>(One Time)</small><span
                                        class="text-danger">*</span></label>
                                <input type="tel" min="1" name="setup_fee" id="setup_fee" class="form-control input"
                                    required placeholder="Enter setup fee">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="program_periods" class="form-label">Program Period
                                    <small>(Days)</small><span class="text-danger">*</span></label>
                                <input type="tel" name="program_periods" class="form-control input"
                                    placeholder="Enter program period days" min="1" max="365" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="number_of_users" class="form-label">Number of Slots <span
                                        class="text-danger">*</span></label>
                                <input type="number" name="number_of_users" class="form-control input"
                                    placeholder="Enter number of slots" min="0" required>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="CRM_link" class="form-label">CRM Link</label>
                                <input type="url" name="CRM_link" class="form-control input"
                                    placeholder="Enter CRM link (e.g., https://crm.example.com)" id="CRM_link" required>
                                <small class="text-muted" style="padding: inherit;margin-left: 40px;">e.g.,
                                    https://crm.example.com</small>
                                <div class="invalid-feedback">
                                    Please enter a valid URL (e.g., https://crm.example.com).
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <label for="notes" class="form-label">Notes</label>
                                <textarea class="form-control input rounded-3" name="notes" id="notes"
                                    rows="3"></textarea>
                            </div>
                            <div class="col-12">
                                <hr class="hr">
                            </div>
                            <h5 class="mb-3">Address Details</h5>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="office" class="form-label">Office</label>
                                <input type="text" name="office" placeholder="Enter office" class="form-control input"
                                    id="office" value="{{ old('office') }}">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="city" class="form-label">City</label>
                                <input type="text" name="city" placeholder="Enter city" class="form-control input"
                                    id="city" value="{{ old('city') }}">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="state" class="form-label">State</label>
                                <input type="text" name="state" placeholder="Enter state" class="form-control input"
                                    id="state" value="{{ old('state') }}">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="country" class="form-label">Country</label>
                                <input type="text" name="country" class="form-control input" placeholder="Enter country"
                                    id="country" value="{{ old('country') }}">
                            </div>
                            <!-- {{-- <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control input" id="password" required  >
                                 </div> --}} -->

                        </div>
                    </div>
            </div>
            <div class="modal-footer gap-3">
                <!-- {{-- <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Close</button> --}} -->
                <button type="button" class="button cancel_button m-0 modal-close-btn"
                    data-bs-dismiss="modal">Close</button>
                <!-- {{-- <button class="button primary_btn m-0" type="submit"  >Submit</button> --}} -->
                <button type="submit" class="button primary_btn m-0" id="submitBtn">
                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"
                        id="submitSpinner"></span>
                    <span class="btn-text">Submit</span>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Employer Modal -->
<div class="modal fade" id="edit_user" data-bs-keyboard="false" aria-labelledby="edit_userLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
        <div class="modal-content">

            <div class="modal-header">
                <h3 class="modal-title fs-5" id="edit_userLabel">Edit Employer</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editUserForm" action="" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="container-fluid p-0">
                        <div id="editUserErrors" class="alert alert-danger d-none"></div>
                        <div class="row">
                            <h5 class="mb-3">Basic Details</h5>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="organization" class="form-label">Employer Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="organization1" name="organization"
                                    maxlength="25" pattern="[A-Za-z0-9 ]+" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="first_name" class="form-label">First Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="first_name1" name="first_name"
                                    maxlength="25" pattern="[A-Za-z0-9 ]+" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="last_name" class="form-label">Last Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="last_name1" name="last_name"
                                    maxlength="25" pattern="[A-Za-z0-9 ]+" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="email" class="form-label">Employer Email<span
                                        class="text-danger">*</span></label>
                                <input type="email" class="form-control input" id="email1" name="email" readonly>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="mobile_phone" class="form-label">Employer Phone<span
                                        class="text-danger">*</span></label>
                                <input type="tel" class="form-control input" id="phone1" name="mobile_phone" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="username" class="form-label">Username<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="username1" name="username"
                                    maxlength="30" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="user_timezone" class="form-label">Timezone</label>
                                <select class="form-control input" id="user_timezone1" name="user_timezone_id">
                                    <option value="">Select Timezone</option>
                                </select>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="licenses1" class="form-label">License<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control input" id="licenses1" name="licenses" required
                                    value="7856987">
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="number_of_users" class="form-label">Number of Slots <span
                                        class="text-danger">*</span></label>
                                <input type="number" name="number_of_users" class="form-control input"
                                    placeholder="Enter number of slots" min="0" id="number_of_users1" required>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="CRM_link1" class="form-label">CRM Link</label>
                                <input type="url" name="CRM_link" class="form-control input"
                                    placeholder="Enter CRM link (e.g., https://crm.example.com)" id="CRM_link1"
                                    required>
                                <small class="text-muted" style="padding: inherit;margin-left: 40px;">e.g.,
                                    https://crm.example.com</small>
                                <div class="invalid-feedback">
                                    Please enter a valid URL (e.g., https://crm.example.com).
                                </div>
                            </div>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="profile_picture" class="form-label w-100">Employer Logo</label>
                                <input type="file" class="form-control input" id="profile_picture1"
                                    name="profile_picture" accept="image/*">
                                <div id="currentProfilePicture" class="mt-2"></div>
                            </div>
                            <div class="col-12 mb-3">
                                <label for="notes1" class="form-label">Notes</label>
                                <textarea class="form-control input rounded-3" name="notes" id="notes1"
                                    rows="3"></textarea>
                            </div>
                            <div class="col-12">
                                <hr class="hr">
                            </div>

                            <h5 class="mb-3">Address Details</h5>

                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="office" class="form-label">Office</label>
                                <input type="text" class="form-control input" id="office1" name="office">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="city" class="form-label">City</label>
                                <input type="text" class="form-control input" id="city1" name="city">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="state" class="form-label">State</label>
                                <input type="text" class="form-control input" id="state1" name="state">
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-12 mb-3">
                                <label for="country" class="form-label">Country</label>
                                <input type="text" class="form-control input" id="country1" name="country">
                            </div>
                        </div>
                    </div>
            </div>
            <div class="modal-footer gap-3">
                {{-- <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Cancel</button> --}}
                <button type="button" class="button cancel_button m-0 modal-close-btn"
                    data-bs-dismiss="modal">Cancel</button>
                {{-- <button type="submit" class="button primary_btn m-0">Update</button> --}}
                <button type="submit" class="button primary_btn m-0" id="updateBtn">
                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"
                        id="updateSpinner"></span>
                    <span class="btn-text">Update</span>
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<!-- View Employer Modal -->
<div class="modal fade" id="view_user" data-bs-keyboard="false" aria-labelledby="view_userLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title fs-5" id="view_userLabel">View Employer</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="view_user_content">

                </div>
            </div>
            <div class="modal-footer gap-3">
                <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Employer Modal -->
<div class="modal fade" id="delete_user" data-bs-keyboard="false" aria-labelledby="delete_userLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="deleteUserForm">
                @csrf
                @method('DELETE')
                <input type="hidden" id="delete_user_id" name="user_id" value="">
                <div class="modal-body">
                    <div class="container-fluid px-0 py-3">
                        <div class="row">
                            <div class="col-12 text-center">
                                @php
                                $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                                'staging/public/warning.svg',
                                now()->addHour() // Link expires in 1 hour
                                );
                                @endphp
                                <img src="{{    $warningImageUrl }}" alt="warning icon" class="img-fluid">
                                <h4 class="mt-4 text-danger">Delete This Employer?</h4>
                                <p class="mt-3 line_height_30"> This employer will move to recently deleted <br>
                                    Are you sure you want to continue?</p>
                            </div>
                            <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                                <button type="button" class="button cancel_button m-0"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button class="button primary_btn m-0 warning_button" type="submit">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Restore Employer Modal -->
<div class="modal fade" id="restore_user" data-bs-keyboard="false" tabindex="-1" aria-labelledby="restore_userLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                            @php
                            $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                            'staging/public/warning.svg',
                            now()->addHour() // Link expires in 1 hour
                            );
                            @endphp
                            <img src=" {{ $warningImageUrl }}" alt="warning icon" class="img-fluid">
                            <h4 class="mt-4 text-success">Restore Employer?</h4>
                            <p class="mt-3 line_height_30">
                                Selected employer will be restored <br>
                                Are you sure you want to continue?
                            </p>
                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0" data-bs-dismiss="modal"
                                tabindex="-1">Cancel</button>
                            <button class="button primary_btn m-0 confirm-restore-btn" type="button"
                                tabindex="-1">Restore</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bulk Restore Employer Modal -->
<div class="modal fade" id="bulk_restore_user" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="bulk_restore_userLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                            @php
                            $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                            'staging/public/warning.svg',
                            now()->addHour() // Link expires in 1 hour
                            );
                            @endphp
                            <img src="{{ $warningImageUrl }}" alt="warning icon" class="img-fluid">
                            <h4 class="mt-4 text-success">Restore Employers?</h4>
                            <p class="mt-3 line_height_30">
                                Selected employers will be restored.<br>
                                Are you sure you want to continue?
                            </p>
                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0"
                                data-bs-dismiss="modal">Cancel</button>
                            <button class="button primary_btn m-0 confirm-bulk-restore-btn"
                                type="button">Restore</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="send_welcome_modal" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="send_welcome_modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                            @php
                            $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                            'staging/public/warning.svg',
                            now()->addHour() // Link expires in 1 hour
                            );
                            @endphp
                            <img src="{{ $warningImageUrl}}" alt="Mail Icon" class="img-fluid">
                            <h4 class="mt-4" style="color: #52ab17;">Send Welcome Email?</h4>
                            <p class="mt-3 line_height_30">
                                Do you want to send Welcome Email to the following employer?
                                <br>
                                <strong id="employerInfo" class="d-block mt-2 text-dark"></strong>
                            </p>
                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0"
                                data-bs-dismiss="modal">Cancel</button>
                            <button id="confirmSendEmail" class="button primary_btn m-0"
                                style="background-color: #52ab17; border-color: #52ab17;">
                                Send Email
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="resend_welcome_modal" tabindex="-1" aria-labelledby="resendWelcomeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                            @php
                            $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                            'staging/public/warning.svg',
                            now()->addHour() // Link expires in 1 hour
                            );
                            @endphp
                            <img src="{{ $warningImageUrl }}" alt="Mail Icon" class="img-fluid">
                            <h4 class="mt-4" style="color: #FFA500;">Resend Welcome Email?</h4>
                            <p class="mt-3 line_height_30">
                                Welcome Email have already been sent to:
                                <br>
                                <strong id="resendEmployerInfo" class="d-block mt-2 text-dark"></strong>
                                <br>
                                Do you want to send them again?
                            </p>
                        </div>
                        <div class="col-12 d-flex justify-content-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0"
                                data-bs-dismiss="modal">Cancel</button>
                            <button id="confirmResendEmail" class="button primary_btn m-0"
                                style="background-color: #FFA500; border-color: #FFA500;">
                                Resend Email
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="pending_payment_modal" tabindex="-1" aria-labelledby="pendingPaymentModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body delete">
                <div class="container-fluid px-0 py-3">
                    <div class="row">
                        <div class="col-12 text-center">
                            @php
                            $warningImageUrl = Storage::disk('s3')->temporaryUrl(
                            'staging/public/warning.svg',
                            now()->addHour() // Link expires in 1 hour
                            );
                            @endphp
                            <img src="{{ $warningImageUrl }}" alt="Pending Icon" class="img-fluid">
                            <h4 class="mt-4 text-secondary">Payment Pending</h4>
                            <p class="mt-3 line_height_30">
                                This employer has not paid the setup fee yet.<br>
                                Please wait until payment is complete to send Welcome Email.
                                <br>
                                <strong id="pendingEmployerInfo" class="d-block mt-2 text-dark"></strong>
                            </p>
                        </div>
                        <div class="col-12 d-flex justify-content-center gap-3 mt-3">
                            <button type="button" class="button cancel_button m-0"
                                data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
</script>
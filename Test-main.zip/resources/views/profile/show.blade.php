@extends('layouts.app')
@include('common.header')
@include('common.sidebar')

<section class="main_card">
    <div class="container-fluid">
        <div class="row">
            <div class="title_section d-xxl-flex d-xl-flex d-lg-flex d-md-flex d-block">
                <h5 class="mb-xxl-0 mb-xl-0 mb-lg-0 mb-md-0 mb-3">User Profile</h5>
                <button class="button primary_btn" type="button" id="editProfile">
                    Edit Profile
                </button>
            </div>
        </div>
        <!-- profile details section -->
        <!-- @php
        use Illuminate\Support\Facades\Auth;
        use Illuminate\Support\Facades\Storage;
        $user = Auth::user();
        $defaultAvatar = asset('assets/images/default_logo.jfif');
        $profilePicUrl = $defaultAvatar;

        if ($user->profile_picture) {
        $s3Path = 'staging/users/' . $user->profile_picture;

        try {
        $profilePicUrl = Storage::disk('s3')->temporaryUrl(
        $s3Path,
        now()->addMinutes(10)
        );
        } catch (Exception $e) {
        // fallback to default if URL generation fails
        $profilePicUrl = $defaultAvatar;
        }
        }
        @endphp -->
        @php
            $user = \Illuminate\Support\Facades\Auth::user();
            $defaultAvatar = asset('assets/images/default_logo.jfif');
            $profilePicUrl = $defaultAvatar;

            if ($user->profile_picture) {
                $s3Path = 'staging/users/' . $user->profile_picture;

                try {
                    $profilePicUrl = \Illuminate\Support\Facades\Storage::disk('s3')->temporaryUrl(
                        $s3Path,
                        now()->addMinutes(10)
                    );
                } catch (Exception $e) {
                    $profilePicUrl = $defaultAvatar;
                }
            }
        @endphp

    <form method="POST" action="{{ route('profile.update') }}" enctype="multipart/form-data" id="profileForm">
        @csrf
        <article id="profile_wrapper">
            <div class="container-fluid card_borderd mt_24">
                <div class="row ">
                    <div class="col-xxl-5 col-xl-12 col-lg-12 col-md-12 col-12 profile_left">
                        <div class="row align-items-center">
                            <div class="col-xxl-4 col-xl-3 col-lg-3 col-md-12 col-12 mb-3 d-xxl-block d-xl-flex d-lg-flex d-md-flex d-flex justify-content-center">
                                <div class="avatar-preview rounded-circle position-relative">
                                    <div class="avatar-edit d-none" id="avatar-edit">
                                        <input type="file" id="imageUpload" name="profile_picture" accept=".png, .jpg, .jpeg">
                                        <label for="imageUpload"
                                            class="d-flex align-items-center justify-content-center bg-white rounded-circle mb-0 editavatar_icon">
                                            <img src="{{asset('assets/images/edit.svg')}}" alt="">
                                        </label>
                                    </div>

                                    <!-- <div id="imagePreview" class="rounded-circle user_profile_image">
                                    </div> -->
                                    <div id="imagePreview" class="rounded-circle user_profile_image" style="background-image: url('{{ $profilePicUrl }}');">

                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-8 col-xl-9 col-lg-9 col-md-12 col-12">
                                <!-- <input type="text"
                                    class="form-control form_profile mb-3 text-xxl-start text-xl-start text-lg-start text-md-center text-center" name="organization"
                                    value="{{ $user->organization }}" tabindex="-1" disabled> -->
                                    <p>{{$user->organization}}</p>
                                <!-- <input type="text"
                                    class="form-control form_profile text-underline text-primary mb-3 text-xxl-start text-xl-start text-lg-start text-md-center text-center" name="email"
                                    value="{{$user->email}}" tabindex="-1" disabled> -->
                                    <p>{{$user->email}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-7 col-xl-12 col-lg-12 col-md-12 col-12 d-xxl-flex align-items-center">
                        <div class="row mt-xxl-0 mt-xl-0 mt-lg-4 mt-md-4 mt-4">
                            <div class="mb-3 col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-12 ">
                                <div class="row align-items-center">
                                    <div class="col-xxl-4">
                                        <label class="form-label fw-bold mb-0 text-nowrap" for="userId">User Name :</label>
                                    </div>
                                    <div class="col-xxl-8">
                                        <input type="text" class="form-control form_profile" id="username" name="username"
                                            value="{{ old('username', $user->username) }}" tabindex="-1" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3 col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-12">
                                <div class="row align-items-center">
                                    <div class="col-xxl-4">
                                        <label class="form-label fw-bold mb-0 text-nowrap"
                                            for="registered">Registered :</label>
                                    </div>
                                    <div class="col-xxl-8">
                                        <!-- <input type="text" class="form-control form_profile" id="registered"
                                            value="{{$user->created_at}}" tabindex="-1" disabled> -->
                                            <p style="margin-top:15px;">{{ $user->created_at->format('j F Y') }}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3 col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12">
                                <div class="row align-items-center">
                                    <div class="col-xxl-4">
                                        <label class="form-label fw-bold mb-0 text-nowrap" for="timeZone">
                                            Time zone :</label>
                                    </div>
                                    <div class="col-xxl-8">
                                        <!-- <select name="timezone_id" class="form-select form-control form_profile" aria-label="Default select example" tabindex="-1" id="timeZone" disabled>
                                            @foreach($timezones as $timezone)
                                            <option value="{{ $timezone->id }}" {{ $user->timezone_id == $timezone->id ? 'selected' : '' }}>
                                                {{ $timezone->tz_identifier }}
                                            </option>
                                            @endforeach
                                        </select> -->
                                        <select name="timezone_id" class="form-select form-control form_profile" id="timeZone" aria-label="Default select example" tabindex="-1" disabled>
                                            @foreach($timezones as $timezone)
                                                <option value="{{ $timezone->id }}"
                                                    {{ $user->user_timezone_id == $timezone->id ? 'selected' : '' }}>
                                                    {{ $timezone->tz_identifier }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3 col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12">
                                <div class="row align-items-center">
                                    <div class="col-xxl-4">
                                        <label class="form-label fw-bold mb-0 text-nowrap" for="status">
                                            Status :</label>
                                    </div>
                                    <div class="col-xxl-8">
                                        <select class="form-select form-control form_profile text-success" aria-label="Default select example" tabindex="-1" id="status" name="status" disabled>
                                            <option value="1" {{ $user->status ? 'selected' : '' }}>Active</option>
                                            <option value="0" {{ !$user->status ? 'selected' : '' }}>Inactive</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid p-0 mt_24 ">
                <div class="row">
                    <div class="col-xxl-6 col-xl-12 col-lg-12 col-md-12 col-12 mb-4">
                        <div class="container-fluid border_green border-radius_12 h-100">
                            <div class="row">
                                <div class="col-12 card_header">
                                    <h6 class="text-white fs_18 fw- mb-0">Personal Information</h6>
                                </div>
                            </div>
                            <div class="row px-2 py-3">
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label class="form-label text-nowrap mb-1" for="first_name">First Name</label>
                                    <input type="text" class="form-control form_profile" id="first_name" name="first_name"
                                        value="{{$user->first_name}}" tabindex="-1" disabled>
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label class="form-label text-nowrap mb-1" for="last_name">Last Name</label>
                                    <input type="text" class="form-control form_profile" id="last_name" name="last_name"
                                        value="{{$user->last_name}}" tabindex="-1" disabled>
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label class="form-label text-nowrap mb-1" for="phone">Phone</label>
                                    <input type="tel" class="form-control form_profile" id="phone" name="mobile_phone"
                                        value="{{$user->mobile_phone}}" tabindex="-1" disabled>
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label class="form-label text-nowrap mb-1" for="contactPersonphone">Contact
                                        Person Phone</label>
                                    <input type="tel" class="form-control form_profile" id="contactPersonphone" name="work_phone"
                                        value="{{$user->work_phone}}" tabindex="-1" disabled>
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label class="form-label text-nowrap mb-1" for="city">City</label>
                                    <input type="text" class="form-control form_profile" id="phone" name="city"
                                        value="{{$user->city}}" tabindex="-1" disabled>
                                </div>
                                 <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label class="form-label text-nowrap mb-1" for="state">State</label>
                                    <input type="text" class="form-control form_profile" id="phone" name="state"
                                        value="{{$user->state}}" tabindex="-1" disabled>
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label class="form-label text-nowrap mb-1" for="state">Country</label>
                                    <input type="text" class="form-control form_profile" id="phone" name="country"
                                        value="{{$user->country}}" tabindex="-1" disabled>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-6 col-xl-12 col-lg-12 col-md-12 col-12 mb-4">
                        <div class="container-fluid border_green border-radius_12 h-100">
                            <div class="row">
                                <div class="col-12 card_header">
                                    <h6 class="text-white fs_18 fw- mb-0">Other Information</h6>
                                </div>
                            </div>
                            <div class="row px-2 py-3">
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label class="form-label text-nowrap mb-1" for="totalEmp">Total
                                        Employees</label>
                                        <p>{{$totalEmployees}}</p>
                                    <!-- <input type="tel" class="form-control form_profile" id="totalEmp" name=""
                                        value="{{$totalEmployees}}" tabindex="-1" disabled> -->
                                </div>
                                 <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12 mb-3">
                                    <label class="form-label text-nowrap mb-1"
                                        for="department">Departments</label>
                                        <p>{{$totalDepartments}}</p>
                                    <!-- <input type="tel" class="form-control form_profile" id="department"
                                        value="{{$totalDepartments}}" tabindex="-1" disabled> -->
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12">
                                    <label class="form-label text-nowrap mb-1">Completed Classes</label>
                                    <p>{{$totalCompletedClasses}}</p>
                                </div>
                                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-12">
                                    <label class="form-label text-nowrap mb-1">Completed Activities</label>
                                    <p>{{$totalCompletedActivities}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row d-none" id="btnsGroupProfile">
                    <div class="col-12 d-flex justify-content-end gap-3">
                        <button type="button" class="button cancel_button m-0" id="closebtn" tabindex="-1">Close</button>
                        <button class="button primary_btn m-0" type="submit" tabindex="-1"
                            id="updateProfile">Update</button>
                    </div>
                </div>
            </div>
        </article>
        </form>
    </div>
</section>

<!-- <script>
    var editProfileBtn = document.getElementById("editProfile");
    var profileInputs = document.querySelectorAll("#profile_wrapper .form-control");
    var updateRow = document.getElementById("btnsGroupProfile");
    var updateProfile = document.getElementById("updateProfile");
    var closeBtn = document.getElementById("closebtn");
    var avatarEdit = document.getElementById("avatar-edit");

    // Enable inputs and show buttons on Edit Profile click
    editProfileBtn.addEventListener("click", () => {
        profileInputs.forEach(input => {
            input.classList.add("input");
            input.disabled = false;
        });
        updateRow.classList.remove("d-none");
        avatarEdit.classList.remove("d-none");
    });

    // Disable inputs and hide buttons on Close click
    closeBtn.addEventListener("click", () => {
        profileInputs.forEach(input => {
            input.classList.remove("input");
            input.disabled = true;
        });
        updateRow.classList.add("d-none");
        avatarEdit.classList.add("d-none");
    });

    updateProfile.addEventListener("click", () => {
        profileInputs.forEach(input => {
            input.classList.remove("input");
            input.disabled = true;
        });
        updateRow.classList.add("d-none");
        avatarEdit.classList.add("d-none");
    });

    // Image preview function unchanged
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#imagePreview').css('background-image', 'url(' + e.target.result + ')');
                $('#imagePreview').hide();
                $('#imagePreview').fadeIn(650);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imageUpload").change(function () {
        readURL(this);
    });

</script> -->

<script>
document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('profileForm');

  // Input selectors
  const firstNameInput = form.querySelector('input[name="first_name"]');
  const lastNameInput = form.querySelector('input[name="last_name"]');
  const mobilePhoneInput = form.querySelector('input[name="mobile_phone"]');
  const workPhoneInput = form.querySelector('input[name="work_phone"]');
  const cityInput = form.querySelector('input[name="city"]');
  const stateInput = form.querySelector('input[name="state"]');
  const countryInput = form.querySelector('input[name="country"]');

  // Helper regex patterns
  const specialCharRegex = /[^a-zA-Z0-9\s\-]/g; // allow letters, numbers, space and dash only
  const nameInvalidChars = /[^a-zA-Z\s]/g; // only letters and space allowed
  const noNumbersRegex = /[0-9]/g;
  const phoneAllowedChars = /[0-9\-]/g;

  // Prevent special characters in all text fields except phone (block as user types)
  function preventSpecialChars(event) {
    const input = event.target;
    const val = input.value;

    // Remove special chars immediately (except for phone inputs)
    if (!['mobile_phone', 'work_phone'].includes(input.name)) {
      input.value = val.replace(specialCharRegex, '');
    }
  }

  // Prevent numbers in names, city, state, country on input
  function preventNumbers(event) {
    const input = event.target;
    input.value = input.value.replace(noNumbersRegex, '');
  }

  // Format phone input with dashes automatically
  function formatPhoneInput(event) {
    let val = event.target.value.replace(/\D/g, ''); // Remove all non-digit chars
    if (val.length > 10) val = val.slice(0, 10); // limit to 10 digits

    // Insert dashes after 3rd and 6th digit
    if (val.length > 6) {
      val = val.slice(0,3) + '-' + val.slice(3,6) + '-' + val.slice(6);
    } else if (val.length > 3) {
      val = val.slice(0,3) + '-' + val.slice(3);
    }

    event.target.value = val;
  }

  // Validate phones on blur or submit (check length exactly 12 including dashes)
  function validatePhoneLength(input) {
    // Valid format: 3 digits - 3 digits - 4 digits = total 12 chars
    return input.value.length === 12;
  }

  // Attach input event listeners
  [firstNameInput, lastNameInput, cityInput, stateInput, countryInput].forEach(input => {
    input.addEventListener('input', (e) => {
      preventSpecialChars(e);
      preventNumbers(e);
    });
  });

  [mobilePhoneInput, workPhoneInput].forEach(input => {
    input.addEventListener('input', formatPhoneInput);
    input.addEventListener('input', (e) => {
      // Allow only numbers and dash
      const allowed = e.target.value.match(phoneAllowedChars);
      e.target.value = allowed ? allowed.join('') : '';
    });
  });

  // On form submit validate all fields
  form.addEventListener('submit', function (e) {
    let errors = [];

    // Check first name and last name non-empty and no numbers or special chars
    if (!firstNameInput.value.trim()) {
      errors.push('First name is required');
    }
    if (!lastNameInput.value.trim()) {
      errors.push('Last name is required');
    }

    // Phone numbers: optional but if entered, must be exactly 10 digits formatted
    if (mobilePhoneInput.value.trim() && !validatePhoneLength(mobilePhoneInput)) {
      errors.push('Mobile phone must be 10 digits formatted as 123-456-7890');
    }
    if (workPhoneInput.value.trim() && !validatePhoneLength(workPhoneInput)) {
      errors.push('Work phone must be 10 digits formatted as 123-456-7890');
    }

    // City, State, Country: no numbers or special chars
    if (cityInput.value.match(noNumbersRegex)) {
      errors.push('City cannot contain numbers');
    }
    if (stateInput.value.match(noNumbersRegex)) {
      errors.push('State cannot contain numbers');
    }
    if (countryInput.value.match(noNumbersRegex)) {
      errors.push('Country cannot contain numbers');
    }

    if (errors.length > 0) {
      e.preventDefault();
      alert(errors.join('\n'));
      return false;
    }
  });
});
</script>



<script>
    // Define all variables
    var editProfileBtn = document.getElementById("editProfile");
    var profileInputs = document.querySelectorAll("#profileForm .form-control, #profileForm input[type='file']");
    var updateRow = document.getElementById("btnsGroupProfile");
    var closeBtn = document.getElementById("closebtn");
    var avatarEdit = document.getElementById("avatar-edit"); // Define this properly

    // Enable inputs and show buttons on Edit Profile click
    editProfileBtn.addEventListener("click", () => {
        profileInputs.forEach(input => {
            input.classList.add("input");
            input.disabled = false;
        });
        updateRow.classList.remove("d-none");
        avatarEdit.classList.remove("d-none");
    });

    // Disable inputs and hide buttons on Close click
    closeBtn.addEventListener("click", () => {
        profileInputs.forEach(input => {
            input.classList.remove("input");
            input.disabled = true;
        });
        updateRow.classList.add("d-none");
        avatarEdit.classList.add("d-none");
    });

    // Preview image before upload
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                var imagePreview = document.getElementById("imagePreview");
                imagePreview.style.backgroundImage = 'url(' + e.target.result + ')';
                imagePreview.style.display = "none";
                imagePreview.style.backgroundSize = "cover";
                imagePreview.style.backgroundPosition = "center";
                imagePreview.style.borderRadius = "50%";
                $(imagePreview).fadeIn(650);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    // Attach to input[type=file]
    document.getElementById("imageUpload").addEventListener("change", function () {
        readURL(this);
    });

    editProfileBtn.addEventListener("click", () => {
        profileInputs.forEach(input => {
            input.classList.add("input");
            input.disabled = false;
        });
        updateRow.classList.remove("d-none");
        avatarEdit.classList.remove("d-none");

        // enable timezone select explicitly (if not included in profileInputs)
        document.getElementById('timeZone').disabled = false;
    });


</script>


    @if(session('success'))
        <script>
            swal({
                title: "Success!",
                text: "{{ session('success') }}",
                icon: "success",
                button: "OK",
            });
        </script>
    @elseif(session('error'))
        <script>
            swal({
                title: "Oops!",
                text: "{{ session('error') }}",
                icon: "error",
                button: "OK",
            });
        </script>
    @endif


<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class EmployerRequestedSlots extends Mailable
{
    use Queueable, SerializesModels;
    public $employer;
    public $requestedSlots;

    public function __construct($employer, $requestedSlots)
    {
        $this->employer = $employer;
        $this->requestedSlots = $requestedSlots;
    }

    public function build()
    {
        return $this->subject('Employer Requested Additional Slots')
            ->view('emails.employer_requested_slots')
            ->with([
                'employer' => $this->employer,
                'requestedSlots' => $this->requestedSlots
            ]);
    }
}
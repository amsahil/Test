<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class EmployeeWelcomeMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct($personalizedContent, $username, $email, $password)
    {
        $this->personalizedContent = $personalizedContent;
        $this->username = $username;
        $this->email = $email;
        $this->password = $password;
    }

    public function build()
    {
        return $this->subject('Welcome to Wellify')
            ->view('emails.employee_welcome')
            ->with([
                'content' => $this->personalizedContent,
                'username' => $this->username,
                'email' => $this->email,
                'password' => $this->password,
            ]);
    }
}

<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use App\Models\WellifyUser;

class EmployerCreatedMail extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    public $password;

    public function __construct(WellifyUser $user,$password)
    {
        $this->user = $user;
        $this->password = $password;

    }

    public function build()
    {
        return $this->subject('Welcome to Wellify!')
            ->view('emails.employer_created')
            ->with([
                'first_name' => $this->user->first_name,
                'email' => $this->user->email,
                'username' => $this->user->username,
                'password' => $this->user->password,

            ]);
    }
}

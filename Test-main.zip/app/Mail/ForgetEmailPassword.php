<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ForgetEmailPassword extends Mailable
{
    use Queueable, SerializesModels;

    public $otp;
    public $fullName;
    public $imagePath;

    public function __construct($otp = null, $fullName = null)
    {
        $this->otp = $otp;
        $this->fullName  = $fullName;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Wellify Password Reset OTP',
        );
    }

    public function content(): Content
    {
        Log::info("Sending OTP via Mailable: " . $this->otp);

        return new Content(
            view: 'emails.forgetPassword',
            with: [
                'otp' => $this->otp,
                'fullName ' => $this->fullName,
            ]
        );
    }

    public function attachments(): array
    {
        return [];
    }
}

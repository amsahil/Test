<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use App\Models\Staff;

class StaffWelcomeMail extends Mailable
{
    use Queueable, SerializesModels;

    public $personalizedContent;

    // public function __construct($mailData)
    // {
    //     $this->mailData = $mailData;
    // }

//   public function build()
// {
//     return $this->subject('Welcome to Wellify')
//                 ->view('emails.staff_welcome')
//                 ->with([
//                     'email' => $this->mailData['email'],
//                     'username' => $this->mailData['username'],
//                      'password' => $this->mailData['password']
//                 ]);
// } 
// public function build()
// {
//     return $this->subject('Welcome to Wellify')
//                 ->view('emails.staff_welcome')
//                 ->with([
//                     'email' => $this->mailData['email'],
//                     'username' => $this->mailData['username'],
//                     'password' => $this->mailData['password'],
//                     'customContent' => $this->mailData['customContent'] // Include custom content
//                 ]);
// }
public function __construct($personalizedContent, $username, $email, $password)
{
    $this->personalizedContent = $personalizedContent;
    $this->username = $username;
    $this->email = $email;
    $this->password = $password;
}

public function build()
{
    return $this->subject('Welcome to Wellify')
                ->view('emails.staff_welcome')
                ->with([
                    'content' => $this->personalizedContent,
                    'username' => $this->username,
                    'email' => $this->email,
                    'password' => $this->password,
                ]);
}
}
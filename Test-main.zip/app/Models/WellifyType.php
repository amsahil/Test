<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WellifyType extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_types';

    protected $fillable = [
        'name',
    ];

    public function moods()
    {
        return $this->hasMany(WellifyMood::class, 'wellify_types_id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyActivity;
use App\Models\Employer\Employee;

class WellifyAppUserActivityProgress extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_app_user_activity_progress';
    protected $casts = [
        'activity_id' => 'string',
    ];

    protected $fillable = [
        'user_id','mood_id','activity_id','is_completed','completed_at'
    ];

     public function classes()
    {
        return $this->belongsToMany(WellifyActivity::class, 'activity_id');
    }

    public function users()
    {
        return $this->belongsToMany(Employee::class, 'user_id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyClass;
use App\Models\WellifyQuiz;

class WellifyQuizOption extends Model
{
    use SoftDeletes;
    protected $table = 'wellify_class_quiz_options';

    protected $casts = [
        'class_id' => 'string'
    ];

    protected $fillable = [
        'class_id','quiz_id','option','media','status',
        'isAnswer','description'
    ];


    public function class()
    {
        return $this->belongsTo(WellifyClass::class, 'class_id');
    }

    public function quiz()
    {
        return $this->belongsTo(WellifyQuiz::class, 'quiz_id');
    }


}

<?php

namespace App\Models\Employer;

use App\Models\WellifyUser;
use App\Models\WellifyTimezone;
use App\Models\WellifySubscription;
use Illuminate\Database\Eloquent\Model;
use App\Models\WellifyUserClassProgress;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyAppUserActivityProgress;
use Illuminate\Contracts\Auth\CanResetPassword;
use Illuminate\Auth\Notifications\ResetPassword;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;


class Employee extends Authenticatable implements CanResetPassword
{
    use HasFactory;
    use Notifiable;
    use SoftDeletes;
    protected $table = 'wellify_app_users';

    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'password',
        'licenses',
        'user_timezone_id',
        'employer_id',
        'mobile_phone',
        'created_by',
        'city',
        'state',
        'country',
        'status',
        'is_active', // NEW: Field to track active/inactive employees
        'program_start_date', // NEW: Employee's program start date
        'program_end_date', // NEW: Employee's program end date
    ];
    protected $dates = ['deleted_at'];
    protected $casts = [
        'licenses' => 'array',
        'is_active' => 'boolean', // NEW: Cast as boolean
        'program_start_date' => 'date', // NEW: Cast as date
        'program_end_date' => 'date', // NEW: Cast as date
    ];

    // Optional: mutator for password hashing
    public function setPasswordAttribute($value)
    {
        if ($value) {
            $this->attributes['password'] = bcrypt($value);
        }
    }
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new ResetPassword($token));
    }

    // public function department()
    // {
    //     return $this->belongsTo(Department::class);
    // }
    // public function department()
    // {
    //     return $this->belongsTo(Department::class)->withDefault([
    //         'name' => 'Unassigned'
    //     ]);
    // }
    public function department()
    {
        return $this->belongsTo(Department::class)->withDefault([
            'name' => 'Unassigned'
        ]);
    }

    public function wellify_user()
    {
        return $this->belongsTo(WellifyUser::class, 'employer_id')->withDefault([
            'username' => 'Unassigned'
        ]);
    }
    public function classProgress()
    {
        return $this->hasMany(WellifyUserClassProgress::class, 'user_id', 'id');
    }
    public function activityProgress()
    {
        return $this->hasMany(WellifyAppUserActivityProgress::class, 'user_id', 'id');
    }
     public function timezone()
    {
        return $this->belongsTo(WellifyTimezone::class, 'user_timezone_id');
    }

    public function employer()
    {
        return $this->belongsTo(WellifyUser::class, 'employer_id');
    }

    public function subscriptions()
    {
        return $this->hasMany(WellifySubscription::class, 'app_user_id');
    }

}
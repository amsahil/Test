<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyClass;

class WellifyClassMedia extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_classes_media';
    protected $casts = [
        'class_id' => 'string'
    ];

    protected $fillable = [
        'class_id','media','media_type_id','description','sequence_no'
    ];


    public function classes()
    {
        return $this->belongsToMany(WellifyClass::class, 'class_id');
    }

    public function mediaTypes()
    {
        return $this->belongsToMany(WellifyClassMedia::class, 'id');
    }
}

<?php

namespace App\Models;

use App\Models\Employer\Employee;
use Illuminate\Database\Eloquent\Model;

class WellifySubscription extends Model
{
    protected $table = 'wellify_subscriptions';

    protected $fillable = [
        'employer_id',
        'app_user_id',
        'plan_id',
        'start_date',
        'end_date',
        'platform',
        'status',
        'is_employer_sponsored',
    ];

    public function employer()
    {
        return $this->belongsTo(WellifyUser::class, 'employer_id');
    }

    public function appUser()
    {
        return $this->belongsTo(Employee::class, 'app_user_id');
    }

    public function employees()
    {
        return $this->belongsToMany(Employee::class, 'wellify_subscription_employees', 'subscription_id', 'app_user_id')
            ->withPivot(['trial_start_date', 'trial_end_date', 'status'])
            ->withTimestamps();
    }

    public function plan()
    {
        return $this->belongsTo(WellifyPlans::class, 'plan_id');
    }

    public function user()
    {
        return $this->belongsTo(WellifyUser::class, 'employer_id');
    }

}

<?php

namespace App\Models;

use App\Models\WellifyMood;
use App\Models\WellifyLevel;
use App\Models\WellifyCategory;
use Illuminate\Database\Eloquent\Model;
use App\Models\WellifyClassMoodAssociation;
use Illuminate\Database\Eloquent\SoftDeletes;


class WellifyClass extends Model
{
    use SoftDeletes;

    protected $table = 'wellify_classes';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $dates = ['deleted_at'];
    protected $casts = [
        'id' => 'string','images' => 'array',
        'media_types' => 'array',
    ];

        protected $fillable = [
            'id','title','description','background_image',
            'category_id','level_id','duration',
            'points_on_completion','seeds_on_completion','prerequisite_course',
            'prerequisite_alternate','class_status','media_status'
        ];


    public function categories()
    {
        return $this->belongsToMany(WellifyCategory::class, 'category_id');
    }
    public function levels()
    {
        return $this->belongsTo(WellifyLevel::class, 'level_id');
    }

    public function seed()
    {
        return $this->belongsTo(WellifySeed::class, 'seed_id');
    }

    public function category()
    {
        return $this->belongsTo(WellifyCategory::class, 'category_id');
    }

    public function level()
    {
        return $this->belongsTo(WellifyLevel::class, 'level_id');
    }

    public function moods()
    {
        return $this->belongsToMany(
            WellifyMood::class,
            'wellify_class_mood_associations',
            'class_id',
            'mood_id'
        );
    }
    public function media()
    {
        return $this->hasMany(WellifyClassMedia::class, 'class_id','id');
    }

    public function quizzes()
    {
        return $this->hasMany(WellifyQuiz::class, 'class_id','id');
    }


}

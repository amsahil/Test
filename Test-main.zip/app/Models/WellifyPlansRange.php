<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class WellifyPlansRange extends Model
{
    use HasFactory;

    protected $table = 'wellify_subscription_plan_range';

    protected $fillable = [
        'plan_id',
        'users_range_min',
        'users_range_max',
        'mothly_price_per_user',
        'yearly_price_per_user',
    ];

    public function plan()
    {
        return $this->belongsTo(WellifyPlans::class, 'plan_id');
    }
}

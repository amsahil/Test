<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\WellifyClass;

class WellifyQuiz extends Model
{
    use SoftDeletes;
    protected $table = 'wellify_class_quiz';
    protected $casts = [
        'class_id' => 'string'
    ];

    protected $fillable = [
        'class_id','title',
        'media','status'
    ];

    public function options()
    {
        return $this->hasMany(WellifyQuizOption::class, 'quiz_id');
    }

    public function class()
    {
        return $this->belongsTo(WellifyClass::class, 'class_id');
    }

}

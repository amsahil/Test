<?php

namespace App\Models;

use App\Models\Employer\Department;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Tymon\JWTAuth\Contracts\JWTSubject;
use App\Models\WellifyTempAppUser;
use App\Models\WellifyClass;
use App\Models\WellifyUserClassProgress;
use App\Models\WellifyAppUserActivityProgress;
use App\Models\WellifyActivity;
use App\Models\Employer\Employee;



class WellifyUser extends Authenticable implements JWTSubject
{
    use HasFactory, Notifiable, HasRoles, SoftDeletes;
    protected $table = 'wellify_users';
    protected $guard_name = 'web';
    protected $dates = ['deleted_at'];

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'first_name','last_name','profile_picture','program_periods',
        'email','agree_tnc','mobile_phone','username',
        'password','user_timezone_id','supervisor_id',
        'organization','username','user_timezone','office','city','state','country','licenses',
        'CRM_link','notes','number_of_users', 'program_launch_date',
        'program_duration_days'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'program_launch_date' => 'date',
        ];
    }

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

     /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    /**set user profile image */
    public function getProfileImageAttribute($value){
        if(!$value){
            return url('images/userProfile.png');
        }
        return url('storage/profile_images/'.$value);
    }

    // The single department a user belongs to (for staff/users)
    public function department()
    {
        return $this->belongsTo(Department::class, 'department_id');
    }

    // The departments owned by the user as employer (multiple departments)
    public function departments()
    {
        return $this->hasMany(Department::class, 'employer_id', 'id');
    }


    public function timezone()
    {
        return $this->belongsTo(WellifyTimezone::class, 'user_timezone_id');
    }
    //relationship for temp app users where user is an employer
    public function tempAppUsersAsEmployer()
    {
        return $this->hasMany(WellifyTempAppUser::class, 'employer_id');
    }
    //relationship for temp app users where user is a creator
    public function tempAppUsersAsCreator()
    {
        return $this->hasMany(WellifyTempAppUser::class, 'created_by');
    }
    public function employees()
    {
        return $this->hasMany(Employee::class, 'employer_id', 'id');
    }
    public function completedClasses()
    {
        return WellifyClass::whereIn('id', function ($query) {
            $query->select('class_id')
                ->from('wellify_app_user_class_progress')
                ->whereIn('user_id', function ($subQuery) {
                    $subQuery->select('id')
                        ->from('wellify_app_users')
                        ->where('employer_id', $this->id);
                })
                ->where('is_completed', true); // Assuming 'status' indicates completion
        });
    }
    public function completedActivities()
    {
        return WellifyActivity::whereIn('activity_id', function ($query) {
            $query->select('activity_id')
                ->from('wellify_app_user_activity_progress')
                ->whereIn('user_id', function ($subQuery) {
                    $subQuery->select('user_id')
                        ->from('wellify_app_users')
                        ->where('employer_id', $this->id);
                })
                ->where('is_completed', true); // Assuming 'status' indicates completion
        });
    }
    public function getTotalCompletedClassesAttribute()
    {
        return $this->completedClasses()->count();
    }
    public function getTotalCompletedActivitiesAttribute()
    {
        return $this->completedActivities()->count();
    }

    public function supervisor()
    {
        return $this->belongsTo(WellifyUser::class, 'supervisor_id');
    }

    public function subordinates()
    {
        return $this->hasMany(WellifyUser::class, 'supervisor_id');
    }

    public function wellify_user()
    {
        return $this->belongsTo(WellifyUser::class, 'employer_id')->withDefault([
            'username' => 'Unassigned'
        ]);
    }


}
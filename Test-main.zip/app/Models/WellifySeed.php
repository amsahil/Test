<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WellifySeed extends Model
{
    use SoftDeletes;
    protected $table = 'wellify_seeds';

    protected $fillable = [
        'seed_name',
        'image',
        'seed_description',
        'status'
    ];

    public function growthStageMedia()
    {
        return $this->hasMany(WellifyGrowthStageMedia::class, 'seed_id', 'id');
    }

    public function growthStages()
    {
        return $this->hasManyThrough(
            WellifyGrowthStage::class,
            WellifyGrowthStageMedia::class,
            'seed_id',
            'id',
            'id',
            'growth_stage_id'
        );
    }

}

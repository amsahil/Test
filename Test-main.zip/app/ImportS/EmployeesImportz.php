<?php

namespace App\Imports;

use App\Models\Employer\Staff;
use App\Models\Employer\Department;
use Maatwebsite\Excel\Concerns\ToModel;
use Illuminate\Validation\Rule;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;

class EmployeesImportz implements ToCollection, WithHeadingRow
{
    private $employerId;
    public function __construct()
    {
        $this->employerId = session('selected_employer_id');
    }

    /**
     * to import excel file in employees table
     */

    public function collection(Collection $rows)
    {
        $employeesToInsert = [];
        $skippedEmployees = [];
        $existingEmployees = [];
        $processedPhoneNumbers = [];
        $processedEmails = [];
        $randomPassword = Str::random(10);

        foreach ($rows as $row) {
            if (empty(trim($row['first_name'])) || empty(trim($row['email']))) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'] ?? 'N/A',
                    'last_name' => $row['last_name'] ?? '',
                    'email' => $row['email'] ?? 'N/A',
                    'reason' => 'Missing employee details'
                ];
                continue;
            }


            $validateEmail = function ($email) {
                $email = trim($email);
                return filter_var($email, FILTER_VALIDATE_EMAIL)
                    && strpos($email, '@') !== false
                    && strpos(explode('@', $email)[1], '.') !== false;
            };

            $email = trim($row['email']);
            if (!$validateEmail($email)) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'reason' => 'Invalid email format'
                ];
                continue;
            }

            if (in_array($email, $processedEmails)) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'reason' => 'Duplicate email in import'
                ];
                continue;
            }


            $existingEmployee = Staff::where('email', $email)->first();
            if ($existingEmployee) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'reason' => 'Employee already exists',
                    'existing_department' => optional($existingEmployee->department)->name
                ];

                $existingEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'existing_department_id' => $existingEmployee->department_id
                ];

                continue;
            }

            $departmentName = trim($row['department_name'] ?? '');
            if (empty($departmentName)) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'reason' => 'Empty Department Name'
                ];
                continue;
            }


            $phoneNumber = trim($row['phone'] ?? '');
            if (empty($phoneNumber)) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'reason' => 'Phone number is blank'
                ];
                continue;
            }


            $cleanedPhone = preg_replace('/[^0-9]/', '', $phoneNumber);

            if (!preg_match('/^\d{10}$/', $cleanedPhone)) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'phone' => $phoneNumber,
                    'reason' => 'Invalid phone number format (must be 10 numeric digits)'
                ];
                continue;
            }


            if (in_array($cleanedPhone, $processedPhoneNumbers)) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'phone' => $phoneNumber,
                    'reason' => 'Duplicate phone number in import'
                ];
                continue;
            }


            $existingPhoneEmployee = Staff::where('mobile_phone', $cleanedPhone)->first();
            if ($existingPhoneEmployee) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'phone' => $phoneNumber,
                    'reason' => 'Phone number already exists',
                    'existing_employee' => $existingPhoneEmployee->first_name . ' ' . $existingPhoneEmployee->last_name
                ];
                continue;
            }


            $city = trim($row['city'] ?? '');
            $state = trim($row['state'] ?? '');
            $country = trim($row['country'] ?? '');

            $validateTextField = function ($field) {
                return preg_match('/^[a-zA-Z\s]*$/', $field);
            };

            if (!empty($city) && !$validateTextField($city)) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'city' => $city,
                    'reason' => 'City must contain only letters and spaces'
                ];
                continue;
            }

            if (!empty($state) && !$validateTextField($state)) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'state' => $state,
                    'reason' => 'State must contain only letters and spaces'
                ];
                continue;
            }

            if (!empty($country) && !$validateTextField($country)) {
                $skippedEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'country' => $country,
                    'reason' => 'Country must contain only letters and spaces'
                ];
                continue;
            }

            $processedPhoneNumbers[] = $cleanedPhone;
            $processedEmails[] = $email;

            $departmentEmployerId = $this->employerId;
            $department = Department::firstOrCreate(
                [
                    'employer_id' => $departmentEmployerId,
                    'name' => $departmentName
                ],
                [
                    'created_at' => now(),
                    'created_by' => Auth::id(),
                    'description' => ''
                ]
            );
            /**
             * to create random username
             */
            $wellnessWords = ['Zen', 'Calm', 'Breathe', 'Pulse', 'Glow', 'Mindful', 'Wellness', 'Harmony', 'Serene', 'Balance'];
            $randomDisplayName = $wellnessWords[array_rand($wellnessWords)] . '_' . rand(100, 999);

            $employeesToInsert[] = [
                'first_name'     => $row['first_name'],
                'last_name'      => $row['last_name'],
                'username'       => $randomDisplayName,
                'email'          => $email,
                'mobile_phone'   => $cleanedPhone,
                'department_id'  => $department->id,
                'city'           => $city,
                'state'          => $state,
                'country'        => $country,
                'created_at'     => now(),
                'updated_at'     => now(),
                'created_by'     => Auth::id(),
                'password' => Hash::make($randomPassword),
            ];
        }

        $importResult = [
            'new_employees_count' => count($employeesToInsert),
            'existing_employees_count' => count($existingEmployees),
            'skipped_employees_count' => count($skippedEmployees)
        ];


        if (!empty($employeesToInsert)) {
            try {
                $chunks = array_chunk($employeesToInsert, 100);
                foreach ($chunks as $chunk) {
                    Staff::insert($chunk);
                }

                Log::info('Employees Imported Successfully', $importResult);
            } catch (\Exception $e) {
                Log::error('Employee Import Error', [
                    'message' => $e->getMessage(),
                    'employees' => $employeesToInsert
                ]);


                $importResult['new_employees_count'] = 0;
                $importResult['skipped_employees_count'] += count($employeesToInsert);
            }
        }


        session([
            'import_result' => $importResult,
            'existing_employees' => $existingEmployees,
            'skipped_employees' => $skippedEmployees
        ]);
    }


    private function validateHeaders($row)
    {
        $rowArray = $row->toArray();
        $requiredHeaders = [
            'first_name',
            'last_name',
            'email',
            'phone',
            'department_name',
            'city',
            'state',
            'country',
            'licenses'
        ];

        $missingHeaders = [];

        foreach ($requiredHeaders as $header) {
            if (!array_key_exists($header, $rowArray)) {
                $missingHeaders[] = $header; // Collect missing headers
            }
        }

        if (!empty($missingHeaders)) {
            // Create a user-friendly message listing the missing headers
            $missingHeadersList = implode(', ', $missingHeaders);
            throw new \Exception("The following required headers are missing from the Excel sheet: {$missingHeadersList}.");
        }

        return true; // All required headers are present
    }
}

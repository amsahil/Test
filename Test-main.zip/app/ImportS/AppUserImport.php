<?php

namespace App\Imports;

use App\Models\Employer\Employee;
use App\Models\WellifyUser;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use App\Models\WellifyTempAppUser;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;

class AppUserImport implements ToCollection, WithHeadingRow
{
    protected $employerId;
    protected $userTimezoneId;
    public function __construct($employerId, $userTimezoneId = 1)
    {
        $this->employerId = $employerId;
        $this->userTimezoneId = $userTimezoneId ?: 1;
    }

    /**
     * to import excel file in employees table
     */
    public function collection(Collection $rows)
    {
                      Log::info('Employees Imported ', ['employer_id'=>$this->employerId]);

        $employeesToInsert = [];
        $skippedEmployees = [];
        $existingEmployees = [];
        $processedPhoneNumbers = [];
        $processedEmails = [];
        $latestImportId = DB::table('wellify_temp_app_users')->max('import_id');
        $nextImportId = $latestImportId ? $latestImportId + 1 : 1;
        $randomPassword = Str::random(10);
        $employer = WellifyUser::find($this->employerId);
        $maxAllowed = $employer->number_of_users;

        // Get all existing users
        $existingUsersCount = Employee::where('employer_id', $this->employerId)->count();

        $paidSlotsRemaining = max($maxAllowed - $existingUsersCount, 0);

        foreach ($rows as $row) {
            // Initial validations (first name and email)
            if (empty(trim($row['first_name'])) || empty(trim($row['email']))) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'] ?? 'N/A',
                    'last_name' => $row['last_name'] ?? '',
                    'email' => $row['email'] ?? 'N/A',
                    'mobile_phone'  => $row['mobile_phone'] ?? ($row['phone'] ?? 'N/A'),
                    'city'          => $row['city'] ?? 'N/A',
                    'office'          => $row['office'] ?? 'N/A',
                    'state'         => $row['state'] ?? 'N/A',
                    'country'       => $row['country'] ?? 'N/A',
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'error_message' => 'Missing employee details',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                continue;
            }

            // Email validation
            $validateEmail = function ($email) {
                $email = trim($email);
                return filter_var($email, FILTER_VALIDATE_EMAIL)
                    && strpos($email, '@') !== false
                    && strpos(explode('@', $email)[1], '.') !== false;
            };

            $email = trim($row['email']);
            if (!$validateEmail($email)) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'mobile_phone'  => $row['mobile_phone'] ?? ($row['phone'] ?? 'N/A'),
                    'city'          => $row['city'] ?? 'N/A',
                    'office'          => $row['office'] ?? 'N/A',
                    'state'         => $row['state'] ?? 'N/A',
                    'country'       => $row['country'] ?? 'N/A',
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'error_message' => 'Invalid email format',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                continue;
            }

            // Check if email is already processed in this import
            if (in_array($email, $processedEmails)) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'mobile_phone'  => $row['mobile_phone'] ?? ($row['phone'] ?? 'N/A'),
                    'city'  => $row['city'] ?? 'N/A',
                    'office'          => $row['office'] ?? 'N/A',
                    'state'  => $row['state'] ?? 'N/A',
                    'country'  => $row['country'] ?? 'N/A',
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'error_message' => 'Duplicate email in import',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                continue;
            }

            // Check if email already exists in the database
            // $existingEmployee = Employee::where('email', $email)->first();
            $existingEmployee = Employee::where('email', $email)
    ->where('employer_id', $this->employerId)
    ->first();

            if ($existingEmployee) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'mobile_phone'  => $row['mobile_phone'] ?? ($row['phone'] ?? 'N/A'),
                    'city'  => $row['city'] ?? 'N/A',
                    'state'  => $row['state'] ?? 'N/A',
                    'office'          => $row['office'] ?? 'N/A',
                    'country' => $row['country'] ?? 'N/A',
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'error_message' => 'Employee already exists',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                $existingEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                ];
                continue;
            }

            // Phone number validation
            $phoneNumber = trim($row['phone'] ?? '');
            if (empty($phoneNumber)) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'mobile_phone'  => $row['mobile_phone'] ?? ($row['phone'] ?? 'N/A'),
                    'city'  => $row['city'] ?? 'N/A',
                    'office'          => $row['office'] ?? 'N/A',
                    'state'   => $row['state'] ?? 'N/A',
                    'country' => $row['country'] ?? 'N/A',
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'error_message' => 'Phone number is blank',
                    'created_by' => Auth::id(),
                    'created_at' => Carbon::now()
                ];
                continue;
            }

            // Comprehensive phone number validation
            $cleanedPhone = preg_replace('/[^0-9]/', '', $phoneNumber);

            // Check for non-numeric or incorrect length
            if (!preg_match('/^\d{10}$/', $cleanedPhone)) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'mobile_phone' => $phoneNumber,
                    'city' => $row['city'] ?? 'N/A',
                    'state' => $row['state'] ?? 'N/A',
                    'office'          => $row['office'] ?? 'N/A',
                    'country' => $row['country'] ?? 'N/A',
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'error_message' => 'Invalid phone number format (must be 10 numeric digits)',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                continue;
            }

            // Check for duplicate phone number within the current import
            if (in_array($cleanedPhone, $processedPhoneNumbers)) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'mobile_phone' => $phoneNumber,
                    'office'          => $row['office'] ?? 'N/A',
                    'city'  => $row['city'] ?? 'N/A',
                    'state' => $row['state'] ?? 'N/A',
                    'country' => $row['country'] ?? 'N/A',
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'error_message' => 'Duplicate phone number in import',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                continue;
            }

            // Check if phone number already exists in the database
            // $existingPhoneEmployee = Employee::where('mobile_phone', $cleanedPhone)->first();
            $existingPhoneEmployee = Employee::where('mobile_phone', $cleanedPhone)
    ->where('employer_id', $this->employerId)
    ->first();
            if ($existingPhoneEmployee) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'mobile_phone' => $phoneNumber,
                    'office'          => $row['office'] ?? 'N/A',
                    'city' => $row['city'] ?? 'N/A',
                    'state'  => $row['state'] ?? 'N/A',
                    'country' => $row['country'] ?? 'N/A',
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'error_message' => 'Phone number already exists',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                continue;
            }

            // Validate City, State, and Country fields
            $city = trim($row['city'] ?? '');
            $state = trim($row['state'] ?? '');
            $country = trim($row['country'] ?? '');
            $office = trim($row['office'] ?? '');
            $licenses = trim($row['licenses'] ?? '');

            // Function to validate text fields
            $validateTextField = function ($field) {
                return preg_match('/^[a-zA-Z\s]*$/', $field);
            };

            if (!empty($city) && !$validateTextField($city)) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'mobile_phone' => $phoneNumber,
                    'office'          => $row['office'] ?? 'N/A',
                    'state' => $row['state'] ?? 'N/A',
                    'country'  => $row['country'] ?? 'N/A',
                    'city' => $city,
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'error_message' => 'City must contain only letters and spaces',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                continue;
            }

            if (!empty($state) && !$validateTextField($state)) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'mobile_phone' => $phoneNumber,
                    'office'          => $row['office'] ?? 'N/A',
                    'city' => $row['city'] ?? 'N/A',
                    'country' => $row['country'] ?? 'N/A',
                    'state' => $state,
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'error_message' => 'State must contain only letters and spaces',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                continue;
            }

            if (!empty($country) && !$validateTextField($country)) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'country' => $country,
                    'office'          => $row['office'] ?? 'N/A',
                    'city'  => $row['city'] ?? 'N/A',
                    'state' => $row['state'] ?? 'N/A',
                    'mobile_phone' => $phoneNumber,
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'error_message' => 'Country must contain only letters and spaces',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                continue;
            }
            if (empty(trim($row['licenses']))) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'] ?? 'N/A',
                    'last_name' => $row['last_name'] ?? '',
                    'email' => $row['email'] ?? 'N/A',
                    'mobile_phone'  => $row['mobile_phone'] ?? ($row['phone'] ?? 'N/A'),
                    'city'          => $row['city'] ?? 'N/A',
                    'office'          => $row['office'] ?? 'N/A',
                    'state'         => $row['state'] ?? 'N/A',
                    'country'       => $row['country'] ?? 'N/A',
                    'error_message' => 'License is Blank',
                    'licenses'       => $row['licenses'] ?? 'N/A',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                continue;
            }
            // Check if email already exists in the database
            // $existingEmployee = Employee::where('licenses', $licenses)->first();
            $existingLicenseEmployee = Employee::where('licenses', $licenses)
            ->where('employer_id', $this->employerId)
            ->first();
            if ($existingLicenseEmployee) {
                $skippedEmployees[] = [
                    'import_id' => $nextImportId,
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                    'mobile_phone'  => $row['mobile_phone'] ?? ($row['phone'] ?? 'N/A'),
                    'city'  => $row['city'] ?? 'N/A',
                    'state'  => $row['state'] ?? 'N/A',
                    'office'          => $row['office'] ?? 'N/A',
                    'country' => $row['country'] ?? 'N/A',
                    'licenses'       => $licenses,
                    'error_message' => 'License already exists',
                    'created_by' => Auth::id(),
                    'employer_id' => $this->employerId,
                    'created_at' => Carbon::now()
                ];
                $existingEmployees[] = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $email,
                ];
                continue;
            }
            $processedPhoneNumbers[] = $cleanedPhone;
            $processedEmails[] = $email;

            // Generate display name
            $wellnessWords = ['Zen', 'Calm', 'Breathe', 'Pulse', 'Glow', 'Mindful', 'Wellness', 'Harmony', 'Serene', 'Balance'];
            $randomDisplayName = $wellnessWords[array_rand($wellnessWords)] . '_' . rand(100, 999);

            $isPaid = $paidSlotsRemaining > 0 ? 1 : 0;
            if ($paidSlotsRemaining > 0) {
                $paidSlotsRemaining--;
            }

            $employeesToInsert[] = [
                'first_name'     => $row['first_name'],
                'last_name'      => $row['last_name'],
                'username'       => $randomDisplayName,
                'email'          => $email,
                'mobile_phone'   => $cleanedPhone,
                'city'           => $city,
                'state'          => $state,
                'country'        => $country,
                'office'         => $office,
                'licenses'       => $row['licenses'],
                'created_at'     => now(),
                'updated_at'     => now(),
                'created_by'     => Auth::id(),
                'employer_id'    => $this->employerId,
                'user_timezone_id' => $this->userTimezoneId,
                'password' => Hash::make($randomPassword),
            ];
        }
        // Insert skipped employees in one go
        if (!empty($skippedEmployees)) {
            WellifyTempAppUser::insert($skippedEmployees);
        }

        $importResult = [
            'new_employees_count' => count($employeesToInsert),
            'existing_employees_count' => count($existingEmployees),
            'skipped_employees_count' => count($skippedEmployees)
        ];
        // Insert employees
        if (!empty($employeesToInsert)) {
            try {
                $chunks = array_chunk($employeesToInsert, 100);
                foreach ($chunks as $chunk) {
                    Employee::insert($chunk);
                }

                Log::info('Employees Imported Successfully', $importResult);
            } catch (\Exception $e) {
                Log::error('Employee Import Error', [
                    'message' => $e->getMessage(),
                    'employees' => $employeesToInsert
                ]);

                $importResult['new_employees_count'] = 0;
                $importResult['skipped_employees_count'] += count($employeesToInsert);
            }
        }

        session([
            'import_result' => $importResult,
            'existing_employees' => $existingEmployees,
            'skipped_employees' => $skippedEmployees
        ]);
    }

    private function validateHeaders($row)
    {
        $rowArray = $row->toArray();
        $requiredHeaders = [
            'first_name',
            'last_name',
            'email',
            'phone',
            'department_name',
            'city',
            'state',
            'country',
            'licenses',
            'office'
        ];

        $missingHeaders = [];

        foreach ($requiredHeaders as $header) {
            if (!array_key_exists($header, $rowArray)) {
                $missingHeaders[] = $header; // Collect missing headers
            }
        }

        if (!empty($missingHeaders)) {
            // Create a user-friendly message listing the missing headers
            $missingHeadersList = implode(', ', $missingHeaders);
            throw new \Exception("The following required headers are missing from the Excel sheet: {$missingHeadersList}.");
        }

        return true; // All required headers are present
    }
}
<?php

namespace App\Http\Controllers;

use Aws\S3\S3Client;
use Illuminate\Http\Request;
use App\Models\WellifyActivity;
use App\Models\WellifyActivityMedia;
use Illuminate\Support\Facades\Storage;
use Yajra\DataTables\Facades\DataTables;

class WellifyActivityMediaController extends Controller
{

    public function index($id)
    {
        $activity = WellifyActivity::findOrFail($id);
        return view('wellify_activities.media', compact('activity'));
    }

    // Fetch media items for DataTables
    public function getMediaData(Request $request, $activityId)
    {
        $mediaItems = WellifyActivityMedia::where('activity_id', $activityId)->where('media_type', 'image');

        return DataTables::of($mediaItems)
            // ->addColumn('id', fn($row) => $row->activity_id)
            ->addColumn('dummy', fn() => ' ')
            ->editColumn('activity_id', fn($row) => $row->activity_id)

            ->addColumn('image', function ($row) {
                if (!$row->media) return 'No Image';

                try {
                    $s3 = new S3Client([
                        'version' => 'latest',
                        'region' => env('AWS_DEFAULT_REGION'),
                        'credentials' => [
                            'key' => env('AWS_ACCESS_KEY_ID'),
                            'secret' => env('AWS_SECRET_ACCESS_KEY'),
                        ],
                    ]);

                    $key = env('S3_ACTIVITIES') . $row->media;

                    $cmd = $s3->getCommand('GetObject', [
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $key,
                    ]);

                    $request = $s3->createPresignedRequest($cmd, '+20 minutes');
                    $url = (string) $request->getUri();

                    return '<img src="' . $url . '" alt="Class Image" target="_blank" class=" logo_outer border-0">';


                } catch (\Exception $e) {
                    return 'Image Error';
                }
            })
            // ->addColumn('description', fn($row) => $row->description)
            ->editColumn('description', function ($row) {
                    return '<span class="text-wrap">' . e($row->description) . '</span>';
                })
            ->addColumn('action', function ($row) {
                return '
                    <div class="action_td">
                        <span class="edit_icon" title="Edit" data-id="' . $row->id . '" data-bs-toggle="modal"
                                                data-bs-target="#edit_user3" >
                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20"
                                viewBox="0 0 21 20" fill="none">
                                <path
                                    d="M14.666 2.49993C14.8849 2.28106 15.1447 2.10744 15.4307 1.98899C15.7167 1.87054 16.0232 1.80957 16.3327 1.80957C16.6422 1.80957 16.9487 1.87054 17.2347 1.98899C17.5206 2.10744 17.7805 2.28106 17.9993 2.49993C18.2182 2.7188 18.3918 2.97863 18.5103 3.2646C18.6287 3.55057 18.6897 3.85706 18.6897 4.16659C18.6897 4.47612 18.6287 4.78262 18.5103 5.06859C18.3918 5.35455 18.2182 5.61439 17.9993 5.83326L6.74935 17.0833L2.16602 18.3333L3.41602 13.7499L14.666 2.49993Z"
                                    stroke="#A25AD9" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                        </span>
                        <span class="delete_icon" title="Delete" data-id="' . $row->id . '" data-bs-toggle="modal"
                                                data-bs-target="#delete_user"">
                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20"
                                viewBox="0 0 21 20" fill="none">
                                <path
                                    d="M3 5.00033H4.66667M4.66667 5.00033H18M4.66667 5.00033V16.667C4.66667 17.109 4.84226 17.5329 5.15482 17.8455C5.46738 18.1581 5.89131 18.3337 6.33333 18.3337H14.6667C15.1087 18.3337 15.5326 18.1581 15.8452 17.8455C16.1577 17.5329 16.3333 17.109 16.3333 16.667V5.00033H4.66667ZM7.16667 5.00033V3.33366C7.16667 2.89163 7.34226 2.46771 7.65482 2.15515C7.96738 1.84259 8.39131 1.66699 8.83333 1.66699H12.1667C12.6087 1.66699 13.0326 1.84259 13.3452 2.15515C13.6577 2.46771 13.8333 2.89163 13.8333 3.33366V5.00033M8.83333 9.16699V14.167M12.1667 9.16699V14.167"
                                    stroke="#F54E51" stroke-width="1.66667" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                        </span>
                    </div>
                ';
            })

            ->rawColumns(['image', 'action','description','dummy','activity_id'])
            ->make(true);
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'activity_id' => 'required|exists:wellify_activities,activity_id',
                'media.*' => 'required|mimes:svg,svg+xml',
                'description.*' => 'required|string'
            ]);

            $mediaFiles = $request->file('media');
            $descriptions = $request->description;
            $activityId = $request->activity_id;

            if (count($mediaFiles) !== count($descriptions)) {
                return response()->json(['success' => false, 'message' => 'Mismatch between media and description count.'], 422);
            }

            $s3 = new \Aws\S3\S3Client([
                'version' => 'latest',
                'region'  => env('AWS_DEFAULT_REGION'),
                'credentials' => [
                    'key'    => env('AWS_ACCESS_KEY_ID'),
                    'secret' => env('AWS_SECRET_ACCESS_KEY'),
                ]
            ]);

            foreach ($mediaFiles as $index => $file) {
                $filename = time() . '_' . $file->getClientOriginalName();
                $keyname = env('S3_ACTIVITIES') . $filename;

                $s3->putObject([
                    'Bucket' => env('AWS_BUCKET'),
                    'Key'    => $keyname,
                    'Body'   => fopen($file, 'r'),
                    'ContentType' => $file->getMimeType()
                ]);

                \App\Models\WellifyActivityMedia::create([
                    'activity_id'    => $activityId,
                    'media'       => $filename,
                    'media_type'  => 'image',
                    'description' => $descriptions[$index],
                ]);
            }

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function edit($id)
    {
        $media = WellifyActivityMedia::findOrFail($id);
        return response()->json($media);
    }

    public function update(Request $request)
    {
        try {
            $request->validate([
                'media_id' => 'required|exists:wellify_activity_media,id',
                'description' => 'required|string',
                'media' => 'nullable|file',
            ]);

            $media = WellifyActivityMedia::findOrFail($request->media_id);
            $media->description = $request->description;

            // If new image is uploaded
            if ($request->hasFile('media')) {
                $file = $request->file('media');
                $filename = time() . '_' . $file->getClientOriginalName();
                $keyname = env('S3_ACTIVITIES') . $filename;

                $s3 = new S3Client([
                    'version' => 'latest',
                    'region' => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key' => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ],
                ]);

                $s3->putObject([
                    'Bucket' => env('AWS_BUCKET'),
                    'Key'    => $keyname,
                    'Body'   => fopen($file, 'r+'),
                ]);

                $media->media = $filename;
                $media->media_type = $this->getMediaTypeId($file);
            }

            $media->save();

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Update failed: ' . $e->getMessage()
            ], 500);
        }
    }

    private function getMediaTypeId($file)
    {
        $mime = $file->getMimeType();
        if (str_starts_with($mime, 'image/svg+xml')) return 1;
        if ($mime === 'application/pdf') return 2;
        if ($mime === 'image/gif') return 3;
        return null;
    }

    public function show($id)
    {
        $media = WellifyActivityMedia::findOrFail($id);

        $previewUrl = null;

        if (in_array($media->media_type, [1, 3])) { // 1: image, 3: gif
            $s3 = new S3Client([
                'version' => 'latest',
                'region' => env('AWS_DEFAULT_REGION'),
                'credentials' => [
                    'key' => env('AWS_ACCESS_KEY_ID'),
                    'secret' => env('AWS_SECRET_ACCESS_KEY'),
                ],
            ]);

            $key = env('S3_ACTIVITIES') . $media->media;

            $cmd = $s3->getCommand('GetObject', [
                'Bucket' => env('AWS_BUCKET'),
                'Key'    => $key,
            ]);

            $request = $s3->createPresignedRequest($cmd, '+20 minutes');
            $previewUrl = (string) $request->getUri();
        }

        return response()->json([
            'id' => $media->id,
            'description' => $media->description,
            'preview_url' => $previewUrl,
        ]);
    }

    public function uploadMedia(Request $request)
    {
        $request->validate([
            'activity_id' => 'required|exists:wellify_activities,activity_id',
            'media.*' => 'required|mimes:svg,svg+xml',
            'description.*' => 'required|string|max:255',
        ]);

        try {
            $activityId = $request->activity_id;
            $files = $request->file('media');
            $descriptions = $request->description;

            foreach ($files as $index => $file) {
                $description = $descriptions[$index] ?? '';

                $filename = 'activity_' . time() . '_' . $file->getClientOriginalName();
                $s3Key = 'staging/activities/media/' . $filename;

                Storage::disk('s3')->put($s3Key, fopen($file, 'r+'), 'public');

                WellifyActivityMedia::create([
                    'activity_id' => $activityId,
                    'media' => $s3Key,
                    'description' => $description,
                    'media_type' => 'image',
                    'status' => 1
                ]);
            }

            return response()->json(['success' => true, 'message' => 'Media uploaded successfully']);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Upload failed: ' . $e->getMessage()
            ], 500);
        }
    }

    public function destroy($id)
    {
        $media = WellifyActivityMedia::findOrFail($id);

        // Delete from S3
        if ($media->media) {
            $s3 = new S3Client([
                'version' => 'latest',
                'region' => env('AWS_DEFAULT_REGION'),
                'credentials' => [
                    'key' => env('AWS_ACCESS_KEY_ID'),
                    'secret' => env('AWS_SECRET_ACCESS_KEY'),
                ],
            ]);

            $key = env('S3_ACTIVITIES') . $media->media;

            try {
                $s3->deleteObject([
                    'Bucket' => env('AWS_BUCKET'),
                    'Key'    => $key,
                ]);
            } catch (\Exception $e) {
                // Log the error or ignore if not critical
            }
        }

        $media->delete();

        return response()->json(['message' => 'Media deleted successfully']);
    }
}

<?php
namespace App\Http\Controllers;

use Exception;
use Stripe\Stripe;
use Aws\S3\S3Client;
use Stripe\Customer;
use App\Models\WellifyUser;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Stripe\Checkout\Session;
use App\Models\WellifyTimezone;
use Illuminate\Validation\Rule;
use App\Mail\EmployerCreatedMail;
use Aws\S3\Exception\S3Exception;
use Spatie\Permission\Models\Role;
use App\Models\WellifySubscription;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmployerPaymentLinkMail;
use App\Mail\SlotsPaymentMail;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Validation\ValidationException;

class WellifyUserController extends Controller
{
    public function index()
    {
         $timezones = WellifyTimezone::all();

        return view('wellify_users.index', compact('timezones'));
    }

    /*Function to Show the data of the Employer*/
    public function data(Request $request)
    {
        if ($request->ajax()) {
            Log::info('DataTables request received');

            $employerRole = Role::where('name', 'Employer')->first();
            if (!$employerRole) {
                Log::error('Employer role not found');
                return response()->json(['error' => 'Employer role not found'], 500);
            }

            $data = WellifyUser::where('supervisor_id', $employerRole->id);
            if ($request->has('sort_filter') && $request->sort_filter) {
                switch ($request->sort_filter) {
                    case 'today':
                        $data->whereDate('created_at', today());
                        break;
                    case 'last_week':
                        $data->whereBetween('created_at', [now()->subWeek(), now()]);
                        break;
                    case 'last_month':
                        $data->whereBetween('created_at', [now()->subMonth(), now()]);
                        break;
                }
            }

            $data = $data->orderBy('created_at', 'desc')->get();

            Log::info('Query will return: ' . $data->count() . ' records');

            return DataTables::of($data)
            ->addColumn('',function($user){
                return '';
            })
                ->editColumn('organization', function($user) {
                    $imgTag = '';
                    if ($user->profile_picture) {
                        $s3 = new S3Client([
                            'version' => 'latest',
                            'region'  => env('AWS_DEFAULT_REGION'),
                            'credentials' => [
                                'key'    => env('AWS_ACCESS_KEY_ID'),
                                'secret' => env('AWS_SECRET_ACCESS_KEY'),
                            ]
                        ]);

                        $cmd = $s3->getCommand('GetObject', [
                            'Bucket' => env('AWS_BUCKET'),
                            'Key'    => env('S3_USER') . $user->profile_picture
                        ]);

                        $request = $s3->createPresignedRequest($cmd, '+20 minutes');
                        $presignedUrl = (string) $request->getUri();
                        $imgTag = '<span class="logo_outer"><img src="' . $presignedUrl . '" alt="Profile Picture" class="table_logo_img"></span>';
                    }

                    return '
                        <span class="d-flex align-items-center gap-2">
                            ' . $imgTag . '
                            <span class="ms-2">' . e($user->organization) . '</span>
                        </span>';
                })

                ->addColumn('username',function($user){
                    return '@'.$user->username;
                })
                ->addColumn('contact_person',function($user){
                    return $user->first_name.' '.$user->last_name;
                })
                ->addColumn('timezone',function($user){
                    return  $user->timezone?->utc_offset;
                })
                ->addColumn('CRM_link', function($user) {
                    if (!$user->CRM_link) return '-';

                    $url = $user->CRM_link;
                    $host = parse_url($url, PHP_URL_HOST);

                    if (!$host) return '-';

                    return '<a href="#" title="' . e($url) . '">' . e($host) . '</a>';
                })
                ->addColumn('payment_status', function($user) {
                    return $user->setup_fee_paid ? '<span class="status_btn bg_active">
                                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M5 10C4.30833 10 3.65833 9.86866 3.05 9.606C2.44167 9.34333 1.9125 8.98716 1.4625 8.5375C1.0125 8.08783 0.656334 7.55866 0.394 6.95C0.131667 6.34133 0.000333966 5.69133 6.32911e-07 5C-0.0003327 4.30867 0.131001 3.65867 0.394 3.05C0.657 2.44133 1.01317 1.91217 1.4625 1.4625C1.91183 1.01283 2.441 0.656667 3.05 0.394C3.659 0.131333 4.309 0 5 0C5.691 0 6.341 0.131333 6.95 0.394C7.559 0.656667 8.08816 1.01283 8.5375 1.4625C8.98683 1.91217 9.34316 2.44133 9.60649 3.05C9.86983 3.65867 10.001 4.30867 9.99999 5C9.99899 5.69133 9.86766 6.34133 9.60599 6.95C9.34433 7.55866 8.98816 8.08783 8.5375 8.5375C8.08683 8.98716 7.55766 9.3435 6.95 9.6065C6.34233 9.8695 5.69233 10.0007 5 10Z"
                                                            fill="#52AB17" />
                                                    </svg>Paid</span>' : '<span class="status_btn bg_delete"><svg width="10" height="10" viewBox="0 0 10 10" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M5 10C4.30833 10 3.65833 9.86866 3.05 9.606C2.44167 9.34333 1.9125 8.98716 1.4625 8.5375C1.0125 8.08783 0.656334 7.55866 0.394 6.95C0.131667 6.34133 0.000333966 5.69133 6.32911e-07 5C-0.0003327 4.30867 0.131001 3.65867 0.394 3.05C0.657 2.44133 1.01317 1.91217 1.4625 1.4625C1.91183 1.01283 2.441 0.656667 3.05 0.394C3.659 0.131333 4.309 0 5 0C5.691 0 6.341 0.131333 6.95 0.394C7.559 0.656667 8.08816 1.01283 8.5375 1.4625C8.98683 1.91217 9.34316 2.44133 9.60649 3.05C9.86983 3.65867 10.001 4.30867 9.99999 5C9.99899 5.69133 9.86766 6.34133 9.60599 6.95C9.34433 7.55866 8.98816 8.08783 8.5375 8.5375C8.08683 8.98716 7.55766 9.3435 6.95 9.6065C6.34233 9.8695 5.69233 10.0007 5 10Z"
                                                            fill="#52AB17"></path>
                                                    </svg>
                                                    Pending</span>';
                })
                ->addColumn('action', function($user) {
                    $iconColor = 'gray';
                    $iconClass = 'disabled_mail_icon';
                    $tooltip = 'Pending Payment';
                    $dataStatus = !$user->setup_fee_paid ? 'pending' :($user->welcome_email_sent ? 'sent' : 'new');

                    if ($user->setup_fee_paid && !$user->welcome_email_sent) {
                        $iconColor = 'blue';
                        $iconClass = 'send_mail_icon';
                        $tooltip = 'Send Welcome Email';
                    } elseif ($user->setup_fee_paid && $user->welcome_email_sent) {
                        $iconColor = 'orange';
                        $iconClass = 'send_mail_icon';
                        $tooltip = 'Resend Welcome Email';
                    }


                    $mailIcon = '
                        <span class="' . $iconClass . '" title="' . $tooltip . '" data-id="' . $user->id . '" data-name="'. $user->organization .'" data-status="'. $dataStatus. '" style="cursor:' . ($iconClass === 'send_mail_icon' ? 'pointer' : 'not-allowed') . '; margin-right: 8px;">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" >
                                    <path d="M13 19H5C4.46957 19 3.96086 18.7893 3.58579 18.4142C3.21071 18.0391 3 17.5304 3 17V7C3 6.46957 3.21071 5.96086 3.58579 5.58579C3.96086 5.21071 4.46957 5 5 5H19C19.5304 5 20.0391 5.21071 20.4142 5.58579C20.7893 5.96086 21 6.46957 21 7V13" stroke="#45841C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M3 7L12 13L21 7M16 22L21 17M21 17V21.5M21 17H16.5" stroke="#45841C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                        </span>';

                    return '<div class="action_td">

                        ' . $mailIcon . '
                        <span class="view_icon" title="View" data-id="' . $user->id . '">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="14" viewBox="0 0 20 14" fill="none">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M6 7C6 6.00544 6.39509 5.05161 7.09835 4.34835C7.80161 3.64509 8.75544 3.25 9.75 3.25C10.7446 3.25 11.6984 3.64509 12.4017 4.34835C13.1049 5.05161 13.5 6.00544 13.5 7C13.5 7.99456 13.1049 8.94839 12.4017 9.65165C11.6984 10.3549 10.7446 10.75 9.75 10.75C8.75544 10.75 7.80161 10.3549 7.09835 9.65165C6.39509 8.94839 6 7.99456 6 7ZM9.75 4.75C9.15326 4.75 8.58097 4.98705 8.15901 5.40901C7.73705 5.83097 7.5 6.40326 7.5 7C7.5 7.59674 7.73705 8.16903 8.15901 8.59099C8.58097 9.01295 9.15326 9.25 9.75 9.25C10.3467 9.25 10.919 9.01295 11.341 8.59099C11.7629 8.16903 12 7.59674 12 7C12 6.40326 11.7629 5.83097 11.341 5.40901C10.919 4.98705 10.3467 4.75 9.75 4.75Z" fill="#1283CE" />
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M2.073 5.646C1.654 6.25 1.5 6.723 1.5 7C1.5 7.277 1.654 7.75 2.073 8.354C2.479 8.937 3.081 9.57 3.843 10.155C5.37 11.327 7.463 12.25 9.75 12.25C12.037 12.25 14.13 11.327 15.657 10.155C16.419 9.57 17.021 8.937 17.427 8.354C17.846 7.75 18 7.277 18 7C18 6.723 17.846 6.25 17.427 5.646C17.021 5.063 16.419 4.43 15.657 3.845C14.13 2.673 12.037 1.75 9.75 1.75C7.463 1.75 5.37 2.673 3.843 3.845C3.081 4.43 2.479 5.063 2.073 5.646ZM2.929 2.655C4.66 1.327 7.066 0.25 9.75 0.25C12.434 0.25 14.84 1.327 16.57 2.655C17.437 3.32 18.153 4.062 18.659 4.791C19.151 5.5 19.5 6.277 19.5 7C19.5 7.723 19.15 8.5 18.659 9.209C18.153 9.938 17.437 10.679 16.571 11.345C14.841 12.673 12.434 13.75 9.75 13.75C7.066 13.75 4.66 12.673 2.93 11.345C2.063 10.68 1.347 9.938 0.841 9.209C0.35 8.5 0 7.723 0 7C0 6.277 0.35 5.5 0.841 4.791C1.347 4.062 2.063 3.321 2.929 2.655Z" fill="#1283CE" />
                            </svg>
                        </span>

                        <span class="edit_icon"data-id="'.$user->id.'" title="Edit">
                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                            <path d="M14.666 2.49993C14.8849 2.28106 15.1447 2.10744 15.4307 1.98899C15.7167 1.87054 16.0232 1.80957 16.3327 1.80957C16.6422 1.80957 16.9487 1.87054 17.2347 1.98899C17.5206 2.10744 17.7805 2.28106 17.9993 2.49993C18.2182 2.7188 18.3918 2.97863 18.5103 3.2646C18.6287 3.55057 18.6897 3.85706 18.6897 4.16659C18.6897 4.47612 18.6287 4.78262 18.5103 5.06859C18.3918 5.35455 18.2182 5.61439 17.9993 5.83326L6.74935 17.0833L2.16602 18.3333L3.41602 13.7499L14.666 2.49993Z" stroke="#A25AD9" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </span>

                        <span class="delete_icon" title="Delete" data-id="'.$user->id.'" data-bs-toggle="modal" data-bs-target="#delete_user">
                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                            <path d="M3 5.00033H4.66667M4.66667 5.00033H18M4.66667 5.00033V16.667C4.66667 17.109 4.84226 17.5329 5.15482 17.8455C5.46738 18.1581 5.89131 18.3337 6.33333 18.3337H14.6667C15.1087 18.3337 15.5326 18.1581 15.8452 17.8455C16.1577 17.5329 16.3333 17.109 16.3333 16.667V5.00033H4.66667ZM7.16667 5.00033V3.33366C7.16667 2.89163 7.34226 2.46771 7.65482 2.15515C7.96738 1.84259 8.39131 1.66699 8.83333 1.66699H12.1667C12.6087 1.66699 13.0326 1.84259 13.3452 2.15515C13.6577 2.46771 13.8333 2.89163 13.8333 3.33366V5.00033M8.83333 9.16699V14.167M12.1667 9.16699V14.167" stroke="#F54E51" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </span>
                    </div>';
                })
                ->addColumn('dummy', fn() => ' ')

                ->rawColumns(['organization','contact_person','username', 'action','dummy','timezone','payment_status','CRM_link'])
                ->make(true);
        }

        return response()->json(['error' => 'Invalid request'], 400);
    }

    /*Store the Employer Function*/
    // public function store(Request $request)
    // {
    //     try {
    //         $validatedData = $request->validate([
    //             'organization' => 'required|string|max:255',
    //             'first_name' => 'required|string|max:255',
    //             'last_name' => 'required|string|max:255',
    //             'setup_fee' => 'required|numeric|min:1|max:10000',
    //             'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
    //             'email' => 'required|email|unique:wellify_users,email|max:255',
    //             'mobile_phone' => 'required|string|max:20',
    //             'username' => 'required|string|unique:wellify_users,username|max:255',
    //             'licenses' => 'required|string',
    //             'program_periods' => 'required|integer|min:1|max:365',
    //         ]);

    //         $employerRole = Role::where('name', 'Employer')->first();

    //         $user = new WellifyUser();
    //         $user->organization = $validatedData['organization'];
    //         $user->first_name = $validatedData['first_name'];
    //         $user->last_name = $validatedData['last_name'];

    //         // Handle profile picture upload to S3
    //         if ($request->hasFile('profile_picture')) {
    //             $file = $request->file('profile_picture');
    //             $filename = time() . '_' . $file->getClientOriginalName();
    //             $keyname = 'staging/users/' . $filename;

    //             $s3 = new S3Client([
    //                 'version' => 'latest',
    //                 'region'  => env('AWS_DEFAULT_REGION'),
    //                 'credentials' => [
    //                     'key'    => env('AWS_ACCESS_KEY_ID'),
    //                     'secret' => env('AWS_SECRET_ACCESS_KEY'),
    //                 ]
    //             ]);

    //             try {
    //                 $s3->putObject([
    //                     'Bucket' => env('AWS_BUCKET'),
    //                     'Key'    => $keyname,
    //                     'Body'   => fopen($file, 'r+'),
    //                     'ACL'    => 'private',
    //                 ]);
    //                 $user->profile_picture = $filename;
    //             } catch (S3Exception $e) {
    //                 return response()->json(['success' => false, 'message' => 'Image upload failed.'], 500);
    //             }
    //         }

    //         // Set basic fields
    //         $customSetupFee = $request->setup_fee;
    //         $user->program_periods = $validatedData['program_periods'];
    //         $user->email = $validatedData['email'];
    //         $user->mobile_phone = $validatedData['mobile_phone'];
    //         $user->username = $validatedData['username'];
    //         $user->user_timezone_id = $request->user_timezone_id;
    //         $user->supervisor_id = $employerRole->id;
    //         $user->office = $request->office;
    //         $user->city = $request->city;
    //         $user->state = $request->state;
    //         $user->country = $request->country;
    //         $user->licenses = $request->licenses;
    //         $user->setup_fee = $customSetupFee;
    //         $user->setup_fee_paid = false;

    //         // Generate random password to send after payment
    //         $randomPassword = Str::random(10);
    //         $user->password = Hash::make($randomPassword);

    //         // Save employer
    //         $user->save();
    //         $user->assignRole('Employer');

    //         // Setup Stripe
    //         Stripe::setApiKey(env('STRIPE_SECRET'));

    //         $customer = Customer::create([
    //             'email' => $user->email,
    //             'name' => $user->first_name . ' ' . $user->last_name,
    //         ]);

    //         $session = Session::create([
    //             'payment_method_types' => ['card'],
    //             'customer_email' => $user->email,
    //             // 'customer' => $customer->id,
    //             'line_items' => [[
    //                 'price_data' => [
    //                     'currency' => 'usd',
    //                     'product_data' => ['name' => 'One-Time Setup Fee'],
    //                     'unit_amount' => $customSetupFee * 100, // USD to cents
    //                 ],
    //                 'quantity' => 1,
    //             ]],
    //             'mode' => 'payment',
    //             'success_url' => route('stripe.success', ['employer_id' => $user->id, 'token' => encrypt($randomPassword)]) . '&session_id={CHECKOUT_SESSION_ID}',
    //             'cancel_url' => route('stripe.cancel'),
    //             'metadata' => [
    //                 'employer_id' => $user->id,
    //                 'setup_fee_usd' => $customSetupFee,
    //             ],
    //         ]);

    //         // Save Stripe customer
    //         $user->stripe_customer_id = $customer->id;
    //         $user->save();

    //         // Send payment link with fee
    //         Mail::to($user->email)->send(new EmployerPaymentLinkMail($user, $session->url, $customSetupFee));

    //         return response()->json(['success' => true, 'message' => 'Employer created. Payment link sent to email.']);
    //     } catch (\Illuminate\Validation\ValidationException $e) {
    //         return response()->json(['success' => false, 'errors' => $e->errors()], 422);
    //     } catch (\Exception $e) {
    //         Log::error('Employer creation failed: ' . $e->getMessage());
    //         return response()->json(['success' => false, 'message' => 'Server error.'], 500);
    //     }
    // }

    public function store(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'organization' => 'required|string|max:255',
                'first_name' => 'required|string|max:255',
                'last_name' => 'required|string|max:255',
                'setup_fee' => 'required|numeric|min:1|max:10000',
                'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
                'email' => 'required|email|unique:wellify_users,email|max:255',
                'mobile_phone' => 'required|string|max:20',
                'username' => 'required|string|unique:wellify_users,username|max:255',
                'licenses' => 'required|string',
                'CRM_link' => 'nullable|url',
                'program_periods' => 'required|integer|min:1|max:365',
                'number_of_users' => 'required|integer|min:0',
            ]);

            $employerRole = Role::where('name', 'Employer')->first();

            $user = new WellifyUser();
            $user->organization = $validatedData['organization'];
            $user->first_name = $validatedData['first_name'];
            $user->last_name = $validatedData['last_name'];

            // Upload image to S3
            if ($request->hasFile('profile_picture')) {
                $file = $request->file('profile_picture');
                $filename = time() . '_' . $file->getClientOriginalName();
                $keyname = env('S3_USER') . $filename;

                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ]
                ]);

                try {
                    $s3->putObject([
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $keyname,
                        'Body'   => fopen($file, 'r+'),
                        'ACL'    => 'private',
                    ]);
                    $user->profile_picture = $filename;
                } catch (S3Exception $e) {
                    return response()->json(['success' => false, 'message' => 'Image upload failed.'], 500);
                }
            }

            // Set employer data
            $customSetupFee = $request->setup_fee;
            $user->program_periods = $validatedData['program_periods'];
            $user->number_of_users = $validatedData['number_of_users'];
            $user->email = $validatedData['email'];
            $user->mobile_phone = $validatedData['mobile_phone'];
            $user->username = $validatedData['username'];
            $user->user_timezone_id = $request->user_timezone_id;
            $user->supervisor_id = $employerRole->id;
            $user->office = $request->office;
            $user->city = $request->city;
            $user->state = $request->state;
            $user->country = $request->country;
            $user->licenses = $request->licenses;
            $user->setup_fee = $customSetupFee;
            $user->CRM_link = $request->CRM_link;
            $user->notes = $request->notes;
            $user->setup_fee_paid = false;

            $randomPassword = Str::random(10);
            $user->password = Hash::make($randomPassword);

            $user->save();
            $user->assignRole('Employer');

            $existingPlan = WellifySubscription::where('employer_id', $user->id)->first();

            if (!$existingPlan) {
                WellifySubscription::create([
                    'employer_id' => $user->id,
                    'plan_id' => 1,
                    'start_date' => now(),
                    'end_date' => now(),
                    'platform' => 'stripe',
                    'status' => 'pending',
                    'is_employer_sponsored' => true,
                ]);
            }

            // Stripe setup
            Stripe::setApiKey(env('STRIPE_SECRET'));

            $customer = Customer::create([
                'email' => $user->email,
                'name' => $user->first_name . ' ' . $user->last_name,
            ]);

            $session = Session::create([
                'payment_method_types' => ['card'],
                'customer_email' => $user->email,
                'line_items' => [[
                    'price_data' => [
                        'currency' => 'usd',
                        'product_data' => ['name' => 'One-Time Setup Fee'],
                        'unit_amount' => $customSetupFee * 100,
                    ],
                    'quantity' => 1,
                ]],
                'mode' => 'payment',
                'success_url' => route('stripe.success', [
                    'employer_id' => $user->id,
                    'token' => encrypt($randomPassword)
                ]) . '&session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => route('stripe.cancel'),
                'metadata' => [
                    'employer_id' => $user->id,
                    'setup_fee_usd' => $customSetupFee,
                    'program_days' => $user->program_periods,
                    'user_limit' => $user->number_of_users,
                ],
            ]);

            $user->stripe_customer_id = $customer->id;
            $user->save();

            WellifySubscription::create([
                'employer_id' => $user->id,
                'plan_id' => 1,
                'start_date' => now(),
                'end_date' => now()->addDays((int)$user->program_periods),
                'platform' => 'stripe',
                'status' => 'active',
                'is_employer_sponsored' => true,
            ]);

            Mail::to($user->email)->send(new EmployerPaymentLinkMail($user, $session->url, $customSetupFee));

            return response()->json([
                'success' => true,
                'message' => 'Employer created. Payment link sent to email.'
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json(['success' => false, 'errors' => $e->errors()], 422);
        } catch (\Exception $e) {
            Log::error('Employer creation failed: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Server error.'], 500);
        }
    }
    /*Show the Employer Function*/
    public function show($id)
    {
        try {
            // $user = WellifyUser::with('timezone')->findOrFail($id);
            // $user = WellifyUser::withTrashed()->findOrFail($id);
            $user = WellifyUser::withTrashed()->with('timezone')->findOrFail($id);
            $profilePictureUrl = null;
            if ($user->profile_picture) {
                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ]
                ]);

                $cmd = $s3->getCommand('GetObject', [
                    'Bucket' => env('AWS_BUCKET'),
                    'Key'    => env('S3_USER') . $user->profile_picture
                ]);

                $request = $s3->createPresignedRequest($cmd, '+20 minutes');
                $profilePictureUrl = (string)$request->getUri();
            }
            $paymentStatusHtml = $user->setup_fee_paid
                ? '<span class="status_btn bg_active">
                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M5 10C4.30833 10 3.65833 9.86866 3.05 9.606C2.44167 9.34333 1.9125 8.98716 1.4625 8.5375C1.0125 8.08783 0.656334 7.55866 0.394 6.95C0.131667 6.34133 0.000333966 5.69133 6.32911e-07 5C-0.0003327 4.30867 0.131001 3.65867 0.394 3.05C0.657 2.44133 1.01317 1.91217 1.4625 1.4625C1.91183 1.01283 2.441 0.656667 3.05 0.394C3.659 0.131333 4.309 0 5 0C5.691 0 6.341 0.131333 6.95 0.394C7.559 0.656667 8.08816 1.01283 8.5375 1.4625C8.98683 1.91217 9.34316 2.44133 9.60649 3.05C9.86983 3.65867 10.001 4.30867 9.99999 5C9.99899 5.69133 9.86766 6.34133 9.60599 6.95C9.34433 7.55866 8.98816 8.08783 8.5375 8.5375C8.08683 8.98716 7.55766 9.3435 6.95 9.6065C6.34233 9.8695 5.69233 10.0007 5 10Z"
                                fill="#52AB17" />
                        </svg> Paid</span>'
                : '<span class="status_btn bg_delete">
                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M5 10C4.30833 10 3.65833 9.86866 3.05 9.606C2.44167 9.34333 1.9125 8.98716 1.4625 8.5375C1.0125 8.08783 0.656334 7.55866 0.394 6.95C0.131667 6.34133 0.000333966 5.69133 6.32911e-07 5C-0.0003327 4.30867 0.131001 3.65867 0.394 3.05C0.657 2.44133 1.01317 1.91217 1.4625 1.4625C1.91183 1.01283 2.441 0.656667 3.05 0.394C3.659 0.131333 4.309 0 5 0C5.691 0 6.341 0.131333 6.95 0.394C7.559 0.656667 8.08816 1.01283 8.5375 1.4625C8.98683 1.91217 9.34316 2.44133 9.60649 3.05C9.86983 3.65867 10.001 4.30867 9.99999 5C9.99899 5.69133 9.86766 6.34133 9.60599 6.95C9.34433 7.55866 8.98816 8.08783 8.5375 8.5375C8.08683 8.98716 7.55766 9.3435 6.95 9.6065C6.34233 9.8695 5.69233 10.0007 5 10Z"
                            fill="#DC3545" />
                    </svg> Pending</span>';

            if (request()->ajax()) {
                $html = '
                    <div class="row">
                        <div class="col-md-4">
                            <label class="form-label"><strong>Employer Name:</strong></label>
                            <p>' . ($user->organization ?? 'N/A') . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Contact Person:</strong></label>
                            <p>' . $user->first_name . ' ' . $user->last_name . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Employer Email:</strong></label>
                            <p>' . $user->email . '</p>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-4">
                            <label class="form-label"><strong>Username:</strong></label>
                            <p>' . $user->username . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Contact Person:</strong></label>
                            <p>' . $user->mobile_phone . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Timezone:</strong></label>
                            <p>' . $user->timezone?->utc_offset.'</p>
                        </div>

                        
                        <div class="col-md-4">
                            <label class="form-label"><strong>License:</strong></label>
                            <p>' . $user->licenses . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Number of Slots:</strong></label>
                            <p>' . $user->number_of_users . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Setup Fees:</strong></label>
                            <p>' . $user->setup_fee . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>CRM Link:</strong></label>
                            <p>' . $user->CRM_link . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Office:</strong></label>
                            <p>' . $user->office . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>City:</strong></label>
                            <p>' . $user->city . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>State:</strong></label>
                            <p>' . $user->state . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Country:</strong></label>
                            <p>' . $user->country . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Notes:</strong></label>
                            <p>' . $user->notes . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Payment Status:</strong></label>
                            <p>' . $paymentStatusHtml . '</p>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label d-block"><strong>Employer Logo:</strong></label>';

                if ($profilePictureUrl) {
                    $html .= '<img src="' . $profilePictureUrl . '" alt="Profile Picture" class="logo-preview">';
                } else {
                    $html .= '<p>No profile picture available.</p>';
                }
                $html .= '</div></div>';
                return response()->json(['html' => $html]);
            }
            return view('wellify_users.show', compact('user'));
        } catch (Exception $e) {
            return response()->json(['html' => '<p class="text-danger">Error loading user.</p>']);
        }
    }

    /*Edit the Employer Function*/
    public function edit($id)
    {
        try {
            $user = WellifyUser::findOrFail($id);
            $timezones = WellifyTimezone::all();
            return response()->json([
                'success' => true,
                'user' => $user,
                'timezones' => $timezones
            ]);
        } catch (Exception $e) {
            Log::error('Error fetching user for editing: ' . $e->getMessage());
            return request()->ajax()
                ? response()->json(['success' => false, 'message' => 'User not found'], 404)
                : redirect()->back()->with('error', 'User not found.');
        }
    }

    /*Update the Employer Function* */
    // public function update(Request $request, $id)
    // {
    //     try {
    //         $user = WellifyUser::findOrFail($id);

    //         $validatedData = $request->validate([
    //             'organization' => 'required|string|max:255',
    //             'first_name' => 'required|string|max:255',
    //             'last_name' => 'required|string|max:255',
    //             'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
    //             'number_of_users' => 'required|integer|min:0',
    //             'email' => [
    //                 'required',
    //                 'email',
    //                 'max:255',
    //                 Rule::unique('wellify_users')->ignore($user->id),
    //             ],
    //             'mobile_phone' => 'required|string|max:20',
    //             'username' => [
    //                 'required',
    //                 'string',
    //                 'max:255',
    //                 Rule::unique('wellify_users')->ignore($user->id),
    //             ],
    //         ]);
    //         $user->organization = $validatedData['organization'];
    //         $user->first_name = $validatedData['first_name'];
    //         $user->last_name = $validatedData['last_name'];
    //         $user->number_of_users = $validatedData['number_of_users'];

    //         if ($request->hasFile('profile_picture')) {
    //             $file = $request->file('profile_picture');
    //             $filename = time() . '_' . $file->getClientOriginalName();
    //             $keyname = env('S3_USER') . $filename;

    //             $s3 = new S3Client([
    //                 'version' => 'latest',
    //                 'region'  => env('AWS_DEFAULT_REGION'),
    //                 'credentials' => [
    //                     'key'    => env('AWS_ACCESS_KEY_ID'),
    //                     'secret' => env('AWS_SECRET_ACCESS_KEY'),
    //                 ],
    //             ]);

    //             try {
    //                 Log::info("Attempting to upload file to S3: $keyname");

    //                 $result = $s3->putObject([
    //                     'Bucket' => env('AWS_BUCKET'),
    //                     'Key'    => $keyname,
    //                     'Body'   => fopen($file->getPathname(), 'r'),
    //                     'ACL'    => 'private',
    //                     'ContentType' => $file->getClientMimeType(),
    //                 ]);

    //                 Log::info('S3 Upload Success: ', ['url' => $result['ObjectURL']]);

    //                 // Save filename only
    //                 $user->profile_picture = $filename;

    //             } catch (S3Exception $e) {
    //                 Log::error('S3 Upload Error: ' . $e->getAwsErrorMessage());
    //                 return redirect()->back()->with('error', 'Failed to upload profile picture.')->withInput();
    //             }
    //         }
    //         $user->mobile_phone = $validatedData['mobile_phone'];
    //         $user->username = $validatedData['username'];
    //         $user->user_timezone_id = $request->user_timezone_id;
    //         $user->office = $request->office;
    //         $user->city = $request->city;
    //         $user->state = $request->state;
    //         $user->country = $request->country;
    //         $user->licenses = $request->licenses;
    //         $user->CRM_link = $request->CRM_link;
    //         $user->notes = $request->notes;
    //         $user->save();

    //         return redirect()->to('/wellify_users')->with('success', 'User updated successfully!');
    //     } catch (ValidationException $e) {
    //         return redirect()->back()->withErrors($e->validator)->withInput();
    //     } catch (Exception $e) {
    //         Log::error('Error updating user: ' . $e->getMessage());
    //         return redirect()->back()->with('error', 'Failed to update user. Please try again.')->withInput();
    //     }
    // }

    public function update(Request $request, $id)
    {
        try {
            $user = WellifyUser::findOrFail($id);

            $validatedData = $request->validate([
                'organization' => 'required|string|max:255',
                'first_name' => 'required|string|max:255',
                'last_name' => 'required|string|max:255',
                'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
                'number_of_users' => 'required|integer|min:0',
                'email' => [
                    'required',
                    'email',
                    'max:255',
                    Rule::unique('wellify_users')->ignore($user->id),
                ],
                'mobile_phone' => 'required|string|max:20',
                'username' => [
                    'required',
                    'string',
                    'max:255',
                    Rule::unique('wellify_users')->ignore($user->id),
                ],
            ]);

            $oldSlots = $user->number_of_users;
            $newSlots = $validatedData['number_of_users'];

            $user->organization = $validatedData['organization'];
            $user->first_name = $validatedData['first_name'];
            $user->last_name = $validatedData['last_name'];

            if ($request->hasFile('profile_picture')) {
                $file = $request->file('profile_picture');
                $filename = time() . '_' . $file->getClientOriginalName();
                $keyname = env('S3_USER') . $filename;

                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ],
                ]);

                try {
                    $result = $s3->putObject([
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $keyname,
                        'Body'   => fopen($file->getPathname(), 'r'),
                        'ACL'    => 'private',
                        'ContentType' => $file->getClientMimeType(),
                    ]);

                    $user->profile_picture = $filename;

                } catch (S3Exception $e) {
                    Log::error('S3 Upload Error: ' . $e->getAwsErrorMessage());
                    return redirect()->back()->with('error', 'Failed to upload profile picture.')->withInput();
                }
            }

            $user->mobile_phone = $validatedData['mobile_phone'];
            $user->username = $validatedData['username'];
            $user->user_timezone_id = $request->user_timezone_id;
            $user->office = $request->office;
            $user->city = $request->city;
            $user->state = $request->state;
            $user->country = $request->country;
            $user->licenses = $request->licenses;
            $user->CRM_link = $request->CRM_link;
            $user->notes = $request->notes;

            // Update slots AFTER checking difference
            $user->number_of_users = $newSlots;

            if ($newSlots > $oldSlots) {
                $extraSlots = $newSlots - $oldSlots;
                $amountDue = $extraSlots * 1;

                // ✅ Reset payment and subscription status properly
                $user->setup_fee_paid = false;

                WellifySubscription::where('employer_id', $user->id)
                    ->update(['status' => 'pending']);
                    $user->save();

                Stripe::setApiKey(env('STRIPE_SECRET'));

                $session = Session::create([
                    'payment_method_types' => ['card'],
                    'customer_email' => $user->email,
                    'line_items' => [[
                        'price_data' => [
                            'currency' => 'usd',
                            'product_data' => ['name' => 'Additional Employee Slots'],
                            'unit_amount' => 100,
                        ],
                        'quantity' => $extraSlots,
                    ]],
                    'mode' => 'payment',
                    'success_url' => route('stripe.extra_slots.success', ['employer_id' => $user->id]) . '&session_id={CHECKOUT_SESSION_ID}',
                    'cancel_url' => route('stripe.cancel'),
                    'metadata' => [
                        'employer_id' => $user->id,
                    ],
                ]);

                $paymentLink = $session->url;

                Mail::to($user->email)->send(new SlotsPaymentMail($user, $amountDue, $paymentLink));
            }
            else {
                // If slots are not increased, save normally here
                $user->save();
            }



            return redirect()->to('/wellify_users')->with('success', 'User updated successfully!');
        } catch (ValidationException $e) {
            return redirect()->back()->withErrors($e->validator)->withInput();
        } catch (Exception $e) {
            Log::error('Error updating user: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Failed to update user. Please try again.')->withInput();
        }
    }




    /*Delete the Employer Function* */
    public function destroy($id)
    {
        try {
            $user = WellifyUser::findOrFail($id);
            // dd($user);
            $user->status=0;
            $user->save();
            $user->delete();

            return response()->json([
                'success' => true,
                'message' => 'Employer deleted successfully'
            ]);
        } catch (Exception $e) {
            Log::error('Error deleting Employer: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete Employer'
            ], 500);
        }
    }

    public function getProfilePictureUrl($id)
    {
        $user = WellifyUser::findOrFail($id);

        if ($user->profile_picture) {
            $s3 = new S3Client([
                'version' => 'latest',
                'region'  => env('AWS_DEFAULT_REGION'),
                'credentials' => [
                    'key'    => env('AWS_ACCESS_KEY_ID'),
                    'secret' => env('AWS_SECRET_ACCESS_KEY'),
                ]
            ]);
            $cmd = $s3->getCommand('GetObject', [
                'Bucket' => env('AWS_BUCKET'),
                'Key'    => env('S3_USER') . $user->profile_picture
            ]);

            $request = $s3->createPresignedRequest($cmd, '+20 minutes');
            $url = (string) $request->getUri();

            return response()->json([
                'success' => true,
                'url' => $url,
            ]);
        }

        return response()->json(['success' => false, 'url' => null]);
    }

    /*Show deleted users */
    public function deletedUsers()
    {
        return view('wellify_users.index');
    }

    public function deletedData(Request $request)
    {

        if ($request->ajax()) {
            Log::info('DataTables request received2');
            $users = WellifyUser::onlyTrashed();
            if ($request->has('sort_filter') && $request->sort_filter) {
                switch ($request->sort_filter) {
                    case 'today':
                        $users->whereDate('deleted_at', today());
                        break;
                    case 'last_week':
                        $users->whereBetween('deleted_at', [now()->subWeek(), now()]);
                        break;
                    case 'last_month':
                        $users->whereBetween('deleted_at', [now()->subMonth(), now()]);
                        break;
                }
            }
            Log::info('Query will return: ' . $users->count() . ' records');
            return DataTables::of($users)
                ->addColumn('checkbox', function ($user) {
                    return '<input type="checkbox" class="restore-checkbox" value="' . $user->id . '">';
                })

                ->editColumn('organization', function ($user) {
                    $imgTag = '';
                    if ($user->profile_picture) {
                        $s3 = new S3Client([
                            'version' => 'latest',
                            'region'  => env('AWS_DEFAULT_REGION'),
                            'credentials' => [
                                'key'    => env('AWS_ACCESS_KEY_ID'),
                                'secret' => env('AWS_SECRET_ACCESS_KEY'),
                            ]
                        ]);

                        $cmd = $s3->getCommand('GetObject', [
                            'Bucket' => env('AWS_BUCKET'),
                            'Key'    => env('S3_USER') . $user->profile_picture
                        ]);

                        $request = $s3->createPresignedRequest($cmd, '+20 minutes');
                        $presignedUrl = (string) $request->getUri();

                        $imgTag = '<span class="logo_outer"><img src="' . $presignedUrl . '" alt="Profile Picture" class="table_logo_img"></span>';
                    }

                    return '
                        <span class="d-flex align-items-center gap-2">
                            ' . $imgTag . '
                            <span class="ms-2">' . e($user->organization) . '</span>
                        </span>';
                })
                ->addColumn('username', fn($user) => '@' . $user->username)
                ->addColumn('contact_person', fn($user) => $user->first_name . ' ' . $user->last_name)
                ->addColumn('status', fn($user) => $user->status ? 'Active' : 'Inactive')
                ->addColumn('deleted_at', fn($user) => optional($user->deleted_at)->format('d M Y'))
                ->addColumn('timezone',function($user){
                    return  $user->timezone?->utc_offset;
                })
                ->editColumn('mobile_phone', function($user) {
                    $digits = preg_replace('/\D/', '', $user->mobile_phone); // Remove non-digits
                    if (strlen($digits) === 10) {
                        return 'XXX-XXX-' . substr($digits, 6, 4);
                    }
                    return $user->mobile_phone; // Fallback for non-10-digit numbers
                })


                ->addColumn('action', function($user) {
                    return '<div class="action_td">
                        <span class="view_icon" title="View" data-id="' . $user->id . '">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="14" viewBox="0 0 20 14" fill="none">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M6 7C6 6.00544 6.39509 5.05161 7.09835 4.34835C7.80161 3.64509 8.75544 3.25 9.75 3.25C10.7446 3.25 11.6984 3.64509 12.4017 4.34835C13.1049 5.05161 13.5 6.00544 13.5 7C13.5 7.99456 13.1049 8.94839 12.4017 9.65165C11.6984 10.3549 10.7446 10.75 9.75 10.75C8.75544 10.75 7.80161 10.3549 7.09835 9.65165C6.39509 8.94839 6 7.99456 6 7ZM9.75 4.75C9.15326 4.75 8.58097 4.98705 8.15901 5.40901C7.73705 5.83097 7.5 6.40326 7.5 7C7.5 7.59674 7.73705 8.16903 8.15901 8.59099C8.58097 9.01295 9.15326 9.25 9.75 9.25C10.3467 9.25 10.919 9.01295 11.341 8.59099C11.7629 8.16903 12 7.59674 12 7C12 6.40326 11.7629 5.83097 11.341 5.40901C10.919 4.98705 10.3467 4.75 9.75 4.75Z" fill="#1283CE" />
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M2.073 5.646C1.654 6.25 1.5 6.723 1.5 7C1.5 7.277 1.654 7.75 2.073 8.354C2.479 8.937 3.081 9.57 3.843 10.155C5.37 11.327 7.463 12.25 9.75 12.25C12.037 12.25 14.13 11.327 15.657 10.155C16.419 9.57 17.021 8.937 17.427 8.354C17.846 7.75 18 7.277 18 7C18 6.723 17.846 6.25 17.427 5.646C17.021 5.063 16.419 4.43 15.657 3.845C14.13 2.673 12.037 1.75 9.75 1.75C7.463 1.75 5.37 2.673 3.843 3.845C3.081 4.43 2.479 5.063 2.073 5.646ZM2.929 2.655C4.66 1.327 7.066 0.25 9.75 0.25C12.434 0.25 14.84 1.327 16.57 2.655C17.437 3.32 18.153 4.062 18.659 4.791C19.151 5.5 19.5 6.277 19.5 7C19.5 7.723 19.15 8.5 18.659 9.209C18.153 9.938 17.437 10.679 16.571 11.345C14.841 12.673 12.434 13.75 9.75 13.75C7.066 13.75 4.66 12.673 2.93 11.345C2.063 10.68 1.347 9.938 0.841 9.209C0.35 8.5 0 7.723 0 7C0 6.277 0.35 5.5 0.841 4.791C1.347 4.062 2.063 3.321 2.929 2.655Z" fill="#1283CE" />
                            </svg>
                        </span>
                        <span class="restore_icon" title="Restore" data-id="' . $user->id . '" data-bs-toggle="modal" data-bs-target="#restore_user">
                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                d="M9.00003 3.723C6.75838 4.23409 4.7972 5.58344 3.51867 7.49436C2.24014 9.40527 1.74116 11.7329 2.12403 14M9.00003 3.723L6.00003 2.5M9.00003 3.723L8.00003 6.5M19.064 16.5C19.6816 15.2571 20.002 13.8878 20 12.5C20 8.04 16.757 4.339 12.5 3.624M19.064 16.5L22 14.5M19.064 16.5L17.5 13.5M3.51603 17.5C4.33773 18.7314 5.45079 19.7408 6.75638 20.4386C8.06196 21.1364 9.51967 21.501 11 21.5C13.2144 21.5028 15.3515 20.6864 17 19.208M3.51603 17.5H7.00003M3.51603 17.5V21"
                                stroke="#007C00" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                        </span>
                    </div>';
                })
                ->rawColumns(['checkbox', 'organization', 'contact_person', 'username', 'deleted_at', 'action','timezone','mobile_phone'])
                ->make(true);
        }

        return abort(404);
    }

    /*Restore a soft-deleted user */
    public function restore($id)
    {
        try {
            $user = WellifyUser::onlyTrashed()->findOrFail($id);
            $user->restore();
            $user->status = 1;
            $user->save();

            return redirect()->route('wellify_users.index')->with('success', 'Employer restored successfully.');
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to restore employer.'
            ], 500);
        }
    }

    public function bulkRestore(Request $request)
    {
        $ids = $request->input('ids');
        if (!$ids || !is_array($ids)) {
            return response()->json(['success' => false, 'message' => 'No employers selected.'], 400);
        }
        $users = WellifyUser::onlyTrashed()->whereIn('id', $ids)->get();
        foreach ($users as $user) {
            $user->restore();
            $user->status = 1;
            $user->save();
        }
        return response()->json(['success' => true, 'message' => 'Employers restored successfully.']);
    }

    public function sendWelcomeEmail($id)
    {
        $user = WellifyUser::findOrFail($id);

        if (!$user->setup_fee_paid) {
            return response()->json(['message' => 'Setup fee not paid yet. Cannot send credentials.'], 400);
        }

        // if ($user->welcome_email_sent) {
        //     return response()->json(['message' => 'Credentials already sent.'], 400);
        // }

        $newPassword = Str::random(10);
        $user->password = Hash::make($newPassword);
        $user->welcome_email_sent = true;
        $user->save();

        Mail::to($user->email)->send(new EmployerCreatedMail($user, $newPassword));

        return response()->json(['message' => 'Welcome email sent successfully.']);
    }
}
<?php

namespace App\Http\Controllers\Employer;

use App\Http\Controllers\Controller;
use App\Models\Employer\Department;
use App\Models\Employer\Staff;
use App\Models\WellifyUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Validator;
use App\Imports\EmployeesImportz;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use App\Mail\StaffWelcomeMail;
use App\Mail\StaffCreatedMail;
use Illuminate\Support\Facades\Password;
use Illuminate\Validation\Rule;
use Illuminate\Database\QueryException;

class StaffController extends Controller
{
    /**
     * to display all staffs
     */
    public function index()
    {
        $user = Auth::user();
        if ($user->hasRole('Super Admin')) {
            $employees = WellifyUser::where('supervisor_id', '2')->get();
            $departments = Department::with('employer')->get();
        } else {
            $departments = Department::where('employer_id', $user->id)->with('employer')->get();
            // dd($departments);
            $employees = WellifyUser::where('supervisor_id', $user->id)
                ->with(['department', 'department.employer'])
                ->get();
        }
        return view('employer.staff', compact('departments', 'employees'));
    }

    /**
     * to download sample excel file
     */
    public function downloadExcel()
    {
        $templatePath = public_path('excelFile/Staffs_Import_Excel.xlsx');
        if (!file_exists($templatePath)) {
            return back()->with('error', 'Template file not found');
        }
        return response()->download($templatePath, 'Staffs_Import_Excel.xlsx');
    }

    /**
     * to display all staffs
     */
    public function getAllStaffs(Request $request)
    {
        $user = Auth::user();

        if ($user->hasRole('Super Admin')) {
            // Super Admin sees all employees with their employers
            $employees = Staff::with(['department', 'department.employer'])
                ->orderBy('created_at', 'desc')
                ->get();
        } else {
            // Employer sees only employees created under their departments
            $employees = Staff::with(['department', 'department.employer'])
                ->whereHas('department', function ($query) use ($user) {
                    $query->where('employer_id', $user->id);
                })
                ->orderBy('created_at', 'desc')
                ->get();
        }

        $data = $employees->map(function ($employee) use ($user) {
            $departmentName = $employee->department ? $employee->department->name : 'Un-Assigned';
            $viewButton = '<span class="view_icon me-4 view-employee-modal" title="View"
                        data-id="' . $employee->id . '">
                         <svg xmlns="http://www.w3.org/2000/svg" width="20" height="14" viewBox="0 0 20 14" fill="none">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M6 7C6 6.00544 6.39509 5.05161 7.09835 4.34835C7.80161 3.64509 8.75544 3.25 9.75 3.25C10.7446 3.25 11.6984 3.64509 12.4017 4.34835C13.1049 5.05161 13.5 6.00544 13.5 7C13.5 7.99456 13.1049 8.94839 12.4017 9.65165C11.6984 10.3549 10.7446 10.75 9.75 10.75C8.75544 10.75 7.80161 10.3549 7.09835 9.65165C6.39509 8.94839 6 7.99456 6 7ZM9.75 4.75C9.15326 4.75 8.58097 4.98705 8.15901 5.40901C7.73705 5.83097 7.5 6.40326 7.5 7C7.5 7.59674 7.73705 8.16903 8.15901 8.59099C8.58097 9.01295 9.15326 9.25 9.75 9.25C10.3467 9.25 10.919 9.01295 11.341 8.59099C11.7629 8.16903 12 7.59674 12 7C12 6.40326 11.7629 5.83097 11.341 5.40901C10.919 4.98705 10.3467 4.75 9.75 4.75Z" fill="#1283CE" />
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M2.073 5.646C1.654 6.25 1.5 6.723 1.5 7C1.5 7.277 1.654 7.75 2.073 8.354C2.479 8.937 3.081 9.57 3.843 10.155C5.37 11.327 7.463 12.25 9.75 12.25C12.037 12.25 14.13 11.327 15.657 10.155C16.419 9.57 17.021 8.937 17.427 8.354C17.846 7.75 18 7.277 18 7C18 6.723 17.846 6.25 17.427 5.646C17.021 5.063 16.419 4.43 15.657 3.845C14.13 2.673 12.037 1.75 9.75 1.75C7.463 1.75 5.37 2.673 3.843 3.845C3.081 4.43 2.479 5.063 2.073 5.646ZM2.929 2.655C4.66 1.327 7.066 0.25 9.75 0.25C12.434 0.25 14.84 1.327 16.57 2.655C17.437 3.32 18.153 4.062 18.659 4.791C19.151 5.5 19.5 6.277 19.5 7C19.5 7.723 19.15 8.5 18.659 9.209C18.153 9.938 17.437 10.679 16.571 11.345C14.841 12.673 12.434 13.75 9.75 13.75C7.066 13.75 4.66 12.673 2.93 11.345C2.063 10.68 1.347 9.938 0.841 9.209C0.35 8.5 0 7.723 0 7C0 6.277 0.35 5.5 0.841 4.791C1.347 4.062 2.063 3.321 2.929 2.655Z" fill="#1283CE" />
                    </svg>
                    </span>';

            $editButton = '<span class="edit_icon1 me-3 edit-employee-modal" title="Edit"
                        data-id="' . $employee->id . '"
                        data-firstname="' . $employee->first_name . '"
                        data-lastname="' . $employee->last_name . '"
                        data-email="' . $employee->email . '"
                        data-phone="' . $employee->mobile_phone . '"
                        data-department_id="' . $employee->department_id . '"
                        data-city="' . $employee->city . '"
                        data-state="' . $employee->state . '"
                        data-country="' . $employee->country . '">

                        <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" fill="none" viewBox="0 0 21 20">
                            <path d="M14.666 2.5C14.8849 2.28113 15.1447 2.10751 15.4307 1.98906C15.7167 1.87061 16.0232 1.80964 16.3327 1.80964C16.6422 1.80964 16.9487 1.87061 17.2347 1.98906C17.5206 2.10751 17.7805 2.28113 17.9993 2.5C18.2182 2.71887 18.3918 2.9787 18.5103 3.26467C18.6287 3.55064 18.6897 3.85713 18.6897 4.16666C18.6897 4.47619 18.6287 4.78269 18.5103 5.06866C18.3918 5.35462 18.2182 5.61446 17.9993 5.83333L6.74935 17.0833L2.16602 18.3333L3.41602 13.75L14.666 2.5Z"
                                stroke="#A25AD9" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>';

            $deleteButton = '<span class="delete_icon delete-employee-btn" title="Delete"
                        data-id="' . $employee->id . '">
                        <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" fill="none" viewBox="0 0 21 20">
                            <path d="M3 5H4.667H18M4.667 5V16.667C4.667 17.109 4.8426 17.533 5.1551 17.8455C5.4676 18.1581 5.8916 18.3337 6.33367 18.3337H14.667C15.1091 18.3337 15.533 18.1581 15.8456 17.8455C16.1581 17.533 16.3337 17.109 16.3337 16.667V5M7.167 5V3.333C7.167 2.891 7.3426 2.467 7.6551 2.1545C7.9676 1.842 8.3916 1.666 8.83367 1.666H12.167C12.6091 1.666 13.033 1.842 13.3456 2.1545C13.6581 2.467 13.8337 2.891 13.8337 3.333V5M8.83367 9.167V14.167M12.167 9.167V14.167"
                                stroke="#F54E51" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>';

            $actionButtons = '<div class="d-flex align-items-center" style="height: 100%;">'
                .  $viewButton . $editButton . $deleteButton . '</div>';

            $employeeData = [
                'id' => $employee->id,
                'name' => $employee->username,
                'email' => $employee->email,
                'phone' => $employee->mobile_phone
                    ? (strlen(preg_replace('/[^0-9]/', '', $employee->mobile_phone)) === 10
                        ? 'XXX-XXX-' . substr(preg_replace('/[^0-9]/', '', $employee->mobile_phone), -4)
                        : $employee->mobile_phone)
                    : $employee->mobile_phone,
                'department' => $departmentName,
                'city' => $employee->city,
                'state' => $employee->state,
                'country' => $employee->country,
                'status' => '
        <div class="flipswitch">
            <input ' . ($employee->status ? 'checked' : '') . ' class="flipswitch-cb" type="checkbox" id="fs_' . $employee->id . '" data-id="' . $employee->id . '">
            <label for="fs_' . $employee->id . '" class="flipswitch-label">
                <span class="flipswitch-inner d-block"></span>
                <span class="flipswitch-switch d-block"></span>
            </label>
        </div>',
                'actions' => $actionButtons,
            ];

            // Add employer column for non-employer roles
            if (!$user->hasRole('Employer')) {
                $employeeData['employer'] = $employee->department && $employee->department->employer
                    ? $employee->department->employer->username
                    : 'N/A';
            }
            return $employeeData;
        });
        return response()->json(['data' => $data]);
    }

    public function getDeletedStaffs(Request $request)
    {
        $employees = Staff::onlyTrashed()->with('department')->orderBy('deleted_at', 'desc')->get();
        $data = $employees->map(function ($employee) {
            $departmentName = $employee->department ? $employee->department->name : 'N/A';

            $restoreButton = '<span class="restore_icon restore-employee-btn" title="Restore"
                                data-id="' . $employee->id . '">
                                <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" fill="none" viewBox="0 0 24 24">
                                    <path d="M9 3.72C6.76 4.23 4.8 5.58 3.52 7.49C2.24 9.4 1.74 11.73 2.12 14M9 3.72L6 2.5M9 3.72L8 6.5M19.06 16.5C19.68 15.26 20 13.89 20 12.5C20 8.04 16.76 4.34 12.5 3.62M19.06 16.5L22 14.5M19.06 16.5L17.5 13.5M3.52 17.5C4.34 18.73 5.45 19.74 6.76 20.44C8.06 21.14 9.52 21.5 11 21.5C13.21 21.5 15.35 20.69 17 19.21M3.52 17.5H7M3.52 17.5V21"
                                        stroke="#007C00" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </span>';

            return [
                'id' => $employee->id,
                'name' => $employee->first_name . ' ' . $employee->last_name,
                'email' => $employee->email,
                'phone' => $employee->mobile_phone
                    ? (strlen(preg_replace('/[^0-9]/', '', $employee->mobile_phone)) === 10
                        ? 'XXX-XXX-' . substr(preg_replace('/[^0-9]/', '', $employee->mobile_phone), -4)
                        : $employee->mobile_phone)
                    : $employee->mobile_phone,
                'department' => $departmentName,
                'city' => $employee->city,
                'state' => $employee->state,
                'country' => $employee->country,
                'actions' => $restoreButton,
            ];
        });

        return response()->json(['data' => $data]);
    }

    /**
     * to store staffs with ADD NEW Module
     */
    // public function store(Request $request)
    // {
    //     $request->validate([
    //         'firstName' => 'required|string|max:255',
    //         'secondName' => 'required|string|max:255',
    //         'staff_email' => 'required|email|unique:wellify_staffs,email',
    //         'phone' => ['required', 'string', 'regex:/^\d{3}-\d{3}-\d{4}$/'],
    //         'department_id' => 'required|exists:wellify_departments,id'
    //     ]);
    //     // Generate display name (wellness-themed)
    //     $wellnessWords = ['Zen', 'Calm', 'Breathe', 'Pulse', 'Glow', 'Mindful', 'Wellness', 'Harmony', 'Serene', 'Balance'];
    //     $randomDisplayName = $wellnessWords[array_rand($wellnessWords)] . '_' . rand(100, 999);
    //     $randomPassword = Str::random(12);
    //     $employee = Staff::create([
    //         'username' => $randomDisplayName,
    //         'first_name' => $request->firstName,
    //         'last_name' => $request->secondName,
    //         'email' => $request->staff_email,
    //         'mobile_phone' => $request->phone,
    //         'department_id' => $request->department_id,
    //         'city' => $request->city,
    //         'state' => $request->state,
    //         'country' => $request->country,
    //         'password' => Hash::make($randomPassword),
    //         'created_by' => auth()->user()->id,
    //     ]);
    //     $employee->assignRole('Staff');
    //     $user = $employee->email;
    //     $token = Password::broker('staff')->createToken($user);
    //     $link = url('password/reset', $token) . '?email=' . urlencode($user);
    //     // Send email
    //     Mail::to($user)->send(new StaffCreatedMail($user, $randomPassword, $link));
    //     return response()->json([
    //         'status' => 'success',
    //         'message' => 'Employee added successfully!',
    //         'generated_display_name' => $randomDisplayName,
    //     ]);
    // }

    public function store(Request $request)
    {
        // Validate the request inputs including phone uniqueness
        $validatedData = $request->validate([
            'firstName' => 'required|string|max:255',
            'secondName' => 'required|string|max:255',
            'staff_email' => 'required|email|unique:wellify_staffs,email',
            'phone' => [
                'required',
                'string',
                'regex:/^\d{3}-\d{3}-\d{4}$/',
                'unique:wellify_staffs,mobile_phone', // unique on mobile_phone column
            ],
            'department_id' => 'required|exists:wellify_departments,id',
        ], [
            'phone.unique' => 'Phone number has already been taken.', // Custom message for duplicate phone
            'phone.regex' => 'Phone number must be in the format XXX-XXX-XXXX.',
        ]);

        // Remove dashes for storage
        $mobilePhone = str_replace('-', '', $validatedData['phone']);

        // Generate display name (wellness-themed)
        $wellnessWords = ['Zen', 'Calm', 'Breathe', 'Pulse', 'Glow', 'Mindful', 'Wellness', 'Harmony', 'Serene', 'Balance'];
        $randomDisplayName = $wellnessWords[array_rand($wellnessWords)] . '_' . rand(100, 999);

        // Generate random password

        $randomPassword = Str::random(12);

        // Create Staff record
        $staff = Staff::create([
            'username' => $randomDisplayName,
            'first_name' => $request->firstName,
            'last_name' => $request->secondName,
            'email' => $request->staff_email,
            'mobile_phone' => $request->phone,
            'department_id' => $request->department_id,
            'city' => $request->city,
            'state' => $request->state,
            'country' => $request->country,
            'password' => Hash::make($randomPassword),
            'created_by' => auth()->user()->id,
        ]);

        // Assign role
        $staff->assignRole('Staff');

        // IMPORTANT: Pass model instance (Staff) to createToken
        $token = Password::broker('staff')->createToken($staff);

        $link = url('password/reset', $token) . '?email=' . urlencode($staff->email);

        // Send email using StaffCreatedMail - pass Staff model, password, and link
        Mail::to($staff->email)->send(new StaffCreatedMail($staff, $randomPassword, $link));

        return response()->json([
            'status' => 'success',
            'message' => 'Staff added successfully!',
            'generated_display_name' => $randomDisplayName,
        ]);
    }


    //     try {
    //         $employee = Staff::create([
    //             'username' => $randomDisplayName,
    //             'first_name' => $validatedData['firstName'],
    //             'last_name' => $validatedData['secondName'],
    //             'email' => $validatedData['staff_email'],
    //             'mobile_phone' => $mobilePhone,
    //             'department_id' => $validatedData['department_id'],
    //             'city' => $request->city,
    //             'state' => $request->state,
    //             'country' => $request->country,
    //             'password' => Hash::make($randomPassword),
    //             'created_by' => auth()->user()->id,
    //         ]);
    //         return response()->json(['message' => 'Staff added successfully!'], 200);
    //     } catch (QueryException $e) {
    //         // Duplicate entry error code is 23000 for MySQL
    //         if ($e->getCode() == 23000) {
    //             return response()->json([
    //                 'errors' => [
    //                     'phone' => ['Phone number has already been taken.']
    //                 ]
    //             ], 422);
    //         }
    //         return response()->json([
    //             'status' => 'success',
    //             'message' => 'Employee added successfully!',
    //             'generated_display_name' => $randomDisplayName,
    //         ]);
    //     }
    // }
    /**
     * to view staffs
     */
    public function viewStaff($id)
    {
        $employee = Staff::with('department')->findOrFail($id);
        return response()->json([
            'status' => true,
            'data' => [
                'id' => $employee->id,
                'userName' => $employee->username,
                'firstName' => $employee->first_name,
                'lastName' => $employee->last_name,
                'email' => $employee->email,
                'phone' => preg_replace("/(\d{3})(\d{3})(\d{4})/", "$1-$2-$3", $employee->mobile_phone),
                'department' => $employee->department ? $employee->department->name : 'N/A',
                'city' => $employee->city,
                'state' => $employee->state,
                'country' => $employee->country,
            ]
        ]);
    }

    /**
     * to update staffs
     */

    public function updateStaff(Request $request)
    {
        $input = $request->all();
        $input['mobile_phone_stripped'] = str_replace('-', '', $request->mobile_phone);
        $validator = Validator::make($input, [
            'id' => 'required|exists:wellify_staffs,id',
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'mobile_phone' => [
                'required',
                'string',
                'regex:/^\d{3}-\d{3}-\d{4}$/'
            ],
            'mobile_phone_stripped' => [
                Rule::unique('wellify_staffs', 'mobile_phone')->ignore($request->id)
            ],
            'department_id' => [
                'nullable',
                'exists:wellify_departments,id',
            ],
            'city' => 'nullable|string|max:255',
            'state' => 'nullable|string|max:255',
            'country' => 'nullable|string|max:255',
        ], [
            'mobile_phone_stripped.unique' => 'This phone number has already been taken.'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $employee = Staff::findOrFail($request->id);
            $updateData = [
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'mobile_phone' => $input['mobile_phone_stripped'],
                'city' => $request->city,
                'state' => $request->state,
                'country' => $request->country,
            ];

            if ($request->filled('department_id')) {
                $departmentExists = Department::where('id', $request->department_id)
                    ->where('employer_id', $employee->department->employer_id)
                    ->exists();
                if ($departmentExists) {
                    $updateData['department_id'] = $request->department_id;
                } else {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Selected department is not valid for this employee\'s employer.'
                    ], 422);
                }
            }

            $employee->update($updateData);

            return response()->json([
                'status' => 'success',
                'message' => 'Staff updated successfully.',
                'employee' => $employee
            ]);
        } catch (\Exception $e) {
            Log::error('Staff Update Error: ' . $e->getMessage());

            return response()->json([
                'status' => 'error',
                'message' => 'An error occurred while updating the staff.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * to delete staffs
     */
    public function destroy($id)
    {
        $employee = Staff::findOrFail($id);
        $employee->delete();
        return response()->json([
            'success' => true,
            'message' => 'Employee has been marked as inactive and moved to Inactive Staff list.',
            'inactive' => true
        ]);
    }

    /**
     * to restore deleted staffs
     */
    public function restore($id)
    {
        $employee = Staff::withTrashed()->findOrFail($id);
        if ($employee->trashed()) {
            $employee->restore();
        }

        return response()->json([
            'success' => true,
            'message' => 'Employee restored successfully.'
        ]);
    }

    /**
     * to import excel file
     */
    public function import(Request $request)
    {
        $user = Auth::user();
        $validationRules = [
            'file' => 'required|mimes:xlsx,csv'
        ];


        if ($user->hasRole('Employer')) {
            $employerId = $user->id;
        } elseif ($user->hasRole('Super Admin')) {
            $validationRules['employer_id'] = 'required|exists:wellify_users,id';
            $employerId = $request->input('employer_id');
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized access. Invalid user role.'
            ], 403);
        }

        $validator = Validator::make($request->all(), $validationRules, [
            'file.required' => 'The file is required.',
            'file.mimes' => 'The file must be a file of type: xlsx, csv.',
            'employer_id.required' => 'Please select an employer.',
            'employer_id.exists' => 'Selected employer does not exist.'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 400);
        }

        try {
            Log::info('Import Initiated', [
                'employer_id' => $employerId,
                'user_id' => Auth::id(),
                'file_name' => $request->file('file')->getClientOriginalName()
            ]);


            session(['selected_employer_id' => $employerId]);

            $import = new EmployeesImportz($employerId);
            Excel::import($import, $request->file('file'));

            $importResult = session('import_result', [
                'new_employees_count' => 0,
                'existing_employees_count' => 0,
                'skipped_employees_count' => 0
            ]);

            $skippedEmployees = session('skipped_employees', []);
            $existingEmployees = session('existing_employees', []);

            $responseMessage = "Import Summary: ";
            if ($importResult['new_employees_count'] > 0) {
                $responseMessage .= "{$importResult['new_employees_count']} new employees added. ";
            }

            if (!empty($skippedEmployees)) {
                $responseMessage .= count($skippedEmployees) . " employees were skipped due to invalid data or duplicates. ";
            }

            if (!empty($existingEmployees)) {
                $responseMessage .= count($existingEmployees) . " employees already exist. ";
            }

            // Determine response based on import results
            if ($importResult['new_employees_count'] > 0) {

                return response()->json([
                    'success' => true,
                    'message' => $responseMessage,
                    'import_details' => $importResult,
                    'skipped_employees' => $skippedEmployees,
                    'existing_employees' => $existingEmployees,
                ]);
            } elseif (!empty($skippedEmployees)) {

                return response()->json([
                    'success' => false,
                    'message' => "No new employees added. Some employees were skipped due to invalid data or duplicates.",
                    'import_details' => $importResult,
                    'skipped_employees' => $skippedEmployees,
                    'existing_employees' => $existingEmployees,
                ], 400);
            } elseif (!empty($existingEmployees)) {

                return response()->json([
                    'success' => false,
                    'message' => "No new employees added. All employees already exist.",
                    'import_details' => $importResult,
                    'existing_employees' => $existingEmployees,
                ], 400);
            } else {

                return response()->json([
                    'success' => false,
                    'message' => "No employees were imported.",
                    'import_details' => $importResult,
                ], 400);
            }
        } catch (\Exception $e) {
            Log::error('Import Failure', [
                'message' => $e->getMessage(),
                'employer_id' => $employerId,
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Import failed due to an unexpected error.',
                'error' => $e->getMessage(),
                'existing_employees' => session('existing_employees', []),
                'skipped_employees' => session('skipped_employees', [])
            ], 500);
        }
    }

    public function toggleStatus(Request $request)
    {
        $user = Staff::find($request->id);
        if (!$user) {
            return response()->json(['message' => 'Staff not found'], 404);
        }

        $user->status = $request->status;
        $user->save();
        return response()->json(['message' => 'Status updated']);
    }

    /**
     * to send welcome emails to selected staffs
     */
    public function sendBulkWelcomeEmails(Request $request)
    {
        $employees = $request->input('employees');
        $emailContent = $request->input('emailContents');
        $successCount = 0;
        $failedEmails = [];

        foreach ($employees as $index => $employee) {
            try {
                $staff = Staff::find($employee['id']);
                $tempPassword = Str::random(12);
                $staff->password = Hash::make($tempPassword);
                $staff->save();

                $personalizedContent = str_replace(
                    ['[username]', '[email]', '[password]'],
                    [$employee['username'], $employee['email'], $tempPassword],
                    $emailContent[$index]['content']
                );
                Mail::to($employee['email'])->send(new StaffWelcomeMail($personalizedContent, $employee['username'], $employee['email'], $tempPassword));
                $successCount++;
                Log::info('Employee Data:', $employee);
            } catch (\Exception $e) {
                $failedEmails[] = $employee['email'];
                Log::error('Failed to send welcome email', [
                    'email' => $employee['email'],
                    'error' => $e->getMessage()
                ]);
            }
        }

        return response()->json([
            'success' => true,
            'successCount' => $successCount,
            'failedEmails' => $failedEmails
        ]);
    }

    /**
     * to display textarea for edit welcome email
     */
    public function getWelcomeEmailTemplate()
    {
        return view('emails.staff_welcome_template');
    }
}

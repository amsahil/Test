<?php

namespace App\Http\Controllers;

use Stripe\Price;
use Stripe\Refund;
use Stripe\Stripe;
use Stripe\Product;
use Stripe\Customer;
use Stripe\SetupIntent;
use Stripe\Subscription;
use Stripe\PaymentIntent;
use Stripe\PaymentMethod;
use App\Models\WellifyUser;
use App\Models\WellifyPlans;
use Illuminate\Http\Request;
use Stripe\Checkout\Session;
use App\Models\WellifyDtcPlan;
use App\Models\Wellifypayments;
use App\Models\WellifyPlansRange;
use App\Models\WellifystripePlan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use App\Models\WellifyUserSubscription;


class WellifyStripePaymentController extends Controller
{

    public function showPlanPage()
    {
        $employers = WellifyUser::select('id', 'username')->get();
        return view('wellifyplans.index', compact('employers'));
    }

    // public function plansStore(Request $request)
    // {
    //     $request->validate([
    //         // 'employer_id' => 'required|exists:wellify_users,id',
    //         'plan_name' => 'required|string|max:50',
    //         'free_trial_days' => 'nullable|string',
    //         'weekly_classes' => ['nullable', 'regex:/^(\d+|Unlimited)$/i'],
    //         'weekly_activities' => ['nullable', 'regex:/^(\d+|Unlimited)$/i'],
    //         'users_range' => 'required|array',
    //         'monthly_price' => 'required|array',
    //         // 'annual_price' => 'required|array',
    //         'notes' => 'nullable|string',
    //     ]);

    //     // Start transaction to ensure both inserts succeed or fail
    //     DB::beginTransaction();

    //     try {
    //         // Insert into wellify_subscription_plans
    //         $defaultPlan = WellifyPlans::where('is_default', true)->first();
    //         $plan = WellifyPlans::create([
    //             'employer_id' => Auth::id(),
    //             // 'employer_id' => $request->employer_id,
    //             'name' => $request->plan_name,
    //             'duration' => 'monthly',  // or add form input if dynamic
    //             'trial_days' => $request->free_trial_days,
    //             'class_limit' => is_numeric($request->weekly_classes) ? (int) $request->weekly_classes : null,
    //             'activity_limit' => is_numeric($request->weekly_activities) ? (int) $request->weekly_activities : null,
    //             'is_freemium' => false,  // or your logic
    //             'status' => 1,
    //             'notes' => $request->notes,
    //         ]);

    //         // Insert into wellify_subscription_plan_range
    //         $usersRanges = $request->users_range;
    //         $monthlyPrices = $request->monthly_price;
    //         // $annualPrices = $request->annual_price;

    //         foreach ($usersRanges as $index => $range) {
    //             // Parse user range like "100-200"
    //             $parts = explode('-', $range);
    //             $min = isset($parts[0]) ? (int)trim($parts[0]) : null;
    //             $max = isset($parts[1]) ? (int)trim($parts[1]) : null;

    //             WellifyPlansRange::create([
    //                 'plan_id' => $plan->id,
    //                 'users_range_min' => $min,
    //                 'users_range_max' => $max,
    //                 'mothly_price_per_user' => $monthlyPrices[$index],
    //                 // 'yearly_price_per_user' => $annualPrices[$index],
    //             ]);
    //         }

    //         DB::commit();

    //         return redirect()->back()->with('success', 'Plan and pricing ranges added successfully.');

    //     } catch (\Exception $e) {
    //         DB::rollBack();
    //         return redirect()->back()->with('error', 'Failed to save data: ' . $e->getMessage());
    //     }
    // }

    public function plansStore(Request $request)
    {
        $request->validate([
            'plan_name' => 'required|string|max:50',
            'free_trial_days' => 'nullable|string',
            'weekly_classes' => ['nullable', 'regex:/^(\d+|Unlimited)$/i'],
            'weekly_activities' => ['nullable', 'regex:/^(\d+|Unlimited)$/i'],
            'users_range' => 'required|array',
            'monthly_price' => 'required|array',
            'notes' => 'nullable|string',
        ]);

        DB::beginTransaction();

        try {
            $plan = WellifyPlans::create([
                'employer_id' => Auth::id(),
                'name' => $request->plan_name,
                'duration' => 'monthly',
                'trial_days' => $request->free_trial_days,
                'class_limit' => is_numeric($request->weekly_classes) ? (int) $request->weekly_classes : null,
                'activity_limit' => is_numeric($request->weekly_activities) ? (int) $request->weekly_activities : null,
                'is_freemium' => false,
                'status' => 1,
                'notes' => $request->notes,
            ]);

            foreach ($request->users_range as $index => $range) {
                $parts = explode('-', $range);
                $min = isset($parts[0]) ? (int)trim($parts[0]) : null;
                $max = isset($parts[1]) ? (int)trim($parts[1]) : null;

                WellifyPlansRange::create([
                    'plan_id' => $plan->id,
                    'users_range_min' => $min,
                    'users_range_max' => $max,
                    'mothly_price_per_user' => $request->monthly_price[$index],
                ]);
            }

            DB::commit();

            return redirect()->back()->with('success', 'Plan and pricing ranges added successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Failed to save data: ' . $e->getMessage());
        }
    }

    public function getPlan($id)
    {
        $plan = WellifyPlans::find($id);
        if ($plan) {
            return response()->json(['success' => true, 'data' => $plan]);
        }
        return response()->json(['success' => false, 'message' => 'Plan not found'], 404);
    }

    public function PlanStoreDtc(Request $request)
    {
    }

    public function getB2BPlans()
    {
        $plans = WellifyPlans::select([
            'id',
            'name',
            'trial_days',
            'class_limit',
            'activity_limit',
            'status',
            'is_default',
        ])->get();

        $data = $plans->map(function($plan) {
            return [
                'id' => $plan->id,
                'plan_name' => $plan->name,
                'free_trial' => $plan->trial_days > 0
                    ? $plan->trial_days . ' ' . ($plan->trial_days == 1 ? 'day' : 'days')
                    : 'No Trial',
                'weekly_classes' => $plan->class_limit !== null
                    ? $plan->class_limit . ' ' . ($plan->class_limit == 1 ? 'Class' : 'Classes')
                    : 'Unlimited',
                'weekly_activities' => $plan->activity_limit !== null
                    ? $plan->activity_limit . ' ' . ($plan->activity_limit == 1 ? 'Activity' : 'Activities')
                    : 'Unlimited',
                'status' => $plan->status,
                'is_default'=>$plan->is_default,
            ];
        });

        return response()->json(['data' => $data]);
    }

    // public function update(Request $request, $id)
    // {
    //     $plan = WellifyPlans::findOrFail($id);
    //     $plan->update($request->all());

    //     return response()->json(['success' => true]);
    // }

    public function edit($id)
    {
        $plan = WellifyPlans::with('ranges')->findOrFail($id);
        return response()->json($plan);
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'plan_name' => 'required|string|max:50',
            'free_trial_days' => 'nullable|string',
            'weekly_classes' => ['nullable', 'regex:/^(\d+|Unlimited)$/i'],
            'weekly_activities' => ['nullable', 'regex:/^(\d+|Unlimited)$/i'],
            'users_range' => 'required|array',
            'monthly_price' => 'required|array',
            // 'annual_price' => 'required|array',
            'notes' => 'nullable|string',
        ]);

        DB::beginTransaction();

        try {
            $plan = WellifyPlans::findOrFail($id);
            $plan->name = $request->plan_name;
            $plan->trial_days = $request->free_trial_days;
            $plan->class_limit = is_numeric($request->weekly_classes) ? (int) $request->weekly_classes : null;
            $plan->activity_limit = is_numeric($request->weekly_activities) ? (int) $request->weekly_activities : null;
            $plan->notes = $request->notes;
            $plan->save();

            // Delete existing ranges and reinsert
            WellifyPlansRange::where('plan_id', $plan->id)->delete();

            foreach ($request->users_range as $index => $range) {
                $parts = explode('-', str_replace(['+', '–'], ['-', '-'], $range));
                $min = isset($parts[0]) ? (int) trim($parts[0]) : 0;
                $max = isset($parts[1]) ? (int) trim($parts[1]) : null;

                WellifyPlansRange::create([
                    'plan_id' => $plan->id,
                    'users_range_min' => $min,
                    'users_range_max' => $max,
                    'mothly_price_per_user' => $request->monthly_price[$index],
                    // 'yearly_price_per_user' => $request->annual_price[$index],
                ]);
            }

            DB::commit();

            return redirect()->back()->with('success', 'Plan updated successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Failed to update plan: ' . $e->getMessage());
        }
    }

    public function getD2CPlans()
    {
        $plans = WellifyDtcPlan::all();
        $data = $plans->map(function($plan) {
            return [
                'id' => $plan->id,
                'plan_name' => $plan->name,
                'duration' => $plan->duration,
                // 'trial_days' => $plan->trial_days ?? 'N/A',
                // 'weekly_classes' => $plan->class_limit ?? 'N/A',
                // 'weekly_activities' => $plan->activity_limit ?? 'N/A',
                'trial_days' => $plan->trial_days > 0
                    ? $plan->trial_days . ' ' . ($plan->trial_days == 1 ? 'day' : 'days')
                    : 'No Trial',
                'weekly_classes' => $plan->class_limit !== null
                    ? $plan->class_limit . ' ' . ($plan->class_limit == 1 ? 'Class' : 'Classes')
                    : 'Unlimited',
                'weekly_activities' => $plan->activity_limit !== null
                    ? $plan->activity_limit . ' ' . ($plan->activity_limit == 1 ? 'Activity' : 'Activities')
                    : 'Unlimited',

                'status' => $plan->status ?? 1,
                'notes' => $plan->notes ?? '',
                'price' => $plan->price,
                'plan_annual_price' => 'N/A',
            ];
        });

        return response()->json(['data' => $data]);
    }

    public function updatePlanStatus(Request $request){
        $request->validate([
            'id' => 'required|integer|exists:wellify_subscription_plans,id',
            'status' => 'required|in:0,1',
        ]);

        $plan = WellifyPlans::findOrFail($request->id);
        $plan->status = $request->status;
        $plan->save();

        return response()->json(['message' => 'Status updated successfully.']);
    }


    public function updateD2CPlans(Request $request)
    {
        $validated = $request->validate([
            'planNameEdit' => 'required|string|max:50', // matches migration limit
            'freePlanmonth' => 'required|string|max:50',
            'freePlanclass' => 'required|integer', // class_limit is integer
            'freePlanactivity' => 'required|integer', // activity_limit is integer
            'freePlantrial' => 'nullable|string|max:255', // trial_days is text & nullable
            'editFreenotes' => 'nullable|string|max:1000',
            'plan_id' => 'required|integer',
        ]);

        $plan = WellifyDtcPlan::findOrFail($validated['plan_id']);

        $plan->name = $validated['planNameEdit'];
        $plan->price = floatval(str_replace(['$', ','], '', $validated['freePlanmonth']));
        $plan->class_limit = $validated['freePlanclass'];
        $plan->activity_limit = $validated['freePlanactivity'];
        $plan->trial_days = $validated['freePlantrial'];
        $plan->notes = $validated['editFreenotes'];

        $plan->save();

        return redirect()->back()->with('success', 'D2C Plan updated successfully!');
    }

    public function showPaymentForm()
    {
        return view('wellifypayments.stripepayment');
    }

    public function processPayment(Request $request)
    {
        return $this->handleProcessPayment($request);
    }

    public function paymentSuccess(Request $request)
    {
        return $this->handlePaymentSuccess($request);
    }

    private function handleProcessPayment(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:1'
        ]);
        Stripe::setApiKey(config('services.stripe.secret'));

        $session = Session::create([
            'payment_method_types' => ['card'],
            'line_items' => [[
                'price_data' => [
                    'currency' => 'usd',
                    'product_data' => ['name' => 'Wellify Payment'],
                    'unit_amount' => $request->amount * 100,
                ],
                'quantity' => 1,
            ]],
            'mode'        => 'payment',
            'success_url' => route('wellifypayments.success') . '?session_id={CHECKOUT_SESSION_ID}',
            'cancel_url' => route('wellifypayments.cancel') . '?amount=' . $request->amount,
            'metadata' => [
                'user_id' => Auth::id(),
            ],
        ]);

        return response()->json(['id' => $session->id]);
    }

    private function handlePaymentSuccess(Request $request)
    {
        $sessionId = $request->query('session_id');
        if (!$sessionId) {
            return 'Missing session id';
        }

        Stripe::setApiKey(config('services.stripe.secret'));

        try {
            $session = Session::retrieve($sessionId);
            $pi = PaymentIntent::retrieve($session->payment_intent);
            $paymentMethodId = $pi->payment_method;
            $paymentMethod = PaymentMethod::retrieve($paymentMethodId);
            $cardDetails = $paymentMethod->card ?? null;
            $billing = $paymentMethod->billing_details ?? $session->customer_details ?? null;
            $status = $pi->status;

            // Attempt to save payment record
            try {
                Wellifypayments::updateOrCreate(
                    ['stripe_payment_id' => $pi->id],
                    [
                        'user_id' => Auth::id(),
                        'amount' => $pi->amount / 100,
                        'currency' => $pi->currency,
                        'status' => $status,
                        'payment_method' => json_encode($pi->payment_method),
                        'card_last_4digit' => $cardDetails->last4 ?? null,
                        'card_type' => $cardDetails->brand ?? null,
                        'card_owner' => $billing?->name ?? null,
                        'card_owner_email' => $billing?->email ?? null,
                    ]
                );
            } catch (\Exception $e) {
                Refund::create([
                    'payment_intent' => $pi->id,
                    'reason' => 'requested_by_customer',
                ]);

                return 'Payment was successful, but data save failed. Amount refunded. Error: ';
            }

            if ($status === 'succeeded') {
                return 'Payment succeeded and saved!';
            } else {
                return 'Payment status: ' . $status . '. Details saved.';
            }
        } catch (\Exception $ex) {
            return 'Error handling payment: ' . $ex->getMessage();
        }
    }

    public function paymentCancel(Request $request)
    {
        $amount = $request->query('amount', 0);
        Wellifypayments::create([
            'user_id' => Auth::id(),
            'amount' => $amount,
            'currency' => 'usd',
            'status' => 'failed',
            'payment_method' => null,
            'card_last_4digit' => null,
            'card_type' => null,
            'card_owner' => null,
            'card_owner_email' => null,
        ]);

        return 'Payment failed';
    }

    public function showCreateForm()
    {
        $plans = WellifystripePlan::orderBy('created_at', 'asc')->get();
        return view('wellifypayments.stripeplans', compact('plans'));
    }

    public function createPlan(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'amount' => 'required|numeric|min:1',
            'currency' => 'required|string|size:3',
            'interval' => 'required|string|in:day,week,month,year',
            'image' => 'required|image|max:2048', // validate image file max 2MB
        ]);
        // Store image and get public URL
        $path = $request->file('image')->store('plan_images', 'public');
        $imageUrl = asset('storage/' . $path);

        Stripe::setApiKey(config('services.stripe.secret'));
        // Create Stripe product with image URL
        $product = Product::create([
            'name' => $request->name,
            'type' => 'service',
            'images' => [$imageUrl],  // pass image URL here as an array
        ]);
        $price = Price::create([
            'unit_amount' => $request->amount * 100,
            'currency' => strtolower($request->currency),
            'recurring' => ['interval' => $request->interval],
            'product' => $product->id,
        ]);
        // Save plan info and image URL to your database if needed
        WellifystripePlan::create([
            'stripe_product_id' => $product->id,
            'stripe_price_id' => $price->id,
            'name' => $request->name,
            'currency' => strtolower($request->currency),
            'amount' => $request->amount * 100,
            'interval' => $request->interval,
        ]);

        return redirect()->route('plans.create')->with('success', 'Plan created successfully');
    }

    // -----------------------------Subscription Plan Code-----------------------------------


    public function createSubscription(Request $request)
    {
        return $this->handleCreateSubscription($request);
    }

    public function subscriptionSuccess(Request $request)
    {
        return $this->handleSubscriptionSuccess($request);
    }

    public function handleCreateSubscription(Request $request)
    {
        $user = Auth::user();
        if (!$user) {
            return response()->json(['error' => 'User not authenticated'], 401);
        }

        $planId = $request->input('plan_id');
        $plan = WellifystripePlan::find($planId);

        if (!$plan) {
            return response()->json(['error' => 'Plan not found'], 404);
        }

        Stripe::setApiKey(config('services.stripe.secret'));
        $subscriptionRecord = WellifyUserSubscription::where('user_id', $user->id)->first();

        if ($subscriptionRecord && $subscriptionRecord->stripe_customer_id) {
            $customerId = $subscriptionRecord->stripe_customer_id;
        } else {
            // Create a new Stripe customer
            $customer = Customer::create([
                'email' => $user->email,
                'name'  => $user->name,
            ]);
            $customerId = $customer->id;
        }

        $session = Session::create([
            'customer' => $customerId,
            'payment_method_types' => ['card'],
            'mode' => 'subscription',
            'line_items' => [[
                'price'    => $plan->stripe_price_id,
                'quantity' => 1,
            ]],
            'subscription_data' => [
                'trial_period_days' => 1,
                'metadata' => [
                    'user_id' => $user->id,
                    'plan_id' => $planId,
                ],
            ],
            'payment_method_collection' => 'always',

            'success_url' => route('subscription.success') . '?session_id={CHECKOUT_SESSION_ID}',
            'cancel_url'  => route('subscription.cancel'),
        ]);


        return response()->json(['id' => $session->id]);
    }


    public function handleSubscriptionSuccess(Request $request)
    {
        $sessionId = $request->query('session_id');
        if (!$sessionId) {
            return 'Missing session id';
        }

        Stripe::setApiKey(config('services.stripe.secret'));
        $session = Session::retrieve($sessionId, ['expand' => ['setup_intent']]);

        $subscription = Subscription::retrieve($session->subscription);
        $paymentMethodId = $session->setup_intent->payment_method ?? null;

        if ($paymentMethodId) {
            Customer::update($subscription->customer, [
                'invoice_settings' => ['default_payment_method' => $paymentMethodId],
            ]);

            Subscription::update($subscription->id, [
                'default_payment_method' => $paymentMethodId,
            ]);
        }
        WellifyUserSubscription::updateOrCreate(
            ['user_id' => Auth::id()],
            [
                'stripe_customer_id' => $subscription->customer,
                'stripe_subscription_id' => $subscription->id,
                'stripe_price_id' => $subscription->items->data[0]->price->id,
                'plan_name' => 'Wellify Plans',
                'status' => $subscription->status,
                'current_period_start' => date('Y-m-d H:i:s', $subscription->current_period_start),
                'current_period_end' => date('Y-m-d H:i:s', $subscription->current_period_end),
                'cancel_at_period_end' => $subscription->cancel_at_period_end,
                'trial_end' => $subscription->trial_end ? date('Y-m-d H:i:s', $subscription->trial_end) : null,
            ]
        );

        return view('wellifypayments.subscription-success');
    }

    public function subscriptionCancel()
    {
        return 'wellify payments subscription cancel';
    }

    public function toggleDefault(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            if ($request->status == 1) {
                // Set all others to non-default
                WellifyPlans::where('is_default', true)->update(['is_default' => false]);
            }

            $plan = WellifyPlans::findOrFail($id);
            $plan->is_default = $request->status;
            $plan->save();

            DB::commit();
            return response()->json(['success' => true, 'message' => $request->status ? 'Plan set as default.' : 'Plan unset as default.']);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => 'Error updating default status.']);
        }
    }
}

<?php

namespace App\Http\Controllers;

use App\Mail\SlotsPurchasedNotificationMail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use Stripe\Stripe;
use Stripe\Checkout\Session;
use App\Models\WellifyUser;

class EmployerSubscriptionController extends Controller
{
    public function requestExtraSlots(Request $request)
    {
        $user = Auth::user();
        $slots = (int) $request->additional_slots;

        if ($slots <= 0) {
            return response()->json(['error' => 'Invalid slot count.'], 422);
        }

        Stripe::setApiKey(env('STRIPE_SECRET'));

        $session = Session::create([
            'payment_method_types' => ['card'],
            'customer_email' => $user->email,
            'line_items' => [[
                'price_data' => [
                    'currency' => 'usd',
                    'product_data' => ['name' => 'Additional Employee Slots'],
                    'unit_amount' => 100, // 100 cents = $1 per slot
                ],
                'quantity' => $slots,
            ]],
            'mode' => 'payment',
            'success_url' => route('employer.extra_slots.success') . '?slots=' . $slots . '&session_id={CHECKOUT_SESSION_ID}',
            'cancel_url' => url('/dashboard'),
        ]);

        return response()->json(['session_url' => $session->url]);
    }

    public function handleExtraSlotsPaymentSuccess(Request $request)
    {
        $user = Auth::user();
        $slots = (int) $request->get('slots');

        if ($slots <= 0) {
            return redirect()->route('wellify_employees.index')->with('error', 'Invalid slot update request.');
        }

        // Update employer slot allocation
        $user->number_of_users += $slots;
        $user->save();

        // Notify Super Admin
        Mail::to('superadmin@wellify.com')->send(new SlotsPurchasedNotificationMail($user, $slots));

        return redirect()->route('wellify_employees.index')->with('success', 'Payment successful! Additional slots added.');
    }
}

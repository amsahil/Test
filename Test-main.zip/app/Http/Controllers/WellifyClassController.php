<?php

namespace App\Http\Controllers;

use Exception;
use Aws\S3\S3Client;
use App\Models\WellifyMood;
use App\Models\WellifyUser;
use Illuminate\Support\Str;
use App\Models\WellifyClass;
use App\Models\WellifyLevel;
use Illuminate\Http\Request;
use App\Models\WellifyCategory;
use Aws\Exception\AwsException;
use App\Models\WellifyClassMedia;
use Aws\S3\Exception\S3Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Yajra\DataTables\Facades\DataTables;

class WellifyClassController extends Controller
{

    /*Fetch all the Class EORM* */
    public function index()
    {
        $moods = WellifyMood::select('id', 'title')->get();
        $categories = WellifyCategory::select('id')->get();
        $levels = WellifyLevel::select('id', 'title')->get();

        return view('wellify_classes.index', compact('moods', 'categories', 'levels'));
    }

    /*Datatable of the Class Function* */
    public function getData(Request $request)
    {
        $data = WellifyClass::with(['moods', 'levels', 'media', 'quizzes']);

        return DataTables::of($data)
            ->addColumn('associated_moods', function ($row) {
                $moods = $row->moods; // from belongsToMany relationship
                $moodCount = $moods->count();
                $tooltipTitle = $moods->pluck('title')->join(', ');

                $moodHtml = '<small class="d-inline-flex px-3 py-1 fw-semibold text-success-emphasis mood_numbers border border-success-subtle rounded-4" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="custom-tooltip" data-bs-title="' . $tooltipTitle . '">' . $moodCount . ' ' . ($moodCount == 1 ? 'Mood' : 'Moods') . '</small>';

                return $moodHtml;
            })
            ->addColumn('level', function ($row) {
                return $row->levels ? $row->levels->title : 'N/A';
            })
            ->addColumn('media_status', function ($row) {
                $enumToValue = [
                    'Completed' =>   '1',
                    'In-Progress' => '2',
                    'Not-Started' => '3',
                ];

                $valueToEnum = array_flip($enumToValue);

                $currentStatusValue = $enumToValue[$row->media_status ?? 'Not-Started'];

                $options = [
                    '1' => 'Completed',
                    '2' => 'In-Progress',
                    '3' => 'Not Started'
                ];

                $disabled = $row->class_status == 0 ? 'disabled' : '';
                $grayedOut = $row->class_status == 0 ? 'opacity: 0.6; cursor: not-allowed;' : '';

                $html = '<select class="form-select image_status_select status_select" data-id="' . $row->id . '" style="' . $grayedOut . '" ' . $disabled . '>';
                foreach ($options as $value => $label) {
                    $selected = ($currentStatusValue == $value) ? 'selected' : '';
                    $html .= "<option value=\"{$value}\" {$selected}>{$label}</option>";
                }
                $html .= '</select>';

                return $html;
            })
            ->addColumn('class_status', function ($row) {
                $checked = $row->class_status ? 'checked' : '';
                $statusLabel = $row->class_status ? 'Active' : 'Inactive';

                return '<div class="flipswitch">
                            <input class="flipswitch-cb toggle-status" type="checkbox"
                                id="fs' . $row->id . '" data-id="' . $row->id . '" ' . $checked . '>
                            <label for="fs' . $row->id . '" class="flipswitch-label">
                                <span class="flipswitch-inner d-block"></span>
                                <span class="flipswitch-switch d-block"></span>
                            </label>
                        </div>';
            })
            // ->addColumn('class_images', function ($row) {
            //     $imageCount = $row->media->count();

            //     $html = '<small class="d-inline-flex px-3 py-1 fw-semibold border border-success-subtle rounded-4 curser-pointer"
            //                 onclick="window.location.href=\'' . route('wellify_classes.media', ['id' => $row->id]) . '\'">'
            //             . $imageCount . ' ' . Str::plural('Image', $imageCount) . '</small>
            //             <img src="' . asset('assets/images/Add_icon.svg') . '" alt="add icon"
            //                 class="img-fluid ms-3 curser-pointer"
            //                 data-id="' . $row->id . '"
            //                 data-bs-target="#addimagesModal"
            //                 data-bs-toggle="modal"
            //                 title="Add Class Images">';

            //     return $html;
            // })
            ->addColumn('class_images', function ($row) {
                $imageCount = $row->media->count();
                $s3IconUrl = Storage::disk('s3')->temporaryUrl(
                    'staging/public/Add_icon.svg',
                    now()->addHour()
                );
                $html = '<small class="d-inline-flex px-3 py-1 fw-semibold border border-success-subtle rounded-4 curser-pointer"
                            onclick="window.location.href=\'' . route('wellify_classes.media', ['id' => $row->id]) . '\'">'
                    . $imageCount . ' ' . Str::plural('Image', $imageCount) . '</small>
                        <img src="' .  $s3IconUrl . '" alt="add icon"
                            class="img-fluid curser-pointer open-upload-modal"
                            data-id="' . $row->id . '"
                            title="Add Class Images">';
                return $html;
            })

            ->addColumn('quiz', function ($row) {
                $quizCount = $row->quizzes->count();
                $questions = ($quizCount > 1) ? 'Questions' : 'Question';

                $quizViewUrl = route('classes.quizzes.show', $row->id);
                $s3IconUrl = Storage::disk('s3')->temporaryUrl(
                    'staging/public/Add_icon.svg',
                    now()->addHour()
                );
                return '
                    <a href="' . $quizViewUrl . '" class="text-decoration-none">
                        <small class="d-inline-flex px-3 py-1 fw-semibold border border-success-subtle rounded-4 curser-pointer text-dark">
                            ' . $quizCount . ' ' . $questions . '
                        </small>
                    </a>
                    
                    <img src="' . $s3IconUrl . '" alt="add icon"
                        class="img-fluid curser-pointer" data-class-id="' . $row->id . '"
                        data-bs-target="#addQuizModal" data-bs-toggle="modal" title="Add Quiz">';
            })

            ->addColumn('actions', function ($row) {
                return '<div class="action_td">
                            <span class="view_icon1" title="View"  data-id="' . $row->id . '" data-bs-toggle="modal" data-bs-target="#view_user">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="14" viewBox="0 0 20 14" fill="none">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M6 7C6 6.00544 6.39509 5.05161 7.09835 4.34835C7.80161 3.64509 8.75544 3.25 9.75 3.25C10.7446 3.25 11.6984 3.64509 12.4017 4.34835C13.1049 5.05161 13.5 6.00544 13.5 7C13.5 7.99456 13.1049 8.94839 12.4017 9.65165C11.6984 10.3549 10.7446 10.75 9.75 10.75C8.75544 10.75 7.80161 10.3549 7.09835 9.65165C6.39509 8.94839 6 7.99456 6 7ZM9.75 4.75C9.15326 4.75 8.58097 4.98705 8.15901 5.40901C7.73705 5.83097 7.5 6.40326 7.5 7C7.5 7.59674 7.73705 8.16903 8.15901 8.59099C8.58097 9.01295 9.15326 9.25 9.75 9.25C10.3467 9.25 10.919 9.01295 11.341 8.59099C11.7629 8.16903 12 7.59674 12 7C12 6.40326 11.7629 5.83097 11.341 5.40901C10.919 4.98705 10.3467 4.75 9.75 4.75Z"
                                        fill="#1283CE"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M2.073 5.646C1.654 6.25 1.5 6.723 1.5 7C1.5 7.277 1.654 7.75 2.073 8.354C2.479 8.937 3.081 9.57 3.843 10.155C5.37 11.327 7.463 12.25 9.75 12.25C12.037 12.25 14.13 11.327 15.657 10.155C16.419 9.57 17.021 8.937 17.427 8.354C17.846 7.75 18 7.277 18 7C18 6.723 17.846 6.25 17.427 5.646C17.021 5.063 16.419 4.43 15.657 3.845C14.13 2.673 12.037 1.75 9.75 1.75C7.463 1.75 5.37 2.673 3.843 3.845C3.081 4.43 2.479 5.063 2.073 5.646ZM2.929 2.655C4.66 1.327 7.066 0.25 9.75 0.25C12.434 0.25 14.84 1.327 16.57 2.655C17.437 3.32 18.153 4.062 18.659 4.791C19.151 5.5 19.5 6.277 19.5 7C19.5 7.723 19.15 8.5 18.659 9.209C18.153 9.938 17.437 10.679 16.571 11.345C14.841 12.673 12.434 13.75 9.75 13.75C7.066 13.75 4.66 12.673 2.93 11.345C2.063 10.68 1.347 9.938 0.841 9.209C0.35 8.5 0 7.723 0 7C0 6.277 0.35 5.5 0.841 4.791C1.347 4.062 2.063 3.321 2.929 2.655Z"
                                        fill="#1283CE"/>
                                </svg>
                            </span>
                            <span class="edit_icon1" title="Edit" data-bs-toggle="modal" data-bs-target="#edit_user" data-id="' . $row->id . '">
                                <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20"
                                    viewBox="0 0 21 20" fill="none">
                                    <path
                                        d="M14.666 2.49993C14.8849 2.28106 15.1447 2.10744 15.4307 1.98899C15.7167 1.87054 16.0232 1.80957 16.3327 1.80957C16.6422 1.80957 16.9487 1.87054 17.2347 1.98899C17.5206 2.10744 17.7805 2.28106 17.9993 2.49993C18.2182 2.7188 18.3918 2.97863 18.5103 3.2646C18.6287 3.55057 18.6897 3.85706 18.6897 4.16659C18.6897 4.47612 18.6287 4.78262 18.5103 5.06859C18.3918 5.35455 18.2182 5.61439 17.9993 5.83326L6.74935 17.0833L2.16602 18.3333L3.41602 13.7499L14.666 2.49993Z"
                                        stroke="#A25AD9" stroke-width="1.66667" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </span>
                            <span class="delete_icon1" title="Delete" data-bs-toggle="modal" data-bs-target="#delete_user" data-id="' . $row->id . '">
                                <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20"
                                    viewBox="0 0 21 20" fill="none">
                                    <path
                                        d="M3 5.00033H4.66667M4.66667 5.00033H18M4.66667 5.00033V16.667C4.66667 17.109 4.84226 17.5329 5.15482 17.8455C5.46738 18.1581 5.89131 18.3337 6.33333 18.3337H14.6667C15.1087 18.3337 15.5326 18.1581 15.8452 17.8455C16.1577 17.5329 16.3333 17.109 16.3333 16.667V5.00033H4.66667ZM7.16667 5.00033V3.33366C7.16667 2.89163 7.34226 2.46771 7.65482 2.15515C7.96738 1.84259 8.39131 1.66699 8.83333 1.66699H12.1667C12.6087 1.66699 13.0326 1.84259 13.3452 2.15515C13.6577 2.46771 13.8333 2.89163 13.8333 3.33366V5.00033M8.83333 9.16699V14.167M12.1667 9.16699V14.167"
                                        stroke="#F54E51" stroke-width="1.66667" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </span>



                        </div>';
            })
            ->addColumn('dummy', fn() => ' ')
            ->addColumn('created_at', fn($user) => optional($user->created_at)->format('M d, Y'))
            ->rawColumns(['actions', 'dummy', 'created_at', 'associated_moods', 'media_status', 'class_status', 'class_images', 'quiz', 'level'])
            ->rawColumns(['actions', 'dummy', 'created_at', 'associated_moods', 'media_status', 'class_status', 'class_images', 'quiz'])
            ->make(true);
    }

    /*Store the Class Function* */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'id' => 'required|string|unique:wellify_classes,id',
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'points_on_completion' => 'required|numeric',
            'seeds_on_completion' => 'required|numeric',
            'category_id' => 'required',
            'level_id' => 'required|exists:wellify_levels,id',
            'moods' => 'required|array',
            'moods.*' => 'exists:wellify_moods,id',
            'background_image' => 'required|mimes:svg,svg+xml',
        ]);

        $class = new WellifyClass();
        $class->id = $validated['id'];
        $class->title = $validated['title'];
        $class->description = $validated['description'];
        $class->points_on_completion = $validated['points_on_completion'];
        $class->seeds_on_completion = $validated['seeds_on_completion'];
        $class->category_id = $validated['category_id'];
        $class->level_id = $validated['level_id'];
        $class->class_status = 1;
        $class->media_status = 'Not-Started';
        if ($request->hasFile('background_image')) {
            $file = $request->file('background_image');
            $filename = time() . '_' . $file->getClientOriginalName();
            $keyname = 'staging/classes/' . $filename;

            $s3 = new S3Client([
                'version' => 'latest',
                'region'  => env('AWS_DEFAULT_REGION'),
                'credentials' => [
                    'key'    => env('AWS_ACCESS_KEY_ID'),
                    'secret' => env('AWS_SECRET_ACCESS_KEY'),
                ]
            ]);

            try {
                $s3->putObject([
                    'Bucket' => env('AWS_BUCKET'),
                    'Key'    => $keyname,
                    'Body'   => fopen($file, 'r+'),
                    'ContentType' => 'image/svg+xml',
                    'ACL'    => 'private',
                ]);
                $class->background_image = $filename;
            } catch (S3Exception $e) {
                return response()->json(['success' => false, 'message' => 'Image upload failed.'], 500);
            }
        }
        $class->save();


        $class->moods()->attach($validated['moods']);


        return response()->json(['success' => true, 'message' => 'Class created successfully']);
    }

    /*Update the Class Status Function* */
    public function updateStatus(Request $request, $id)
    {
        $class = WellifyClass::findOrFail($id);
        $class->class_status = $request->class_status;
        $class->save();

        return response()->json(['success' => true, 'status' => $class->class_status]);
    }

    /*Update the Class Image Status Function* */
    public function updateManualStatus(Request $request)
    {
        $class = WellifyClass::findOrFail($request->id);

        $valueToEnum = [
            '1' => 'Completed',
            '2' => 'In-Progress',
            '3' => 'Not-Started',
        ];

        $enumValue = $valueToEnum[$request->media_status] ?? 'Not-Started';

        $class->media_status = $enumValue;
        $class->save();
        return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
    }

    /*Show the Class Function* */
    public function show($id)
    {
        $class = WellifyClass::with(['moods', 'level', 'category', 'quizzes', 'media'])->findOrFail($id);
        return response()->json([
            'id' => $class->id,
            'title' => $class->title,
            'points' => $class->points_on_completion, // renamed to match JS
            'seeds_on_completion' => $class->seeds_on_completion,
            'category_id' => $class->category_id,
            'category_title' => optional($class->category)->title,
            'level_id' => $class->level_id,
            'level_title' => optional($class->level)->title,
            'status' => $class->class_status ? 'Active' : 'Inactive',
            'description' => $class->description,
            'moods' => $class->moods->map(function ($mood) {
                return [
                    'title' => $mood->title,
                    'color_code' => ltrim($mood->color_code, '#'),
                    'text_code' => ltrim($mood->text_code, '#'),
                ];
            }),
            'image_count' => $class->media->count(),
            'quiz_count' => $class->quizzes->count(),
        ]);
    }

    /*Edit the Class Function* */
    public function edit($id)
    {
        $class = WellifyClass::with(['moods', 'level', 'category'])->findOrFail($id);

        return response()->json([
            'id' => $class->id,
            'title' => $class->title,
            'points_on_completion' => $class->points_on_completion,
            'seeds_on_completion' => $class->seeds_on_completion,
            'category_id' => $class->category_id,
            'category_title' => $class->category->title,
            'level_id' => $class->level_id,
            'description' => $class->description,
            'moods' => $class->moods->pluck('id')->toArray(),
            'background_image' => $class->background_image,
        ]);
    }

    /*Update the Class Function* */
    public function update(Request $request, $id)
    {
        // dd($request->all());
        $class = WellifyClass::findOrFail($id);

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'points_on_completion' => 'required|numeric',
            'seeds_on_completion' => 'required|numeric',
            'category_id' => 'required',
            'level_id' => 'required|exists:wellify_levels,id',
            'moods' => 'required|array',
            'moods.*' => 'exists:wellify_moods,id',
            'background_image' => 'nullable|mimes:svg,svg+xml'

        ]);

        $class->title = $validated['title'];
        $class->description = $validated['description'];
        $class->points_on_completion = $validated['points_on_completion'];
        $class->seeds_on_completion = $validated['seeds_on_completion'];
        $class->category_id = $validated['category_id'];
        $class->level_id = $validated['level_id'];

        if ($request->hasFile('background_image')) {
            $file = $request->file('background_image');
            $filename = time() . '_' . $file->getClientOriginalName();
            $keyname = env('S3_CLASSES') . $filename;

            $s3 = new S3Client([
                'version' => 'latest',
                'region'  => env('AWS_DEFAULT_REGION'),
                'credentials' => [
                    'key'    => env('AWS_ACCESS_KEY_ID'),
                    'secret' => env('AWS_SECRET_ACCESS_KEY'),
                ]
            ]);

            try {
                $s3->putObject([
                    'Bucket' => env('AWS_BUCKET'),
                    'Key'    => $keyname,
                    'Body'   => fopen($file, 'r+'),
                    'ContentType' => 'image/svg+xml',
                    // 'ACL'    => 'private',
                ]);

                $class->background_image = $filename;
            } catch (S3Exception $e) {
                return response()->json(['success' => false, 'message' => 'Image upload failed.'], 500);
            }
        }

        $class->save();
        $class->moods()->sync($validated['moods']);

        return response()->json(['success' => true, 'message' => 'Class updated successfully']);
    }

    /*Delete the Class Function* */
    public function destroy($id)
    {
        $class = WellifyClass::where('id', $id)->first();

        if (!$class) {
            return response()->json([
                'success' => false,
                'message' => 'Class not found or already deleted'
            ], 404);
        }

        $class->delete();

        return response()->json([
            'success' => true,
            'message' => 'Class soft-deleted successfully'
        ]);
    }


    public function getDeletedClasses(Request $request)
    {

        $data = WellifyClass::onlyTrashed()
            ->with(['moods', 'levels', 'media', 'quizzes']);

        return DataTables::of($data)
            ->addColumn('checkbox', function ($row) {
                return '<input type="checkbox" class="restore-checkbox" value="' . $row->id . '">';
            })
            ->addColumn('dummy', fn() => '')
            ->addColumn('associated_moods', function ($row) {
                $moods = $row->moods;
                $moodCount = $moods->count();
                $tooltipTitle = $moods->pluck('title')->join(', ');

                return '<small class="d-inline-flex px-3 py-1 fw-semibold text-success-emphasis mood_numbers border border-success-subtle rounded-4"
                        data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-custom-class="custom-tooltip"
                        data-bs-title="' . $tooltipTitle . '">'
                    . $moodCount . ' ' . ($moodCount == 1 ? 'Mood' : 'Moods') . '</small>';
            })
            ->addColumn('level', function ($row) {
                return $row->levels ? $row->levels->title : 'N/A';
            })
            ->addColumn('class_images', function ($row) {
                $imageCount = $row->media->count();
                return '<small class="d-inline-flex px-3 py-1 fw-semibold border border-success-subtle rounded-4 text-dark"
                            onclick="window.location.href=#">'
                    . $imageCount . ' ' . Str::plural('Image', $imageCount) . '</small>';
            })
            ->addColumn('quiz', function ($row) {
                $quizCount = $row->quizzes->count();
                $questions = ($quizCount > 1) ? 'Questions' : 'Question';
                return '<a href="#" class="text-decoration-none">
                            <small class="d-inline-flex px-3 py-1 fw-semibold border border-success-subtle rounded-4 text-dark">
                                ' . $quizCount . ' ' . $questions . '
                            </small>
                        </a>';
            })
            ->addColumn('actions', function ($row) {
                return '<span class="btn-restore" title="Restore" data-id="' . $row->id . '" data-bs-toggle="modal" data-bs-target="#restore_user"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.00003 3.723C6.75838 4.23409 4.7972 5.58344 3.51867 7.49436C2.24014 9.40527 1.74116 11.7329 2.12403 14M9.00003 3.723L6.00003 2.5M9.00003 3.723L8.00003 6.5M19.064 16.5C19.6816 15.2571 20.002 13.8878 20 12.5C20 8.04 16.757 4.339 12.5 3.624M19.064 16.5L22 14.5M19.064 16.5L17.5 13.5M3.51603 17.5C4.33773 18.7314 5.45079 19.7408 6.75638 20.4386C8.06196 21.1364 9.51967 21.501 11 21.5C13.2144 21.5028 15.3515 20.6864 17 19.208M3.51603 17.5H7.00003M3.51603 17.5V21" stroke="#007C00" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg> </span>';
            })
            ->rawColumns(['checkbox', 'dummy', 'associated_moods', 'level', 'class_images', 'quiz', 'actions'])
            ->make(true);
    }

    public function restore($id)
    {
        $class = WellifyClass::onlyTrashed()->where('id', $id)->first();

        if (!$class) {
            return response()->json([
                'success' => false,
                'message' => 'Class not found in deleted records'
            ], 404);
        }

        $class->restore();
        Log::info("Successfully restored class with ID: " . $id);

        return response()->json([
            'success' => true,
            'message' => 'Class restored successfully'
        ]);
    }

    public function bulkRestore(Request $request)
    {
        $ids = $request->input('ids');
        WellifyClass::onlyTrashed()->whereIn('id', $ids)->restore();

        return response()->json([
            'success' => true,
            'message' => 'Selected classes have been restored successfully'
        ]);
    }
}

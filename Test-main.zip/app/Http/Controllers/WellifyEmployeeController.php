<?php

namespace App\Http\Controllers;

use Exception;
use Aws\S3\S3Client;
use App\Models\WellifyUser;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Imports\AppUserImport;
use App\Models\WellifyTimezone;
use Illuminate\Validation\Rule;
use App\Mail\EmployeeWelcomeMail;
use App\Models\Employer\Employee;
use Aws\S3\Exception\S3Exception;
use App\Models\WellifyTempAppUser;
use App\Models\WellifySubscription;
use Spatie\Permission\Models\Role;
use App\Mail\UserLaunchCredentials;
use App\Mail\EmployerRequestedSlots;
use App\Models\Employer\Department;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Password;
use Yajra\DataTables\Facades\DataTables;
use App\Exports\WellifyTempAppUserExport;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

/**
 * WellifyEmployeeController
 * USED to show the Employees data inside the portal
 * dt- 02/06/2025
 */
class WellifyEmployeeController extends Controller
{
    /**
     * index
     * this method is the used to show the view page for the employees data
     *
     * @return void
     */
    public function index()
    {
        $user = Auth::user();
        $timezones = WellifyTimezone::all();
        if ($user->hasRole('Super Admin')) {
            $employees = WellifyUser::where('supervisor_id', '2')->get();
            $departments = Department::all();
        } else {
            $departments = Department::where('employer_id', $user->id)->get();
            $employees = WellifyUser::where('supervisor_id', $user->id)->get();
        }
        return view('wellify_employees.index', compact('departments', 'employees', 'timezones'));
    }

    public function data(Request $request)
    {
        if ($request->ajax()) {
            $user = Auth::user();
            if ($user->hasRole('Employer')) {
                $query = Employee::with(['department', 'department.employer', 'wellify_user'])->where('employer_id', $user->id)->orderBy('created_at', 'desc');
            } else {
                $query = Employee::with(['department', 'department.employer', 'wellify_user'])->orderBy('created_at', 'desc');
            }
            // Apply employer_id filter from select dropdown
            if ($request->has('employer_id') && !empty($request->employer_id)) {
                $query->where('employer_id', $request->employer_id);
            }
            if ($request->has('sort_filter') && $request->sort_filter) {
                switch ($request->sort_filter) {
                    case 'today':
                        $query->whereDate('created_at', today());
                        break;
                    case 'last_week':
                        $query->whereBetween('created_at', [now()->subWeek(), now()]);
                        break;
                    case 'last_month':
                        $query->whereBetween('created_at', [now()->subMonth(), now()]);
                        break;
                }
            }
            $data = $query->get();
            return Datatables::of($data)
                ->addColumn('employee_name', function ($user) {
                    $imgTag = '';

                    $s3 = new S3Client([
                        'version' => 'latest',
                        'region'  => env('AWS_DEFAULT_REGION'),
                        'credentials' => [
                            'key'    => env('AWS_ACCESS_KEY_ID'),
                            'secret' => env('AWS_SECRET_ACCESS_KEY'),
                        ]
                    ]);
                    if ($user->profile_picture) {
                        $cmd = $s3->getCommand('GetObject', [
                            'Bucket' => env('AWS_BUCKET'),
                            'Key'    => env('S3_USER') . $user->profile_picture
                        ]);
                    } else {
                        $cmd = $s3->getCommand('GetObject', [
                            'Bucket' => env('AWS_BUCKET'),
                            'Key'    => env('S3_USER') . env('DEFAULT_USER_LOGO')
                        ]);
                    }
                    $request = $s3->createPresignedRequest($cmd, '+20 minutes');
                    $presignedUrl = (string) $request->getUri();

                    $imgTag = '<span class="logo_outer"><img src="' . $presignedUrl . '" alt="Profile Picture" class="table_logo_img"></span>';
                    return '
                        <span class="d-flex align-items-center gap-2">
                            ' . $imgTag . '
                            <span class="ms-2">' . e($user->username) . '</span>
                        </span>';
                })
                ->addColumn('employer_id', function ($user) {
                    return optional($user->wellify_user)->username ?? 'N/A';
                })
                ->addColumn('mobile_no', function ($user) {
                    return   $user->mobile_phone
                        ? (strlen(preg_replace('/[^0-9]/', '', $user->mobile_phone)) === 10
                            ? 'XXX-XXX-' . substr(preg_replace('/[^0-9]/', '', $user->mobile_phone), -4)
                            : $user->mobile_phone)
                        : $user->mobile_phone;
                })
                //                 ->addColumn('mobile_no', function ($user) {
                //     $digits = preg_replace('/\D/', '', $user->mobile_phone);
                //     if (strlen($digits) === 10) {
                //         return substr($digits, 0, 3) . '-' . substr($digits, 3, 3) . '-' . substr($digits, 6, 4);
                //     }
                //     return $user->mobile_phone;
                // })

                ->addColumn('address', function ($user) {
                    $addressParts = array_filter([$user->office, $user->city, $user->state, $user->country], function ($part) {
                        return !empty(trim($part));
                    });
                    if (empty($addressParts)) {
                        return 'N/A';
                    }
                    return implode(',', $addressParts);
                })
                ->addColumn('status', function ($user) {
                    $checked = $user->isActive ? 'checked' : '';
                    $id = $user->id;

                    return ' <div class="flipswitch">
                    <input ' . $checked . ' class="flipswitch-cb" type="checkbox" id="fs_' . $id . '" data-id="' . $id . '">
                    <label for="fs_' . $id . '" class="flipswitch-label">
                    <span class="flipswitch-inner d-block"></span>
                    <span class="flipswitch-switch d-block"></span>
                    </label>
                    </div>';
                })
                ->addColumn('plan_status', function ($user) {
                    return $user->plan_status;
                })
                ->addColumn('action', function ($user) {
                    $dataStatus = !$user->plan_status ? 'pending' : ($user->welcome_email_sent ? 'sent' : 'new');
                    $iconColor = 'gray';
                    $iconClass = 'disabled_mail_icon';
                    $tooltip = 'Pending Payment';

                    if ($user->plan_status && !$user->welcome_email_sent) {
                        $iconColor = 'blue';
                        $iconClass = 'send_mail_icon_employee';
                        $tooltip = 'Send Welcome Email';
                    } elseif ($user->plan_status && $user->welcome_email_sent) {
                        $iconColor = 'orange';
                        $iconClass = 'send_mail_icon_employee';
                        $tooltip = 'Resend Welcome Email';
                    }

                    $mailIcon = '
                        <span class="' . $iconClass . '"
                            title="' . $tooltip . '"
                            data-id="' . $user->id . '"
                            data-email="' . $user->email . '"
                            data-status="' . $dataStatus . '"
                            style="cursor:' . ($iconClass === 'send_mail_icon_employee' ? 'pointer' : 'not-allowed') . '; margin-right: 8px;">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" >
                                    <path d="M13 19H5C4.46957 19 3.96086 18.7893 3.58579 18.4142C3.21071 18.0391 3 17.5304 3 17V7C3 6.46957 3.21071 5.96086 3.58579 5.58579C3.96086 5.21071 4.46957 5 5 5H19C19.5304 5 20.0391 5.21071 20.4142 5.58579C20.7893 5.96086 21 6.46957 21 7V13" stroke="#45841C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M3 7L12 13L21 7M16 22L21 17M21 17V21.5M21 17H16.5" stroke="#45841C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                        </span>';


                    $actionBtn = '<div class="action_td">

                    <span id="employee_view_icon"class="" title="View" data-id="' . $user->id . '">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="14" viewBox="0 0 20 14" fill="none">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M6 7C6 6.00544 6.39509 5.05161 7.09835 4.34835C7.80161 3.64509 8.75544 3.25 9.75 3.25C10.7446 3.25 11.6984 3.64509 12.4017 4.34835C13.1049 5.05161 13.5 6.00544 13.5 7C13.5 7.99456 13.1049 8.94839 12.4017 9.65165C11.6984 10.3549 10.7446 10.75 9.75 10.75C8.75544 10.75 7.80161 10.3549 7.09835 9.65165C6.39509 8.94839 6 7.99456 6 7ZM9.75 4.75C9.15326 4.75 8.58097 4.98705 8.15901 5.40901C7.73705 5.83097 7.5 6.40326 7.5 7C7.5 7.59674 7.73705 8.16903 8.15901 8.59099C8.58097 9.01295 9.15326 9.25 9.75 9.25C10.3467 9.25 10.919 9.01295 11.341 8.59099C11.7629 8.16903 12 7.59674 12 7C12 6.40326 11.7629 5.83097 11.341 5.40901C10.919 4.98705 10.3467 4.75 9.75 4.75Z" fill="#1283CE" />
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M2.073 5.646C1.654 6.25 1.5 6.723 1.5 7C1.5 7.277 1.654 7.75 2.073 8.354C2.479 8.937 3.081 9.57 3.843 10.155C5.37 11.327 7.463 12.25 9.75 12.25C12.037 12.25 14.13 11.327 15.657 10.155C16.419 9.57 17.021 8.937 17.427 8.354C17.846 7.75 18 7.277 18 7C18 6.723 17.846 6.25 17.427 5.646C17.021 5.063 16.419 4.43 15.657 3.845C14.13 2.673 12.037 1.75 9.75 1.75C7.463 1.75 5.37 2.673 3.843 3.845C3.081 4.43 2.479 5.063 2.073 5.646ZM2.929 2.655C4.66 1.327 7.066 0.25 9.75 0.25C12.434 0.25 14.84 1.327 16.57 2.655C17.437 3.32 18.153 4.062 18.659 4.791C19.151 5.5 19.5 6.277 19.5 7C19.5 7.723 19.15 8.5 18.659 9.209C18.153 9.938 17.437 10.679 16.571 11.345C14.841 12.673 12.434 13.75 9.75 13.75C7.066 13.75 4.66 12.673 2.93 11.345C2.063 10.68 1.347 9.938 0.841 9.209C0.35 8.5 0 7.723 0 7C0 6.277 0.35 5.5 0.841 4.791C1.347 4.062 2.063 3.321 2.929 2.655Z" fill="#1283CE" />
                    </svg>
                    </span>

                    <span id="employee_edit_icon"class=""data-id="' . $user->id . '" title="Edit">
                    <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                    <path d="M14.666 2.49993C14.8849 2.28106 15.1447 2.10744 15.4307 1.98899C15.7167 1.87054 16.0232 1.80957 16.3327 1.80957C16.6422 1.80957 16.9487 1.87054 17.2347 1.98899C17.5206 2.10744 17.7805 2.28106 17.9993 2.49993C18.2182 2.7188 18.3918 2.97863 18.5103 3.2646C18.6287 3.55057 18.6897 3.85706 18.6897 4.16659C18.6897 4.47612 18.6287 4.78262 18.5103 5.06859C18.3918 5.35455 18.2182 5.61439 17.9993 5.83326L6.74935 17.0833L2.16602 18.3333L3.41602 13.7499L14.666 2.49993Z" stroke="#A25AD9" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    </span>
                    <span id="employee_delete_icon" class="" title="Delete" data-id="' . $user->id . '" data-bs-toggle="modal" data-bs-target="#delete_app_user">
                    <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                    <path d="M3 5.00033H4.66667M4.66667 5.00033H18M4.66667 5.00033V16.667C4.66667 17.109 4.84226 17.5329 5.15482 17.8455C5.46738 18.1581 5.89131 18.3337 6.33333 18.3337H14.6667C15.1087 18.3337 15.5326 18.1581 15.8452 17.8455C16.1577 17.5329 16.3333 17.109 16.3333 16.667V5.00033H4.66667ZM7.16667 5.00033V3.33366C7.16667 2.89163 7.34226 2.46771 7.65482 2.15515C7.96738 1.84259 8.39131 1.66699 8.83333 1.66699H12.1667C12.6087 1.66699 13.0326 1.84259 13.3452 2.15515C13.6577 2.46771 13.8333 2.89163 13.8333 3.33366V5.00033M8.83333 9.16699V14.167M12.1667 9.16699V14.167" stroke="#F54E51" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    </span>
                    <span>' . $mailIcon . '<span>';


                    $actionBtn .= '</div>';

                    return $actionBtn;
                })
                ->rawColumns(['employee_name', 'created_by', 'mobile_no', 'address', 'status', 'action','plan_status'])
                ->make(true);
        }
        return response()->json(['error' => 'Invalid request'], 400);
    }

    /**
     * store
     *dt- 04/06/2025
     * @param  mixed $request
     * @author Anurag S
     * @return void
     */
    public function store(Request $request)
    {
        // dd($request->licenses);
        try {
            $validatedData = $request->validate([
                'first_name' => 'required|string|max:255',
                'last_name' => 'required|string|max:255',
                'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
                'email' => 'required|email|unique:wellify_app_users,email|max:255',
                'mobile_phone' => [
                    'required',
                    'string',
                    'regex:/^\d{3}-\d{3}-\d{4}$/',
                    'unique:wellify_app_users,mobile_phone',
                ],
                'licenses' => 'required|string|unique:wellify_app_users,licenses',
                'employer_id' => Auth::user()->hasRole('Super Admin') ? 'required|exists:wellify_users,id' : 'sometimes',
            ], [
                'mobile_phone.unique' => 'Phone number has already been taken.',
                'mobile_phone.regex' => 'Phone number must be in the format XXX-XXX-XXXX.',
                'email.unique' => 'Email already exists.',
            ]);

            // Remove dashes for storage
            $mobilePhone = str_replace('-', '', $validatedData['mobile_phone']);

            $wellnessWords = ['Zen', 'Calm', 'Breathe', 'Pulse', 'Glow', 'Mindful', 'Wellness', 'Harmony', 'Serene', 'Balance'];
            $randomDisplayName = $wellnessWords[array_rand($wellnessWords)] . '_' . rand(100, 999);

            $user = new Employee();
            $user->first_name = $validatedData['first_name'];
            $user->last_name = $validatedData['last_name'];

            if ($request->hasFile('profile_picture')) {
                $file = $request->file('profile_picture');
                $filename = time() . '_' . $file->getClientOriginalName();
                $keyname = 'staging/users/' . $filename;

                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ]
                ]);

                try {
                    $s3->putObject([
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $keyname,
                        'Body'   => fopen($file, 'r+'),
                        'ACL'    => 'private',
                    ]);
                    $user->profile_picture = $filename;
                } catch (S3Exception $e) {
                    return response()->json(['success' => false, 'message' => 'Image upload failed.'], 500);
                }
            }

            $user->email = $validatedData['email'];
            $user->mobile_phone = $mobilePhone;
            $user->username = $randomDisplayName;
            $user->user_timezone_id = $request->input('user_timezone', 1);
            $user->office = $request->office;
            $user->city = $request->city;
            $user->state = $request->state;
            $user->country = $request->country;
            $user->licenses = $request->licenses;
            $user->created_by = Auth::user()->id;
            $user->employer_id = Auth::user()->hasRole('Super Admin') ? $request->employer_id : Auth::id();
            $user->password = Hash::make(Str::random(10));
            $user->save();

            return response()->json(['success' => true, 'message' => 'Employer created successfully!']);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json(['success' => false, 'errors' => $e->errors()], 422);
        } catch (QueryException $e) {
            return response()->json(['success' => false, 'message' => 'Server error.'], 500);
        } catch (\Exception $e) {
            Log::error('Employer creation failed: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Unexpected error.'], 500);
        }
    }

    /**
     * Edit the Employee Function
     * @author Anurag
     * @date 03/06/2025
     * @param  mixed $id
     * @return void
     */
    public function edit($id)
    {
        try {
            $user = Employee::findOrFail($id);
            $timezones = WellifyTimezone::all();
            return response()->json([
                'success' => true,
                'user' => $user,
                'timezones' => $timezones,
            ]);
        } catch (Exception $e) {
            Log::error('Error fetching user for editing: ' . $e->getMessage());

            return request()->ajax()
                ? response()->json(['success' => false, 'message' => 'User not found'], 404)
                : redirect()->back()->with('error', 'User not found.');
        }
    }

    /**
     * update employee data
     *dt- 03/06/2025
     * @param  mixed $request
     * @param  mixed $id
     * @return void
     */
    public function update(Request $request, $id)
    {

        try {
            $user = Employee::findOrFail($id);
            $cleanPhone = preg_replace('/\D/', '', $request->mobile_phone);
            $validatedData = $request->validate([
                'first_name' => 'required|string|max:255',
                'last_name' => 'required|string|max:255',
                'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
                'mobile_phone' => [
                    'required',
                    'string',
                    'max:20',
                    Rule::unique('wellify_app_users', 'mobile_phone')->ignore($id),
                ],
                'user_timezone' => 'nullable|exists:wellify_timezones,id',
                'licenses' => [
                    'required',
                    'string',
                    Rule::unique('wellify_app_users', 'licenses')->ignore($user->id),
                ],
            ]);
            $user->first_name = $validatedData['first_name'];
            $user->last_name = $validatedData['last_name'];
            if ($request->hasFile('profile_picture')) {
                $file = $request->file('profile_picture');
                $filename = time() . '_' . $file->getClientOriginalName();
                $keyname = 'staging/users/' . $filename;

                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ],
                ]);

                try {
                    Log::info("Attempting to upload file to S3: $keyname");

                    $result = $s3->putObject([
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $keyname,
                        'Body'   => fopen($file->getPathname(), 'r'),
                        'ACL'    => 'private',
                        'ContentType' => $file->getClientMimeType(),
                    ]);

                    Log::info('S3 Upload Success: ', ['url' => $result['ObjectURL']]);
                    $user->profile_picture = $filename;
                } catch (S3Exception $e) {
                    Log::error('S3 Upload Error: ' . $e->getAwsErrorMessage());
                    return redirect()->back()->with('error', 'Failed to upload profile picture.')->withInput();
                }
            }
            $user->mobile_phone = $cleanPhone;
            $user->office = $request->office;
            $user->city = $request->city;
            $user->state = $request->state;
            $user->user_timezone_id = $request->input('user_timezone', 1);
            $user->country = $request->country;
            $user->licenses = $request->licenses;
            $user->save();

            return redirect()->to('/wellify_employees')->with('success', 'User updated successfully!');
        } catch (ValidationException $e) {
            return redirect()->back()->withErrors($e->validator)->withInput();
        } catch (Exception $e) {
            Log::error('Error updating user: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Failed to update user. Please try again.')->withInput();
        }
    }

    /**
     * show employee datils
     * dt 02/06/2025
     * @author Anurag S
     * @param  mixed $id
     * @return void
     */
    public function show($id)
    {
        $employess = Employee::withTrashed()->with('department.employer')->findOrFail($id);
        // dd($employess);
        if ($employess->profile_picture) {
            $s3 = new S3Client([
                'version' => 'latest',
                'region'  => env('AWS_DEFAULT_REGION'),
                'credentials' => [
                    'key'    => env('AWS_ACCESS_KEY_ID'),
                    'secret' => env('AWS_SECRET_ACCESS_KEY'),
                ]
            ]);

            $cmd = $s3->getCommand('GetObject', [
                'Bucket' => env('AWS_BUCKET'),
                'Key'    => env('S3_USER') . $employess->profile_picture
            ]);

            $request = $s3->createPresignedRequest($cmd, '+20 minutes');
            $profilePictureUrl = (string)$request->getUri();
        }

        if (request()->ajax()) {
            $html = '
                    <div class="row">
                      <div class="col-md-4">
                            <label class="form-label"><strong>Employee Username:</strong></label>
                            <p>' . $employess->username . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>First Name:</strong></label>
                            <p>' . $employess->first_name . '</p>
                        </div>
                           <div class="col-md-4">
                            <label class="form-label"><strong>Last Name:</strong></label>
                            <p>' . $employess->last_name . '</p>
                        </div>
                    </div>
                    <div class="row mt-3">
                    <div class="col-md-4">
                            <label class="form-label"><strong>Employer Email:</strong></label>
                            <p>' . $employess->email . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Contact:</strong></label>
                            <p>' . $employess->mobile_phone . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Office:</strong></label>
                            <p>' . $employess->office . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>City:</strong></label>
                            <p>' . $employess->city . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>State:</strong></label>
                            <p>' . $employess->state . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>Country:</strong></label>
                            <p>' . $employess->country . '</p>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><strong>License:</strong></label>
                            <p>' . $employess->licenses . '</p>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label d-block"><strong>Employer Logo:</strong></label>';

            if (!empty($profilePictureUrl)) {
                $html .= '<img src="' . $profilePictureUrl . '" alt="Profile Picture" class="logo-preview">';
            } else {
                $html .= '<p>No profile picture available.</p>';
            }
            $html .= '</div></div>';
            return response()->json(['html' => $html]);
        }
        return view('wellify_employees.show', compact('employess'));
    }

    /**
     * getProfilePictureUrl of employee
     *dt- 03/06/2025
     * @param  mixed $id
     * @author Anurag S
     * @return void
     */
    public function getProfilePictureUrl($id)
    {
        $user = Employee::findOrFail($id);
        if ($user->profile_picture) {
            $s3 = new S3Client([
                'version' => 'latest',
                'region'  => env('AWS_DEFAULT_REGION'),
                'credentials' => [
                    'key'    => env('AWS_ACCESS_KEY_ID'),
                    'secret' => env('AWS_SECRET_ACCESS_KEY'),
                ]
            ]);

            $cmd = $s3->getCommand('GetObject', [
                'Bucket' => env('AWS_BUCKET'),
                'Key'    => env('S3_USER') . $user->profile_picture
            ]);

            $request = $s3->createPresignedRequest($cmd, '+20 minutes');
            $url = (string) $request->getUri();

            return response()->json([
                'success' => true,
                'url' => $url,
            ]);
        }

        return response()->json(['success' => false, 'url' => null]);
    }

    /**
     * destroy(soft delete employee data)
     *dt- 04/06/2025
     * @param  mixed $id
     * @author Anurag S
     * @return void
     */
    public function destroy($id)
    {
        try {
            $user = Employee::findOrFail($id);
            $user->status = 0;
            $user->save();
            $user->delete();

            return response()->json([
                'success' => true,
                'message' => 'Employer deleted successfully'
            ]);
        } catch (Exception $e) {
            Log::error('Error deleting Employer: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete Employer'
            ], 500);
        }
    }

    public function showResetForm(Request $request, $token)
    {
        return view('auth.passwords.employee_reset_password', ['token' => $token, 'email' => $request->email]);
    }

    public function reset(Request $request)
    {

        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6|confirmed',
            'token' => 'required'
        ]);

        // Attempt to find the user by email
        $user = Employee::where('email', $request->email)->first();
        if (!$user) {
            throw ValidationException::withMessages(['email' => trans('passwords.user')]);
        }
        // Verify the token
        $response = Password::broker()->reset(
            $request->only('email', 'password', 'password_confirmation', 'token'),
            function ($user, $password) {
                $user->password = Hash::make($password);
                $user->save();
            }
        );

        if ($response == Password::PASSWORD_RESET) {
            return redirect()->route('login')->with('status', trans($response));
        }
        return back()->withErrors(['email' => trans($response)]);
    }

    /**
     * to bulk upload of employees through excel file
     */

    public function import(Request $request)
    {
        $user = Auth::user();

        $validationRules = [
            'file' => 'required|mimes:xlsx,csv'
        ];

        if ($user->hasRole('Employer')) {
            $employerId = $user->id;
        } elseif ($user->hasRole('Super Admin')) {
            $validationRules['employer_id'] = 'required|exists:wellify_users,id';
            $employerId = $request->input('employer_id');
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized access. Invalid user role.'
            ], 403);
        }

        $validator = Validator::make($request->all(), $validationRules);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 400);
        }

        try {
            $employer = WellifyUser::findOrFail($employerId);

            $allowedSlots = $employer->number_of_users;
            $existingCount = Employee::where('employer_id', $employerId)->count();

            // Read uploaded users without saving yet
            $uploadedRows = Excel::toCollection(new AppUserImport($employerId, $request->input('user_timezone', 1)), $request->file('file'))->first();
            $newEmployeesCount = count($uploadedRows);

            $availableSlots = max(0, $allowedSlots - $existingCount);

            if ($newEmployeesCount > $availableSlots) {
                $extraSlotsNeeded = $newEmployeesCount - $availableSlots;

                return response()->json([
                    'requires_payment' => true,
                    'extra_slots_needed' => $extraSlotsNeeded,
                    'total_uploaded' => $newEmployeesCount,
                    'paid_slots' => $allowedSlots,
                    'message' => "You need to purchase {$extraSlotsNeeded} additional slot(s) to continue.",
                    'file_cache_token' => base64_encode($request->file('file')->store('temp-imports')), // Optional: if you want to reuse the file after payment
                ]);
            }

            // Proceed with actual import
            Excel::import(new AppUserImport($employerId, $request->input('user_timezone', 1)), $request->file('file'));

            return response()->json([
                'success' => true,
                'message' => 'Employees imported successfully.',
            ]);
        } catch (\Exception $e) {
            Log::error('Import Failure', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Import failed. Please try again.'
            ], 500);
        }
    }



    // public function import(Request $request)
    // {
    //     $user = Auth::user();
    //     $validationRules = [
    //         'file' => 'required|mimes:xlsx,csv'
    //     ];

    //     // Determine employer ID based on user role
    //     if ($user->hasRole('Employer')) {
    //         $employerId = $user->id;
    //     } elseif ($user->hasRole('Super Admin')) {
    //         $validationRules['employer_id'] = 'required|exists:wellify_users,id';
    //         $employerId = $request->input('employer_id');
    //     } else {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Unauthorized access. Invalid user role.'
    //         ], 403);
    //     }

    //     $validator = Validator::make($request->all(), $validationRules, [
    //         'file.required' => 'The file is required.',
    //         'file.mimes' => 'The file must be a file of type: xlsx, csv.',
    //         'employer_id.required' => 'Please select an employer.',
    //         'employer_id.exists' => 'Selected employer does not exist.'
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Validation failed',
    //             'errors' => $validator->errors()
    //         ], 400);
    //     }

    //     try {
    //         Log::info('Import Initiated', [
    //             'employer_id' => $employerId,
    //             'user_id' => Auth::id(),
    //             'file_name' => $request->file('file')->getClientOriginalName()
    //         ]);

    //         // Store employer ID in session
    //         session(['selected_employer_id' => $employerId]);

    //         $import = new AppUserImport($employerId, $request->input('user_timezone', 1));
    //         Excel::import($import, $request->file('file'));
    //         $importResult = session('import_result', [
    //             'new_employees_count' => 0,
    //             'existing_employees_count' => 0,
    //             'skipped_employees_count' => 0
    //         ]);

    //         $skippedEmployees = session('skipped_employees', []);
    //         $existingEmployees = session('existing_employees', []);

    //         $responseMessage = "Import Summary: ";
    //         if ($importResult['new_employees_count'] > 0) {
    //             $responseMessage .= "{$importResult['new_employees_count']} new employees added. ";
    //         }

    //         if (!empty($skippedEmployees)) {
    //             $responseMessage .= count($skippedEmployees) . " employees were skipped. ";
    //         }

    //         // Determine response based on import results
    //         if ($importResult['new_employees_count'] > 0) {
    //             return response()->json([
    //                 'success' => true,
    //                 'message' => $responseMessage,
    //                 'import_details' => $importResult,
    //                 'skipped_employees' => $skippedEmployees
    //             ]);
    //         } elseif (!empty($skippedEmployees) || !empty($existingEmployees)) {
    //             return response()->json([
    //                 'success' => false,
    //                 'message' => 'No new employees were added.',
    //                 'import_details' => $importResult,
    //                 'skipped_employees' => $skippedEmployees,
    //                 'existing_employees' => $existingEmployees
    //             ], 400);
    //         } else {
    //             return response()->json([
    //                 'success' => false,
    //                 'message' => 'No new employees were added. All employees already exist.',
    //                 'import_details' => $importResult,
    //                 'skipped_employees' => $skippedEmployees
    //             ], 400);
    //         }
    //     } catch (\Exception $e) {
    //         Log::error('Import Failure', [
    //             'message' => $e->getMessage(),
    //             'employer_id' => $employerId,
    //             'trace' => $e->getTraceAsString()
    //         ]);

    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Import completed with some issues.',
    //             'existing_employees' => session('existing_employees', []),
    //             'skipped_employees' => session('skipped_employees', [])
    //         ], 200);
    //     }
    // }

    public function deletedData(Request $request)
    {
        if ($request->ajax()) {
            $user = Auth::user();
            if ($user->hasRole('Employer')) {
                $query = Employee::onlyTrashed()->with(['department', 'department.employer', 'wellify_user'])->where('employer_id', $user->id)->orderBy('created_at', 'desc');
            } else {
                $query = Employee::onlyTrashed()->with(['department', 'department.employer', 'wellify_user'])->orderBy('created_at', 'desc');
            }
            // Apply employer_id filter from select dropdown
            if ($request->has('employer_id') && !empty($request->employer_id)) {
                $query->where('employer_id', $request->employer_id);
            }
            if ($request->has('sort_filter') && $request->sort_filter) {
                switch ($request->sort_filter) {
                    case 'today':
                        $query->whereDate('deleted_at', today());
                        break;
                    case 'last_week':
                        $query->whereBetween('deleted_at', [now()->subWeek(), now()]);
                        break;
                    case 'last_month':
                        $query->whereBetween('deleted_at', [now()->subMonth(), now()]);
                        break;
                }
            }
            $data = $query->get();
            return DataTables::of($data)
                ->addColumn('checkbox', function ($user) {
                    return '<input type="checkbox" class="restore-employee-checkbox" value="' . $user->id . '">';
                })

                ->editColumn('organization', function ($user) {
                    $imgTag = '';
                    $s3 = new S3Client([
                        'version' => 'latest',
                        'region'  => env('AWS_DEFAULT_REGION'),
                        'credentials' => [
                            'key'    => env('AWS_ACCESS_KEY_ID'),
                            'secret' => env('AWS_SECRET_ACCESS_KEY'),
                        ]
                    ]);
                    if ($user->profile_picture) {
                        $cmd = $s3->getCommand('GetObject', [
                            'Bucket' => env('AWS_BUCKET'),
                            'Key'    => env('S3_USER') . $user->profile_picture
                        ]);
                    } else {
                        $cmd = $s3->getCommand('GetObject', [
                            'Bucket' => env('AWS_BUCKET'),
                            'Key'    => env('S3_USER') . env('DEFAULT_USER_LOGO')
                        ]);
                    }
                    $request = $s3->createPresignedRequest($cmd, '+20 minutes');
                    $presignedUrl = (string) $request->getUri();

                    $imgTag = '<span class="logo_outer"><img src="' . $presignedUrl . '" alt="Profile Picture" class="table_logo_img"></span>';

                    return '
                        <span class="d-flex align-items-center gap-2">
                            ' . $imgTag . '
                            <span class="ms-2">' . e($user->first_name . ' ' . $user->last_name) . '</span>
                        </span>';
                })
                ->addColumn('created_by', function ($user) {
                    return optional($user->wellify_user)->username ?? 'N/A';
                })

                ->addColumn('address', function ($user) {
                    $addressParts = array_filter([$user->office, $user->city, $user->state, $user->country], function ($part) {
                        return !empty(trim($part));
                    });
                    if (empty($addressParts)) {
                        return 'N/A';
                    }
                    return implode(',', $addressParts);
                })

                ->addColumn('deleted_at', fn($user) => optional($user->deleted_at)->format('d M Y'))

                ->addColumn('action', function ($user) {
                    return '<div class="action_td">
                        <span id="employee_view_icon"class="" title="View" data-id="' . $user->id . '">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="14" viewBox="0 0 20 14" fill="none">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M6 7C6 6.00544 6.39509 5.05161 7.09835 4.34835C7.80161 3.64509 8.75544 3.25 9.75 3.25C10.7446 3.25 11.6984 3.64509 12.4017 4.34835C13.1049 5.05161 13.5 6.00544 13.5 7C13.5 7.99456 13.1049 8.94839 12.4017 9.65165C11.6984 10.3549 10.7446 10.75 9.75 10.75C8.75544 10.75 7.80161 10.3549 7.09835 9.65165C6.39509 8.94839 6 7.99456 6 7ZM9.75 4.75C9.15326 4.75 8.58097 4.98705 8.15901 5.40901C7.73705 5.83097 7.5 6.40326 7.5 7C7.5 7.59674 7.73705 8.16903 8.15901 8.59099C8.58097 9.01295 9.15326 9.25 9.75 9.25C10.3467 9.25 10.919 9.01295 11.341 8.59099C11.7629 8.16903 12 7.59674 12 7C12 6.40326 11.7629 5.83097 11.341 5.40901C10.919 4.98705 10.3467 4.75 9.75 4.75Z" fill="#1283CE" />
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M2.073 5.646C1.654 6.25 1.5 6.723 1.5 7C1.5 7.277 1.654 7.75 2.073 8.354C2.479 8.937 3.081 9.57 3.843 10.155C5.37 11.327 7.463 12.25 9.75 12.25C12.037 12.25 14.13 11.327 15.657 10.155C16.419 9.57 17.021 8.937 17.427 8.354C17.846 7.75 18 7.277 18 7C18 6.723 17.846 6.25 17.427 5.646C17.021 5.063 16.419 4.43 15.657 3.845C14.13 2.673 12.037 1.75 9.75 1.75C7.463 1.75 5.37 2.673 3.843 3.845C3.081 4.43 2.479 5.063 2.073 5.646ZM2.929 2.655C4.66 1.327 7.066 0.25 9.75 0.25C12.434 0.25 14.84 1.327 16.57 2.655C17.437 3.32 18.153 4.062 18.659 4.791C19.151 5.5 19.5 6.277 19.5 7C19.5 7.723 19.15 8.5 18.659 9.209C18.153 9.938 17.437 10.679 16.571 11.345C14.841 12.673 12.434 13.75 9.75 13.75C7.066 13.75 4.66 12.673 2.93 11.345C2.063 10.68 1.347 9.938 0.841 9.209C0.35 8.5 0 7.723 0 7C0 6.277 0.35 5.5 0.841 4.791C1.347 4.062 2.063 3.321 2.929 2.655Z" fill="#1283CE" />
                            </svg>
                        </span>
                        <span class="restore_icon employee_restore_icon" title="Restore"
                                data-id="' . $user->id . '">
                                <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" fill="none" viewBox="0 0 24 24">
                                    <path d="M9 3.72C6.76 4.23 4.8 5.58 3.52 7.49C2.24 9.4 1.74 11.73 2.12 14M9 3.72L6 2.5M9 3.72L8 6.5M19.06 16.5C19.68 15.26 20 13.89 20 12.5C20 8.04 16.76 4.34 12.5 3.62M19.06 16.5L22 14.5M19.06 16.5L17.5 13.5M3.52 17.5C4.34 18.73 5.45 19.74 6.76 20.44C8.06 21.14 9.52 21.5 11 21.5C13.21 21.5 15.35 20.69 17 19.21M3.52 17.5H7M3.52 17.5V21"
                                        stroke="#007C00" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </span>
                    </div>';
                })
                ->rawColumns(['checkbox', 'organization', 'created_by', 'address', 'action'])
                ->make(true);
        }
        return abort(404);
    }
    /**
     * to toogle employees status
     */
    public function toggleStatus(Request $request)
    {
        $user = Employee::find($request->id);
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        $user->isActive = $request->isActive;
        $user->save();

        return response()->json(['message' => 'Status updated']);
    }

    /*Restore a soft-deleted user */
    public function restore($id)
    {
        try {
            $user = Employee::onlyTrashed()->findOrFail($id);
            $user->restore();
            $user->status = 1;
            $user->save();

            return redirect()->route('wellify_employees.index')->with('success', 'Employer restored successfully.');
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to restore employer.'
            ], 500);
        }
    }

    public function bulkRestore(Request $request)
    {
        $ids = $request->input('ids');
        if (!$ids || !is_array($ids)) {
            return response()->json(['success' => false, 'message' => 'No employers selected.'], 400);
        }
        $users = Employee::onlyTrashed()->whereIn('id', $ids)->get();
        foreach ($users as $user) {
            $user->restore();
            $user->status = 1;
            $user->save();
        }
        return response()->json(['success' => true, 'message' => 'Employers restored successfully.']);
    }

    /**
     * to display skipped employees
     */
    public function skippedData(Request $request)
    {
        if ($request->ajax()) {
            $user = Auth::user();
            if ($user->hasRole('Employer')) {
                $query = WellifyTempAppUser::with(['department', 'employer', 'creator'])->where('employer_id', $user->id)->orderBy('created_at', 'desc');
            } else {
                $query = WellifyTempAppUser::with(['department', 'employer', 'creator'])->orderBy('created_at', 'desc');
            }
            // Apply employer_id filter from select dropdown
            if ($request->has('employer_id') && !empty($request->employer_id)) {
                $query->where('employer_id', $request->employer_id);
            }
            if ($request->has('sort_filter') && $request->sort_filter) {
                switch ($request->sort_filter) {
                    case 'today':
                        $query->whereDate('created_at', today());
                        break;
                    case 'last_week':
                        $query->whereBetween('created_at', [now()->subWeek(), now()]);
                        break;
                    case 'last_month':
                        $query->whereBetween('created_at', [now()->subMonth(), now()]);
                        break;
                }
            }
            $data = $query->get();
            return DataTables::of($data)
                ->addColumn('checkbox', function ($user) {
                    return '<input type="checkbox" class="skipped-employee-checkbox" value="' . $user->id . '">';
                })
                ->addColumn('name', function ($user) {
                    return e($user->first_name . ' ' . $user->last_name);
                })
                ->addColumn('email', function ($user) {
                    return $user->email ?? 'N/A';
                })
                ->addColumn('created_by', function ($user) {
                    return optional($user->creator)->username ?? 'N/A';
                })

                ->addColumn('employer', function ($user) {
                    return optional($user->employer)->username ?? 'N/A';
                })
                ->addColumn('address', function ($user) {
                    $addressParts = array_filter([$user->office, $user->city, $user->state, $user->country], function ($part) {
                        return !empty(trim($part));
                    });
                    if (empty($addressParts)) {
                        return 'N/A';
                    }
                    return implode(',', $addressParts);
                })
                ->addColumn('error_message', function ($user) {
                    return $user->error_message;
                })
                ->rawColumns(['checkbox'])
                ->make(true);
        }
        return abort(404);
    }

    /**to download sample excel file */
    public function downloadExcel()
    {
        $templatePath = public_path('excelFile/Employees_Import_Excel.xlsx');
        if (!file_exists($templatePath)) {
            return back()->with('error', 'Template file not found');
        }
        return response()->download($templatePath, 'Employees_Import_Excel.xlsx');
    }

    /**to export skipped employees record */
    public function exportTempUser(Request $request)
    {
        $ids = explode(',', $request->input('ids'));
        try {
            return Excel::download(new WellifyTempAppUserExport($ids), 'employees.xlsx');
        } catch (\Throwable $th) {
            Log::error('Excel export error: ' . $th->getMessage());
            return response()->json(['error' => 'An error occurred while exporting the data. Please try again later.'], 500);
        }
    }

    /**to send bulk welcome email to employees */
    public function sendBulkWelcomeEmployeeEmails(Request $request)
    {
        $employees = $request->input('employees');
        $emailContent = $request->input('emailContents');
        $successCount = 0;
        $failedEmails = [];

        foreach ($employees as $index => $employee) {
            try {
                $selectedEmployee = Employee::find($employee['id']);
                $tempPassword = Str::random(12);
                $selectedEmployee->password = Hash::make($tempPassword);
                $selectedEmployee->save();

                $personalizedContent = str_replace(
                    ['[username]', '[email]', '[password]'],
                    [$employee['username'], $employee['email'], $tempPassword],
                    $emailContent[$index]['content']
                );
                Mail::to($employee['email'])->send(new EmployeeWelcomeMail($personalizedContent, $employee['username'], $employee['email'], $tempPassword));
                $successCount++;
                Log::info('Employee Data:', $employee);
            } catch (\Exception $e) {
                $failedEmails[] = $employee['email'];
                Log::error('Failed to send welcome email', [
                    'email' => $employee['email'],
                    'error' => $e->getMessage()
                ]);
            }
        }
        return response()->json([
            'success' => true,
            'successCount' => $successCount,
            'failedEmails' => $failedEmails
        ]);
    }

    /**
     * to display welcome email template on edit modal
     */
    public function getWelcomeEmployeeTemplate()
    {
        return view('emails.employee_welcome_template');
    }

    public function getAllUserIds(Request $request)
    {
        $user = Auth::user();
        $ids = Employee::where('employer_id', $user->id)->pluck('id')->toArray();
        return response()->json(['user_ids' => $ids]);
    }

    public function checkLaunchQuota(Request $request)
    {
        $employer = Auth::user();
        $prepaidSlots = $employer->number_of_users;
        $totalUploaded = Employee::where('employer_id', $employer->id)->count();
        $alreadyLaunched = Employee::where('employer_id', $employer->id)->where('plan_status', 1)->count();
        $extraSlots = max(0, $totalUploaded - $prepaidSlots);

        if ($extraSlots > 0) {
            return response()->json([
                'requires_payment' => true,
                'remaining_to_pay' => $extraSlots,
                'total_uploaded' => $totalUploaded,
                'paid_slots' => $prepaidSlots
            ]);
        }

        return response()->json(['requires_payment' => false]);
    }

    public function requestExtraSlots(Request $request)
    {
        $user = Auth::user();
        $slots = (int) $request->additional_slots;

        if ($slots <= 0) {
            return response()->json(['error' => 'Invalid slot count.'], 422);
        }

        Stripe::setApiKey(env('STRIPE_SECRET'));

        $session = Session::create([
            'payment_method_types' => ['card'],
            'customer_email' => $user->email,
            'line_items' => [[
                'price_data' => [
                    'currency' => 'usd',
                    'product_data' => ['name' => 'Additional Employee Slots'],
                    'unit_amount' => 100,
                ],
                'quantity' => $slots,
            ]],
            'mode' => 'payment',
            'success_url' => route('stripe.extra_slots.success', ['slots' => $slots]) . '&session_id={CHECKOUT_SESSION_ID}',
            'cancel_url' => url('/dashboard'),
        ]);

        return response()->json(['session_url' => $session->url]);
    }


    public function bulkLaunch(Request $request)
    {
        $employer = Auth::user();
        if ($employer->program_launched_at) {
            return response()->json([
                'success' => false,
                'already_launched' => true,
                'message' => 'Program has already been launched. You cannot launch again.'
            ]);
        }
        $userIds = Employee::where('employer_id', $employer->id)->pluck('id')->toArray();

        $prepaidLimit = $employer->number_of_users;
        $alreadyLaunchedCount = Employee::where('employer_id', $employer->id)->where('plan_status', 1)->count();
        $remainingCredits = max(0, $prepaidLimit - $alreadyLaunchedCount);


        if (count($userIds) > $remainingCredits + $alreadyLaunchedCount) {
            return response()->json([
                'requires_payment' => true,
                'remaining_to_pay' => count($userIds) - $prepaidLimit,
                'message' => "You must pay for " . (count($userIds) - $prepaidLimit) . " users to proceed."
            ]);
        }

        if (!$employer->program_launched_at) {
            $employer->program_launched_at = now();
            $employer->save();
        }
        $programEndDate = $employer->program_launched_at->copy()->addDays($employer->program_periods ?? 30);

        foreach ($userIds as $id) {
            $user = Employee::findOrFail($id);
            if ($user->plan_status === 1) continue;

            $password = Str::random(8);
            $user->password = Hash::make($password);
            $user->plan_status = 1;
            $user->welcome_email_sent = 1;
            $user->save();

            Mail::to($user->email)->send(new UserLaunchCredentials($user->email, $password));

            WellifySubscription::create([
                'employer_id' => $employer->id,
                'app_user_id' => $id,
                'start_date' => now(),
                'end_date' => $programEndDate,
                'platform' => 'stripe',
                'status' => 'active',
                'is_employer_sponsored' => true,
                'plan_id' => 1
            ]);
        }

        return response()->json(['success' => true, 'message' => 'Launch successful.']);
    }

}

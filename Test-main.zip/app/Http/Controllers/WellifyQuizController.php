<?php

namespace App\Http\Controllers;

use Aws\S3\S3Client;
use App\Helpers\S3Helper;
use App\Models\WellifyQuiz;
use App\Models\WellifyClass;
use Illuminate\Http\Request;
use App\Models\WellifyQuizOption;
use Aws\S3\Exception\S3Exception;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class WellifyQuizController extends Controller
{
    public function create($classId)
    {
        $class = WellifyClass::findOrFail($classId);
        return view('wellify_classes.quiz_modal', compact('class'))->render();
    }

    public function store(Request $request, $classId)
    {
        $validator = Validator::make($request->all(), [
            'question' => 'required|string',
            'options' => 'required|array|min:2',
            'options.*' => 'required|string',
            'correct_answers' => 'required|array|min:1',
            'description' => 'nullable|string',
            'media' => 'nullable|mimes:svg,svg+xml',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $mediaPath = null;
            if ($request->hasFile('media')) {
                $file = $request->file('media');
                $originalFilename = $file->getClientOriginalName();
                $filename = $classId . '_'  . $originalFilename;

                $keyname = env('S3_CLASSES') . $filename;

                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ]
                ]);

                try {
                    $s3->putObject([
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $keyname,
                        'Body'   => fopen($file, 'r+'),
                        'ContentType' => 'image/svg+xml',
                        // 'ACL'    => 'private',
                    ]);
                    $mediaPath = $filename;
                } catch (S3Exception $e) {
                    return response()->json(['success' => false, 'message' => 'Image upload failed.'], 500);
                }
            }
            $quiz = WellifyQuiz::create([
                'class_id' => $classId,
                'title' => $request->question,
                'media' => $mediaPath,
            ]);
            foreach ($request->options as $index => $optionText) {
                $isAnswer = in_array($index, $request->correct_answers);

                WellifyQuizOption::create([
                    'quiz_id' => $quiz->id,
                    'class_id' => $classId,
                    'option' => $optionText,
                    'media' => $mediaPath,
                    'isAnswer' => $isAnswer ? 1 : 0,
                    'description' => $isAnswer ? $request->description : null,
                ]);
            }
            return response()->json([
                'success' => true,
                'message' => 'Quiz created successfully!',
                'quiz_count' => WellifyQuiz::where('class_id', $classId)->count()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error creating quiz: ' . $e->getMessage()
            ], 500);
        }
    }


    public function showQuizzes(WellifyClass $class)
    {
        $quizzes = WellifyQuiz::where('class_id', $class->id)
            ->with('options')
            ->get();

        foreach ($quizzes as $quiz) {
            $quiz->media_url = S3Helper::generatePresignedUrl(env('S3_CLASSES'), $quiz->media);
        }

        return view('wellify_classes.quizzes.index', compact('class', 'quizzes'));
    }

    public function update(Request $request, $id)
    {
        // dd($request->all());
        try {
            $quiz = WellifyQuiz::findOrFail($id);
            $quiz->title = $request->input('title');
            if ($request->hasFile('media')) {
                $file = $request->file('media');

                // Delete old media from S3 if exists
                if ($quiz->media) {
                    Storage::disk('s3')->delete(env('S3_CLASSES') . $quiz->media);
                }

                // Create unique filename
                $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                $keyname = env('S3_CLASSES') . $filename;

                // Upload to S3
                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ]
                ]);

                $s3->putObject([
                    'Bucket' => env('AWS_BUCKET'),
                    'Key'    => $keyname,
                    'Body'   => fopen($file, 'r'),
                    'ContentType' => 'image/svg+xml',
                    // 'ACL'    => 'private',
                ]);

                // Save only filename to DB
                $quiz->media = $filename;
            }

            $quiz->save();

            // Update options if any
            if ($request->has('options')) {
                $options = json_decode($request->input('options'), true);
                foreach ($options as $optionData) {
                    $option = WellifyQuizOption::find($optionData['id']);
                    if ($option) {
                        $option->option = $optionData['option'];
                        $option->isAnswer = $optionData['isAnswer'];
                        $option->description = $optionData['description'];
                        $option->save();
                    }
                }
            }

            // Generate presigned URL for frontend
            $mediaUrl = S3Helper::generatePresignedUrl(env('S3_CLASSES'), $quiz->media);

            return response()->json([
                'status' => 'success',
                // 'message' => 'Quiz updated successfully',
                'media_url' => $mediaUrl
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to update quiz: ' . $e->getMessage()
            ], 500);
        }
    }

    public function destroy($id)
    {
        try {
            $quiz = WellifyQuiz::findOrFail($id);

            // Delete media from S3 if exists
            if ($quiz->media) {
                Storage::disk('s3')->delete('quiz_images/' . $quiz->media);
            }

            // Delete quiz options first (foreign key constraint)
            $quiz->options()->delete();

            // Delete quiz
            $quiz->delete();

            return response()->json([
                'status' => 'success',
                'message' => 'Quiz deleted successfully'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to delete quiz: ' . $e->getMessage()
            ], 500);
        }
    }
}

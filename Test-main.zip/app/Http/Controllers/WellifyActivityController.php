<?php

namespace App\Http\Controllers;

use Aws\S3\S3Client;
use App\Models\WellifyMood;
use Illuminate\Support\Str;
use App\Models\WellifyClass;
use App\Models\WellifyLevel;
use Illuminate\Http\Request;
use App\Models\WellifyActivity;
use Illuminate\Validation\Rule;
use Aws\S3\Exception\S3Exception;
use Illuminate\Support\Facades\Log;
use App\Models\WellifyActivityMedia;
use App\Models\WellifyActivityCategory;
use Illuminate\Support\Facades\Storage;
use Yajra\DataTables\Facades\DataTables;
use App\Models\WellifyActivityMoodAssociation;

class WellifyActivityController extends Controller
{
    /*Fetch all the Class EORM* */
    public function index()
    {
        $categories = WellifyActivityCategory::where('status', 1)
            ->get(['id', 'title'])
            ->mapWithKeys(function ($item) {
                return [$item->id => $item->title];
            });

        $levels = WellifyLevel::select('id', 'title')->get();
        $moods = WellifyMood::select('id', 'title')->get();
        $classes = WellifyClass::all();

        return view('wellify_activities.index', compact('levels', 'moods', 'classes', 'categories'));
    }

    /*GetData Activity Function* */
    public function getData(Request $request)
    {
        $data = WellifyActivity::with(['levels', 'media', 'prerequisiteClass']);

        return DataTables::of($data)
            ->addColumn('activity_id', fn($row) => $row->activity_id)

            ->addColumn('level_id', function ($row) {
                return $row->levels ? $row->levels->title : 'N/A';
            })

            ->addColumn('points_on_completion', function ($row) {
                $value = (int) $row->points_on_completion ?? 0;
                return $value . ' ' . Str::plural('Point', $value);
            })
            ->addColumn('associated_moods', function ($row) {
                $moods = $row->moods;
                $moodCount = $moods->count();
                $tooltipTitle = $moods->pluck('title')->join(', ');

                $moodHtml = '<small class="d-inline-flex px-3 py-1 fw-semibold text-success-emphasis mood_numbers border border-success-subtle rounded-4" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="custom-tooltip" data-bs-title="' . $tooltipTitle . '">' . $moodCount . ' ' . ($moodCount == 1 ? 'Mood' : 'Moods') . '</small>';

                return $moodHtml;
            })
            // ->addColumn('prerequisite_class', function ($row) {
            //     return $row->prerequisiteClass ? $row->prerequisiteClass->title : 'N/A';
            // })

            ->addColumn('water_on_completion', function ($row) {
                $value = (int) $row->water_on_completion ?? 0;
                return $value . ' ' . Str::plural('Water Droplet', $value);
            })

            ->addColumn('media_status', function ($row) {
                $enumToValue = [
                    'Completed'    => '1',
                    'In-Progress'  => '2',
                    'Not-Started'  => '3',
                ];

                $valueToEnum = array_flip($enumToValue);

                // Default to 'Not-Started' if null
                $currentStatusValue = $enumToValue[$row->media_status ?? 'Not-Started'];

                $options = [
                    '1' => 'Completed',
                    '2' => 'In-Progress',
                    '3' => 'Not-Started',
                ];
                $disabled = $row->status == 0 ? 'disabled' : '';
                $grayedOut = $row->status == 0 ? 'opacity: 0.6; cursor: not-allowed;' : '';

                $html = '<select class="form-select image_status_select status_select" data-id="' . $row->activity_id . '" style="' . $grayedOut . '" ' . $disabled . ' >';
                foreach ($options as $value => $label) {
                    $selected = ($currentStatusValue == $value) ? 'selected' : '';
                    $html .= "<option value=\"{$value}\" {$selected}>{$label}</option>";
                }
                $html .= '</select>';

                return $html;
            })

            ->addColumn('class_status', function ($row) {
                $checked = $row->status ? 'checked' : '';
                return '<div class="flipswitch">
                            <input class="flipswitch-cb toggle-status" type="checkbox"
                                id="fs' . $row->activity_id . '" data-activity-id="' . $row->activity_id . '" ' . $checked . '>
                            <label for="fs' . $row->activity_id . '" class="flipswitch-label">
                                <span class="flipswitch-inner d-block"></span>
                                <span class="flipswitch-switch d-block"></span>
                            </label>
                        </div>';
            })

            ->addColumn('activities_images', function ($row) {
                $imageCount = $row->media->count();
                $imageNouns = ($imageCount > 1) ? 'Images' : 'Image';
                $s3IconUrl = Storage::disk('s3')->temporaryUrl(
                    'staging/public/Add_icon.svg', 
                    now()->addHour()
                );
                return '
                    <small class="d-inline-flex px-3 py-1 fw-semibold border border-success-subtle rounded-4 cursor-pointer"
                        onclick="window.location.href=\'' . route('wellify_activities.media', ['activity_id' => $row->activity_id]) . '\'" style="cursor: pointer;">'
                    . $imageCount . ' ' . $imageNouns . '
                    </small>
                    <img src="' . $s3IconUrl . '" alt="add icon"
                        class="img-fluid cursor-pointer open-upload-modal"
                        data-id="' . $row->activity_id . '" style="cursor: pointer;" title="Add Activity Images">';
            })

            ->addColumn('actions', function ($row) {
                return '<div class="action_td">
                            <span class="view_icon1" title="View"  data-id="' . $row->activity_id . '" data-bs-toggle="modal" data-bs-target="#view_user">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="14" viewBox="0 0 20 14" fill="none">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M6 7C6 6.00544 6.39509 5.05161 7.09835 4.34835C7.80161 3.64509 8.75544 3.25 9.75 3.25C10.7446 3.25 11.6984 3.64509 12.4017 4.34835C13.1049 5.05161 13.5 6.00544 13.5 7C13.5 7.99456 13.1049 8.94839 12.4017 9.65165C11.6984 10.3549 10.7446 10.75 9.75 10.75C8.75544 10.75 7.80161 10.3549 7.09835 9.65165C6.39509 8.94839 6 7.99456 6 7ZM9.75 4.75C9.15326 4.75 8.58097 4.98705 8.15901 5.40901C7.73705 5.83097 7.5 6.40326 7.5 7C7.5 7.59674 7.73705 8.16903 8.15901 8.59099C8.58097 9.01295 9.15326 9.25 9.75 9.25C10.3467 9.25 10.919 9.01295 11.341 8.59099C11.7629 8.16903 12 7.59674 12 7C12 6.40326 11.7629 5.83097 11.341 5.40901C10.919 4.98705 10.3467 4.75 9.75 4.75Z"
                                        fill="#1283CE"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M2.073 5.646C1.654 6.25 1.5 6.723 1.5 7C1.5 7.277 1.654 7.75 2.073 8.354C2.479 8.937 3.081 9.57 3.843 10.155C5.37 11.327 7.463 12.25 9.75 12.25C12.037 12.25 14.13 11.327 15.657 10.155C16.419 9.57 17.021 8.937 17.427 8.354C17.846 7.75 18 7.277 18 7C18 6.723 17.846 6.25 17.427 5.646C17.021 5.063 16.419 4.43 15.657 3.845C14.13 2.673 12.037 1.75 9.75 1.75C7.463 1.75 5.37 2.673 3.843 3.845C3.081 4.43 2.479 5.063 2.073 5.646ZM2.929 2.655C4.66 1.327 7.066 0.25 9.75 0.25C12.434 0.25 14.84 1.327 16.57 2.655C17.437 3.32 18.153 4.062 18.659 4.791C19.151 5.5 19.5 6.277 19.5 7C19.5 7.723 19.15 8.5 18.659 9.209C18.153 9.938 17.437 10.679 16.571 11.345C14.841 12.673 12.434 13.75 9.75 13.75C7.066 13.75 4.66 12.673 2.93 11.345C2.063 10.68 1.347 9.938 0.841 9.209C0.35 8.5 0 7.723 0 7C0 6.277 0.35 5.5 0.841 4.791C1.347 4.062 2.063 3.321 2.929 2.655Z"
                                        fill="#1283CE"/>
                                </svg>
                            </span>
                            <span class="edit_activity" title="Edit" data-bs-toggle="modal" data-bs-target="#edit_user" data-id="' . $row->activity_id . '">
                                <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20"
                                    viewBox="0 0 21 20" fill="none">
                                    <path
                                        d="M14.666 2.49993C14.8849 2.28106 15.1447 2.10744 15.4307 1.98899C15.7167 1.87054 16.0232 1.80957 16.3327 1.80957C16.6422 1.80957 16.9487 1.87054 17.2347 1.98899C17.5206 2.10744 17.7805 2.28106 17.9993 2.49993C18.2182 2.7188 18.3918 2.97863 18.5103 3.2646C18.6287 3.55057 18.6897 3.85706 18.6897 4.16659C18.6897 4.47612 18.6287 4.78262 18.5103 5.06859C18.3918 5.35455 18.2182 5.61439 17.9993 5.83326L6.74935 17.0833L2.16602 18.3333L3.41602 13.7499L14.666 2.49993Z"
                                        stroke="#A25AD9" stroke-width="1.66667" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </span>
                            <span class="delete_icon1" title="Delete" data-id="' . $row->activity_id . '">
                                <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                                    <path d="M3 5.00033H4.66667M4.66667 5.00033H18M4.66667 5.00033V16.667C4.66667 17.109 4.84226 17.5329 5.15482 17.8455C5.46738 18.1581 5.89131 18.3337 6.33333 18.3337H14.6667C15.1087 18.3337 15.5326 18.1581 15.8452 17.8455C16.1577 17.5329 16.3333 17.109 16.3333 16.667V5.00033H4.66667ZM7.16667 5.00033V3.33366C7.16667 2.89163 7.34226 2.46771 7.65482 2.15515C7.96738 1.84259 8.39131 1.66699 8.83333 1.66699H12.1667C12.6087 1.66699 13.0326 1.84259 13.3452 2.15515C13.6577 2.46771 13.8333 2.89163 13.8333 3.33366V5.00033M8.83333 9.16699V14.167M12.1667 9.16699V14.167"
                                        stroke="#F54E51" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </span>

                        </div>';
            })

            ->addColumn('dummy', fn() => ' ')
            ->rawColumns(['media_status', 'class_status', 'associated_moods', 'activities_images', 'actions', 'activity_id', 'points_on_completion', 'water_on_completion', 'prerequisite_class'])
            ->make(true);
    }

    /*Update Media Status Activity Function* */
    public function updateMediaStatus(Request $request)
    {
        Log::debug('Full Request:', $request->all());
        $request->validate([
            'activity_id' => 'required|exists:wellify_activities,activity_id',
            'media_status' => 'required|in:1,2,3',
        ]);

        $statusMap = [
            '1' => 'Completed',
            '2' => 'In-Progress',
            '3' => 'Not-Started',
        ];

        $activity = WellifyActivity::where('activity_id', $request->activity_id)->firstOrFail();
        $activity->media_status = $statusMap[$request->media_status];
        $activity->save();

        return response()->json([
            'success' => true,
            'message' => 'Media status updated successfully'
        ]);
    }

    /*Update Status Activity Function* */
    public function updateStatus(Request $request)
    {
        $request->validate([
            'activity_id' => 'required|exists:wellify_activities,activity_id',
            'status' => 'required|boolean',
        ]);

        $activity = WellifyActivity::where('activity_id', $request->activity_id)->firstOrFail();
        $activity->status = $request->status;
        $activity->save();

        return response()->json([
            'success' => true,
            'message' => 'Status updated successfully',
            'new_status' => $request->status ? 'Active' : 'Inactive'
        ]);
    }

    /*Store the Activity Function* */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'activity_id' => 'required|string|unique:wellify_activities,activity_id',
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'background_image' => 'required|mimes:svg,svg+xml',
            // 'activity_category_id' => [
            //     'required',
            //     'string',
            //     Rule::exists('wellify_activity_categories', 'id')->where('status', 1)
            // ],
            'level_id' => 'nullable|exists:wellify_levels,id',
            'points_on_completion' => 'nullable|integer|min:0',
            'water_on_completion' => 'nullable|integer|min:0',
            // 'prerequisite_class' => 'nullable|array',
            // 'prerequisite_class.*' => 'exists:wellify_classes,id',
            'mood_id' => 'nullable|array',
            'mood_id.*' => 'exists:wellify_moods,id'
        ]);
        // dd($validated);

        try {
            // Upload SVG background image to S3
            $backgroundImagePath = null;
            if ($request->hasFile('background_image')) {

                $file = $request->file('background_image');
                $filename = 'activity_' . time() . '_' . $file->getClientOriginalName();
                $keyname = env('S3_ACTIVITIES') . $filename;
                Log::info('Background image uploaded:', [
                    'name' => $file->getClientOriginalName(),
                    'size' => $file->getSize(),
                    'mime' => $file->getMimeType()
                ]);

                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ]
                ]);

                try {
                    $s3->putObject([
                        'Bucket' => env('AWS_BUCKET'),
                        'Key'    => $keyname,
                        'Body'   => fopen($file->getRealPath(), 'r'),
                        'ContentType' => 'image/svg+xml',
                        // 'ACL'    => 'public-read',
                    ]);
                    $backgroundImagePath = $keyname;
                } catch (S3Exception $e) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Failed to upload SVG image: ' . $e->getMessage()
                    ], 500);
                }
            }

            // Create the activity
            $activity = WellifyActivity::create([
                'activity_id' => $validated['activity_id'],
                'title' => $validated['title'],
                'description' => $validated['description'],
                'background_image' => $backgroundImagePath,
                // 'activity_category_id' => $validated['activity_category_id'],
                'level_id' => $validated['level_id'],
                'points_on_completion' => $validated['points_on_completion'],
                'water_on_completion' => $validated['water_on_completion'],
                // 'prerequisite_class' => $validated['prerequisite_class'] ? implode(',', $validated['prerequisite_class']) : null,
                'status' => 1, // Default to inactive
                'media_status' => 'Not-Started'
            ]);
            Log::info('Activity created:', $activity->toArray());

            // Handle mood associations
            $activity->moods()->attach($validated['mood_id']);

            return redirect('/wellify-activities');
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create activity: ' . $e->getMessage()
            ], 500);
        }
    }

    /*Show the Activity Function* */
    public function show($activity_id)
    {
        $activity = WellifyActivity::with(['levels', 'category', 'moods', 'media'])
            ->where('activity_id', $activity_id)
            ->first();

        if (!$activity) {
            return response()->json([
                'success' => false,
                'message' => 'Activity not found.'
            ]);
        }

        return response()->json([
            'success' => true,
            'data' => [
                'activity_id' => $activity->activity_id,
                'title' => $activity->title,
                'description' => $activity->description,
                // 'background_image' => $activity->background_image ? Storage::disk('s3')->url($activity->background_image) : null,
                // 'category' => optional($activity->category)->title,
                'levels' => optional($activity->levels)->title,
                'level_id' => $activity->level_id,
                'points_on_completion' => $activity->points_on_completion,
                'water_on_completion' => $activity->water_on_completion,
                // 'prerequisite_class' => $activity->prerequisite_class,
                // 'moods' => $activity->moods->pluck('title')->toArray(),
                'associated_moods' => $activity->moods->map(function ($mood) {
                    return [
                        'title' => $mood->title,
                        'color_code' => ltrim($mood->color_code, '#'),
                        'text_code' => ltrim($mood->text_code, '#'),
                    ];
                }),
                'mood_ids' => $activity->moods->pluck('id')->toArray(),
                'image_count' => $activity->media->count(),
            ]
        ]);
    }

    /*Edit the Activity Function* */
    public function update(Request $request, $activity_id)
    {
        $activity = WellifyActivity::where('activity_id', $activity_id)->firstOrFail();

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'background_image' => 'nullable|mimes:svg,svg+xml',
            // 'activity_category_id' => [
            //     'required',
            //     'string',
            //     Rule::exists('wellify_activity_categories', 'id')->where('status', 1)
            // ],
            'level_id' => 'nullable|exists:wellify_levels,id',
            'points_on_completion' => 'nullable|integer|min:0',
            'water_on_completion' => 'nullable|integer|min:0',
            // 'prerequisite_class' => 'nullable|array',
            // 'prerequisite_class.*' => 'exists:wellify_classes,id',
            'mood_id' => 'nullable|array',
            'mood_id.*' => 'exists:wellify_moods,id'
        ]);

        try {
            if ($request->hasFile('background_image')) {
                $file = $request->file('background_image');
                $filename = 'activity_' . time() . '_' . $file->getClientOriginalName();
                $keyname = env('S3_ACTIVITIES') . $filename;

                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  => env('AWS_DEFAULT_REGION'),
                    'credentials' => [
                        'key'    => env('AWS_ACCESS_KEY_ID'),
                        'secret' => env('AWS_SECRET_ACCESS_KEY'),
                    ]
                ]);

                $s3->putObject([
                    'Bucket' => env('AWS_BUCKET'),
                    'Key'    => $keyname,
                    'Body'   => fopen($file->getRealPath(), 'r'),
                    'ContentType' => 'image/svg+xml',
                ]);

                $activity->background_image = $keyname;
            }

            $activity->update([
                'title' => $validated['title'],
                'description' => $validated['description'],
                // 'activity_category_id' => $validated['activity_category_id'],
                'level_id' => $validated['level_id'],
                'points_on_completion' => $validated['points_on_completion'],
                'water_on_completion' => $validated['water_on_completion'],

                // 'prerequisite_class' => $validated['prerequisite_class'] ? implode(',', $validated['prerequisite_class']) : null,
            ]);
            $activity->moods()->sync($validated['mood_id']);

            // Update moods
            // WellifyActivityMoodAssociation::where('activity_id', $activity->activity_id)->delete();
            // if ($request->mood_id && is_array($request->mood_id)) {
            //     foreach ($request->mood_id as $moodId) {
            //         WellifyActivityMoodAssociation::create([
            //             'activity_id' => $activity->activity_id,
            //             'mood_id' => $moodId
            //         ]);
            //     }
            // }

            return response()->json(['success' => true, 'message' => 'Activity updated successfully']);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update activity: ' . $e->getMessage()
            ], 500);
        }
    }


    private function getMediaType($file)
    {
        $mime = $file->getMimeType();

        if (str_contains($mime, 'video')) {
            return 'video';
        } elseif (str_contains($mime, 'gif')) {
            return 'gif';
        }

        return 'image';
    }

    /*Delete the Activity Function* */
    public function destroy($activity_id)
    {
        try {
            $activity = WellifyActivity::where('activity_id', $activity_id)->firstOrFail();
            $activity->delete();

            return response()->json([
                'success' => true,
                'message' => 'Activity deleted successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete activity: ' . $e->getMessage()
            ], 500);
        }
    }

    /*Get Deleted Activity Function* */
    public function getDeletedActivities(Request $request)
    {

        $data = WellifyActivity::onlyTrashed()
            ->with(['levels', 'media', 'prerequisiteClass', 'moods']);

        return DataTables::of($data)
            ->addColumn('checkbox', function ($row) {
                return '';
            })
            ->addColumn('dummy', function ($row) {
                return '';
            })
            ->addColumn('associated_moods', function ($row) {
                $moods = $row->moods;
                $moodCount = $moods->count();
                $tooltipTitle = $moods->pluck('title')->join(', ');

                return '<small class="d-inline-flex px-3 py-1 fw-semibold text-success-emphasis mood_numbers border border-success-subtle rounded-4"
                        data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-custom-class="custom-tooltip"
                        data-bs-title="' . $tooltipTitle . '">'
                    . $moodCount . ' ' . ($moodCount == 1 ? 'Mood' : 'Moods') . '</small>';
            })
            // Add all your existing columns from getData() method
            ->addColumn('activity_id', fn($row) => $row->activity_id)
            ->addColumn('title', fn($row) => $row->title)

            ->addColumn('level_id', function ($row) {
                return $row->levels ? $row->levels->title : 'N/A';
            })

            ->addColumn('points_on_completion', function ($row) {
                $value = (int) $row->points_on_completion ?? 0;
                return $value . ' ' . Str::plural('Point', $value);
            })
            // ->addColumn('prerequisite_class', function ($row) {
            //     return $row->prerequisiteClass ? $row->prerequisiteClass->title : 'N/A';
            // })

            ->addColumn('water_on_completion', function ($row) {
                $value = (int) $row->water_on_completion ?? 0;
                return $value . ' ' . Str::plural('Water Droplet', $value);
            })
            ->addColumn('actions', function ($row) {
                return ''; // Will be handled by DataTables render function
            })
            ->rawColumns(['checkbox', 'dummy', 'associated_moods', 'title', 'level_id', 'actions', 'activity_id', 'points_on_completion', 'water_on_completion', 'prerequisite_class'])
            ->make(true);
    }

    /*Restore the Activity Function* */
    public function restore($activity_id)
    {
        $activity = WellifyActivity::onlyTrashed()->where('activity_id', $activity_id)->first();

        if (!$activity) {
            return response()->json([
                'success' => false,
                'message' => 'Activity not found.'
            ], 404);
        }

        $activity->restore();

        return response()->json([
            'success' => true,
            'message' => 'Activity restored successfully'
        ]);
    }

    /*Bulk Restore the Activity Function* */
    public function bulkRestore(Request $request)
    {
        WellifyActivity::onlyTrashed()
            ->whereIn('activity_id', $request->ids)
            ->restore();

        return response()->json([
            'success' => true,
            'message' => 'Selected activities restored successfully'
        ]);
    }

    public function forceDelete($activity_id)
    {
        $activity = WellifyActivity::onlyTrashed()->where('activity_id', $activity_id)->first();

        if (!$activity) {
            return response()->json([
                'success' => false,
                'message' => 'Activity not found or already deleted permanently.'
            ], 404);
        }

        $activity->forceDelete();

        return response()->json([
            'success' => true,
            'message' => 'Activity permanently deleted'
        ]);
    }
}

<?php

namespace App\Http\Controllers;

use Stripe\Stripe;
use Stripe\Customer;
use Stripe\PaymentIntent;
use Stripe\PaymentMethod;
use App\Models\WellifyUser;
use Illuminate\Http\Request;
use Stripe\Checkout\Session;
use App\Models\EmployerPayment;
use App\Mail\EmployerCreatedMail;
use Illuminate\Support\Facades\Mail;

class StripeController extends Controller
{
    public function handleSuccess(Request $request)
    {
        $user = WellifyUser::findOrFail($request->employer_id);

        if (!$user->setup_fee_paid) {
            $user->setup_fee_paid = true;
            $user->save();

            $decryptedPassword = decrypt($request->token);

            Stripe::setApiKey(env('STRIPE_SECRET'));

            $sessionId = $request->get('session_id');
            if (!$sessionId) {
                return redirect('/admin/employers')->with('error', 'Missing payment session ID.');
            }

            $session = Session::retrieve($sessionId);
            $paymentIntent = PaymentIntent::retrieve($session->payment_intent);
            $paymentMethod = $paymentIntent->payment_method ? PaymentMethod::retrieve($paymentIntent->payment_method) : null;

            EmployerPayment::create([
                'employer_id' => $user->id,
                'stripe_payment_id' => $paymentIntent->id,
                'stripe_checkout_session_id' => $session->id,
                'stripe_customer_id' => $session->customer,
                'amount_paid' => $session->amount_total / 100,
                'currency' => strtoupper($session->currency),
                'status' => $session->payment_status,
                'paid_at' => now(),
                'payment_method' => $paymentMethod?->type,
                'card_brand' => $paymentMethod?->card?->brand,
                'card_last4' => $paymentMethod?->card?->last4,
                'receipt_url' => $session->payment_status === 'paid' ? $session->url : null,
                'customer_email' => $session->customer_email ?? optional(Customer::retrieve($session->customer))->email,
            ]);

            Mail::to($user->email)->send(new EmployerCreatedMail($user, $decryptedPassword));

            $user->welcome_email_sent = 1;
            $user->save();
        }

        return redirect()->route('thank.you')->with('success', 'Payment confirmed and welcome email sent.');
    }

    public function extraSlotsPayment(Request $request, WellifyUser $employer, $amount)
    {
        Stripe::setApiKey(env('STRIPE_SECRET'));

        $customer = Customer::create([
            'email' => $employer->email,
            'name' => $employer->first_name . ' ' . $employer->last_name,
        ]);

        $session = Session::create([
            'payment_method_types' => ['card'],
            'customer_email' => $employer->email,
            'line_items' => [[
                'price_data' => [
                    'currency' => 'usd',
                    'product_data' => ['name' => 'Extra Slots Payment'],
                    'unit_amount' => $amount * 100,
                ],
                'quantity' => 1,
            ]],
            'mode' => 'payment',
            'success_url' => route('stripe.extra_slots.success', ['employer_id' => $employer->id]) . '&session_id={CHECKOUT_SESSION_ID}',

            'cancel_url' => url('/dashboard'),
        ]);

        return redirect($session->url);
    }

    public function handleExtraSlotsPaymentSuccess(Request $request)
    {
        $user = WellifyUser::findOrFail($request->employer_id);

        $user->setup_fee_paid = true;
        $user->save();

        // Send confirmation email after slots payment
        Mail::to($user->email)->send(new \App\Mail\SlotsPaymentConfirmedMail($user, $user->number_of_users));

        return redirect()->route('wellify_employees.index')->with('success', 'Payment confirmed. You can now launch all your users.');
    }





}
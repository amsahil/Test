<?php

namespace App\Http\Controllers;

use App\Mail\ForgetEmailPassword;
use App\Models\Employer\Employee;
use App\Models\Employer\Staff;
use App\Models\WellifyUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;


class AuthController extends Controller
{
    /**  
     * Show the login form
     */
    public function showLoginForm()
    {
        return view('superAdmin.auth.login');
    }

    // public function login(Request $request)
    // {
    //     $credentials = $request->validate([
    //         'email' => 'required|email',
    //         'password' => 'required',
    //     ]);

    //     $remember = $request->filled('remember');

    //     if (Auth::attempt($credentials, $remember)) {
    //         $user = Auth::user();
    //         /**manually set remember token*/
    //         if ($remember) {
    //             $rememberToken = Str::random(100);
    //             setcookie('remember_me', $rememberToken, time() + (86400 * 7), "/");
    //             $user->remember_token = $rememberToken;
    //             $user->save();
    //         } else {
    //             setcookie('remember_me', '', time() - 3600, "/");
    //             $user->remember_token = null;
    //             $user->save();
    //         }

    //         /**Redirect logic*/ 
    //         if ($user->hasRole('Super Admin')) {
    //             // return redirect()->route('wellify_users.index');
    //             return redirect()->route('dashboard');
    //         } elseif ($user->hasRole('Employer')) {
    //             return redirect()->route('dashboard');
    //         } elseif ($user->hasRole('Staff')) {
    //             dd('hello');
    //         }
    //         if (! $remember) {
    //             config(['session.expire_on_close' => true]);
    //             session()->put('logout_on_close', true);
    //         }
    //         return redirect()->route('dashboard');
    //     }
    //     return back()->withErrors([
    //         'email' => 'Invalid credentials.',
    //         'password' => 'Invalid credentials.',
    //     ])->with("error_class", "error_input");
    // }


    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $remember = $request->filled('remember');

        // Attempt login for Employer (users table)
        if (Auth::guard('web')->attempt($credentials, $remember)) {
            $user = Auth::guard('web')->user();
            
            $rememberToken = Str::random(100);
            setcookie('remember_me', $rememberToken, time() + (86400 * 7), "/");
            $user->remember_token = $rememberToken;
            $user->save();
            return redirect()->route('dashboard');
        }

        // Attempt login for Staff (staff table)
        if (Auth::guard('staff')->attempt($credentials, $remember)) {
            $user = Auth::guard('staff')->user();
            
            setcookie('remember_me', '', time() - 3600, "/");
            $user->remember_token = null;
            $user->save();
            config(['session.expire_on_close' => true]);
            session()->put('logout_on_close', true);
            return redirect()->route('dashboard');
        }

        // If both fail
        return back()->withErrors([
            'email' => 'Invalid credentials.',
            'password' => 'Invalid credentials.',
        ])->with("error_class", "error_input");
    }

    
    /**  
     * Handle user logout
     */
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('login');
    }


    /**  
     * Show the forgot password form 
     */
    public function showForgotForm()
    {
        return view('superAdmin.auth.forgot_password');
    }

    /**  
     * Send OTP to user's email for password reset
     */
    public function forgotPassword(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:wellify_users,email',
        ], [
            'email.required' => 'Email is required.',
            'email.email' => 'Please enter a valid email address.',
            'email.exists' => 'This email is not registered with us.',
        ]);

        $token = $this->generateOtp();

        try {
            session(['otp_email' => $request->email]);
            session(['last_otp_sent_at' => now()]);

            DB::table('password_reset_tokens')->updateOrInsert(
                ['email' => $request->email],
                [
                    'token' => $token,
                    'created_at' => now(),
                    'expires_at' => now()->addMinutes(10),
                ]
            );

            $user = DB::table('wellify_users')->where('email', $request->email)->first();
            $fullName = $user ? $user->first_name . ' ' . $user->last_name : 'User';

            Mail::to($request->email)->send(new ForgetEmailPassword($token, $fullName));

            return redirect()->route('otp.verification');
        } catch (\Exception $e) {
            Log::error("Error sending OTP: " . $e->getMessage(), ['trace' => $e->getTrace()]);
            return back()
                ->withInput()
                ->withErrors(['email' => 'Failed to send OTP. Please try again.'])
                ->with("error_class", "error_input");
        }
    }


    /**
     * function for resend otp
     */
    public function resendOtp(Request $request)
    {
        // If cooldown is over, generate and send OTP
        $token = $this->generateOtp();
        try {
            // Update session timestamp for OTP resend
            session(['last_otp_sent_at' => now()]);

            // Send the email using Mailable
            $store =  Mail::to($request->email)->send(new ForgetEmailPassword($token));
            return response()->json(['message' => 'OTP has been sent successfully!']);
        } catch (\Exception $e) {
            Log::error("Error sending OTP: " . $e->getMessage(), ['trace' => $e->getTrace()]);
            return response()->json(['message' => 'Failed to send OTP. Please try again.'], 500);
        }
    }

    /**  
     * Show otp form
     */
    public function showOtpVerificationForm()
    {
        return view('superAdmin.auth.otp_verification');
    }

    /**  
     * Verify the entered OTP
     */
    public function verifyOtp(Request $request)
    {
        $request->validate([
            'otp' => 'required|array|size:4',
            'otp.*' => 'required|integer|digits:1',
        ]);

        $otp = implode("", $request->otp);

        try {
            $record = DB::table('password_reset_tokens')->where('token', $otp)->first();

            if (!$record) {
                return back()->withErrors(['otp' => 'Requested OTP not found.']);
            }

            if (now()->greaterThan($record->expires_at)) {
                return back()->withErrors(['otp' => 'OTP has expired.']);
            }

            DB::table('password_reset_tokens')->where('token', $otp)->delete();

            return redirect()->route('reset.password', ['email' => $record->email]);
        } catch (\Exception $e) {
            Log::error("OTP Verification Error: " . $e->getMessage());
            return back()->with('error', 'Failed to verify OTP. Please try again.');
        }
    }

    /**  
     * Show the reset password form
     */
    public function showResetForm(Request $request)
    {
        $email = $request->query('email');
        return view('superAdmin.auth.reset_password', compact('email'));
    }

    /**  
     * Handle reset password submission
     */
    public function resetPassword(Request $request)
    {
        $messages = [
            'password.regex' => 'Contain 8 char like- Abc@1234',
        ];

        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:wellify_users,email',
            'password' => [
                'required',
                'string',
                'confirmed',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&]).{9,}$/'
            ],
        ], $messages);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        try {
            Log::info('Reset Password Attempt', ['email' => $request->email]);

            $user = WellifyUser::where('email', $request->email)->firstOrFail();
            $user->update([
                'password' => Hash::make($request->password),
                'updated_at' => now()
            ]);

            return redirect()->route('login')->with('success', 'Password has been reset successfully.');
        } catch (\Exception $e) {
            Log::error('Reset Password Error: ' . $e->getMessage(), ['trace' => $e->getTrace()]);
            return back()->with('error', 'An unexpected error occurred while resetting the password.');
        }
    }

    /**  
     * Generate a 4-digit OTPsssss
     */
    private function generateOtp(): int
    {
        return rand(1000, 9999);
    }

    public function getRoles()
    {
        $roles = DB::table('roles')->select('id', 'name')->orderBy('name', 'desc')->get();
        return response()->json($roles);
    }
}

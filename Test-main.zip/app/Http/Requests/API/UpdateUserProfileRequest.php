<?php

namespace App\Http\Requests\API;

use Illuminate\Foundation\Http\FormRequest;

class UpdateUserProfileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            // 'email' => 'required|email|max:255|exists:wellify_users,email',
            'profile_picture' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'first_name' => 'nullable|string|max:255',
            'last_name' => 'nullable|string|max:255',
            'phone' => 'nullable|string|max:15',
            'timezone' => 'nullable|string|max:50',
        ];
    }

    public function messages()
    {
        return [
            'email.required' => 'The email field is required.',
            'email.email' => 'Please provide a valid email address.',
            'email.max' => 'The email must not be greater than 255 characters.',
            'email.exists' => 'The provided email does not exist in our records.',
            'profile_picture.required' => 'A profile picture is required.',
            'profile_picture.image' => 'The profile picture must be an image.',
            'profile_picture.mimes' => 'The profile picture must be a file of type: jpeg, png, jpg, gif.',
            'profile_picture.max' => 'The profile picture must not be greater than 2MB.',
            'first_name.string' => 'The first name must be a string.',
            'first_name.max' => 'The first name must not be greater than 255 characters.',
            'last_name.string' => 'The last name must be a string.',
            'last_name.max' => 'The last name must not be greater than 255 characters.',
            'phone.string' => 'The phone number must be a string.',
            'phone.max' => 'The phone number must not be greater than 15 characters.',
            'timezone.string' => 'The timezone must be a string.',
            'timezone.max' => 'The timezone must not be greater than 50 characters.',
         ];
    }
}

<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Yajra\DataTables\Utilities\Request;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\StripeController;
use App\Http\Middleware\PreventBackHistory;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\WellifyMoodController;
use App\Http\Controllers\WellifyQuizController;
use App\Http\Controllers\WellifySeedController;
use App\Http\Controllers\WellifyUserController;
use App\Http\Controllers\WellifyClassController;
use App\Http\Controllers\Employer\StaffController;
use App\Http\Controllers\WellifyEmployersPlanList;
use App\Http\Controllers\WellifyActivityController;
use App\Http\Controllers\WellifyEmployeeController;
use App\Http\Controllers\WellifyClasssMediaController;
use App\Http\Controllers\WellifyUserProfileController;
use App\Http\Controllers\Employer\DepartmentController;
use App\Http\Controllers\EmployerSubscriptionController;
use App\Http\Controllers\WellifyActivityMediaController;
use App\Http\Controllers\WellifyStripePaymentController;
use App\Http\Controllers\WellifyStripeWebhookController;

/**
 * Guest Routes (Unauthenticated)
 */
Route::middleware('guest')->group(function () {
    Route::get('/', [AuthController::class, 'showLoginForm'])->name('home');

    // Login
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);

    // Forgot Password
    Route::get('/forgot-password', [AuthController::class, 'showForgotForm'])->name('forgot.password');
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword'])->name('send.otp');

    // OTP Verification
    Route::get('/otp-verification', [AuthController::class, 'showOtpVerificationForm'])->name('otp.verification');
    Route::post('/otp-verification', [AuthController::class, 'verifyOtp'])->name('verify.otp');
    Route::post('/resend-otp', [AuthController::class, 'resendOtp'])->name('resend.otp');

    // Reset Password
    Route::get('/show-reset-password', [AuthController::class, 'showResetForm'])->name('reset.password');
    Route::post('/reset-password', [AuthController::class, 'resetPassword'])->name('reset.password.submit');

});

/**
 * Authenticated Routes (All logged-in users)
 */

Route::middleware(['auth:web', PreventBackHistory::class])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name("dashboard");
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::get('wellify-plans', [WellifyStripePaymentController::class , 'showPlanPage'])->name('wellifyplans.index');
    Route::get('wellify-employer-plans', [WellifyEmployersPlanList::class , 'index'])->name('wellifyemployerplans.index');

    Route::get('wellify-plans', [WellifyStripePaymentController::class, 'showPlanPage'])->name('wellifyplans.index');

    Route::get('process-payment', [WellifyStripePaymentController::class, 'showPaymentForm'])->name('wellifypayments.stripepayment');
    Route::post('process-payment', [WellifyStripePaymentController::class, 'processPayment'])->name('wellifypayments.process');

    Route::get('checkout', [WellifyStripePaymentController::class, 'showPaymentForm'])->name('wellifypayments.stripecheckout');
    Route::post('create-checkout-session', [WellifyStripePaymentController::class, 'createCheckoutSession'])->name('wellifypayments.createCheckoutSession');
    Route::get('success', [WellifyStripePaymentController::class, 'paymentSuccess'])->name('wellifypayments.success');
    Route::get('cancel', [WellifyStripePaymentController::class, 'paymentCancel'])->name('wellifypayments.cancel');

    // Route::get('/plans/create', [WellifyStripePaymentController::class, 'showCreateForm'])->name('plans.create');
    // Route::post('/plans/create', [WellifyStripePaymentController::class, 'createPlan'])->name('plans.store');

    Route::get('/subscription/success', [WellifyStripePaymentController::class, 'subscriptionSuccess'])->name('subscription.success');
    Route::get('/subscription/cancel', [WellifyStripePaymentController::class, 'subscriptionCancel'])->name('subscription.cancel');
    Route::post('/subscription/create', [WellifyStripePaymentController::class, 'createSubscription'])->name('subscription.create');
});


// Route::middleware(['auth:staff', 'role:Staff'])->group(function () {
//     Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
// });


/**
 * Super Admin Routes Only
 */
Route::middleware(['auth:web,staff', 'role:Super Admin|Employer|Staff'])->group(function () {
    // routes/web.php
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/profile/{id}', [WellifyUserProfileController::class, 'show'])->name('profile.show');
    Route::post('/profile/update', [WellifyUserProfileController::class, 'update'])->name('profile.update');
    /*Manage Admin Dashboard*/
    // Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');


    /**Manage Employers Routes*/
    Route::get('/wellify_users/deleted/data', [WellifyUserController::class, 'deletedData'])->name('wellify_users.deleted.data');
    Route::get('/wellify_users/deleted', [WellifyUserController::class, 'deletedUsers'])->name('wellify_users.deleted');
    Route::post('/wellify_users/{id}/restore', [WellifyUserController::class, 'restore'])->name('wellify_users.restore');
    Route::get('/wellify_users', [WellifyUserController::class, 'index'])->name('wellify_users.index');
    Route::get('/wellify_users/data', [WellifyUserController::class, 'data'])->name('wellify_users.data');
    Route::get('/wellify_users/create', [WellifyUserController::class, 'create']);
    Route::post('/wellify_users', [WellifyUserController::class, 'store'])->name('wellify_users.store');
    Route::post('/admin/employers/send-welcome/{id}', [WellifyUserController::class, 'sendWelcomeEmail'])->name('admin.employers.sendWelcome');
    Route::get('/wellify_users/{id}', [WellifyUserController::class, 'show'])->name('wellify_users.show');
    Route::get('/wellify_users/{id}/edit', [WellifyUserController::class, 'edit']);
    Route::put('/wellify_users/{id}', [WellifyUserController::class, 'update']);
    Route::delete('/wellify_users/{id}', [WellifyUserController::class, 'destroy']);
    Route::get('/wellify_users/{id}/profile-picture-url', [WellifyUserController::class, 'getProfilePictureUrl']);
    Route::post('/wellify_users/bulk-restore', [WellifyUserController::class, 'bulkRestore'])->name('wellify_users.bulk_restore');
    /**Manage wellify_employees*/
    Route::get('/wellify_employees', [WellifyEmployeeController::class, 'index'])->name('wellify_employees.index');
    Route::post('/wellify_employees', [WellifyEmployeeController::class, 'store'])->name('wellify_employees.store');
    Route::get('/wellify_employees/data', [WellifyEmployeeController::class, 'data'])->name('wellify_employees.data');
    Route::post('/wellify_employees/pay-per-user', [EmployerSubscriptionController::class, 'payPerUser'])->name('stripe.per_user.initiate');
    Route::get('/stripe/per-user-success', [EmployerSubscriptionController::class, 'handlePerUserPaymentSuccess'])->name('stripe.per_user.success');
    // Route::post('/launch-user', [EmployerSubscriptionController::class, 'launchUser'])->name('employer.launch_user');
    Route::post('/employer/bulk-launch', [WellifyEmployeeController::class, 'bulkLaunch'])->name('employer.bulk_launch_users');
    // Route::post('/employer/launch-user', [WellifyEmployeeController::class, 'launchUser1'])->name('employer.launch_user1');
    // Route::post('/check-launch-quota', [WellifyEmployeeController::class, 'checkLaunchQuota'])->name('employer.check_launch_quota');

    // Route::post('/employer/request-extra-slots', [WellifyEmployeeController::class, 'requestExtraSlots'])->name('employer.request_extra_slots');
    // For fetching all user IDs for launch
    // Route::get('/employer/get-all-user-ids', [WellifyEmployeeController::class, 'getAllUserIds'])->name('employer.get_all_user_ids');
    



Route::post('/employer/request-extra-slots', [EmployerSubscriptionController::class, 'requestExtraSlots'])->name('employer.request.extra.slots');
Route::get('/employer/extra-slots/success', [EmployerSubscriptionController::class, 'handleExtraSlotsPaymentSuccess'])->name('employer.extra_slots.success');

Route::post('/employer/check-launch-quota', [WellifyEmployeeController::class, 'checkLaunchQuota'])->name('employer.check_launch_quota');
Route::post('/employer/bulk-launch', [WellifyEmployeeController::class, 'bulkLaunch'])->name('employer.bulk_launch_users');
Route::post('/employer/launch-user', [WellifyEmployeeController::class, 'launchUser1'])
        ->name('employer.launch_user1');

Route::get('/test-extra-slots', function () {
    return view('test-extra-slots');
});



    /**Manage Employee*/
    Route::get('/staffs', [StaffController::class, 'index'])->name('staffs.index');
    Route::get('/staffs/data', [StaffController::class, 'getAllStaffs'])->name('staffs.getStaffs');
    Route::get('/staffs/view/{id}', [StaffController::class, 'viewStaff'])->name('staffs.view');
    Route::post('/staffs/update', [StaffController::class, 'updateStaff'])->name('staffs.update');
    Route::post('/staffs', [StaffController::class, 'store'])->name('staffs.store');
    Route::get('/staffs/{id}/edit', [StaffController::class, 'edit'])->name('staffs.edit');
    Route::put('/staffs/{id}', [StaffController::class, 'update'])->name('staffs.update');
    Route::delete('/staffs/{id}', [StaffController::class, 'destroy'])->name('staffs.destroy');
    Route::get('/staffs/Inactiveemployees', [StaffController::class, 'getDeletedStaffs'])->name('staffs.getDeletedStaffs');
    Route::post('/staffs/{id}/restore', [StaffController::class, 'restore'])->name('staffs.restore');
    Route::post('/staffs/import', [StaffController::class, 'import'])->name('staffs.import');
    Route::get('/download/staff-excel', [StaffController::class, 'downloadExcel'])->name('download.staff.excel');
    Route::post('/send-bulk-welcome-emails', [StaffController::class, 'sendBulkWelcomeEmails']);

Route::get('/get-welcome-email-template', [StaffController::class, 'getWelcomeEmailTemplate']);
    Route::post('/staff-toggle-status-endpoint', [StaffController::class, 'toggleStatus'])->name('user.toggleStatus');

    Route::post('/send-bulk-welcome-employee-emails', [WellifyEmployeeController::class, 'sendBulkWelcomeEmployeeEmails']);
    Route::get('/get-welcome-email-employee-template', [WellifyEmployeeController::class, 'getWelcomeEmployeeTemplate']);
    Route::get('/wellify_app_users/{id}', [WellifyEmployeeController::class, 'show'])->name('wellify_app_users.show');

    Route::get('/wellify_app_users/{id}/edit', [WellifyEmployeeController::class, 'edit']);
    Route::get('/wellify_app_users/{id}/profile-picture-url', [WellifyEmployeeController::class, 'getProfilePictureUrl']);
    Route::put('/wellify_app_users/{id}', [WellifyEmployeeController::class, 'update']);
    Route::delete('/wellify_app_users/{id}', [WellifyEmployeeController::class, 'destroy']);
    Route::get('password/reset/{token}', [WellifyEmployeeController::class, 'showResetForm'])->name('password.reset');
    Route::post('password/reset', [WellifyEmployeeController::class, 'reset'])->name('password.update');

    Route::post('/wellify_app_users/import', [WellifyEmployeeController::class, 'import'])->name('wellify_employees.import');
    Route::get('/wellify_app_users/deleted/data', [WellifyEmployeeController::class, 'deletedData'])->name('wellify_app_users.deleted.data');
    Route::post('/wellify_app_users/{id}/restore', [WellifyEmployeeController::class, 'restore'])->name('wellify_app_users.restore');
    Route::post('/wellify_app_users/bulk-restore', [WellifyEmployeeController::class, 'bulkRestore'])->name('wellify_app_users.bulk_restore');
    Route::get('/wellify_app_users/skipped/data', [WellifyEmployeeController::class, 'skippedData'])->name('wellify_app_users.skipped.data');
    Route::post('/wellify_app_users/export', [WellifyEmployeeController::class, 'exportTempUser'])->name('wellify_app_users.export');
    Route::get('/download/wellify-app-users-excel', [WellifyEmployeeController::class, 'downloadExcel'])->name('download.wellify_app_users.excel');
    Route::post('/employee-toggle-status-endpoint', [WellifyEmployeeController::class, 'toggleStatus'])->name('user.toggleStatus');
    Route::get('/departments', [DepartmentController::class, 'index'])->name('departments.index');
    Route::post('/departments', [DepartmentController::class, 'store'])->name('departments.store');
    Route::put('/departments/{id}', [DepartmentController::class, 'update'])->name('departments.update');
    Route::delete('/departments/{id}', [DepartmentController::class, 'destroy'])->name('departments.destroy');
    Route::get('/departments/data', [DepartmentController::class, 'getDepartments'])->name('departments.getDepartments');
    Route::get('/departments/Unassigneddata', [DepartmentController::class, 'getUnassignedDepartments'])->name('departments.getUnassignedDepartments');
    Route::post('/departments/{id}/restore', [DepartmentController::class, 'restore'])->name('departments.restore');
});

/*Classes and Moods Routes* */
Route::middleware(['auth:web', 'role:Super Admin'])->group(function () {
    /*Manage Classes Routes*/
    // Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/wellify-classes', [WellifyClassController::class, 'index'])->name('wellify_classes.index');
    Route::get('/wellify-classes/data', [WellifyClassController::class, 'getData'])->name('wellify_classes.classes.data');
    Route::post('/wellify-classes', [WellifyClassController::class, 'store'])->name('store');
    Route::get('/wellify-classes/{id}', [WellifyClassController::class, 'show'])->name('wellify-classes.show');
    Route::post('/wellify-classes', [WellifyClassController::class, 'store'])->name('wellify-classes.store');
    Route::post('/wellify-classes/update-status/{id}', [WellifyClassController::class, 'updateStatus']);
    Route::post('/wellify-classes/update-images-status', [WellifyClassController::class, 'updateManualStatus'])->name('wellify_classes.update_images_status');
    Route::post('/wellify-classes/media-upload', [WellifyClassController::class, 'uploadMedia'])->name('wellify_classes.media.upload');
    Route::get('/wellify-classes/{id}/edit', [WellifyClassController::class, 'edit']);
    Route::put('/wellify-classes/{id}', [WellifyClassController::class, 'update']);
    Route::delete('/wellify-classes/{id}', [WellifyClassController::class, 'destroy']);
    Route::get('/wellify_classes/deleted', [WellifyClassController::class, 'getDeletedClasses'])->name('wellify_classes.deleted');
    Route::post('/wellify-classes/{id}/restore', [WellifyClassController::class, 'restore']);
    Route::post('/wellify-classes/bulk-restore', [WellifyClassController::class, 'bulkRestore'])->name('wellify-classes.bulk-restore');

    /*Manage ClassMedia Routes*/
    Route::get('/wellify/classes/{id}/media', [WellifyClasssMediaController::class, 'index'])->name('wellify_classes.media');
    Route::get('/wellify/class/{id}/media-data', [WellifyClasssMediaController::class, 'getMediaData'])->name('wellify.class.media.data');
    Route::post('/wellify-classes/media/upload', [WellifyClasssMediaController::class, 'store'])->name('class-media.upload');
    Route::get('/class-media/{id}', [WellifyClasssMediaController::class, 'edit'])->name('class-media.edit');
    Route::post('/class-media/update', [WellifyClasssMediaController::class, 'update'])->name('class-media.update');
    Route::get('/class-media/{id}', [WellifyClasssMediaController::class, 'show']);
    Route::post('/class-media/update', [WellifyClasssMediaController::class, 'update'])->name('class-media.update');
    Route::delete('/class-media/delete/{id}', [WellifyClasssMediaController::class, 'destroy'])->name('class-media.destroy');
    Route::post('/class-media/update-sequence', [WellifyClasssMediaController::class, 'updateMediaSequence'])->name('class-media.update-sequence');
    Route::post('/class-media/swap-sequence', [WellifyClasssMediaController::class, 'swapMediaSequence']);


    /*Manage Moods Routes*/
    Route::prefix('wellify_moods')->group(function () {
        Route::get('/', [WellifyMoodController::class, 'index'])->name('wellify_moods.index');
        Route::get('/data', [WellifyMoodController::class, 'getData'])->name('wellify_moods.data');
        Route::post('/toggle-status/{id}', [WellifyMoodController::class, 'toggleStatus'])->name('moods.toggleStatus');
        Route::get('/{id}/edit', [WellifyMoodController::class, 'edit'])->name('wellify_moods.edit');
        Route::post('/{id}', [WellifyMoodController::class, 'update'])->name('wellify_moods.update');
    });

    /*Manage quizzes Routes*/
    Route::get('/classes/{classId}/quizzes/create', [WellifyQuizController::class, 'create']);
    Route::post('/classes/{classId}/quizzes', [WellifyQuizController::class, 'store']);
    Route::get('/classes/{class}/quizzes', [WellifyQuizController::class, 'showQuizzes'])->name('classes.quizzes.show');
    Route::post('/wellify/quizzes/{id}/update', [WellifyQuizController::class, 'update'])->name('quizzes.update');
    Route::post('/wellify/quizzes/{id}/upload-image', [WellifyQuizController::class, 'uploadImage'])->name('quizzes.upload-image');
    Route::delete('/wellify/quizzes/{id}', [WellifyQuizController::class, 'destroy'])->name('quizzes.destroy');

     /*Manage Activities Routes*/
    Route::get('/wellify-activities/deleted', [WellifyActivityController::class, 'getDeletedActivities'])->name('wellify-activities.deleted');
    Route::post('/wellify-activities/{activity}/restore', [WellifyActivityController::class, 'restore'])->name('wellify-activities.restore');
    Route::post('/wellify-activities/bulk-restore', [WellifyActivityController::class, 'bulkRestore'])->name('wellify-activities.bulk-restore');
    Route::delete('/wellify-activities/{activity}/force-delete', [WellifyActivityController::class, 'forceDelete'])->name('wellify-activities.force-delete');
    Route::get('/wellify-activities', [WellifyActivityController::class, 'index'])->name('wellify_activities.index');
    Route::get('/wellify-activities/data', [WellifyActivityController::class, 'getData'])->name('wellify_activities.activities.data');
    Route::post('/wellify-activities/update-media-status', [WellifyActivityController::class, 'updateMediaStatus']);
    Route::post('/wellify-activities/update-status', [WellifyActivityController::class, 'updateStatus']);
    Route::post('/wellify-activities', [WellifyActivityController::class, 'store'])->name('wellify-activities.store');
    Route::get('/wellify-activities/{activity_id}', [WellifyActivityController::class, 'show'])->name('wellify-activities.show');
    Route::put('/wellify-activities/{activity_id}', [WellifyActivityController::class, 'update'])->name('wellify-activities.update');
    Route::post('/wellify-activities/media-upload', [WellifyActivityMediaController::class, 'uploadMedia'])->name('wellify-activities.media.upload');
    Route::delete('/wellify-activities/{activity}', [WellifyActivityController::class, 'destroy'])->name('wellify-activities.destroy');

    /*Manage ActivityMedia Routes*/
    Route::get('/wellify/activities/{activity_id}/media', [WellifyActivityMediaController::class, 'index'])->name('wellify_activities.media');
    Route::get('/wellify/activities/{activity_id}/media-data', [WellifyActivityMediaController::class, 'getMediaData'])->name('wellify.activity.media.data');
    Route::post('/wellify-activities/media/upload', [WellifyActivityMediaController::class, 'store'])->name('activity-media.upload');
    Route::get('/activity-media/{activity_id}', [WellifyActivityMediaController::class, 'edit'])->name('activity-media.edit');
    Route::post('/activity-media/update', [WellifyActivityMediaController::class, 'update'])->name('activity-media.update');
    Route::get('/activity-media/{activity_id}', [WellifyActivityMediaController::class, 'show']);
    Route::delete('/activity-media/delete/{id}', [WellifyActivityMediaController::class, 'destroy'])->name('activity-media.destroy');
    Route::post('/wellify/activities/media-upload', [WellifyActivityMediaController::class, 'store'])->name('wellify-activities.media.upload');
    // Route::post('/activity-media/update-sequence', [WellifyActivityMediaController::class, 'updateMediaSequence'])->name('activityMedia.updateSequence');

    /*Manage Seeds Routes*/
    Route::get('wellify-seeds', [WellifySeedController::class, 'index'])->name('wellify-seeds.index');
    Route::post('wellify-seeds/toggle-status/{id}', [WellifySeedController::class, 'toggleStatus'])->name('wellify-seeds.toggle-status');
    Route::post('wellify-seeds', [WellifySeedController::class, 'store'])->name('wellify-seeds.store');
    Route::get('/wellify-seeds/{id}/edit', [WellifySeedController::class, 'edit']);
    Route::put('/wellify-seeds/{id}', [WellifySeedController::class, 'update']);
    Route::delete('wellify-seeds/{id}', [WellifySeedController::class, 'destroy'])->name('wellify-seeds.destroy');

     /*Manage Activities Routes*/
    Route::get('/wellify-activities/deleted', [WellifyActivityController::class, 'getDeletedActivities'])->name('wellify-activities.deleted');
    Route::post('/wellify-activities/{activity}/restore', [WellifyActivityController::class, 'restore'])->name('wellify-activities.restore');
    Route::post('/wellify-activities/bulk-restore', [WellifyActivityController::class, 'bulkRestore'])->name('wellify-activities.bulk-restore');
    Route::delete('/wellify-activities/{activity}/force-delete', [WellifyActivityController::class, 'forceDelete'])->name('wellify-activities.force-delete');
    Route::get('/wellify-activities', [WellifyActivityController::class, 'index'])->name('wellify_activities.index');
    Route::get('/wellify-activities/data', [WellifyActivityController::class, 'getData'])->name('wellify_activities.activities.data');
    Route::post('/wellify-activities/update-media-status', [WellifyActivityController::class, 'updateMediaStatus']);
    Route::post('/wellify-activities/update-status', [WellifyActivityController::class, 'updateStatus']);
    Route::post('/wellify-activities', [WellifyActivityController::class, 'store'])->name('wellify-activities.store');
    Route::get('/wellify-activities/{activity_id}', [WellifyActivityController::class, 'show'])->name('wellify-activities.show');
    Route::put('/wellify-activities/{activity_id}', [WellifyActivityController::class, 'update'])->name('wellify-activities.update');
    Route::post('/wellify-activities/media-upload', [WellifyActivityMediaController::class, 'uploadMedia'])->name('wellify-activities.media.upload');
    Route::delete('/wellify-activities/{activity}', [WellifyActivityController::class, 'destroy'])->name('wellify-activities.destroy');

    /*Manage ActivityMedia Routes*/
    Route::get('/wellify/activities/{activity_id}/media', [WellifyActivityMediaController::class, 'index'])->name('wellify_activities.media');
    Route::get('/wellify/activities/{activity_id}/media-data', [WellifyActivityMediaController::class, 'getMediaData'])->name('wellify.activity.media.data');
    Route::post('/wellify-activities/media/upload', [WellifyActivityMediaController::class, 'store'])->name('activity-media.upload');
    Route::get('/activity-media/{activity_id}', [WellifyActivityMediaController::class, 'edit'])->name('activity-media.edit');
    Route::post('/activity-media/update', [WellifyActivityMediaController::class, 'update'])->name('activity-media.update');
    Route::get('/activity-media/{activity_id}', [WellifyActivityMediaController::class, 'show']);
    Route::delete('/activity-media/delete/{id}', [WellifyActivityMediaController::class, 'destroy'])->name('activity-media.destroy');
    Route::post('/wellify/activities/media-upload', [WellifyActivityMediaController::class, 'store'])->name('wellify-activities.media.upload');
    // Route::post('/activity-media/update-sequence', [WellifyActivityMediaController::class, 'updateMediaSequence'])->name('activityMedia.updateSequence');

    /*Manage Seeds Routes*/
    Route::get('wellify-seeds', [WellifySeedController::class, 'index'])->name('wellify-seeds.index');
    Route::post('wellify-seeds/toggle-status/{id}', [WellifySeedController::class, 'toggleStatus'])->name('wellify-seeds.toggle-status');
    Route::post('wellify-seeds', [WellifySeedController::class, 'store'])->name('wellify-seeds.store');
    Route::get('/wellify-seeds/{id}/edit', [WellifySeedController::class, 'edit']);
    Route::put('/wellify-seeds/{id}', [WellifySeedController::class, 'update']);
    Route::delete('wellify-seeds/{id}', [WellifySeedController::class, 'destroy'])->name('wellify-seeds.destroy');

    /*Manage Activities Routes*/
    Route::get('/wellify-activities/deleted', [WellifyActivityController::class, 'getDeletedActivities'])->name('wellify-activities.deleted');
    Route::post('/wellify-activities/{activity}/restore', [WellifyActivityController::class, 'restore'])->name('wellify-activities.restore');
    Route::post('/wellify-activities/bulk-restore', [WellifyActivityController::class, 'bulkRestore'])->name('wellify-activities.bulk-restore');
    Route::delete('/wellify-activities/{activity}/force-delete', [WellifyActivityController::class, 'forceDelete'])->name('wellify-activities.force-delete');
    Route::get('/wellify-activities', [WellifyActivityController::class, 'index'])->name('wellify_activities.index');
    Route::get('/wellify-activities/data', [WellifyActivityController::class, 'getData'])->name('wellify_activities.activities.data');
    Route::post('/wellify-activities/update-media-status', [WellifyActivityController::class, 'updateMediaStatus']);
    Route::post('/wellify-activities/update-status', [WellifyActivityController::class, 'updateStatus']);
    Route::post('/wellify-activities', [WellifyActivityController::class, 'store'])->name('wellify-activities.store');
    Route::get('/wellify-activities/{activity_id}', [WellifyActivityController::class, 'show'])->name('wellify-activities.show');
    Route::put('/wellify-activities/{activity_id}', [WellifyActivityController::class, 'update'])->name('wellify-activities.update');
    Route::post('/wellify-activities/media-upload', [WellifyActivityMediaController::class, 'uploadMedia'])->name('wellify-activities.media.upload');
    Route::delete('/wellify-activities/{activity}', [WellifyActivityController::class, 'destroy'])->name('wellify-activities.destroy');

    /*Manage ActivityMedia Routes*/
    Route::get('/wellify/activities/{activity_id}/media', [WellifyActivityMediaController::class, 'index'])->name('wellify_activities.media');
    Route::get('/wellify/activities/{activity_id}/media-data', [WellifyActivityMediaController::class, 'getMediaData'])->name('wellify.activity.media.data');
    Route::post('/wellify-activities/media/upload', [WellifyActivityMediaController::class, 'store'])->name('activity-media.upload');
    Route::get('/activity-media/{activity_id}', [WellifyActivityMediaController::class, 'edit'])->name('activity-media.edit');
    Route::post('/activity-media/update', [WellifyActivityMediaController::class, 'update'])->name('activity-media.update');
    Route::get('/activity-media/{activity_id}', [WellifyActivityMediaController::class, 'show']);
    Route::delete('/activity-media/delete/{id}', [WellifyActivityMediaController::class, 'destroy'])->name('activity-media.destroy');
    Route::post('/wellify/activities/media-upload', [WellifyActivityMediaController::class, 'store'])->name('wellify-activities.media.upload');
    // Route::post('/activity-media/update-sequence', [WellifyActivityMediaController::class, 'updateMediaSequence'])->name('activityMedia.updateSequence');

    /*Manage Seeds Routes*/
    Route::get('wellify-seeds', [WellifySeedController::class, 'index'])->name('wellify-seeds.index');
    Route::post('wellify-seeds/toggle-status/{id}', [WellifySeedController::class, 'toggleStatus'])->name('wellify-seeds.toggle-status');
    Route::post('wellify-seeds', [WellifySeedController::class, 'store'])->name('wellify-seeds.store');
    Route::get('/wellify-seeds/{id}/edit', [WellifySeedController::class, 'edit']);
    Route::put('/wellify-seeds/{id}', [WellifySeedController::class, 'update']);
    Route::delete('wellify-seeds/{id}', [WellifySeedController::class, 'destroy'])->name('wellify-seeds.destroy');

    Route::get('/wellify-seeds/{seed_id}/growth-stages', [WellifySeedController::class, 'growthStages'])->name('wellify_seeds.growthStages');
    Route::get('/wellify-seeds/{id}/image-url', [WellifySeedController::class, 'getSeedImageUrl']);
    Route::get('/wellify-seeds/{seed_id}/growthStages', [WellifySeedController::class, 'showGrowthStages'])->name('wellify_seeds.growthStages');
    Route::get('/wellify-seeds/{seed_id}/growthStages/data', [WellifySeedController::class, 'getGrowthStagesData'])->name('wellify_seeds.growthStages.data');
    Route::post('/growth-stage-media', [WellifySeedController::class, 'addNewSeedsGrowthStages'])->name('growth-stage-media.store');

    Route::get('admin/show-growth-stage-media/{id}', [WellifySeedController::class, 'showGrowthStageMedia']);
    Route::post('/admin/update-growth-stage-media/{id}', [WellifySeedController::class, 'updateGrowthStageMedia']);


    Route::get('/api/growth-stages', function () {
        return \App\Models\WellifyGrowthStage::select('id', 'title')->get();
    });


    Route::post('plans/store', [WellifyStripePaymentController::class, 'plansStore'])->name('plans.store');
    Route::post('/plans/store-d2c', [WellifyStripePaymentController::class, 'plansStoreD2c'])->name('plans.stored2c');

    Route::get('/get-plans-b2b', [WellifyStripePaymentController::class, 'getB2BPlans'])->name('plans.b2b-data');
    Route::get('/get-plans-d2c', [WellifyStripePaymentController::class, 'getD2CPlans'])->name('plans.d2c-data');
    Route::post('/update-plans-d2c', [WellifyStripePaymentController::class, 'updateD2CPlans'])->name('plans.update-d2c-data');
    Route::get('/plans/{id}/edit', [WellifyStripePaymentController::class, 'edit'])->name('plans.edit');
    Route::put('/plans/{id}', [WellifyStripePaymentController::class, 'update'])->name('plans.update');
    Route::post('/plans/{id}/toggle-default', [WellifyStripePaymentController::class, 'toggleDefault'])->name('plans.toggle-default');

    Route::post('/plans/update-status', [WellifyStripePaymentController::class, 'updatePlanStatus'])->name('plans.updateStatus');
    Route::post('/plans/update-d2c-status', [WellifyStripePaymentController::class, 'updateD2cPlanStatus'])->name('plans.updateD2cStatus');

    Route::get('/plans/{id}', [WellifyStripePaymentController::class, 'getPlan'])->name('plans.getPlan');

/*Manage Activities Routes*/
    Route::get('/wellify-activities/deleted', [WellifyActivityController::class, 'getDeletedActivities'])->name('wellify-activities.deleted');
    Route::post('/wellify-activities/{activity}/restore', [WellifyActivityController::class, 'restore'])->name('wellify-activities.restore');
    Route::post('/wellify-activities/bulk-restore', [WellifyActivityController::class, 'bulkRestore'])->name('wellify-activities.bulk-restore');
    Route::delete('/wellify-activities/{activity}/force-delete', [WellifyActivityController::class, 'forceDelete'])->name('wellify-activities.force-delete');
    Route::get('/wellify-activities', [WellifyActivityController::class, 'index'])->name('wellify_activities.index');
    Route::get('/wellify-activities/data', [WellifyActivityController::class, 'getData'])->name('wellify_activities.activities.data');
    Route::post('/wellify-activities/update-media-status', [WellifyActivityController::class, 'updateMediaStatus']);
    Route::post('/wellify-activities/update-status', [WellifyActivityController::class, 'updateStatus']);
    Route::post('/wellify-activities', [WellifyActivityController::class, 'store'])->name('wellify-activities.store');
    Route::get('/wellify-activities/{activity_id}', [WellifyActivityController::class, 'show'])->name('wellify-activities.show');
    Route::put('/wellify-activities/{activity_id}', [WellifyActivityController::class, 'update'])->name('wellify-activities.update');
    Route::post('/wellify-activities/media-upload', [WellifyActivityMediaController::class, 'uploadMedia'])->name('wellify-activities.media.upload');
    Route::delete('/wellify-activities/{activity}', [WellifyActivityController::class, 'destroy'])->name('wellify-activities.destroy');

    /*Manage ActivityMedia Routes*/
    Route::get('/wellify/activities/{activity_id}/media', [WellifyActivityMediaController::class, 'index'])->name('wellify_activities.media');
    Route::get('/wellify/activities/{activity_id}/media-data', [WellifyActivityMediaController::class, 'getMediaData'])->name('wellify.activity.media.data');
    Route::post('/wellify-activities/media/upload', [WellifyActivityMediaController::class, 'store'])->name('activity-media.upload');
    Route::get('/activity-media/{activity_id}', [WellifyActivityMediaController::class, 'edit'])->name('activity-media.edit');
    Route::post('/activity-media/update', [WellifyActivityMediaController::class, 'update'])->name('activity-media.update');
    Route::get('/activity-media/{activity_id}', [WellifyActivityMediaController::class, 'show']);
    Route::delete('/activity-media/delete/{id}', [WellifyActivityMediaController::class, 'destroy'])->name('activity-media.destroy');
    Route::post('/wellify/activities/media-upload', [WellifyActivityMediaController::class, 'store'])->name('wellify-activities.media.upload');
    // Route::post('/activity-media/update-sequence', [WellifyActivityMediaController::class, 'updateMediaSequence'])->name('activityMedia.updateSequence');

    /*Manage Seeds Routes*/
    Route::get('wellify-seeds', [WellifySeedController::class, 'index'])->name('wellify-seeds.index');
    Route::post('wellify-seeds/toggle-status/{id}', [WellifySeedController::class, 'toggleStatus'])->name('wellify-seeds.toggle-status');
    Route::post('wellify-seeds', [WellifySeedController::class, 'store'])->name('wellify-seeds.store');
    Route::get('/wellify-seeds/{id}/edit', [WellifySeedController::class, 'edit']);
    Route::put('/wellify-seeds/{id}', [WellifySeedController::class, 'update']);
    Route::delete('wellify-seeds/{id}', [WellifySeedController::class, 'destroy'])->name('wellify-seeds.destroy');
});
    Route::get('/stripe/success', [StripeController::class, 'handleSuccess'])->name('stripe.success');
    Route::get('/stripe/cancel', fn() => redirect('/')->with('error', 'Payment cancelled'))->name('stripe.cancel');
    Route::view('/thank-you', 'thank-you')->name('thank.you');
    Route::post('/stripe/webhook', [WellifyStripeWebhookController::class, 'handle'])->name('stripe.webhook');

// Route::middleware(['auth', 'role:Employer'])->group(function () {
//     Route::post('/pay-per-user', [EmployerSubscriptionController::class, 'payPerUser'])->name('stripe.per_user.initiate');
// });
// Route::get('/stripe/success/per-user', function (Request $request) {
//     $employerId = $request->employer_id;
//     $count = $request->count;

//     $user = \App\Models\WellifyUser::findOrFail($employerId);

//     // Activate trial
//     $start = now();
//     $end = now()->addDays((int) $user->program_periods);

//     \App\Models\WellifySubscription::where('user_id', $user->id)
//         ->update([
//             'start_date' => $start,
//             'end_date' => $end,
//             'status' => 'active',
//         ]);

//     return redirect()->route('dashboard')->with('success', "$1/user payment successful. Trial started for {$user->program_periods} days.");
// })->name('stripe.per_user.success');